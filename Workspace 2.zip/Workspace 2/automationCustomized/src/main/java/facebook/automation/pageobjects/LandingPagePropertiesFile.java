package facebook.automation.pageobjects;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class LandingPagePropertiesFile 
{
	
	WebDriver driver;
	private Properties prop;
	    

	    public LandingPagePropertiesFile(WebDriver driver) throws IOException {
		this.driver = driver;
		// TODO Auto-generated constructor stub
	
			 prop = new Properties();
			
			try {
				FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"//locators.properties");
				prop.load(fis);
				System.out.println("Properties loaded successfully");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	    
	    public void goTo()
		{
			driver.get("https://www.facebook.com");
		}

		public WebElement getUsernameField(WebDriver driver) {
	        return driver.findElement(By.id(prop.getProperty("userEmail_id")));
	    }

	    public WebElement getPasswordField(WebDriver driver) {
	        return driver.findElement(By.id(prop.getProperty("password_id")));
	    }

	    public WebElement getLoginButton(WebDriver driver) {
	        return driver.findElement(By.name(prop.getProperty("login_name")));
	    }
	}
