package facebook.automation.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class CreatePost extends AbstractComponents
{
	AndroidDriver<MobileElement> driver;
	
	public CreatePost(AndroidDriver<MobileElement> driver)
	{
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className = "android.widget.ImageView")
	private WebElement facebookLogo;
	
	@FindBy(xpath = "//android.widget.FrameLayout//android.widget.EditText")
	private WebElement inputTextOnStatusField;
	
	@FindBy(xpath="//android.view.ViewGroup[@content-desc='POST']")
	private WebElement clickOnPostButton;
	
		
	public void inputTextOnStatusField(String text)
	{
		waitForElementVisibility(inputTextOnStatusField);
		inputTextOnStatusField.sendKeys(text);
	}
	
	public void clickOnPostButton()
	{
		clickOnPostButton.click();
	}
	
	
}
