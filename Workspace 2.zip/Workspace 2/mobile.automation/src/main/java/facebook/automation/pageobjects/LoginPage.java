package facebook.automation.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginPage extends AbstractComponents
{
AndroidDriver<MobileElement> driver;
String errorMessage;
	
	public LoginPage(AndroidDriver<MobileElement> driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className = "android.widget.EditText")
	private WebElement inputEmail;
	
	@FindBy(xpath="//android.view.View[@content-desc='Log in']")
	private WebElement loginButton;
	
	@FindBy(xpath="//android.view.ViewGroup[3]//android.widget.EditText")
	private WebElement inputPass;
	
	@FindBy(xpath = "//android.widget.ScrollView//android.widget.LinearLayout//android.widget.TextView")
	private WebElement invalidCredentialsError;
	
	@FindBy(xpath="//*[@class='android.widget.Button']")
	private WebElement invalidCredentialsOKButton;
	
	public void inputEmail(String email)
	{
		waitForElementVisibility(inputEmail);
		inputEmail.sendKeys(email);
	}
	
	public void inputPass(String pass)
	{
		waitForElementVisibility(inputPass);
		inputPass.sendKeys(pass);
	}
	
	public void clickOnLoginButton()
	{
		loginButton.click();
	}
	
	public void invalidCredentialsOKButton()
	{
		invalidCredentialsOKButton.click();
	}
	
	public void clearPassField()
	{
		waitForElementVisibility(inputPass);
		inputPass.clear();
	}
	
	public void clearEmailField()
	{
		waitForElementVisibility(inputEmail);
		inputEmail.clear();
	}
	
	public String invalidCredentialsError()
	{
		waitForElementVisibility(invalidCredentialsError);
		errorMessage =invalidCredentialsError.getText();
		return errorMessage;
	
	}
	
}
