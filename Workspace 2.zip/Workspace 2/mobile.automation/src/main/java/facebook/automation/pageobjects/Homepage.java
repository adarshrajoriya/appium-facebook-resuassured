package facebook.automation.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class Homepage extends AbstractComponents
{
	AndroidDriver<MobileElement> driver;
	
	public Homepage(AndroidDriver<MobileElement> driver)
	{
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className = "android.widget.ImageView")
	private WebElement facebookLogo;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc='Make a post on Facebook']")
	private WebElement writeSomething;
	
	@FindBy(xpath="//android.view.ViewGroup[@content-desc='Stories']")
	private WebElement storiesTextOnHomepage;
	
	@FindBy(xpath="//android.view.View[@content-desc='Menu, tab 5 of 5']")
	private WebElement menuButton;
	
	@FindBy(xpath="//android.view.ViewGroup[@content-desc='Log out']")
	private WebElement logoutButton;
	
	
	public boolean facebookLogo()
	{
		waitForElementVisibility(facebookLogo);
		return facebookLogo.isDisplayed();
		
	}
	
	public void writeSomething()
	{
		waitForElementVisibility(writeSomething);
		writeSomething.click();
	}
	
	public boolean storiesDropdown()
	{
		return writeSomething.isDisplayed();
	}
	
	public void clickOnMenuButton()
	{
		menuButton.click();
	}
	
	public void clickOnLogoutButton()
	{
		logoutButton.click();
	}
	
	
}
