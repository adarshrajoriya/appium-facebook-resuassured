package facebookautomation.tests;

import org.testng.annotations.Test;

import facebookautomation.testComponents.BaseTest;

public class LoginTestStandalone extends BaseTest
{
	@Test
	public void login()
	{
		driver.findElementByCssSelector(".android.widget.EditText").sendKeys("Test@123");
		driver.findElementByXPath("//android.view.View[@content-desc='Log in']").click();
	}
}
