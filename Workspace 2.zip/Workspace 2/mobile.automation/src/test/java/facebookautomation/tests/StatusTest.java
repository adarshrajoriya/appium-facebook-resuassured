package facebookautomation.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.CreatePost;
import facebook.automation.pageobjects.Homepage;
import facebookautomation.testComponents.BaseTest;

public class StatusTest extends BaseTest
{
	Homepage homePage;
	CreatePost createPost;
	
	@Test
	public void createStatus()
	{
		log.info("createStatus method started");
		homePage = new Homepage(driver);
		log.info("Homepage object has been created");
		log.info("Clicking on write something");
		homePage.writeSomething();
		createPost = new CreatePost(driver);
		log.info("Input text feild has been displayed and now giving input to status field");
		createPost.inputTextOnStatusField("Hey There");
		log.info("Clicking on Post button");
		createPost.clickOnPostButton();
		log.info("Validating stories dropdown on homepage to verify story success");
		Assert.assertTrue(homePage.storiesDropdown());
		log.info("createStatus test passed");
	}
}
