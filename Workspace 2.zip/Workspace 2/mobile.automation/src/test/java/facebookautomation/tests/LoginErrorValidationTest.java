package facebookautomation.tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.LoginPage;
import facebookautomation.testComponents.BaseTest;

public class LoginErrorValidationTest extends BaseTest
{
	LoginPage loginPage;
	
	@Test
	public void loginError()
	{
		loginPage = new LoginPage(driver);
		log.info("loginError method started..");
		log.info("Entering email");
		loginPage.inputEmail("Adarshtexas@gmail.com");
		log.info("Entering incorrect password");
		loginPage.inputPass("Test@321");
		log.info("Clicking on login button");
		loginPage.clickOnLoginButton();
		log.info("Compairing actual incorrect password message with expected message");
		
		Assert.assertEquals(loginPage.invalidCredentialsError(), "Invalid username or password");
		log.info("Error message validation success");
		log.info("Clicking on OK button");
		loginPage.invalidCredentialsOKButton();
		log.info("Clearing email field");
		loginPage.clearEmailField();
		log.info("Clearing password field");
		loginPage.clearPassField();
		log.info("loginError test completed..");
	}
}
