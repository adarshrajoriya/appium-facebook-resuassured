package facebookautomation.tests;

import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.Homepage;
import facebook.automation.pageobjects.LoginPage;
import facebookautomation.testComponents.BaseTest;

public class FacebookLoginTest extends BaseTest
{
	LoginPage LoginPage; 
	Homepage homepage;
	
	@Test(dataProvider="data")
	public void login(HashMap<String, String> credentials) throws InterruptedException
	{
		
		LoginPage = new LoginPage(driver);
		log.info("Entering email");
		LoginPage.inputEmail(credentials.get("email"));
		log.info("Entering password");
		LoginPage.inputPass(credentials.get("password"));
		log.info("Clicking on Login Button");
		LoginPage.clickOnLoginButton();
		log.info("Homepage object created");
		homepage = new Homepage(driver);
		log.info("Validating Facebook logo on homepage");
		Assert.assertTrue(homepage.facebookLogo());
		log.info("Facebook login test completed");
	}

	@DataProvider
	public Object[][] data()
	{
		HashMap<String, String> map = new HashMap<>();
		map.put("email", "adarshtexas@gmail.com");
		map.put("password", "Changeme@123");
		
		HashMap<String, String> map2 = new HashMap<>();
		map2.put("email", "adarshtexas1@gmail.com");
		map2.put("password", "Changeme@123");
		
		return new Object[][] {{map}, {map2}};
	
	}
}