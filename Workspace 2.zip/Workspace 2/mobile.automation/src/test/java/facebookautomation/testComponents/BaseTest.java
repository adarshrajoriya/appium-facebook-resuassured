package facebookautomation.testComponents;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.asserts.SoftAssert;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class BaseTest 
{
	protected static AndroidDriver<MobileElement> driver;

	public static final Logger log = LogManager.getLogger("Facebook MobileAutomation Project");
	  public AndroidDriver<MobileElement> initializeDriver() throws IOException 
	  { 
		 
		  
		  DesiredCapabilities caps = new DesiredCapabilities();
          caps.setCapability("platformName", "Android");
          caps.setCapability("deviceName", "Android");
          caps.setCapability("appPackage", "com.facebook.katana"); // Facebook app package name
          caps.setCapability("appActivity", "com.facebook.katana.LoginActivity"); // Facebook login activity name
          //caps.setCapability("noReset", "true");
          caps.setCapability("autoGrantPermissions", "true");

          // Initialize the driver
          URL appiumServerURL = new URL("http://localhost:4723/wd/hub");
		 // WebDriverManager.chromedriver().setup();
		 driver = new AndroidDriver<MobileElement>(appiumServerURL, caps);
		 log.info("MobileDriver is up and running...");
	  return driver; 
	  }
	  
		
		 public String getScreenshot (String testCaseName, AndroidDriver<MobileElement> driver) throws
		 IOException { TakesScreenshot ts = (TakesScreenshot) driver; 
		 File source = ts.getScreenshotAs(OutputType.FILE); 
		 File file = new File(System.getProperty("user.dir") + "//reports//" + testCaseName + ".png");
		 FileUtils.copyFile(source, file); 
		 return System.getProperty("user.dir") + "//reports//" + testCaseName + ".png"; }
		
	
	 public void launchApplication() throws IOException
	 { 
	 driver = initializeDriver(); 
	 log.info("Driver initialized");
	   
	 }
	 
	 @BeforeSuite(alwaysRun = true)
	 public void setUp() throws IOException, InterruptedException
	 {
		 launchApplication();
	 }
	 	 
		/*
		 * @AfterMethod(alwaysRun = true) public void closeBrowser() throws
		 * InterruptedException { driver.close(); }
		 */
}
