package appium.pageObjects;


public class LoginPage {
}
