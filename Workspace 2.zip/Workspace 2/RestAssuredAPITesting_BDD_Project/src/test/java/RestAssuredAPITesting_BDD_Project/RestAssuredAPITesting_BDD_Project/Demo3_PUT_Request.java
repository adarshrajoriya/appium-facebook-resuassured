package RestAssuredAPITesting_BDD_Project.RestAssuredAPITesting_BDD_Project;

import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Demo3_PUT_Request 
{
	public static HashMap map=new HashMap();
	@BeforeTest
	public void getData() {
		map.put("name", RestUtils.getFirstName());
		map.put("salary", RestUtils.getSalary());
		map.put("age", RestUtils.getAge());
		int empId=21;
		
		RestAssured.baseURI="https://dummy.restapiexample.com/api/v1";
		RestAssured.basePath="/update/"+empId;		
	}
	
	@Test
	public void testPut() {
		
		//extracting the response in response variable using .extract().response()
		Response response=given().contentType("application/json")
		.body(map)
		.put().then()
		.statusCode(200).log().all().extract().response();
		
		//converting the json response into string and storing it in jsonresponse
		
		String jsonresponse=response.asString();
		
		//comparing the converted string response using assertion
		
		Assert.assertEquals(jsonresponse.contains("Successfully! Record has been updated."), true);
	}
}
