package RestAssuredAPITesting_BDD_Project.RestAssuredAPITesting_BDD_Project;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class Demo1_GET_Request 
{
  @Test
  public void getWeatherDetails() {
	  given().when().get("https://openweathermap.org/city/1269843")
	  .then().statusCode(200).statusLine("HTTP/1.1 200 OK");
	  /*
	  .assertThat().body("City", equalTo("Hyderabad, IN")).header("Content-Type","application/json");
	  */
  }
}
