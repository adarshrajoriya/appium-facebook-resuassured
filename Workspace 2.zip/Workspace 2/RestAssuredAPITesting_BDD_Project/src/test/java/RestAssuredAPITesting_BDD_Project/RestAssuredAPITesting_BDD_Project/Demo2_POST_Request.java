package RestAssuredAPITesting_BDD_Project.RestAssuredAPITesting_BDD_Project;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import io.restassured.RestAssured;

public class Demo2_POST_Request 
{
	public static HashMap map=new HashMap();
	
	@BeforeClass
	public void postData() {
		map.put("username",RestUtils.getUserName());
		map.put("firstName", RestUtils.getFirstName());
		map.put("lastName",RestUtils.getLastName());
		map.put("email",RestUtils.getEmail());
		map.put("password",RestUtils.getPassword());
		
		RestAssured.baseURI="https://petstore.swagger.io";
		RestAssured.basePath="/v2/user";
	}
	
	@Test
	public void testPost() {
		given().contentType("application/json").body(map)
		.when().post().then().statusCode(200).and().body("type", equalTo("unknown")).log().all();
	}
	@Test
	public void testPost1() {
		given().contentType("application/json").body(map)
		.when().post().then().statusCode(400).and().body("type", equalTo("unknown")).log().all();
	}
}
