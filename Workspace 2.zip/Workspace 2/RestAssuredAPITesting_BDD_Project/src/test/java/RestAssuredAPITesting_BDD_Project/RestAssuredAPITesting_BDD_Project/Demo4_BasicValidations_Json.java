package RestAssuredAPITesting_BDD_Project.RestAssuredAPITesting_BDD_Project;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class Demo4_BasicValidations_Json extends ExtentReporterNG
{
	ExtentReports et = ExtentReporterNG.getReportObject();
	@Test(priority=1)
	public void testStatusCode()
	{
		
		given()
		.when().get("http://jsonplaceholder.typicode.com/posts/5")
		.then().statusCode(200);
		
		
	}
	
	@Test(priority=2)
	public void testLogging()
	{
		given()
		.when().get("http://services.groupkt.com/country/get/iso2code/IN")
		.then().statusCode(200).log().all();
	}
	
	@Test(priority=3)
	public void testSingleContent()
	{
		given()
		.when().get("http://services.groupkt.com/country/get/iso2code/IN")
		.then().statusCode(200).body("RestResponse.result.name", equalTo("India"));
		
		//where RestResponse.result.name is JSON path of the result response body
	}
	
	@Test(priority=4)
	public void testMultipleContents()
	{
		given()
		.when().get("http://services.groupkt.com/country/get/iso2code/IN")
		.then()
		.statusCode(200)
		.body("RestResponse.result.name", hasItems("India", "Australia","United States Of America"));
	}
	
	@Test(priority=5)
	public void testParamsAndHeaders()
	{
		given()
			.param("userName", "Adarsh")
			.header("MyHeader","India")
		.when().get("http://services.groupkt.com/country/get/iso2code/IN")
		
		.then().statusCode(200);
	}
	@Test(priority=6)
	public void realRequest()
	{
		Response response=given()
			.header("client_id","bbd4ca2347fc48e7be7297e2eabc2dd5")
			.header("client_secret","09eAaf279EA64b02945235B4D52da4DB")
			
		
		.when().get("https://lab-sapi-v1-ftblu.us-w1.cloudhub.io/api/ping")
		
		.then().statusCode(200).log().all().extract().response();
		
		//String convertedResponse=response.asString();
		
		//Assert.assertEquals(convertedResponse.contains("Alive"),true);
	}
	

}
