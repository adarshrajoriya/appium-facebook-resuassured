package Ordermanagement_Portal_API;


import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;



import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import io.restassured.response.Response;
public class PortalAPISitOra 
{
	
	@Test(dataProvider = "getHeaders")
	public void DraftOrder(HashMap<String, Object> value) throws IOException
	{
		
		
		byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\draftOrder.json"));
		String bdy=new String(b);
		
	
		
		 Response res=given()
		.header("client_id","6b3d042b6b54495a8e8ac9aba60e340c")
		.header("client_secret","213dfeDca80E4E1B8b722E458a480372").header("Content-type", "application/json")
		 .body(bdy).when().post("https://ordermanagement-portal-api-v1-ftora.us-w1.cloudhub.io/api/orderentry/v1/draftorders")
		 .then().statusCode(400).body("errordescription", equalTo("Duplicate Order")).log().all().extract().response();
		
		 String jsonresponse=res.asString();
		 Assert.assertEquals(jsonresponse.contains("OR00"),true);
	}
   @Test
   public void orderRequest() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\orderRequest.xml"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/xml")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/orderentry/v1/orderrequests")
  			.then().statusCode(200).log().all().extract().response();
      
      		String xmlresponse=response.asString();
      		Assert.assertEquals(xmlresponse.contains("US-61E4ED01"), true);
   }
   @Test
   public void orderSpecimenRetrievals() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\orderSpecimenRetrieval.xml"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/xml")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/orderentry/v1/orderspecimenretrievals")
  			.then().statusCode(200).log().all().extract().response();
      
      		String xmlresponse=response.asString();
      		Assert.assertEquals(xmlresponse.contains("-"), true);
   }
   @Test
   public void consent() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\consent.xml"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/xml")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/orderentry/v1/consents")
  			.then().statusCode(200).log().all().extract().response();
      
      		String xmlresponse=response.asString();
      		Assert.assertEquals(xmlresponse.contains("-"), true);
   }
   @Test
   public void dataTagRequest() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\dataTagRequest.xml"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/xml")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/orderentry/v1/datatagrequests")
  			.then().statusCode(200).log().all().extract().response();
  
      		String xmlresponse=response.asString();
      		Assert.assertEquals(xmlresponse.contains("GPS - Patient Life Expectancy gte10 - No"), true);
   }
   @Test
   public void staticContentRequest() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\staticContentRequest.xml"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/xml")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/orderentry/v1/staticcontentrequests")
  			.then().statusCode(200).log().all().extract().response();
  
      		String xmlresponse=response.asString();
      		Assert.assertEquals(xmlresponse.contains("<StaticContentResponse>"), true);
   }
   @Test
   public void invoices() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\invoices.json"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/json")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/orderbilling/v1/invoices")
  			.then().statusCode(200).log().all().extract().response();
  
      		String jsonresponse=response.asString();
      		Assert.assertEquals(jsonresponse.contains("OL001739071"), true);
   }
   @Test
   public void document() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\documents.json"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/json")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/docmanagement/v1/documents")
  			.then().statusCode(200).log().all().extract().response();
  
      		String jsonresponse=response.asString();
      		Assert.assertEquals(jsonresponse.contains("Transfer in progress"), true);
   }
   @Test
   public void reports() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\reports.json"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/json")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/reportsdistribution/v1/reports")
  			.then().statusCode(200).log().all().extract().response();
  
      		String jsonresponse=response.asString();
      		Assert.assertEquals(jsonresponse.contains("%PDF-1.4"), true);
   }
   @Test
   public void patientAmplificationCurves() throws IOException {

      //read data from local JSON file then store in byte array
      byte[] b = Files.readAllBytes(Paths.get("C:\\Users\\arajoriya\\Documents\\payLoads\\patientAmplificationCurves.json"));

      //convert byte array to string
      String bdy = new String(b);

      
      Response response=given()
  			.header("client_id","36fa1d2d2a674df9b95222c11ce901e2")
  			.header("client_secret","7771f46545d04D64B6E0796fA9890BF7").header("Content-type", "application/json")
  			.body(bdy).when().post("https://ordermanagement-portal-api-v1-sitora.us-w1.cloudhub.io/api/reportsdistribution/v1/patientamplificationcurves")
  			.then().statusCode(200).log().all().extract().response();
  
      		String jsonresponse=response.asString();
      		Assert.assertEquals(jsonresponse.contains("Expressed"), true);
   }
   
   @DataProvider
   public Object[][] getHeaders()
   {

		HashMap<String, Object> client_id = new HashMap<String, Object>();
		client_id.put("client_id", "6b3d042b6b54495a8e8ac9aba60e340c");
		   
		HashMap<String, Object> client_secret = new HashMap<String, Object>();
		client_secret.put("client_secret", "213dfeDca80E4E1B8b722E458a480372");
	   
	   return new Object[][] {{client_id},{client_secret}};
   }
   
   
}