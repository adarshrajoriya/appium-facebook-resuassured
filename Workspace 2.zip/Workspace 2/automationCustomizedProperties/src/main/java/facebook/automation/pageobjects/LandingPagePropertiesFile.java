package facebook.automation.pageobjects;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;
import stepDefination.BaseTestProperties;

public class LandingPagePropertiesFile extends BaseTestProperties
{
	
	WebDriver driver;
	Properties Prop;
	    

	    public LandingPagePropertiesFile(WebDriver driver) throws IOException {
		this.driver = driver;
		// TODO Auto-generated constructor stub
	
		Prop = new Properties(); 
		  FileInputStream FIS = new	 FileInputStream(System.getProperty("user.dir")+"//GlobalData.properties"); 
		  Prop.load(FIS); 
		
	    }
	    
	    public void goTo()
		{
			driver.get("https://www.facebook.com");
		}

		public WebElement getUsernameField() {
			System.out.println("Getting username");
	        return driver.findElement(By.xpath(Prop.getProperty("userEmail_xpath")));
	    }

	    public WebElement getPasswordField() {
	    	System.out.println("Getting password");
	        return driver.findElement(By.id(Prop.getProperty("password_id")));
	    }

	    public WebElement getLoginButton() {
	        return driver.findElement(By.name(Prop.getProperty("login_name")));
	    }
	}
