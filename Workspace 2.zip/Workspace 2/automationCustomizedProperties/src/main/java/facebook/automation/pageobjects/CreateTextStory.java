package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class CreateTextStory extends AbstractComponents
{
	WebDriver driver;

	public CreateTextStory(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div/textarea")
	
	//span[text()='Start typing']
	private WebElement enterText;

	@FindBy(xpath = "//div[text()='simple']")
	private WebElement selectFontDropdown;

	@FindBy(xpath = "//div[@id='StoriesCreateSATPFontMenu']/div[1]")
	private WebElement simpleFontOption;

	@FindBy(xpath = "//div[@id='StoriesCreateSATPFontMenu']/div[2]")
	private WebElement cleanFontOption;

	@FindBy(xpath = "//div[@id='StoriesCreateSATPFontMenu']/div[3]")
	private WebElement casualFontOption;

	@FindBy(xpath = "//div[@id='StoriesCreateSATPFontMenu']/div[4]")
	private WebElement fancyFontOption;

	@FindBy(xpath = "//div[@id='StoriesCreateSATPFontMenu']/div[2]")
	private WebElement headlineFontOption;

	@FindBy(xpath = "//div[text()='Backgrounds']/following-sibling::div/div[6]")
	private WebElement blackColorButton;

	@FindBy(xpath = "//span[text()='Share to Story']")
	private WebElement shareToStoryButton;

	@FindBy(xpath = "//span[text()='Discard']")
	private WebElement discardButton;

	public void enterText(String text) {
		enterText.sendKeys(text);
	}

	public void selectFont() {
		selectFontDropdown.click();
	}

	public void simpleFont() {
		simpleFontOption.click();
	}

	public void cleanFont() {
		cleanFontOption.click();
	}

	public void casualFont() {
		casualFontOption.click();
	}

	public void fancyFont() {
		fancyFontOption.click();
	}

	public void headlineFont() {
		headlineFontOption.click();
	}

	public void selectBlackColor() {
		blackColorButton.click();
	}

	public void shareToStory() {
		shareToStoryButton.click();
	}

	public void discardStoryPost() {
		discardButton.click();
	}
}
