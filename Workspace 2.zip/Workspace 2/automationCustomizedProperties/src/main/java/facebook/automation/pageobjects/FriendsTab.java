package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class FriendsTab extends AbstractComponents
{	

	WebDriver driver;
	
	public FriendsTab(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//span[text()='All Friends']")
	private WebElement allFriendsButton;
	
	@FindBy(xpath="//span[text()='Adarsh Rajoria']")
	private WebElement selectFriend;
	
	public void clickAllFriendsButton()
	{
		allFriendsButton.click();
	}
	
	public void selectFriend()
	{
		waitForElementVisibility(selectFriend);
		selectFriend.click();
	}
}
