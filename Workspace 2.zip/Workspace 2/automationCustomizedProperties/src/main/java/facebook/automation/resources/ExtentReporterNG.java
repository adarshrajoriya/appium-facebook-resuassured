package facebook.automation.resources;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReporterNG 
{
	public static ExtentReports getReportObject()
	{
		String path = System.getProperty("user.dir")+"\\reports\\index.html";
		
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);	//HTML Report creation
		reporter.config().setReportName("Web Automation Test Result");
		reporter.config().setDocumentTitle("Extent Report");
		reporter.config().setTheme(Theme.DARK);
		
		
		ExtentReports ExtentReports = new ExtentReports();				//Used to create report
		ExtentReports.attachReporter(reporter);
		ExtentReports.setSystemInfo("Tester Name", "Adarsh Rajoria");
		return ExtentReports;
	}
}
