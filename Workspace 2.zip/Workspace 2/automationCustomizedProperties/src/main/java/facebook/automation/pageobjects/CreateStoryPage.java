package facebook.automation.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class CreateStoryPage extends AbstractComponents
{
	WebDriver driver;
	String filePath = "D:\\FileUploadScript.exe";
		
	public CreateStoryPage(WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[contains(@aria-label, 'Upload photo')]")
	private WebElement photoStory;
		
	@FindBy(xpath="//div[text()='Create a Text Story']")
	private WebElement textStory;
	
	
	public CreatePhotoStory photoStory() throws InterruptedException, IOException 
	{
		
		waitForElementVisibility(photoStory);
		photoStory.click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec(filePath);
		CreatePhotoStory CreatePhotoStory= new CreatePhotoStory(driver);
		return CreatePhotoStory;
	}
	
	public CreateTextStory textStory()
	{
		textStory.click();
		CreateTextStory CreateTextStory = new CreateTextStory(driver);
		return CreateTextStory;
	}

}
