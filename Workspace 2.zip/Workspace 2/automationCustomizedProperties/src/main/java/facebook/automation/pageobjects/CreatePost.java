package facebook.automation.pageobjects;

import java.io.IOException;

import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class CreatePost extends AbstractComponents
{

	WebDriver driver;
	String filePath = "D:\\FileUploadScript.exe";
	
	public CreatePost(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[contains(@role,'textbox')]/div")  
	private WebElement createStoryTextField;
	
	@FindBy(xpath="//span[text()='Add to your post']")     
	private WebElement addPhotosVideosTextButton;
	
	@FindBy(xpath="//div[contains(@aria-label,'Photo/video')]/div/div/div/div/div/img")
	private WebElement addPhotoVideoIconButton;
	
	@FindBy(xpath="//span[text()='Photo/video')]")
	private WebElement addPhotoVideoText;
	
	@FindBy(xpath="//span[text()='Add photos/videos']")
	private WebElement addPhoto;
	
	@FindBy(xpath="//div[contains(@aria-label,'Remove Post Attachment')]")
	private WebElement removeAttachmentButton;
	
	@FindBy(xpath="//span[text()='Post']")
	private WebElement post;
	
	@FindBy(xpath="//div[text()='Testing createPost on wall Test']")
	private WebElement postText;
	
	public void createStoryInputText(String text)
	{
		createStoryTextField.sendKeys(text);
	}
	
	public void addPhotosVideos() throws IOException, InterruptedException
	{
		
		try 
		{
			addPhotosVideosTextButton.click();
		}
		
		 catch (NoSuchElementException e) {
			waitForElementVisibility(addPhotoVideoIconButton);
			addPhotoVideoIconButton.click();
			}
		
				
	}
	
	public void addPhoto() throws InterruptedException
	{
		addPhoto.click();
		Thread.sleep(1000);
		
		try {
			Runtime.getRuntime().exec(filePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String validatePostAttachment()
	{
		return postText.getText();

	}

	public void clickOnPostButton() throws InterruptedException
	{
		Thread.sleep(2000);
		post.click();
	}
}
