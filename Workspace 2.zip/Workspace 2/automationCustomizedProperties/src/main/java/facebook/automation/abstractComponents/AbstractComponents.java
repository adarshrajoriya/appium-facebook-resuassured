package facebook.automation.abstractComponents;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AbstractComponents 
{
	
	WebDriver driver;
	Select select;
	protected Properties prop;
	
	public AbstractComponents(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div/div[2]/div/a")
	private WebElement homeButton;
	
	@FindBy(xpath="//ul/li[2]/span/div/a")
	private WebElement friendsButton;
	
	@FindBy(xpath="//*[@aria-label='Account controls and settings']/span/div")
	private WebElement accountIcon;
	
	@FindBy(xpath="//span[text()='Log Out']")
	private WebElement logout;
	
	public void goToHome()
	{
		homeButton.click();
	}
	
	public void goToFriends()
	{
		waitForElementVisibility(friendsButton);
		friendsButton.click();
	}
	
	public void goToSettingsFromHeader()
	{
		accountIcon.click();
	}
	
	public void logout()
	{
		waitForElementVisibility(logout);
		logout.click();
	}
	
	public Select select(WebElement ele)
	{
		Select select = new Select(ele);
		return select;	
	}
	
	public void waitForElementVisibility(WebElement element)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void waitForElementToBeClickable(WebElement element)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(element));

	}
	
	public void visibilityOfElementLocated(By element)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));

	}
	
	public void locatorsFetching() throws IOException
	{
     
		 prop = new Properties();
		
		try {
			FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"//locators.properties");
			prop.load(fis);
			System.out.println("Properties loaded successfully");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
