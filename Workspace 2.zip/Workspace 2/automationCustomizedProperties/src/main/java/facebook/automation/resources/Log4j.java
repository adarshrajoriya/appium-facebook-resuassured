package facebook.automation.resources;

public class Log4j {

}
