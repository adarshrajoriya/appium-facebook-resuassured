package facebook.automation.pageobjects;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import facebook.automation.abstractComponents.AbstractComponents;

public class HomePage extends AbstractComponents
{
	WebDriver driver;
	
	public HomePage(WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//span[text()='Create Story']")
	private WebElement createStoryButton;
	
	@FindBy(xpath="//a[contains(@aria-label,'Create story')]")
	private WebElement createStoryButtonForMultipleStory;
	
	@FindBy(xpath="//div[contains(@aria-label,'Create a post')]/div[1]")
	private WebElement createPost;
		
	public CreateStoryPage createStory()
	{

		try {
			createStoryButton.click();
		}
		catch (NoSuchElementException e)
		{
			createStoryButtonForMultipleStory.click();
		}
		
		CreateStoryPage CreateStoryPage = new CreateStoryPage(driver);
		return CreateStoryPage;
	}
	
	public CreatePost clickOnCreatePostTextField()
	{
		waitForElementVisibility(createPost);
		createPost.click();
		CreatePost createPost = new CreatePost(driver);
		return createPost;
	}
}
