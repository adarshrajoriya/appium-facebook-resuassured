package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;
import jdk.internal.org.jline.utils.Log;

public class LandingPage extends AbstractComponents
{
	WebDriver driver;
	
	public LandingPage(WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id="email")
	private WebElement userEmail;
	
	@FindBy(id="pass")
	private WebElement password;
	
	@FindBy(name="login")
	private WebElement login;
	
	@FindBy(xpath="//div[@id='loginform']/div/div[2]")
	private WebElement errorMessage;
	
	@FindBy (xpath="//a[text()='Create new account']")
	private WebElement signup;
	
	@FindBy (xpath="//h2[contains(text(), 'Facebook')]")
	private WebElement tagline;
	
	public void goTo()
	{
		driver.get("https://www.facebook.com");
	}
	
	public boolean validateLandedToWebsite()
	{
		tagline.isDisplayed();
		return true;
		
	}
	
	public void enterEmail(String email)
	{
		userEmail.sendKeys(email);
	}
	public void enterPassword(String pass)
	{
		password.sendKeys(pass);
	}
	public void clickOnLoginButton()
	{
		login.click();	
		
	}
	
	public void clearEmailField()
	{
		userEmail.click();
	}
	
	public void clearPasswordField()
	{
		password.clear();
	}
	public String errorMessage()
	{
		errorMessage.getText();
		return errorMessage.getText();
	}
	
	public SignUp SignUp()
	{
		signup.click();
		SignUp SignUp = new SignUp(driver);
		return SignUp;
		
	}
	
	
	
}
