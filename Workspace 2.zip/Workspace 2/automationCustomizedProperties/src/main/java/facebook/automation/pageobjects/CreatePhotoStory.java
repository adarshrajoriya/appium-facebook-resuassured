package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class CreatePhotoStory extends AbstractComponents
{
	WebDriver driver;
	
	public CreatePhotoStory(WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath="//div[contains(@aria-label, 'Upload photo')]")
	private WebElement photoStory;
	
	@FindBy(xpath="//span[text()='Add Text']")
	private WebElement addTextbutton;
	
	@FindBy(xpath="//div[contains(@aria-label,'Start typing')]")
	private WebElement enterText;
			
	@FindBy(xpath="//span[text()='Share to Story']")
	private WebElement shareToStoryButton;
	
	@FindBy(xpath="//span[text()='Discard']")
	private WebElement discardButton;
	
	
	public void photoStory()
	{
		String filePath = System.getProperty("user.dir")+"\\Files\\JuneOutingBill.jpg";
		photoStory.sendKeys(filePath);
		//photoStory.sendKeys("C:\\Users\\arajoriya\\Downloads\\puzzle.png");
		//photoStory.sendKeys("/Users/arajoriya/Downloads/Paytm.png");
	}
	
	public void addText()
	{
		waitForElementVisibility(addTextbutton);
		addTextbutton.click();
	}
	
	public void enterText(String text)
	{
		enterText.sendKeys(text);
	}
	public void shareToStory()
	{
		shareToStoryButton.click();
	}
	
	public void discardStoryPost()
	{
		discardButton.click();
	}
}
