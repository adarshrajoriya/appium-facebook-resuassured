package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class SignUp extends AbstractComponents
{
	WebDriver driver;

	public SignUp(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//input[@name='firstname']")
	private WebElement enterFirstName;
	
	@FindBy(xpath="//input[@name='lastname']")
	private WebElement enterLastName;
	
	@FindBy(xpath="//input[@name='reg_email__']")
	private WebElement enterEmail;
	
	@FindBy(xpath="//input[@name='reg_email_confirmation__']")
	private WebElement confirmEmail;
	
	@FindBy(xpath="//input[@id='password_step_input']")
	private WebElement enterPassword;
	
	@FindBy(id="day")
	private WebElement day;
	
	@FindBy(id="month")
	private WebElement month;
	
	@FindBy(id="year")
	private WebElement year;
	
	@FindBy(xpath="//span/label[text()='Custom']")
	private WebElement gender;
	
	@FindBy(xpath="//div/select[@aria-label='Select your pronoun']/option[3]")
	private WebElement pronoun;
	
	@FindBy(name="websubmit")
	private WebElement submitButton;
	
	@FindBy(id="reg_error_inner")
	private WebElement errorMessage;
	
	public void enterFirstName(String firstName)
	{
		enterFirstName.sendKeys(firstName);
	}
	
	public void enterLastName(String lastName)
	{
		enterLastName.sendKeys(lastName);
	}
	
	public void enterEmail(String email)
	{
		enterEmail.sendKeys(email);
	}
	
	public void confirmEmail(String reEnterEmail)
	{
		confirmEmail.sendKeys(reEnterEmail);
	}
	
	public void enterPassword(String password)
	{
		enterPassword.sendKeys(password);
	}
	
	public void day(String selectDay)
	{
		select(day).selectByValue(selectDay);
	}
	
	public void month(String selectMonth)
	{
		select(month).selectByValue(selectMonth);
	}
	
	public void year(String selectYear)
	{
		select(year).selectByValue(selectYear);
	}
	
	public void selectGender()
	{
		gender.click();
	}
	public void pronoun()
	{
		pronoun.click();
	}
	public void submitButton()
	{
		submitButton.click();
	}
	
	public String errorMessage()
	{
		waitForElementVisibility(errorMessage);
		return errorMessage.getText();
	}
}
