package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class Logout extends AbstractComponents
{
	WebDriver driver;
	public Logout(WebDriver driver)
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="//*[@aria-label='Your profile'][@role='img']")
	private WebElement settingsDropdown;
	
	@FindBy(xpath="//span[text()='Log out']")
	private WebElement logoutButton;
	
	public void openSettingsDropdown()
	{
		waitForElementVisibility(settingsDropdown);
		settingsDropdown.click();
	}
	
	public void clickOnLogoutButton()
	{
		logoutButton.click();
	}
	
}
