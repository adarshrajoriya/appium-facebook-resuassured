package facebookautomation.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import facebookautomation.testComponents.BaseTest;

public class SignUpStandAlone extends BaseTest {

	String expectedPronoun = "Wish him a happy birthday!";
	ExtentReports ExtentReports;
	
	@BeforeTest
	public void report()
	{
		String path = System.getProperty("user.dir")+"\\reports\\index.html";
		ExtentSparkReporter ExtentSparkReporter = new ExtentSparkReporter(path);
		ExtentSparkReporter.config().setReportName("Web Automation Test Result");
		ExtentSparkReporter.config().setDocumentTitle("Extent report");
		
		
		ExtentReports ExtentReports = new ExtentReports();
		ExtentReports.attachReporter(ExtentSparkReporter);
		ExtentReports.setSystemInfo("Tester Name", "Adarsh Rajoria");
		
	}

	@Test
	public void signUp() throws InterruptedException {
		
		ExtentTest test = ExtentReports.createTest("signUp");
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Test");
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Test");
		driver.findElement(By.xpath("//input[@name='reg_email__']")).sendKeys("Test1@gmail.com");
		driver.findElement(By.xpath("//input[@name='reg_email_confirmation__']")).sendKeys("Test1@gmail.com");
		driver.findElement(By.xpath("//input[@id='password_step_input']")).sendKeys("Test@123");
		//WebElement day = driver.findElement(By.id("day"));

		Select selectDay = new Select(driver.findElement(By.id("day")));
		selectDay.selectByIndex(20);

		WebElement month = driver.findElement(By.id("month"));

		Select selectMonth = new Select(month);
		selectMonth.selectByIndex(2);

		WebElement year = driver.findElement(By.id("year"));

		Select selectYear = new Select(year);
		selectYear.selectByValue("1995");

		driver.findElement(By.xpath("//span/label[text()='Custom']")).click();
		List<WebElement> pronoun = driver
				.findElements(By.xpath("//div/select[@aria-label='Select your pronoun']/option"));

		
		  for(int i=0;i<pronoun.size();i++) {
		  
		 String getPronoun = pronoun.get(i).getText();
		 
		 
		 if (getPronoun.contains(expectedPronoun))
		 {
			 WebElement he = driver.findElement(By.xpath("//div/select[@aria-label='Select your pronoun']/option[3]"));
			 he.click();
			 break;
		 }
		 
		
		 
		 WebElement pronoun1 = driver.findElement(By.xpath("//div/select[@aria-label='Select your pronoun']/option[2]"));
		 pronoun1.click();
		 
		 driver.findElement(By.name("websubmit")).click();
		 test.addScreenCaptureFromBase64String(getPronoun);
		 ExtentReports.flush();

	}
	}
}
