package facebookautomation.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import facebookautomation.testComponents.BaseTest;

public class LogoutStandAlone extends BaseTest {


	@Test
	public void logout() throws InterruptedException {
		
	
		driver.findElement(By.id("email")).sendKeys("ross.win08@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("Changeme@123");
		driver.findElement(By.name("login")).click();
		driver.findElement(By.xpath("//*[@aria-label='Account controls and settings']/span/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Log Out']")).click();
		Thread.sleep(2000);
	}
	}

