package facebookautomation.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.SignUp;
import facebookautomation.testComponents.BaseTest;

public class SignUpTest extends BaseTest
{
	String 	email = "Test123@test.com";
	String invalidEmail = "test@test.com";
	String signUpErrorMessageExpected = "This name contains certain characters that aren't allowed. Learn more about our name policies.";
	
	//private static final Logger log = LogManager.getLogger(SignUpTest.class);
	@Test
	public void signUp()
	{
		log.info("signUp method started..");
		SignUp SignUp = LandingPage.SignUp();
		//SignUp SignUp = new SignUp(driver);
		log.info("Entering first name");
		SignUp.enterFirstName("Selenium");
		log.info("Last name");
		SignUp.enterLastName("Automation");
		log.info("Email");
		SignUp.enterEmail(email);
		log.info("Confirm Email");
		SignUp.confirmEmail(email);
		log.info("Password");
		SignUp.enterPassword("Test@123");
		log.info("Selecting day");
		SignUp.day("21");
		log.info("Month");
		SignUp.month("3");
		log.info("Year");
		SignUp.year("1995");
		log.info("Gender");
		SignUp.selectGender();
		log.info("Pronoun");
		SignUp.pronoun();
		log.info("Clicking on signup button");
		SignUp.submitButton();
		log.info("signup method completed..");
	}
	
	@Test(groups= {"ErrorHandling"})
	public void signUpErrorValidationTest() throws InterruptedException
	{
		log.info("signUpErrorValidationTest method started...");
		SignUp SignUp = LandingPage.SignUp();
		//SignUp SignUp = new SignUp(driver);
		log.info("Entering first name");
		SignUp.enterFirstName("Test1");
		log.info("Last");
		SignUp.enterLastName("Test2");
		log.info("Invalid email");
		SignUp.enterEmail(invalidEmail);
		log.info("Confirm invalid email");
		SignUp.confirmEmail(invalidEmail);
		log.info("Password");
		SignUp.enterPassword("Test@123");
		log.info("Selecting day");
		SignUp.day("21");
		log.info("Month");
		SignUp.month("3");
		log.info("Year");
		SignUp.year("1995");
		log.info("Gender");
		SignUp.selectGender();
		log.info("Pronoun");
		SignUp.pronoun();
		log.info("Clicking on signup button");
		SignUp.submitButton();
		log.info("Storing error message in a string");
		String signUpErrorMessageActual = SignUp.errorMessage();
		log.info("Comparing actual vs expected message");
		//Assert.assertEquals(signUpErrorMessageActual, signUpErrorMessageExpected);
		Assert.assertTrue(signUpErrorMessageActual.equals(signUpErrorMessageExpected));
		log.info("signUpErrorValidationTest test passed");
	}
}
