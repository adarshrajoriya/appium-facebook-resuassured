package facebookautomation.tests;

import org.testng.annotations.Test;

import facebook.automation.pageobjects.FriendsTab;
import facebook.automation.pageobjects.HomePage;
import facebookautomation.testComponents.BaseTest;
import facebookautomation.testComponents.Retry;

public class FriendsListTest extends BaseTest

{
	HomePage homePage;
	FriendsTab FriendsTab;
	//private static final Logger log = LogManager.getLogger(FriendsListTest.class);
	
	@Test //(retryAnalyzer=Retry.class)
	public void seeAllFriends() throws InterruptedException
	{
		homePage = new HomePage(driver);
		log.info("Clicking on home button");
		homePage.goToHome();
		
		log.info("Clicking on Friends tab from header");
		homePage.goToFriends();
		log.info("Clicking on friends icon from header");
		FriendsTab = new FriendsTab(driver); //constructor initilization
		log.info("Clicking on all friends");
		FriendsTab.clickAllFriendsButton();
		log.info("Selecting friend from list");
		FriendsTab.selectFriend();
		log.info("seeAllFriends method completed..");
		
	}
}
