package facebookautomation.tests;

import org.testng.annotations.Test;

import facebook.automation.pageobjects.Logout;
import facebookautomation.testComponents.BaseTest;

public class FacebookLogoutTest extends BaseTest
{
	//private static final Logger log = LogManager.getLogger(FacebookLoginTest.class);

	@Test()
	public void logoutTest()
	{
		Logout Logout = new Logout(driver);
		log.info("LogoutTest method started...");
		Logout.openSettingsDropdown();
		log.info("Clicked on settings dropdown");
		Logout.clickOnLogoutButton();
		log.info("Clicked in logout button");
		log.info("LogoutTest method completed...");
	}

}
