package facebookautomation.tests;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.Logout;
import facebookautomation.testComponents.BaseTest;
import io.cucumber.java.jv.Lan;

public class FacebookLoginTest extends BaseTest
{
	//private static final Logger log = LogManager.getLogger(FacebookLoginTest.class);
	@Test(dataProvider="data")
	public void loginTest(String email, String password) throws InterruptedException
	{
		log.info("Starting loginTest method...");

		log.info("Entering userEmail");
		LandingPage.enterEmail(email);
		log.info("Entering userPassword");
		LandingPage.enterPassword(password);
		log.info("Clicking on login button");
		LandingPage.clickOnLoginButton();
		log.info("Logged in Successfully...");
		Thread.sleep(5000);
		
	
	}
	
	/*
	 * @Test() public void logoutTest() {
	 * 
	 * log.info("LogoutTest method started..."); Logout.openSettingsDropdown();
	 * log.info("Clicked on settings dropdown"); Logout.clickOnLogoutButton();
	 * log.info("Clicked in logout button");
	 * log.info("LogoutTest method completed..."); }
	 */
	
	@DataProvider
	public Object[][] data() {
		
		Object[][] data = null;
    try {
        FileInputStream file = new FileInputStream(new File("D:\\Test1.xls"));
        Workbook workbook = new HSSFWorkbook(file);
        Sheet sheet = workbook.getSheetAt(0); // Assuming data is in the first sheet
        
        int rowCount = sheet.getLastRowNum();
        int colCount = sheet.getRow(0).getLastCellNum();
        
        data = new Object[rowCount][colCount];

        // Assuming the data is in the format of "username" in column 0 and "password" in column 1
        for (int i = 1; i <= rowCount; i++) {
            Row row = sheet.getRow(i);
            
            for(int j=0; j< colCount; j++)
            {
            	data[i-1][j]= row.getCell(j).toString();
            }
            
        }

        workbook.close();
        file.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    
    return data;
}

}
