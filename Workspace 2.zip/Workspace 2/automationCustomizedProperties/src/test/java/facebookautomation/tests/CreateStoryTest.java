package facebookautomation.tests;

import java.io.IOException;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.CreatePhotoStory;
import facebook.automation.pageobjects.CreateStoryPage;
import facebook.automation.pageobjects.CreateTextStory;
import facebook.automation.pageobjects.HomePage;
import facebookautomation.testComponents.BaseTest;
import facebookautomation.testComponents.Retry;

public class CreateStoryTest extends BaseTest
{
	
	HomePage HomePage;
	CreatePhotoStory CreatePhotoStory;
	
	//private static final Logger logger = LogManager.getLogger(CreateStoryTest.class);
	@Test(priority=1)
	public void textStory()  //getting credentaials through data provider (hashmap)
	
	{
		HomePage= new HomePage(driver);
		log.info("Clicking on home button");
		HomePage.goToHome();
		log.info("Create Story page");
		CreateStoryPage CreateStoryPage =HomePage.createStory();
		log.info("Text Story page");
		CreateTextStory CreateTextStory = CreateStoryPage.textStory();
		log.info("Entering text for text story");
		CreateTextStory.enterText("My name is Test");
		log.info("Font selection");
		CreateTextStory.selectFont();
		log.info("Casual font selecting");
		CreateTextStory.casualFont();
		log.info("Selecting black color");
		CreateTextStory.selectBlackColor();
		log.info("Share story");
		CreateTextStory.shareToStory();
		log.info("Story shared on wall and Test method completed.");
		CreateTextStory.goToHome();
		log.info("On home page");
		//CreateTextStory.goToAccountFromHeader();
		//CreateTextStory.logout();
		
	}
	
	@Test //(retryAnalyzer = Retry.class, priority = 2)
	public void photoStory() throws InterruptedException, IOException
	{
		HomePage= new HomePage(driver);
		log.info("Homepage object created...");
		CreateStoryPage CreateStoryPage = HomePage.createStory();
		log.info("Clicked on createStory button");
		CreatePhotoStory = CreateStoryPage.photoStory();
		//Thread.sleep(3000); Runtime.getRuntime().exec("D:\\FileUpload.exe");
		log.info("Photo Uploaded successfully");
		CreatePhotoStory.addText();
		CreatePhotoStory.enterText("This is photoStory test");
		CreatePhotoStory.shareToStory();
		log.info("Test method completed...");
		//Thread.sleep(2000);
		//((JavascriptExecutor) driver). executeScript("window. focus();");
	}
	
}
