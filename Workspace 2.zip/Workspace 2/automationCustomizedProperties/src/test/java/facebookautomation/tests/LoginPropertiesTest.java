package facebookautomation.tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.LandingPagePropertiesFile;
import facebookautomation.testComponents.BaseTest;
import facebookautomation.testComponents.BaseTestProperties;

public class LoginPropertiesTest extends BaseTestProperties
{

	LandingPagePropertiesFile lp;
	String username = System.getProperty("username");
	String password = System.getProperty("password");
	@Test
	public void login() throws IOException
	{
		 lp = new LandingPagePropertiesFile(driver);
		 lp.goTo();
		lp.getUsernameField().sendKeys(username);
		lp.getPasswordField().sendKeys(password);
		lp.getLoginButton().click();
	}

}
