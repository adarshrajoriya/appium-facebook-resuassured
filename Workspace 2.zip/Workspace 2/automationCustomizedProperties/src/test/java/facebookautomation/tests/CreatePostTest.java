package facebookautomation.tests;



import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.HomePage;
import facebook.automation.pageobjects.CreatePost;
import facebookautomation.testComponents.BaseTest;

public class CreatePostTest extends BaseTest
{
	
	HomePage homePage;
	String expectedText = "Testing createPost on wall Test";
	
	@Test
	public void CreatePost() throws IOException, InterruptedException
	{
		log.info("CreatePost test started...");
		homePage = new HomePage(driver);
		log.info("HomePage object created");
		CreatePost CreatePost = homePage.clickOnCreatePostTextField();
		log.info("CreatePost object created and clicked on create post text field");
		CreatePost.createStoryInputText("Testing createPost on wall Test");
		log.info("Text input sent");
		CreatePost.addPhotosVideos();
		log.info("Clicked on add photo/video button");
		CreatePost.addPhoto();
		log.info("Photo added");
		CreatePost.clickOnPostButton();
		log.info("Clicked on Post button");
		Assert.assertEquals(CreatePost.validatePostAttachment(),expectedText,"Assertion failed due to unexpected text");
		log.info("Validation completed and CreatePost test case is passed...");
		
	}

}
