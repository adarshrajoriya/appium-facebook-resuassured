package facebookautomation.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import facebookautomation.testComponents.BaseTest;

public class FriendsStandAlone extends BaseTest
{
	@Test
	public void searchAllFriends() throws InterruptedException
	{
		
		LandingPage.enterEmail("wevijo1155@brandoza.com");
		LandingPage.enterPassword("Test@123");
		LandingPage.clickOnLoginButton();
		
		driver.findElement(By.xpath("//ul/li[2]/span/div/a")).click();
		driver.findElement(By.xpath("//span[text()='All Friends']")).click();
		driver.findElement(By.xpath("//h1[normalize-space()='All Friends']")).click();
		
	}
}
