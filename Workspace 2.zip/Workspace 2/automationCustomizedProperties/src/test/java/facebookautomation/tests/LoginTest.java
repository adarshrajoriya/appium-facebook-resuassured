package facebookautomation.tests;

import org.testng.annotations.Test;

import facebook.automation.pageobjects.HomePage;
import facebookautomation.testComponents.BaseTest;

public class LoginTest extends BaseTest
{
	@Test
	public void login()
	{
		log.info("Login method started..");
		log.info("Entering email");
		LandingPage.enterEmail("ross.win08@gmail.com");
		log.info("Entering password");
		LandingPage.enterPassword("Changeme@123");
		log.info("Clicking on login button");
		LandingPage.clickOnLoginButton();
		log.info("Logged in successfully and method passed...");
	}
}
