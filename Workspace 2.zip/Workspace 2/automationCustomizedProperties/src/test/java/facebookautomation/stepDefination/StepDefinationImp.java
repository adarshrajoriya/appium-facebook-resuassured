package facebookautomation.stepDefination;

import java.io.IOException;

import facebook.automation.pageobjects.CreateStoryPage;
import facebook.automation.pageobjects.CreateTextStory;
import facebook.automation.pageobjects.HomePage;
import facebookautomation.testComponents.BaseTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinationImp extends BaseTest {

	public HomePage HomePage;
	public CreateStoryPage CreateStoryPage;
	public CreateTextStory CreateTextStory;
	
	@Given("I landed on facebook homepage")
	public void i_landed_on_facebook_homepage() throws IOException, InterruptedException
	{
		setUp();
		HomePage= new HomePage(driver);
		log.info("Clicking on home button"); 
		HomePage.goToHome();
		HomePage.createStory();
	}
	
	@When("I navigate to create text story page")
	public void i_navigate_to_create_text_story_page() 
	{
		log.info("Create Story page");
		CreateStoryPage = new CreateStoryPage(driver);
		log.info("Text Story page");
		CreateTextStory = CreateStoryPage.textStory();
	}
	
	
	@And("enter text in text field with selected fonts and color")
	public void enter_text_in_text_field_with_selected_fonts_and_color()
	{
		log.info("Entering text for text story");
		CreateTextStory.enterText("My name is Test");
		log.info("Font selection");
		CreateTextStory.selectFont();
		log.info("Casual font selecting");
		CreateTextStory.casualFont();
		log.info("Selecting black color");
		CreateTextStory.selectBlackColor();
	}
	@And("click on share story button")
	public void click_on_share_story_button()
	{
		log.info("Share story");
		CreateTextStory.shareToStory();
	}
	@Then("I validate that text story is created")
	public void i_validate_that_text_story_is_created()
	{
		log.info("Test method completed...");
		driver.close();
	}
}
