package facebookautomation.testComponents;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import facebook.automation.pageobjects.LandingPage;
import facebook.automation.pageobjects.Logout;
import facebook.automation.pageobjects.SignUp;

public class BaseTest 
{
	public static WebDriver driver;
	public LandingPage LandingPage;
	public SignUp SignUpPage;
	public Logout Logout;

	public static final Logger log = LogManager.getLogger("Facebook Automation Project");
	  public WebDriver initializeDriver() throws IOException 
	  { 
		 
		  Properties Properties = new Properties(); 
		  FileInputStream FIS = new	 FileInputStream(System.getProperty("user.dir")+"//GlobalData.properties"); 
		  Properties.load(FIS); 
		  
		 String browserName = System.getProperty("browser") != null ? System.getProperty("browser") : Properties.getProperty("browser");
		  //Properties.getProperty("browser");
	  
	  if(browserName.contains("chrome")) {
	  
			 ChromeOptions chromeOptions = new ChromeOptions();
			 chromeOptions.addArguments("--disable-notifications");
			 chromeOptions.addArguments("download.default_directory", "C:\\Users\\arajoriya\\Desktop");
			 
			 if(browserName.contains("headless"))
			 {
				 chromeOptions.addArguments("headless");
			 }
			 
		 // WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver(chromeOptions);
		 log.info("ChromeDriver is up and running...");
		 driver.manage().window().setSize(new Dimension(1440,900));
		 driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
	  }  
	  else if(browserName.contains("firefox")) {
		  
		  FirefoxOptions firefoxOptions = new FirefoxOptions();
			 
			 if(browserName.contains("headless"))
			 {
				 firefoxOptions.addArguments("--headless");
			 }
			 
		 driver = new FirefoxDriver(firefoxOptions); 	  
	  } 
	  
	  
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	  driver.manage().window().maximize(); 
	  return driver; 
	  }
	  
	  public String getScreenshot (String testCaseName, WebDriver driver) throws IOException
	  {
		  TakesScreenshot ts = (TakesScreenshot) driver;
		  File source = ts.getScreenshotAs(OutputType.FILE);
		  File file = new File (System.getProperty("user.dir") + "//reports//" + testCaseName + ".png");
		  FileUtils.copyFile(source, file);
		  return System.getProperty("user.dir")	+ "//reports//" + testCaseName + ".png";
	  }
	
	 public void launchBrowser() throws IOException
	 { 
	 driver = initializeDriver(); 
	 log.info("Driver initialized");
	   
	 }

	 
	 public void loginApplication() throws InterruptedException
		{
		 LandingPage = new LandingPage(driver); 
		 log.info("Navigation to www.facebook.com");
		 LandingPage.goTo();
		 
		log.info("Entering userEmail");
		LandingPage.enterEmail("adarshtexas@gmail.com");
		log.info("Entering userPassword");
		LandingPage.enterPassword("Changeme@123");
		log.info("Clicking on login button");
		LandingPage.clickOnLoginButton();
		log.info("Logged in Successfully...");
		}
	 
	 	public void logoutApplication()
		{
		 	Logout = new Logout(driver);
			log.info("LogoutTest method started...");
			Logout.openSettingsDropdown();
			log.info("Clicked on settings dropdown");
			Logout.clickOnLogoutButton();
			log.info("Clicked on logout button");
			log.info("LogoutTest method completed...");
		}
	 
	 @BeforeSuite(alwaysRun = true)
	 public void setUp() throws IOException, InterruptedException
	 {
		 launchBrowser();
		 loginApplication();
	 }
	 	 
	 @AfterSuite(alwaysRun = true) 
	 public void closeBrowser() throws InterruptedException 
	 {
		 logoutApplication();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		driver.close();
	 }
}
