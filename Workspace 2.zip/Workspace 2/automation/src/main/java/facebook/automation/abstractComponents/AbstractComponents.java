package facebook.automation.abstractComponents;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AbstractComponents 
{
	
	WebDriver driver;
	Select select;
	
	public AbstractComponents(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div/div[2]/div/a")
	private WebElement homeButton;
	
	@FindBy(xpath="//ul/li[2]/span/div/a")
	private WebElement friendsButton;
	
	@FindBy(xpath="//*[@aria-label='Account controls and settings']/span/div")
	private WebElement accountIcon;
	
	@FindBy(xpath="//span[text()='Log Out']")
	private WebElement logout;
	
	public void goToHome()
	{
		homeButton.click();
	}
	
	public void goToFriends()
	{
		friendsButton.click();
	}
	
	public void goToAccountFromHeader()
	{
		accountIcon.click();
	}
	
	public void logout()
	{
		waitForElementVisibility(logout);
		logout.click();
	}
	
	public Select select(WebElement ele)
	{
		Select select = new Select(ele);
		return select;	
	}
	
	public void waitForElementVisibility(WebElement element)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
}
