package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FacebookHeadersNotInUse 
{
WebDriver driver;
	
	public FacebookHeadersNotInUse(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div/div[2]/div/a")
	private WebElement homeButton;
	
	@FindBy(xpath="//ul/li[2]/span/div/a")
	private WebElement friendsButton;
		
	
	public void goToHome()
	{
		homeButton.click();
	}
	
	public void goToFriends()
	{
		friendsButton.click();
	}
}
