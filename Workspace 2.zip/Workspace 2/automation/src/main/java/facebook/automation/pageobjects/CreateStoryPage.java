package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class CreateStoryPage extends AbstractComponents
{
	WebDriver driver;
	
	public CreateStoryPage(WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[text()='Create a Photo Story']")
	private WebElement photoStory;
		
	@FindBy(xpath="//div[text()='Create a Text Story']")
	private WebElement textStory;
	
	
	public CreatePhotoStory photoStory()
	{
		photoStory.click();
		CreatePhotoStory CreatePhotoStory= new CreatePhotoStory(driver);
		return CreatePhotoStory;
	}
	
	public CreateTextStory textStory()
	{
		textStory.click();
		CreateTextStory CreateTextStory = new CreateTextStory(driver);
		return CreateTextStory;
	}

}
