package facebook.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import facebook.automation.abstractComponents.AbstractComponents;

public class HomePage extends AbstractComponents
{
	WebDriver driver;
	
	public HomePage(WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[@class='x1n2onr6']/a/div/div/div/div[2]")
	private WebElement createStoryButton;
	
	public CreateStoryPage createStory()
	{
		createStoryButton.click();
		CreateStoryPage CreateStoryPage = new CreateStoryPage(driver);
		return CreateStoryPage;
	}
}
