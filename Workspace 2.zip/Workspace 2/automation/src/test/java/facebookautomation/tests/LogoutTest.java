package facebookautomation.tests;

import org.testng.annotations.Test;

import facebook.automation.pageobjects.Logout;
import facebookautomation.testComponents.BaseTest;

public class LogoutTest extends BaseTest
{
	@Test(groups = {"login"})
	public void logoutTest()
	{
		Logout Logout = new Logout(driver);
		log.info("LogoutTest method started...");
		Logout.goToAccountFromHeader();
		log.info("Clicked on settings dropdown");
		Logout.logout();
		log.info("Clicked in logout button");
		log.info("LogoutTest method completed...");
	}

}
