package facebookautomation.tests;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.HomePage;
import facebookautomation.testComponents.BaseTest;

public class FacebookLoginTest extends BaseTest
{
	//private static final Logger log = LogManager.getLogger(FacebookLoginTest.class);
	@Test(dataProvider="data",groups = { "login" })
	public void loginTest(HashMap<String, String> credentials) throws InterruptedException
	{
		log.info("Starting loginTest method...");

		log.info("Entering userEmail");
		LandingPage.enterEmail(credentials.get("email"));
		log.info("Entering userPassword");
		LandingPage.enterPassword(credentials.get("password"));
		log.info("Clicking on login button");
		LandingPage.clickOnLoginButton();
		log.info("Logged in Successfully...");
		Thread.sleep(5000);
	}
	
	@DataProvider
	public Object[][] data()
	{
		HashMap<String, String> map = new HashMap<>();
		map.put("email", "wevijo1155@brandoza.com");
		map.put("password", "Test@123");
		return new Object[][] {{map}};
		
	}

}
