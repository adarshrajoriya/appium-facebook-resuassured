package facebookautomation.tests;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import facebookautomation.testComponents.BaseTest;

public class LoginTest extends BaseTest
{
	@Test(dataProvider = "data")
	public void login(HashMap<String, String> credentials)
	{
		log.info("Login method started..");
		log.info("Entering email");
		LandingPage.enterEmail(credentials.get("email"));
		log.info("Entering password");
		LandingPage.enterPassword(credentials.get("password"));
		log.info("Clicking on login button");
		LandingPage.clickOnLoginButton();
		log.info("Logged in successfully and method passed...");
	}
	
	@DataProvider
	public Object[][] data() throws IOException
	{
		/*
		 * HashMap<String, String> map = new HashMap<>(); map.put("email",
		 * "ross.win08@gmail.com"); map.put("password", "Changeme@123");
		 */
		
		List<HashMap<String, String>> cred = getJsonData(System.getProperty("user.dir")+"//src//test//java//facebookautomation//data//LoginCredentials.json");
		
		return new Object[][] {{cred.get(0)}};
	}
}
