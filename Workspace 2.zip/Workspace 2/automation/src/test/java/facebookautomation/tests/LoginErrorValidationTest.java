package facebookautomation.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import facebookautomation.testComponents.BaseTest;

public class LoginErrorValidationTest extends BaseTest
{
	//CreateStoryPageprivate static final Logger log = LogManager.getLogger(LoginErrorValidationTest.class);
	@Test(priority=1,groups= {"ErrorHandling"})
	public void loginError()
	{
		log.info("loginError method started..");
		log.info("Entering email");
		LandingPage.enterEmail("ross.win08@gmail.com");
		log.info("Entering password");
		LandingPage.enterPassword("Test@321");
		log.info("Clicking on login button");
		LandingPage.clickOnLoginButton();
		log.info("Getting error message");
		String loginErrorMessage = LandingPage.errorMessage();
		log.info("Compairing actual message with expected message");
		Assert.assertEquals("The password that you've entered is incorrect. Forgotten password?", loginErrorMessage);
		log.info("loginError test completed..");
	}
}
