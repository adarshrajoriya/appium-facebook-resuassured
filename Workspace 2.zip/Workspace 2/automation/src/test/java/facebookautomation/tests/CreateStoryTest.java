package facebookautomation.tests;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.CreatePhotoStory;
import facebook.automation.pageobjects.CreateStoryPage;
import facebook.automation.pageobjects.CreateTextStory;
import facebook.automation.pageobjects.HomePage;
import facebookautomation.testComponents.BaseTest;
import facebookautomation.testComponents.Retry;

public class CreateStoryTest extends BaseTest
{
	//private static final Logger logger = LogManager.getLogger(CreateStoryTest.class);
	@Test(dataProvider = "data")
	public void textStory(HashMap<String, String> credentials) //getting credentaials through data provider (hashmap)
	
	{
		
		log.info("Starting textStory method...");
		//LandingPage LandingPage = launchBrowser();
		log.info("Entering userEmail");
		LandingPage.enterEmail(credentials.get("email"));
		log.info("Entering userPassword");
		LandingPage.enterPassword(credentials.get("password"));
		log.info("Clicking on login button");
		HomePage HomePage= LandingPage.clickOnLoginButton();
		log.info("Clicking on home button");
		HomePage.goToHome();
		log.info("Create Story page");
		CreateStoryPage CreateStoryPage =HomePage.createStory();
		log.info("Text Story page");
		CreateTextStory CreateTextStory = CreateStoryPage.textStory();
		log.info("Entering text for text story");
		CreateTextStory.enterText("My name is Test");
		log.info("Font selection");
		CreateTextStory.selectFont();
		log.info("Casual font selecting");
		CreateTextStory.casualFont();
		log.info("Selecting black color");
		CreateTextStory.selectBlackColor();
		log.info("Share story");
		CreateTextStory.shareToStory();
		log.info("Story shared on wall and Test method completed.");
		CreateTextStory.goToHome();
		
		//CreateTextStory.goToAccountFromHeader();
		//CreateTextStory.logout();
		
	}
	
	@Test(retryAnalyzer = Retry.class)
	public void photoStory() 
	{
		log.info("Starting photoStory test method.");
		LandingPage.enterEmail("ross.win08@gmail.com");
		LandingPage.enterPassword("Changeme@123");
		
		HomePage HomePage = LandingPage.clickOnLoginButton();
		HomePage.goToHome();
		CreateStoryPage CreateStoryPage = HomePage.createStory();
		//CreatePhotoStory CreatePhotoStory = 
		//CreateStoryPage.photoStory();
		//Thread.sleep(3000); Runtime.getRuntime().exec("D:\\FileUpload.exe");
		log.info("Test method completed.");
		//Thread.sleep(2000);
		//((JavascriptExecutor) driver). executeScript("window. focus();");
		CreateStoryPage.goToHome();
	}
	
	
	@DataProvider
	public Object[][] data()
	{
		HashMap<String, String> map = new HashMap<>();
		map.put("email", "ross.win08@gmail.com");
		map.put("password", "Changeme@123");
		
		return new Object[][] {{map}};
	}

	
}
