package facebookautomation.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import facebook.automation.pageobjects.FriendsTab;
import facebookautomation.testComponents.BaseTest;
import facebookautomation.testComponents.Retry;

public class FriendsListTest extends BaseTest

{
	
	//private static final Logger log = LogManager.getLogger(FriendsListTest.class);
	
	@Test(retryAnalyzer=Retry.class)
	public void seeAllFriends() throws InterruptedException
	{
		log.info("seeAllFriends method started...");
		LandingPage.goTo();
		LandingPage.enterEmail("ross.win08@gmail.com");
		LandingPage.enterPassword("Changeme@123");
		LandingPage.clickOnLoginButton();
		
		FriendsTab FriendsTab = new FriendsTab(driver); //constructor initilization
		log.info("Clicking on Friends tab from header");
		FriendsTab.goToFriends();
		log.info("Clicking on all friends");
		FriendsTab.clickAllFriendsButton();
		log.info("Selecting friend from list");
		FriendsTab.selectFriend();
		log.info("seeAllFriends method completed..");
		
	}
}
