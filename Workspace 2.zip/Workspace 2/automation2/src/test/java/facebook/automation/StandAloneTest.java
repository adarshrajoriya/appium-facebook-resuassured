package facebook.automation;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import dev.failsafe.internal.util.Assert;
import facebook.automation.pageobjects.CreateStory;
import facebook.automation.pageobjects.HomePage;
import facebook.automation.pageobjects.LandingPage;

public class StandAloneTest 
{
	public static void main(String[] args) throws InterruptedException {
		
		
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		
		LandingPage landingpage = new LandingPage(driver);
		landingpage.goTo();
		landingpage.loginFacebook("wevijo1155@brandoza.com", "Test@123");
		HomePage homepage = new HomePage(driver);
		homepage.goToHome();
		homepage.createStory();
		CreateStory createstory = new CreateStory(driver);
		createstory.textStory("My name is Adarsh and I'm creating a text story");
		createstory.selectFont();
		createstory.selectBlackColor();
		createstory.shareToStory();
		
		
		homepage.goToHome();
		homepage.createStory();
		
		createstory.textStory("My name is Adarsh and I'm creating a text story");
		createstory.selectBlackColor();
		createstory.discardStoryPost();
		
		
		
		
		//List<WebElement> fonts = driver.findElements(By.xpath("//div[@id='StoriesCreateSATPFontMenu']/div"));
		
//		Boolean match = fonts.stream().anyMatch(font-> font.getText().equalsIgnoreCase(fontName));
//		Assert.assertTrue(match);
		
//		
//		for(int i=0; i<fonts.size();i++)
//		{
//			String fontName = fonts.get(i).getText();
//			System.out.println(fontName);
//			
//			if(fontName.contains("Casual"))
//			{
//				driver.findElements(By.xpath("//div[text()='casual']")).get(i).click();
//			}
//		}
		
		//driver.findElement(By.xpath("//div[@id='StoriesCreateSATPFontMenu']/div[2]")).click();
//		driver.findElement(By.xpath("//div[text()='simple']")).click();
//		driver.findElement(By.xpath("//div[@id='StoriesCreateSATPFontMenu']/div[2]")).click();
//		driver.findElement(By.xpath("//div[text()='Backgrounds']/following-sibling::div/div[6]")).click();
//		driver.findElement(By.xpath("//span[text()='Share to Story']")).click();
		
		System.out.println("Success");
		
	}
}
