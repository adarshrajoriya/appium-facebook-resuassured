package facebook.automation.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPage 
{
	WebDriver driver;
	
	public LandingPage(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//WebElement userEmail = driver.findElement(By.id("email"));
	
	@FindBy(id="email")
	WebElement userEmail;
	
	@FindBy(id="pass")
	WebElement emailPassword;
	
	@FindBy(name="login")
	WebElement login;
	
	public void loginFacebook(String email, String password)
	{
		userEmail.sendKeys(email);
		emailPassword.sendKeys(password);
		login.click();
	}
	
	public void goTo()
	{
		driver.get("https://www.facebook.com");
	}
	
}
