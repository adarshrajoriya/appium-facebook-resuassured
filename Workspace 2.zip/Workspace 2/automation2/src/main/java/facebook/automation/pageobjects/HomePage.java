package facebook.automation.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage 
{
	WebDriver driver;
	
	public HomePage(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//WebElement userEmail = driver.findElement(By.id("email"));
	
	@FindBy(xpath="//div/div[2]/div/a")
	WebElement homeButton;
	
	@FindBy(xpath="//div[@class='x1n2onr6']/a/div/div/div/div[2]")
	WebElement createStoryButton;
	
	public void goToHome()
	{
		homeButton.click();
	}
	public void createStory()
	{
		createStoryButton.click();
	}
}
