package facebook.automation.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateStory 
{
	WebDriver driver;
	
	public CreateStory(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[@class='x1n2onr6']/a/div/div/div/div[2]")
	WebElement createStoryButton;
	
	@FindBy(xpath="//div[text()='Create a Photo Story']")
	WebElement photoStory;
	
	@FindBy(xpath="//div[text()='Create a Text Story']")
	WebElement textStory;
	
	@FindBy(xpath="//div/textarea")
	WebElement enterText;
	
	@FindBy(xpath="//div[text()='simple']")
	WebElement fontDropdown;
	
	@FindBy(xpath="//div[@id='StoriesCreateSATPFontMenu']/div[2]")
	WebElement casualFontOption;
	
	@FindBy(xpath="//div[text()='Backgrounds']/following-sibling::div/div[6]")
	WebElement blackColorButton;
	
	@FindBy(xpath="//span[text()='Share to Story']")
	WebElement shareToStoryButton;
	
	@FindBy(xpath="//span[text()='Discard']")
	WebElement discardButton;
	
	public void createStory()
	{
		createStoryButton.click();
	}
	
	public void photoStory()
	{
		photoStory.click();
	}
	
	public void textStory(String text)
	{
		textStory.click();
		enterText.sendKeys(text);
	}
	
	public void selectFont()
	{
		fontDropdown.click();
		casualFontOption.click();
	}
	
	public void selectBlackColor()
	{
		blackColorButton.click();
	}
	public void shareToStory()
	{
		shareToStoryButton.click();
	}
	
	public void discardStoryPost()
	{
		discardButton.click();
	}
}
