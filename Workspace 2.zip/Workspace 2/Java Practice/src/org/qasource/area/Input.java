package org.qasource.area;

import java.util.Scanner;

public class Input 
{
	float a,b;
	
	void Input ()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 1st digit: ");
		a = scan.nextInt();
		System.out.println("Enter 2nd digit: ");
		b = scan.nextInt();
		scan.close();
		
		
		for (int i=0; i)
	}
}
