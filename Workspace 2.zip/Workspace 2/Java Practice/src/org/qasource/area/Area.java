package org.qasource.area;

public class Area 
{
	private final static float pie=3.14f;
	
	//area of circle
	public double area(double r) {
		double area = pie*r*r;
		return area;
	}
	
	//area of square
	public int area(int l) {
		int area = l*l;
		return area;
	}
	
	//area of rectangle
	public int area(int l, int b) {
		int area = l*b;
		return area;
	}
}
