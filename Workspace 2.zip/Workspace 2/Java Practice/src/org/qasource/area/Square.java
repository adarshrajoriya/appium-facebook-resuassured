package org.qasource.area;

public interface Square 
{
	public int area(int length);
}
