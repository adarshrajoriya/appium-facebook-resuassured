package org.qasource.area;

public class InterfaceArea implements Circle, Rectangle, Square
{
	static final double pie = 3.14;
	
	
	public double area(double radius) {
		return pie*radius*radius;
	}

	public int area(int length, int breadth) {
		
		return length*breadth;
	}

	public int area(int length) {
		
		return length*length;
	}

}
