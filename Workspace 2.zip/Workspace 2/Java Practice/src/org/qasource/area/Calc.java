package org.qasource.area;

import java.util.Scanner;

public class Calc extends Input
{
	
void add ()
{
	Input();
	System.out.println("Addition is: "+(a+b));
	
}

void sub ()
{
	Input();
	System.out.println("Substraction is: "+(a-b));
}

void mul ()
{
	Input();
	System.out.println("Multiplication is: "+(a*b));		
}

void div ()
{
	Input();
	System.out.println("Dividation is: "+(a/b));
}

public static void main(String[] args) 
	
	{
		Calc c = new Calc();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter add for addition, subs for substraction, mul for multiplication and div for dividation: ");
		
		String result = sc.nextLine();
		
		String add="add";
		String subs="subs";
		String mul="mul";
		String div="div";
		
		if (result.equals(add))
		{
			System.out.println("Doing addition");
			c.add();	
		}
		else if (result.equals(subs))
		{	
			c.sub();	
		}
		else if (result.equals(mul))
		{
			System.out.println("Doing multiplication");
			c.mul();
		}
		else if (result.equals(div))
		{
			System.out.println("Doing dividation");
			c.div();
		}
		else
			System.out.println("Incorrect input. Expected was add or subs or mul or div");
		sc.close();
	}
}
