package org.qasource.area;

public class CalculateArea  
{
	public static void main(String[] args) 
	{
		Area a = new Area();
		System.out.println("Area of circle: " +a.area(3.0));
		
		System.out.println("Area of square: "+a.area(10));
		
		System.out.println("Area of rectangle: "+a.area(15, 12));
		
	}
}
