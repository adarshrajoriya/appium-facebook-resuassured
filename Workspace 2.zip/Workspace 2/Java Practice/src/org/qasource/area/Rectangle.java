package org.qasource.area;

public interface Rectangle 
{
	public int area(int length, int breadth);
}
