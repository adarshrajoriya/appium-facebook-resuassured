package org.qasource.area;

public interface Circle 
{
	public double area (double radius);
}
