package org.qasource.area;

public class CalculateInterfaceArea 
{
	public static void main(String[] args) {
		
		InterfaceArea ia = new InterfaceArea();
		
		double areaOfCircle = ia.area(2.0);
		System.out.println(areaOfCircle);
		
		int areaOfSquare = ia.area(12);
		System.out.println(areaOfSquare);
		
		int areaOfRectangle = ia.area(12, 13);
		System.out.println(areaOfRectangle);
		
		Circle c = new InterfaceArea();
		System.out.println("Area of circle is: "+c.area(21.5));
		
	}
}
