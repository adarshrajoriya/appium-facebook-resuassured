package org.qasource.javaPrograms;

public class ExceptionHandling 
{
	public static void main(String[] args) {
		int i=0; int j=10;
		
		int div=0;
		
		try 
		{
		div = j/i;
		
		}
		
		catch (ArithmeticException e)
		{
			e.printStackTrace();
			System.out.println("Catch block");
		}
		
		try
		{
			
		}
		
		catch (ArrayIndexOutOfBoundsException ae)
		{
			
		}
		
		try {
			
		}
		catch (ClassCastException cce)
		{
			
		}
		
		finally
		{
			System.out.println("Final block");
		}
		
		
		System.out.println(div);
	}
}
