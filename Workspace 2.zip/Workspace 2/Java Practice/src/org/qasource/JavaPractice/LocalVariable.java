package org.qasource.JavaPractice;

public class LocalVariable 
{
	
	static int a=13;
	int f=20;
	
	public static void main(String[] args) {
		
		
		int c=5;
		int d=10;
		
		System.out.println(a);
		
		LocalVariable lv = new LocalVariable();
		
		System.out.println(lv.f);
		
		System.out.println(c);
		System.out.println(d);
		
		int temp=c;
		c=d;
		d=temp;
		
		System.out.println(c);
		System.out.println(d);
	}
}
