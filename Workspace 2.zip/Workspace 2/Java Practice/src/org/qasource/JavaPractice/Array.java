package org.qasource.JavaPractice;

import java.util.Scanner;

public class Array 
{
	
//	int [][][] multi = {{7,8,9},{10,11,12},{13,14,15}};
	
	public static void main(String[] args) {
		
		int [] one = {1,2,3,4,5,6};
		int [][] two = {{1,2,3},{4,5,6}};
		String [] string = {"Adarsh"};
		
		/*
		 * System.out.println(one[0]); System.out.println(two[1][0]);
		 */
		
		for (int i=0; i<=two.length-1;i++)
		{
			for(int j=0; j<=i;j++)
			{
				System.out.println(two[i][j]);
			}
		}
		
		/*
		 * Scanner scan = new Scanner(System.in); System.out.println("Enter value");
		 * scan.next();
		 */
		System.out.println(string[0]);
	}
}
