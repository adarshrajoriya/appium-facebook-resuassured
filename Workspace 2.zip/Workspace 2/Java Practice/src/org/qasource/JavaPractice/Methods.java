package org.qasource.JavaPractice;

import java.util.Random;

public class Methods 
{
	void zeroArgs() 
	{
		System.out.println("Method with zero agruments");
	}
	
	void add(int a, int b) {
		System.out.println("Method with arguments");
		System.out.println(a+b);
	}
	
	void mul(int a, int b)
	{
		System.out.println("Method with arguments");
		System.out.println(a*b);
	}
	
	double zeroArgsReturn() {
		System.out.println("Method with zero arguments and return type");
		double price=15245;
		return price; 
	}
	
	double argsReturnPrice(double a, int x) {
		System.out.println("Method with arguments and return type "+a);
		System.out.println("Method with arguments and return type "+x);
		return a;
	}
	
	void zeroArgs(long a, int b)
	{
		
	}
	void Args(int d)
	{
		System.out.println("Print");
	}
	void Args(int d, int j)
	{
		System.out.println("Print");
	}

}

class Override extends Methods
{
	void args(int a,int b) 
	{
		
	}
	
	
	
	public static void main(String[] args) {
		Methods m= new Methods();
		
		m.zeroArgs();
		m.add(10,5);
		m.mul(10, 5);
		m.zeroArgsReturn();
		m.argsReturnPrice(11,22);
		double price=m.zeroArgsReturn();
		System.out.println(price);
		m.argsReturnPrice(2255,3355);
		
		Random r1= new Random();
		int result=r1.nextInt(1000);
		int s1=(int) r1.nextLong();
		System.out.println(result);
		System.out.println(s1);
		m.Args(2);
	}
}
