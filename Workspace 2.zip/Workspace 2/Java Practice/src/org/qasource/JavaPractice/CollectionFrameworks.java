package org.qasource.JavaPractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Vector;

import javax.swing.text.html.HTMLDocument.Iterator;

class Object 
{
	void Obj()
	{
		System.out.println("Obj");
	}
}
public class CollectionFrameworks 
{

	public static void main(String[] args) {
		
		/*
		 * HashMap map = new HashMap(); map.put("Name", "Adarsh");
		 * 
		 * LinkedHashMap lhm = new LinkedHashMap<>(); lhm.put("LastName", "Rajoriya");
		 * lhm.put("LastName", "Rajoriya");
		 * 
		 * ArrayList al = new ArrayList(); al.add(1,1); //al.set(0, 1); //al.set(1, 2);
		 * //al.set(0, 1); System.out.println(al.size());
		 */
		Object ob = new Object();
		ob.Obj();
		
		int [] arr = {5,4,2,8,9,7};
		
		ArrayList list = new ArrayList<>();
		list.add(1);
		list.add(5);
		list.add(4);
		list.add(8);
		list.add(0);
		list.add(4, 10);
		
		ArrayList<String> al = new ArrayList<>();
		al.add("Adarsh");
		
		System.out.println(al);
		
		List<String> als = new ArrayList<>();
		als.add("Adarsh");
		System.out.println(als);
		
		
		System.out.println(list);
		
		LinkedList linkedlist = new LinkedList<>();
		
		linkedlist.addFirst("Adarsh");
		linkedlist.addFirst("Rajoriya");
		linkedlist.addLast("0Adarsh");
		linkedlist.addLast("Java");
		linkedlist.addLast("Java");
		
		Vector vectorlist = new Vector<>();
		vectorlist.add(1);
		
		HashSet hs = new HashSet<>();
		hs.add(1);
		hs.add(1);						//Cannot have duplicates in HashSet
		hs.add("Ravi");
		hs.add("Ravi");					//Cannot have duplicates in HashSet
		hs.add("Ravii");
		
		HashMap hm = new HashMap<>();
		hm.put("Name", "Adarsh");
		
		
		//TreeSet ts = new TreeSet();
		Collections.sort(list);
		
		Collections.sort(linkedlist);
		
		System.out.println(list);
		System.out.println(linkedlist);
		System.out.println(hs);
		
	}
}
