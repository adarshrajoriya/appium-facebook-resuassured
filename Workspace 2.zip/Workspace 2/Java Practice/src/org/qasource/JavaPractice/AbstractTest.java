package org.qasource.JavaPractice;

public abstract class AbstractTest 
{
	abstract void details();
}

class Test
{
	public static void main(String[] args) {
		
		AbstractTest = n
	}
}
