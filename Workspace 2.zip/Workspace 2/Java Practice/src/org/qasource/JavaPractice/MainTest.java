package org.qasource.JavaPractice;

class Derived extends MainTest  
{  
     
    void method(double d)  
    {  
        System.out.println("Derived class method called with double d ="+d);  
    }  
}  

class MainTest  
{      
    public static void main(String[] args)  
    {  
        new Derived().method(10);  
    }  
} 
