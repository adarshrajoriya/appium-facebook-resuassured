package org.qasource.JavaPractice;

public class CastingNonPrimitiveArchitect 
{
	void register()
	{
		
	}
	void login()
	{
		
	}
}
class Developer extends CastingNonPrimitiveArchitect
{
	void register()
	{
		System.out.println("Running Register");
	}
	void login()
	{
		System.out.println("Running Login");
	}
	void team()
	{
		System.out.println("Running Team");
	}
}
class TestArchitect
{
	public static void main(String[] args) {
		CastingNonPrimitiveArchitect a1 = new Developer();		//upcasting
		a1.register();
		a1.login();
		
		System.out.println("--------------------");
		
		Developer d1 = (Developer) a1;							//downcasting
		d1.register();
		d1.login();
		d1.team();
	}
}
