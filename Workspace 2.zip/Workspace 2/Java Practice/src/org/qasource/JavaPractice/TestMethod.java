package org.qasource.JavaPractice;

public class TestMethod 
{
	int num1 (int a)
	{
		System.out.println("Num1");
		return a;
	}
	
	void num2 ()
	{
		System.out.println(num1(20));
		
	}
	
	public static void main(String[] args) {
		TestMethod tm = new TestMethod();
		tm.num1(10);
		tm.num2();
	}
}
