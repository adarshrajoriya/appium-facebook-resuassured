package org.qasource.JavaPractice;

public class ConstructorDemo 
{
	int a;
	String b;
	
	 ConstructorDemo ()
	{
		System.out.println(a+" "+b);
	}
	 
}

class PrivateConstructor
{
	private PrivateConstructor()
	{
		System.out.println("Cannot create object of private constructor class");
	}
}

class ParameterizedConstructor
{
	int id;
	String name;
	public ParameterizedConstructor(int i, String n) 
	{
		id = i;
		name = n;
	}
	void display()
	{
		System.out.println(id+" name is: "+name);
	}
}
class TestConstructor
{
	public static void main(String[] args) {
			ConstructorDemo cs = new ConstructorDemo();
		 // PrivateConstructor pc = new PrivateConstructor();
			ParameterizedConstructor pc = new ParameterizedConstructor(263, "Adarsh");
			pc.display();
	}
}