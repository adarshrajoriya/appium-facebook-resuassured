package org.qasource.JavaPractice;

import java.util.Scanner;

public class IsPrime 
{
	public static void main(String[] args) {
		
		int temp, num;
		boolean isPrime = true;
		Scanner scan = new Scanner(System.in);
		num = scan.nextInt();
		scan.close();
		
		for(int i=2; i<num; i++)
		{			
			temp=num%i;
			if(temp==0)
			{
				isPrime=false;
				break;	
			}
		
		}
		if(isPrime)
		
			System.out.println("Number is prime");
		else
			System.out.println("Number is not prime");
	}
}
