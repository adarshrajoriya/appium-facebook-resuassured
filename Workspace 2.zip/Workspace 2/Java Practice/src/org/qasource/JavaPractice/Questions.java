package org.qasource.JavaPractice;

public class Questions 
{
	public int q7(int a, int b)
	{
		int ret = 0;
		for (int i=0; i<b;i++)
		{
			ret = ret * a;
			
		}
		return a;
	
	}
	
	public int q6(int a, int b)
	{
		int ret = 0;
		for (int i=0; i<b;i++)
		{
			ret = ret * a;
			
		}
		return ret;
	}
	
	public int q8(int a)
	{
		int ret = 1;
		for (int i=1; i<=a;i++)
		{
			ret = ret * i;
			
		}
		return ret;
	}
	public static void main(String[] args) {
		Questions q = new Questions();
		int value = q.q7(3, 4);
		System.out.println(value);
		
		int value1 = q.q6(3, 4);
		System.out.println(value1);
		
		int value2 = q.q8(4);
		System.out.println(value2);
				
	}
}
