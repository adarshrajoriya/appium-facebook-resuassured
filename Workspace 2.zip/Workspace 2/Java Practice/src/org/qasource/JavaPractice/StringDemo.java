package org.qasource.JavaPractice;

public class StringDemo 
{
	static public void main(String[] args) {
		
		String name = "Adarsh";
		
		StringBuilder sb = new StringBuilder("Adarsh");
		System.out.println(sb.reverse());
		
		StringBuffer sb1 = new StringBuffer("Rajoria");
		System.out.println(sb1.reverse());
		
		char ch [] =name.toCharArray();
		
		
		for(int i=ch.length-1; i>=0;i--)
		{
			System.out.print(ch[i]);
		}
		
		
		
		
	}
}
