package org.qasource.JavaPractice;

public class CastingPrimitive 
{
	public static void main(String[] args) {
		
		int a = 10;
		System.out.println(a);
		double b = a;					//implicit casting
		
		System.out.println(b);
		
		double c = 20;
		System.out.println(c);
		int d = (int) c;				//explicit casting
		System.out.println(d);
		
		short x=10;
		System.out.println(x);
		byte y = (byte) x;
		System.out.println(y);
	}
}
