package org.qasource.JavaPractice;

public class Main 
{

	  void method(int a)  
	    {  
	        System.out.println("Base class method called with integer a = "+a);  
	    }  
	       
	    void method(double d)  
	    {  
	        System.out.println("Base class method called with double d ="+d);  
	    }  
}
