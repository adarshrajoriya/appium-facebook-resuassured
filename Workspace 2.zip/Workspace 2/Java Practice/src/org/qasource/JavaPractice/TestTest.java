package org.qasource.JavaPractice;

public class TestTest {

	public static void main(String[] args) {
		int k = 24; k=k*k;
		
		String a = "This is Screening " + "Test";
		
		String s = "Interview"; String sub = s.substring(0,4);
		
		
		
		int ind = "Interview".indexOf("e");
		
		System.out.println(ind);
		
		String str = "Adarsh";
		
		char c = str.charAt(4);
		
		System.out.println(c);
		
		int len = ("Interview").length();
		System.out.println(len);
		
		System.out.println(k);// TODO Auto-generated method stub
		
		

	}

}
