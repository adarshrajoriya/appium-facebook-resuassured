package org.qasource.JavaPractice;

 class Demo1 
{
	int a=10;
	int b=20;
	
	//Array [] arr= {1,2,3,4,5};
}
 class Demo2 extends Demo1
{
	int a=12;
	int b=22;
	
	void runDemo1() {
		int a=super.a;
		System.out.println(a);
		
	}
	void runDemo2()
	{
		int a=this.a;
		System.out.println(a);
	}
	
	public static void main(String[] args) {
		
		Demo2 d2=new Demo2();
		d2.runDemo1();
		d2.runDemo2();
	}
}

