package org.qasource.JavaPractice;

public class Swapping 
{
	public static void main(String[] args) {
		int a=10;
		int b=20;
		
		System.out.println("Before swapping a is: "+a+" , b is: "+b);
		
		int temp;
		
		temp=a;
		a=b;
		b=temp;
		
		System.out.println("After swapping a is: "+a+" , b is: "+b);
	}
}
