package org.qasource.JavaPractice;

public interface Interface 
{
	
	static final int i = 10;
	int j=20;
	
	static void staticMethod() {
		
		System.out.println("Interface number is: "+i);
		
	}
	
	public void incompleteMethod();  //Public access specifiers only
	
	  Interface() 
	  {
	 
	  }
	 
	  { 
		  System.out.println("Blocks are not allowed in interface"); 
	  }
	 
	
	public static void main(String[] args) 
	{
		System.out.println("Main method of interface");
		
		Interface.staticMethod();
			
			
	}
	
	void method();
	
}

 abstract class Abstracts //implements Interface
{
	
	static int i;
	
	abstract int methoddd();
	
	public void method() 
	{
		System.out.println("Running incomplete method");
	}

	
	 public static void main(String[] args) { System.out.println(i); }
	 
}
 
 class ConcreteClass extends Abstracts
 {
	 int methoddd()
	 {
		 return i;
	 }
	 
 }