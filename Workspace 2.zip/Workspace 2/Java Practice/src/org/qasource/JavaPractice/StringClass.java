package org.qasource.JavaPractice;

public class StringClass 
{
	String s1 = "Core Java";
	static String s2 = new String("Core Java");
	static String s3 = "Core Java";
	static String s4 = "Core Java";
	
	
	public static void main(String[] args) {
		StringClass sc = new StringClass();
		
		System.out.println(sc.s1);
		System.out.println(sc.s2);
		
		System.out.println(s3);
		System.out.println(s4.toUpperCase());
		System.out.println(s4.length());
		System.out.println(s4.isEmpty());
		System.out.println(s4.startsWith("Core"));
		System.out.println(s4.endsWith("Core"));
		System.out.println(s4.substring(6));
		System.out.println(s4.substring(4, 6));
		System.out.println(s4.subSequence(4, 6));
		System.out.println(s4.replace("Core", "Maha"));
		System.out.println(s4.indexOf('a'));
		System.out.println(s4.lastIndexOf('a'));
		System.out.println(s4.charAt(3));
		
		System.out.println(s3==s4); //comparing address (not possible)
		System.out.println(sc.s1==sc.s2);
		System.out.println(sc.s1.equals(sc.s2)); //comparing value (possible)
		System.out.println(sc.s1.equals(sc.s3));
		System.out.println(sc.s1.equals(sc.s4));
		
		StringBuilder sb = new StringBuilder("Core Java");
		System.out.println("printing reversible ");
		System.out.println(sb.reverse());
		System.out.println(sb.append(" Practice"));
		
		System.out.println(sb.insert(2, "ll"));
		System.out.println(sb.delete(2, 4));
		
		int arr[] = {1,2,3,4,5};
		
		String aa=arr.toString();
		System.out.println(aa);
		System.out.println(aa.toUpperCase());
		
		//we can remove spaces by method trim(), we can concat 2 strings using (s7.concat(s8))
	}
}
