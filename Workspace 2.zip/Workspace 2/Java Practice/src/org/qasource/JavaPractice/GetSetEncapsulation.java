package org.qasource.JavaPractice;

public class GetSetEncapsulation {
	private int pin = 101020;			//For final member, setter method cannot be declared
	String pen = "Accessible";

	 int getPin() 
	 { 
		 return pin;  
	 }
	  void setPin(int pin) 
	  { 
		  this.pin = pin; 
	  }
	  
}

class TestPin
{
	public static void main(String[] args) {
		
		GetSetEncapsulation gse = new GetSetEncapsulation();
		System.out.println(gse.getPin());
		gse.setPin(122332);
		System.out.println(gse.getPin());
	//	System.out.println(gse.pin);         Cannot accessible directly as private member
		System.out.println(gse.pen);		// Can accessible directly as it is not private
	}
}