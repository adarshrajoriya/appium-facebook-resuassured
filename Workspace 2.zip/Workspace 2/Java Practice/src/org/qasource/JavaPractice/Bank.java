package org.qasource.JavaPractice;

class Bank {
	double interestPercentage(double a) {
		return a;
	}
}

class SBI extends Bank {
	double interestPercentage(double a) {
		System.out.println("SBI Bank interest is: " + a + "%");
		return a;
	}
	this
	void sbi()
	{
		System.out.println("SBI");
	}
}

class ICICI extends SBI {
	double interestPercentage(double a) {
		System.out.println("ICICI Bank interest is: " + a + "%");
		return a;
	}
}

class AXIS extends Bank {
	
	double addition;
	double interestPercentage(double x, double y) {
		/*
		 * System.out.println("AXIS overloading Bank " + x);
		 * System.out.println("AXIS overloading Bank " + y);
		 */
		
		 addition =  x + y;
		 
		 System.out.println(addition);
		
		return x;
	}
}

class TestBank {
	public static void main(String[] args) {

		
		SBI sb = new SBI(); 
		sb.interestPercentage(10);
		ICICI ic = new ICICI();
		ic.interestPercentage(12);
		ic.sbi();
		AXIS ax = new AXIS();
		ax.interestPercentage(10, 20);

	}
}