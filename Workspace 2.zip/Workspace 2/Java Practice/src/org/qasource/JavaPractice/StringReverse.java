package org.qasource.JavaPractice;

import java.util.Collections;
import java.util.HashMap;

public class StringReverse 
{
	public static void main(String[] args) {
		
		String str = "Adarsh";
		char[] reverse=str.toCharArray();
		
		for(int i=reverse.length-1; i>=0;i--)
		{
			System.out.print(reverse[i]);
			
		}
		System.out.println();
		
		StringBuilder sb = new StringBuilder("hsradA");
		System.out.println(sb.reverse());
		
		String st = "Saket Saurav";
        char chars[] = st.toCharArray();  // converted to character array and printed in reverse order
        for(int i= chars.length-1; i>=0; i--) {
            System.out.print(chars[i]);
        }
        
        int a =10; int b=20; int temp=a;
        a=b;
        b=temp;
        temp=a;
        System.out.println();
        System.out.println("a is: "+a+"b is: "+b);
        
        int x=10,y=20;
        System.out.println("Before swap x is: "+x+" y is:"+y);
        x=x+y;
        y=x-y;
        x=x-y;
        
        System.out.println("After swap x is: "+x+" y is:"+y);
        
        String count = "Test the string count using hashmap";
        
        String [] string=count.split(" ");
        
        HashMap<String, Integer> hsmap = new HashMap<>();
        
        HashMap hm = new HashMap();
        hm.put("Name", "Test the string count using hashmap");
        
        
        
	}
}
