package org.qasource.JavaPractice;

import java.util.Scanner;

public class Palindrome 
{
	public static void main(String[] args) {
		
	int num, temp;
	
	Scanner scan = new Scanner(System.in);
	
	System.out.println("Enter number to check palindrome: ");
	
	num = scan.nextInt();
	
	temp = num;
	
	for (int num = )
	
	
	}
}