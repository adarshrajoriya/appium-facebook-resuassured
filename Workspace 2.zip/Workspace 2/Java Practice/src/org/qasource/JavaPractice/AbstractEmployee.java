package org.qasource.JavaPractice;

public abstract class AbstractEmployee 
{
	String eName;
	
	AbstractEmployee (String eName)
	{
		this.eName = eName;
	}
	
	abstract void details();			//abstract method
	
	{
		System.out.println("Running non-static block");
	}
	void login()						//complete method
	{
		System.out.println("Complete Method");
	}
}

class HR extends AbstractEmployee
{
	HR()
	{
		super("Samba");
	}
	
	void details()
	{
		System.out.println("Employee name is: "+eName);
	}
}

class TestHR
{
	public static void main(String[] args) {
		HR h = new HR();
		h.details();
	}
}
