package org.qasource.JavaPractice;

import java.util.Scanner;

public class NestedIf 
{
	static int emailOtp= 123;
	static int smsOtp=123;
	

	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter email OTP: ");
		int eOtp=s.nextInt();
		System.out.println("Enter sms OTP: ");
		int sOtp=s.nextInt();
		
		if (emailOtp==eOtp)
		{
			System.out.println("Email OTP is correct ");
			
			if(smsOtp==sOtp)
			{
				System.out.println("Login Successfull");
			}
			else
				System.out.println("Invalid SMS OTP");
		}
		else
			System.out.println("Login Failed");
		
	}

}
