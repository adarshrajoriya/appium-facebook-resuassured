package org.qasource.JavaPractice;

public class FinalDemo 
{
	int a=10;
	int b=20;
	
	final int x=30;
	final int y;
	final int z;
	
	{
		//x=20;
		y=50;
		z=60;
	}
	
	final void test()
	{
		System.out.println("Running test");
	}
}

class FinalDemo2 extends FinalDemo
{
	void test()
	{
		System.out.println("Running test 02");
	}
}

final class FinalClass
{
	
}

class FinalExtend extends FinalClass
{
	
}
