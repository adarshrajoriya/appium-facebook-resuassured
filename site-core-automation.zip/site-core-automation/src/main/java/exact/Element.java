package exact;

import static exact.ReportLogMain.logError;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import exact.navigation.ExactNavNavigation;
import exact.sys.Driver;
import exact.sys.DriverManager;
import exact.sys.Wait;
import exact.util.BasicUtils;

public class Element extends ExactNavNavigation {

	private static final String disabledClass = "disabled";

	/**
	 * Waits for an element to fully hit the page (loaded into DOM and visible to
	 * the naked eye) before clicking the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your clicking needs.
	 * 
	 * @param element thing you want to click
	 * @return WebElement of the element that was clicked. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement loadAndClick(By element) {
		return loadAndClick(waitForEnabled(element));
	}

	public static void waitForDisappear(By by) {
		Wait wait = DriverManager.getWait(Duration.ofSeconds(20));
		wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				try {
					return !isElementDisplayed(by);
				} catch (StaleElementReferenceException e) {
					return true;
				}
			}

			@Override
			public String toString() {
				return "element to no longer be visible: " + by + " - " + BasicUtils.takeScreenshot();
			}
		});
	}

	/**
	 * Waits for an element to fully hit the page (loaded into DOM and visible to
	 * the naked eye) before Hover the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your Hover needs.
	 * 
	 * @param element thing you want to Hover
	 * @return WebElement of the element that was Hover. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement mouseHover(By element) {
		return mouseHover(waitForEnabled(element));
	}

	/**
	 * Waits for an element to fully hit the page (loaded into DOM and visible to
	 * the naked eye) before clicking the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your clicking needs.
	 * 
	 * @param element thing you want to click
	 * @return WebElement of the element that was clicked. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement loadAndClick(WebElement element) {
		waitForEnabled(element);
		scrollToElement(element);
		try {
			element.click();
		} catch (StaleElementReferenceException e) {
			throw new StaleElementReferenceException(
					"loadAndClick failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(), e);
		} catch (RuntimeException e) {
			throw new RuntimeException(
					"loadAndClick failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(), e);
		}
		return element;
	}

	/**
	 * Waits for an element to fully hit the page (loaded into DOM and visible to
	 * the naked eye) before Hover the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your Hover needs.
	 * 
	 * @param element thing you want to Hover
	 * @return WebElement of the element that was Hover. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement mouseHover(WebElement element) {
		waitForEnabled(element);
		try {
			Actions action = new Actions(DriverManager.getCurrent());
			action.moveToElement(element).build().perform();
		} catch (StaleElementReferenceException e) {
			throw new StaleElementReferenceException(
					"mouseHover failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(), e);
		} catch (RuntimeException e) {
			throw new RuntimeException(
					"mouseHover failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(), e);
		}
		return element;
	}

	/**
	 * Scroll an element into view.
	 * 
	 * @param we Element to scroll into view.
	 * @return The {@link WebElement} that gets scrolled to.
	 */
	public static WebElement scrollToElement(WebElement we) {
		((JavascriptExecutor) DriverManager.getCurrent())
				.executeScript("arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", we);
		return we;
	}

	public void printCustomStackTrace(Exception exception) {
		StackTraceElement[] trace = exception.getStackTrace();
		for (StackTraceElement traceElement : trace) {
			logError("\t at " + traceElement);
		}
	}

	/**
	 * Check if element is displayed on the current page.
	 * 
	 * @param by Element to check if displayed.
	 * @return True if element is displayed on page, false otherwise.
	 */
	public static boolean isElementDisplayed(By by) {
		List<WebElement> elements = getMultiple(by);
		for (WebElement element : elements) {
			try {
				if (isElementDisplayed(element)) {
					return true;
				}
			} catch (StaleElementReferenceException e) {
				// Not a match. Moving on.

			}
		}
		return false;
	}

	/**
	 * Return the Element text.
	 * 
	 * @param by Element to Return the Element text.
	 * @return Return the Element text if displayed, null otherwise.
	 */
	public static String getText(By by) {
		return getText(waitForVisible(by));
	}

	/**
	 * Return the Element text.
	 * 
	 * @param by Element to Return the Element text.
	 * @return Return the Element text if displayed, null otherwise.
	 */
	public static String getText(WebElement element) {
		try {
			scrollToElement(element);
			return element.getText();
		} catch (StaleElementReferenceException e) {
			// Not a match. Moving on.
			return null;
		}
	}

	/**
	 * This method waits for DOM to load properly
	 */
	public static void waitForDOMToLoad() {
		((JavascriptExecutor) DriverManager.getCurrent()).executeScript("return document.readyState")
				.equals("complete");
	}

	/**
	 * Waits until an element is no longer present on the DOM.
	 * 
	 * @param by Element to wait for staleness.
	 * @since 05/05/2023
	 */
	public static void waitForElementStale(final By by) {
		try {
			waitForElementStale(get(by));
		} catch (Exception e) {
			// The element is already gone from the DOM
		}
	}

	public static void waitForElementStale(final WebElement element) {
		Wait wait = DriverManager.getWait(Driver.TIMEOUT);
		wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return ExpectedConditions.stalenessOf(element).apply(driver);
			}

			@Override
			public String toString() {
				return String.format("element (%s) to become stale - " + BasicUtils.takeScreenshot(), element);
			}
		});
	}

	/**
	 * Return the Element text.
	 * 
	 * @param by Element to Return the Element text.
	 * @return Return the Element text if displayed, null otherwise.
	 */
	public static String getElementText(By by) {
		List<WebElement> elements = getMultiple(by);
		for (WebElement element : elements) {
			try {
				if (isElementDisplayed(element)) {
					return element.getText();
				}
			} catch (StaleElementReferenceException e) {
				// Not a match. Moving on.

			}
		}
		return null;
	}

	/**
	 * Return the Element text.
	 * 
	 * @param by Element to Return the Element text.
	 * @return Return the Element text if displayed, null otherwise.
	 */
	public static String getElementAttribute(By by) {
		List<WebElement> elements = getMultiple(by);
		for (WebElement element : elements) {
			try {
				if (isElementDisplayed(element)) {
					return element.getAttribute("value");
				}
			} catch (StaleElementReferenceException e) {
				// Not a match. Moving on.

			}
		}
		return null;
	}

	/**
	 * Opens @param URL in webdriver instance
	 * 
	 * @param URL
	 */
	public static void openURL(String URL) {
		new Driver().open(URL);
	}

	/**
	 * Wait for specified element to be present on the current page and visible.
	 * 
	 * @param by Element to wait for.
	 * @return The loaded element.
	 */
	public static WebElement waitForVisible(final By by) {
		return waitForVisibleWithCustomTimeout(by, Driver.TIMEOUT);
	}

	/**
	 * Returns a webelement from within the @param element webelement
	 * 
	 * @param element
	 * @param selector
	 * @return
	 */
	public static WebElement getElementFromWithin(WebElement element, By selector) {
		return element.findElement(selector);
	}

	/**
	 * Returns a list of webelements from within the @param element webelement
	 * 
	 * @param element
	 * @param selector
	 * @return
	 */
	public static List<WebElement> getElementsFromWithin(WebElement element, By selector) {
		return element.findElements(selector);
	}

	/**
	 * wait for element to visible on page with specified timeout
	 * 
	 * @param by      : Element to wait for visible
	 * @param timeout : time to wait for sec
	 */
	public static WebElement waitForVisibleWithCustomTimeout(final By by, Duration timeout) {
		Wait wait = DriverManager.getWait(timeout);
		return wait.until(new ExpectedCondition<WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				List<WebElement> elements = getMultiple(by);
				try {
					// Check if any matching element is visible
					for (WebElement element : elements) {
						if (isElementDisplayed(element)) {
							return element;
						}
					}
				} catch (StaleElementReferenceException e) {
					// The page must still be loading. Let's refresh our element list.
					return null;
				}
				return null;
			}

			@Override
			public String toString() {
				return "visibility of element located by: " + by + " - " + BasicUtils.takeScreenshot();
			}
		});
	}

	/**
	 * Waits for any one of the specified elements to be visible on the current
	 * page. The wait will end as soon as any one of the elements is found to be
	 * visible, and that element will be subsequently returned, even if multiple
	 * elements are actually visible at the time.
	 * 
	 * @param bys Elements to check for visibility.
	 * @return The first element found to be visible.
	 */
	public static WebElement waitForAnyVisible(final By... bys) {
		return waitForConditionOnAny(new Function<By, WebElement>() {
			@Override
			public WebElement apply(By by) {
				List<WebElement> elements = getMultiple(by);
				try {
					// Check if any matching element is visible
					for (WebElement element : elements) {
						if (isElementDisplayed(element)) {
							return element;
						}
					}
				} catch (StaleElementReferenceException e) {
					// The page must still be loading. Let's refresh our element list.
					return null;
				}
				return null;
			}

			@Override
			public String toString() {
				return "become visible";
			}
		}, bys);
	}

	/**
	 * Check if element is displayed on the current page.
	 * 
	 * @param element Element to check if displayed.
	 * @return True if element is displayed on page, false otherwise.
	 */
	public static boolean isElementDisplayed(WebElement element) {
		return element == null ? false : element.isDisplayed();
	}

	/**
	 * <p>
	 * Repeatedly checks for condition on each {@link By} until the condition is
	 * met. It is assumed that the condition is met for a particular element when
	 * that element is returned as a non-null {@link WebElement}, which is
	 * subsequently returned by this method.
	 * </p>
	 * <p>
	 * The condition should be of type Function&lt;By, WebElement&gt; and should
	 * override the {@link Function#apply(Object)} and {@link Function#toString()}
	 * methods.
	 * </p>
	 * <p>
	 * The Function.apply(By) method should return the WebElement associated with
	 * the By if the condition is successfully met, or null otherwise.
	 * </p>
	 * <p>
	 * The Function.toString() method should return a String briefly describing the
	 * condition being checked, such that it fits into the sentence "Timed out
	 * waiting for any of the elements to {condition}."
	 * </p>
	 * 
	 * @param condition The condition to apply to each element.
	 * @param bys       Elements to check condition against.
	 * @return The first element for which the condition is found to be true.
	 * @see Wait#until(Function)
	 */
	private static WebElement waitForConditionOnAny(final Function<By, WebElement> condition, final By... bys) {
		Wait wait = DriverManager.getWait(Driver.TIMEOUT);
		WebElement result = wait.until(new ExpectedCondition<WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				for (By by : bys) {
					WebElement element = condition.apply(by);
					if (element != null)
						return element;
				}
				return null;
			}

			@Override
			public String toString() {
				return "any of the following elements to " + condition.toString() + ": " + Arrays.toString(bys) + " - "
						+ BasicUtils.takeScreenshot();
			}
		});
		return result;
	}

	/**
	 * Check if element is visible and enabled such that it can be clicked.
	 * 
	 * @param element Element to check for enablement
	 * @return True if element is enabled, false otherwise
	 */
	public static boolean isElementEnabled(WebElement element) {
		if (element != null && element.isDisplayed() && element.isEnabled()) {
			String classes = element.getAttribute("class");
			if (classes != null) {
				return !classes.contains(disabledClass);
			}
			return true;
		}
		return false;
	}

	public static List<WebElement> getMultiple(By by) {
		List<WebElement> elements = DriverManager.getCurrent().findElements(by);
		return elements;
	}

	/**
	 * <p>
	 * Attempts to find an element on the DOM. If the element is not found, null is
	 * returned.
	 * </p>
	 * <p>
	 * This method should be preferred over {@link Element#get(By)} for Element
	 * query methods, such as {@link Element#isElementPresent(By)}, where the
	 * absence of an element should not necessarily disrupt flow.
	 * </p>
	 * 
	 * @param by Locator used to find element.
	 * @return The element if it's found, null otherwise.
	 * @see Element#get(By)
	 */
	private static WebElement getSafely(By by) {
		try {
			return DriverManager.getCurrent().findElement(by);
		} catch (NoSuchElementException e) {
			return null;
		}
	}

	/**
	 * Check if element is present on the current page.
	 * 
	 * @param by Element to check presence of.
	 * @return True if element is present on page, false otherwise.
	 */
	public static boolean isElementPresent(By by) {
		return getSafely(by) != null;
	}

	/**
	 * @param by Locator used to find element.
	 * @return The element that was searched for
	 * @throws VeevaNoSuchElementException if the element cannot be found
	 * @see Element#getSafely(By)
	 */
	public static WebElement get(By by) {
		try {
			return DriverManager.getCurrent().findElement(by);
		} catch (Exception e) {
			throw new NoSuchElementException(
					"findElement() failed for element: " + by.toString() + " - " + BasicUtils.takeScreenshot(), e);
		}
	}

	/**
	 * Wait for specified element to be found on current page. Does not wait for
	 * element to be {@link #waitForVisible(By) displayed} or
	 * {@link #waitForEnabled(By) enabled}, just present in the DOM.
	 * 
	 * @param by Element to wait for.
	 * @return The loaded element.
	 * @see Element#waitForVisible(By)
	 * @see Element#waitForEnabled(By)
	 */
	public static WebElement waitForLoad(By by) {
		Wait wait = DriverManager.getWait(Driver.TIMEOUT);
		return wait.until(new ExpectedCondition<WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				return getSafely(by);
			}

			@Override
			public String toString() {
				return "presence of element located by: " + by + " - " + BasicUtils.takeScreenshot();
			}
		});
	}

	/**
	 * Clears a text field and enters a given string into it.
	 * 
	 * @param textBy By element representing the text field you want to fill in
	 * @param text   Text you want to put in the field
	 */
	public static String enterText(By textBy, String text) {
		WebElement field = waitForVisible(textBy);
		return enterText(field, text);
	}

	/**
	 * Clears a text field and enters a given string into it.
	 * 
	 * @param Webelement WebElement representing the text field you want to fill in
	 * @param text       Text you want to put in the field. If null, the text field
	 *                   will just be cleared.
	 */
	public static String enterText(WebElement field, String text) {
		loadAndClick(field);
		field.clear();
		if (text != null) {
			field.sendKeys(text);
			return text;
		} else {
			return null;
		}
	}

	/**
	 * Wait for specified element to be visible and enabled such that you can click
	 * it.
	 * 
	 * @param by Element to wait for.
	 * @return The enabled element.
	 */
	public static WebElement waitForEnabled(By by) {
		Wait wait = DriverManager.getWait(Driver.TIMEOUT);

		return wait.until(new ExpectedCondition<WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				List<WebElement> elements = getMultiple(by);
				try {
					// Check if any matching element is enabled
					for (WebElement element : elements) {
						if (isElementEnabled(element)) {
							return element;
						}
					}
				} catch (StaleElementReferenceException e) {
					// The page must still be loading. Let's refresh our element list.
					return null;
				}
				return null;
			}

			@Override
			public String toString() {
				return "element to be clickable: " + by + " - " + BasicUtils.takeScreenshot();
			}
		});
	}

	/**
	 * Wait for specified element to be enabled such that you can click it.
	 * 
	 * @param wel Element to wait for.
	 * @return The same element, for convenience.
	 */
	public static WebElement waitForEnabled(WebElement wel) {
		Wait wait = DriverManager.getWait(Driver.TIMEOUT);
		return wait.until(new ExpectedCondition<WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				return isElementEnabled(wel) ? wel : null;
			}

			@Override
			public String toString() {
				return "element to be enabled: " + wel + " - " + BasicUtils.takeScreenshot();
			}
		});
	}

	/**
	 * @param elementString
	 */
	public static void selectValueFromDropDownByXpath(By by) {
		WebElement selectValue = loadAndClick(by);
		try {
			selectValue.click();
		} catch (Exception e) {
			throw new NoSuchElementException(
					"findElement() failed for element: " + by.toString() + " - " + BasicUtils.takeScreenshot(), e);
		}
	}

	/**
	 * Check if element is not displayed on the current page.
	 * 
	 * @param by Element to check if displayed.
	 * @return False if element is displayed on page, true otherwise.
	 */
	public static boolean isNotElementDisplayed(By by) {
		List<WebElement> elements = getMultiple(by);
		for (WebElement element : elements) {
			try {
				if (isElementDisplayed(element)) {
					return false;
				}
			} catch (StaleElementReferenceException e) {
				// Not a match. Moving on.

			}
		}
		return true;
	}

	/**
	 * Waits for an element to fully hit the page (loaded into DOM and visible to
	 * the naked eye) before clicking the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your clicking needs When webdriver
	 * is not able to click on element on a page.
	 * 
	 * @param element thing you want to click
	 * @return WebElement of the element that was clicked. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement loadAndClickUsingExecutor(By element) {
		return loadAndClickUsingExecutor(waitForEnabled(element));
	}

	/**
	 * the naked eye) before Hover the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your Hover needs.
	 * 
	 * @param element thing you want to Mouse Click And Hold
	 * @return WebElement of the element that was Hover. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement mouseClickAndHold(By element) {
		return mouseClickAndHold(waitForEnabled(element));
	}

	/**
	 * Waits for an element to fully hit the page (loaded into DOM and visible to
	 * the naked eye) before clicking the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your clicking needs When webdriver
	 * is not able to click on element on a page.
	 * 
	 * @param element thing you want to click
	 * @return WebElement of the element that was clicked. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement loadAndClickUsingExecutor(WebElement element) {
		waitForEnabled(element);
		scrollToElement(element);
		try {
			((JavascriptExecutor) DriverManager.getCurrent()).executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException e) {
			throw new StaleElementReferenceException(
					"loadAndClick failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(), e);
		} catch (RuntimeException e) {
			throw new RuntimeException(
					"loadAndClick failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(), e);
		}
		return element;
	}

	/**
	 * the naked eye) before Hover the element. This is to be used in place of
	 * assuming that WebDriver's implicit wait will adequately wait for your element
	 * to appear. Please use this method for all your Hover needs.
	 * 
	 * @param element thing you want to Mouse Click And Hold
	 * @return WebElement of the element that was Hover. Note that in most cases
	 *         this element will be stale, which could be a useful thing to wait
	 *         for.
	 */
	public static WebElement mouseClickAndHold(WebElement element) {
		waitForEnabled(element);
		try {
			Actions action = new Actions(DriverManager.getCurrent());
			action.clickAndHold(element).perform();
		} catch (StaleElementReferenceException e) {
			throw new StaleElementReferenceException(
					"mouseClickAndHold failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(),
					e);
		} catch (RuntimeException e) {
			throw new RuntimeException(
					"mouseClickAndHold failed for element: " + element.toString() + " - " + BasicUtils.takeScreenshot(),
					e);
		}
		return element;
	}

	/**
	 * Determine whether an element contains the given text. If element is null,
	 * false will be returned.
	 * 
	 * @param element Element to check text of
	 * @param text    Text to find within element
	 * @return True if element contains the specified visible text, false otherwise.
	 */
	public static boolean containsText(WebElement element, String text) {
		try {
			return element.getText().contains(text);
		} catch (NullPointerException e) {
			// Either the element is null, or there is no text
			return false;
		}
	}

	public static WebElement getFromHtml(By by, String elementToBeSelected) {
		int attempt = 0;
		// attempt to get elements again if element is stale
		// Name OSM_Payor_Hierarchy__c OSM_Payor_Type__c OSM_Payor_Category__c
		// OSM_Purchase_Order_Number__c OSM_QDX_Billing_ID__c

		/**
		 * 
		 */
		while (attempt < 2) {
			try {
				waitForVisible(by);
				for (WebElement foundElement : Element.getMultiple(by)) {
					scrollToElement(foundElement);
					// the .contains is causing a null pointer exception .equals works,
					// but I didn't feel comfortable changing
					if (isElementDisplayed(foundElement) && containsText(foundElement, elementToBeSelected)) {
						// perform operation on element to try to invoke StaleElementReferenceException
						foundElement.getText();
						return foundElement;
					}
				}
				return null;

			} catch (StaleElementReferenceException e) {
				attempt++;
			}
		}
		return null;
	}

}
