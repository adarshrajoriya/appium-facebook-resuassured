package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDETestFurMichGeeignetPage extends ExactNavNavigation {

	private final By oncoDxRecScrTstBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("oncoDxRecScrTstBtnBy"));
	private final By testberichtLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("testberichtLinkBy"));
	private final By erSiMeDarWiSiZuZuTeBeBtnBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("erSiMeDarWiSiZuZuTeBeBtnBy"));
	private final By broschureDownloadBy = By.xpath(oiqdeDEPagesProperties.getProperty("broschureDownloadBy"));

	public void clickOncoDxRecScrTstBtn() {
		Element.loadAndClick(oncoDxRecScrTstBtnBy);
	}

	public void clickTestberichtLink() {
		Element.loadAndClick(testberichtLinkBy);
	}

	public void clickErSiMeDarWiSiZuZuTeBeBtn() {
		Element.loadAndClick(erSiMeDarWiSiZuZuTeBeBtnBy);
	}

	public void clickBroschureDownload() {
		Element.loadAndClick(broschureDownloadBy);
	}

}
