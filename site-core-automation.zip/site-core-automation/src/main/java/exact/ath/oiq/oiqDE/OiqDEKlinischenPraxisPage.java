package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEKlinischenPraxisPage extends ExactNavNavigation {

	private final String itemBy = oiqdeDEPagesProperties.getProperty("itemBy");
	private final By leSiMeZuklEvBeBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("leSiMeZuklEvBeBtnBy"));
	private final By mEHRBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("mEHRBtnBy"));

	public boolean isItemUnderlined(String sectionLabel) {
		return Element.isElementDisplayed(By.xpath(itemBy.replace("{sectionLabel}", sectionLabel)));
	}

	public void clickLeSiMeZuklEvBeBtn() {
		Element.loadAndClick(leSiMeZuklEvBeBtnBy);
	}

	public void clickMEHRBtn() {
		Element.loadAndClick(mEHRBtnBy);
	}

}
