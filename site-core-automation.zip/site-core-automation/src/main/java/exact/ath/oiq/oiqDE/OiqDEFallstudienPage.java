package exact.ath.oiq.oiqDE;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEFallstudienPage extends ExactNavNavigation {

	private final String filterOptionsBy = oiqdeDEPagesProperties.getProperty("filterOptionsBy");
	private final String filterOptionSelectionBy = oiqdeDEPagesProperties.getProperty("filterOptionSelectionBy");
	private final By pognVsPradBtnBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("pognVsPradBtnBy"));
	private final By nCCNGuidInsBrCanLinkBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("nCCNGuidInsBrCanLinkBy"));
	private final By nicDiaGuiDGLinkBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("nicDiaGuiDGLinkBy"));
	private final By veiwNowBtnBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("veiwNowBtnBy"));
	private final By einFalEinBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("einFalEinBtnBy"));

	public void selectFilterOption(String flterContent, String filterOption) {
		Element.loadAndClick(By.cssSelector(filterOptionsBy.replace("{filterOption}", filterOption)));
		logInfo("FILTER CONTENT: " + flterContent + ". selected its option: \"" + filterOption + "\"");
	}

	public void selectFilterOptionDropDown(String flterContent, String filterOption) {
		Element.loadAndClick(By.cssSelector(filterOptionSelectionBy.replace("{filterOption}", filterOption)));
		logInfo("FILTER CONTENT: " + flterContent + ". selected its option: \"" + filterOption + "\"");
	}

	public void clickNCCNGuidInsBrCanLink() {
		Element.loadAndClick(nCCNGuidInsBrCanLinkBy);
	}

	public void clickNicDiaGuiDGLink() {
		Element.loadAndClick(nicDiaGuiDGLinkBy);
	}

	public void clickViewNowBtn() {
		Element.loadAndClick(veiwNowBtnBy);
	}

	public void clickEinFalEinBtn() {
		Element.loadAndClick(einFalEinBtnBy);
	}

}