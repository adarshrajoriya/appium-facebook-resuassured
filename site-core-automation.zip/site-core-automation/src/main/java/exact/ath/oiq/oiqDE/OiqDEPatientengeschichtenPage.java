package exact.ath.oiq.oiqDE;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class OiqDEPatientengeschichtenPage extends ExactNavNavigation {

	private final By storyTitleBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("storyTitleBy"));
	private final By horenPodcastBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("horenPodcastBtnBy"));

	public void clickStoryNameLink(String storyTitle) throws Exception {
		List<WebElement> listElements = Element.getMultiple(storyTitleBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(storyTitle)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked 'Story Title:' '" + storyTitle + "'");
				logInfo("Redirected to 'Story Content:' '" + storyTitle + "'");
				return;
			}
		}

		throw new Exception("Unable to find '" + storyTitle + "' option " + BasicUtils.takeScreenshot());

	}

	public void clickHorenPodcastBtn() {
		Element.loadAndClick(horenPodcastBtnBy);
	}

}
