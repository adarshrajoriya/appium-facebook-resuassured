package exact.ath.oiq.oiqDE;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEPatientenprofilPage extends ExactNavNavigation {

	private final By startBtnBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("startBtnBy"));
	private final String patientenprofilFilterOptionBy = oiqdeDEPagesProperties
			.getProperty("patientenprofilFilterOptionBy");
	private final By createProfileButtonBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("createProfileButtonBy"));
	private final By patientenprofil2ndSlideBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("patientenprofil2ndSlideBy"));
	private final By getInTouchBtnBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("getInTouchBtnBy"));
	private final By resetProfilesBtnBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("resetProfilesBtnBy"));
	private final By patientenprofil2ndSlideDisplayedBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("patientenprofil2ndSlideDisplayedBy"));

	public void clickStartBtnBy() {
		Element.loadAndClick(startBtnBy);
	}

	public void selectFilterOption(String flterContent, String filterOption) {
		Element.loadAndClick(By.cssSelector(patientenprofilFilterOptionBy.replace("{filterOption}", filterOption)));
		logInfo("FILTER CONTENT: " + flterContent + ". selected its option: \"" + filterOption + "\"");
	}

	public void clickCreateProfileBtn() {
		Element.loadAndClick(createProfileButtonBy);
	}

	public void click2ndSlideBtn() {
		Element.loadAndClick(patientenprofil2ndSlideBy);
	}

	public void clickGetInTouchBtn() {
		Element.loadAndClick(getInTouchBtnBy);
	}

	public void clickResetProfilesBtn() {
		Element.loadAndClick(resetProfilesBtnBy);
	}

	public boolean is2ndSlideDisplayed() {
		return Element.isElementDisplayed(patientenprofil2ndSlideDisplayedBy);
	}

}
