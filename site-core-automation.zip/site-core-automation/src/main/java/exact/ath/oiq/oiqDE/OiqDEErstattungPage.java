package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEErstattungPage extends ExactNavNavigation {

	private final By oncotypeDxLoginLinkBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("oncotypeDxLoginLinkBy"));
	private final By oncotypeDxBrustLinkBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("oncotypeDxBrustLinkBy"));

	public void clickOncotypeDxLoginLink() {
		Element.loadAndClick(oncotypeDxLoginLinkBy);
	}

	public void clickOncotypeDxBrustLink() {
		Element.loadAndClick(oncotypeDxBrustLinkBy);
	}

}