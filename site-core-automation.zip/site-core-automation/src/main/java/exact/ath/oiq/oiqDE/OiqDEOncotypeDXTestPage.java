package exact.ath.oiq.oiqDE;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class OiqDEOncotypeDXTestPage extends ExactNavNavigation {

	private final By denUntVerBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("denUntVerBtnBy"));
	private final By weInZuInBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("weInZuInBtnBy"));
	private final By leSiHiWeBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("leSiHiWeBtnBy"));
	private final By leSiHiBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("leSiHiBtnBy"));
	private final By tAILORxARTIKELBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("tAILORxARTIKELBtnBy"));
	private final By planBARTIKELBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("planBARTIKELBtnBy"));
	private final By brustkrebsARTIKELBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("brustkrebsARTIKELBtnBy"));
	private final By weInZuSeDeRisBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("weInZuSeDeRisBtnBy"));
	private final By fieldHeadingBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("fieldHeadingBy"));
	private final By toggleContentBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("toggleContentBy"));

	public boolean isAccordionExpanded() {
		return Element.isElementDisplayed(toggleContentBy);
	}

	public void clickDenUntVerBtn() {
		Element.loadAndClick(denUntVerBtnBy);
	}

	public void clickWeInZuInrBtn() {
		Element.loadAndClick(weInZuInBtnBy);
	}

	public void clickLeSiHiWeBtn() {
		Element.loadAndClick(leSiHiWeBtnBy);
	}

	public void clickLeSiHiBtn() {
		Element.loadAndClick(leSiHiBtnBy);
	}

	public void clickTAILORxARTIKELBtn() {
		Element.loadAndClick(tAILORxARTIKELBtnBy);
	}

	public void clickPlanBARTIKELBtn() {
		Element.loadAndClick(planBARTIKELBtnBy);
	}

	public void clickBrustkrebsARTIKELBtn() {
		Element.loadAndClick(brustkrebsARTIKELBtnBy);
	}

	public void clickWeInZuSeUbVoNegPatPageBtn() {
		Element.loadAndClick(weInZuSeDeRisBtnBy);
	}

	public void clickDEAccordian(String option) throws Exception {
		List<WebElement> listElements = Element.getMultiple(fieldHeadingBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(option)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + option + "' accordion");
				return;
			}
		}
		throw new Exception("Unable to find '" + option + "' accordion " + BasicUtils.takeScreenshot());

	}

}
