package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDETestergebnissePage extends ExactNavNavigation {

	private final By patientinnenLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("patientinnenLinkBy"));
	private final By erSiMeUbEiUnTeBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("erSiMeUbEiUnTeBtnBy"));

	public void clickPatientinnenLink() {
		Element.loadAndClick(patientinnenLinkBy);
	}

	public void clickErSiMeUbEiUnTeBtn() {
		Element.loadAndClick(erSiMeUbEiUnTeBtnBy);
	}

}
