package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEUberDenTestPage extends ExactNavNavigation {

	private final By fiSiHeTestGeeignetBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("fiSiHeTestGeeignetBtnBy"));
	private final By erSiMeUBTestergebnisseBtnBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("erSiMeUBTestergebnisseBtnBy"));
	private final By mehrInfoFindenBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("mehrInfoFindenBtnBy"));
	private final By klickenBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("klickenBtnBy"));

	public void clickFiSiHeTestGeeignetBtn() {
		Element.loadAndClick(fiSiHeTestGeeignetBtnBy);
	}

	public void clickErSiMeUBTestergebnisseBtn() {
		Element.loadAndClick(erSiMeUBTestergebnisseBtnBy);
	}

	public void clickMehrInfoFindenBtn() {
		Element.loadAndClick(mehrInfoFindenBtnBy);
	}

	public void clickKlickenBtn() {
		Element.loadAndClick(klickenBtnBy);
	}

}
