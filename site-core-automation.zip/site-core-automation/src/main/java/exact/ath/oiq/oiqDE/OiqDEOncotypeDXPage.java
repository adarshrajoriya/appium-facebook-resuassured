package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEOncotypeDXPage extends ExactNavNavigation {

	private final By sieNccLeiBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("sieNccLeiBtnBy"));
	private final By iqwPReLesBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("iqwPReLesBtnBy"));
	private final By nicEmpAufBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("nicEmpAufBtnBy"));
	private final By klinischeEvidenzNodNegBtnBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("klinischeEvidenzNodNegBtnBy"));
	private final By klinischeEvidenzNodPosBtnBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("klinischeEvidenzNodPosBtnBy"));

	public void clickSieNccLeiBtn() {
		Element.loadAndClick(sieNccLeiBtnBy);
	}

	public void clickIqwPReLesBtn() {
		Element.loadAndClick(iqwPReLesBtnBy);
	}

	public void clickNicEmpAufBtn() {
		Element.loadAndClick(nicEmpAufBtnBy);
	}

	public void clickKlinischeEvidenzNodNegBtn() {
		Element.loadAndClick(klinischeEvidenzNodNegBtnBy);
	}

	public void clickKlinischeEvidenzNodPosBtn() {
		Element.loadAndClick(klinischeEvidenzNodPosBtnBy);
	}

}
