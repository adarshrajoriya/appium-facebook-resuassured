package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class OiqDEInterpretierenPage extends ExactNavNavigation {

	private final By oriZumBerStaBtnBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("oriZumBerStaBtnBy"));
	private final By closeReportGuideBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("closeReportGuideBy"));
	private final By nodalNegBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("nodalNegBtnBy"));
	private final By nodalPosBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("nodalPosBtnBy"));

	public boolean isOriZumBerStaImageDisplayed() {
		Sleeper.sleepTightInSeconds(4);
		return Element.isElementDisplayed(closeReportGuideBy);
	}

	public void clickOriZumBerStaBtn() {
		Element.loadAndClick(oriZumBerStaBtnBy);
	}

	public void clickCloseImage() {
		Element.loadAndClick(closeReportGuideBy);
	}

	public void clickNodalNegBtn() {
		Element.loadAndClick(nodalNegBtnBy);
	}

	public void clickNodalPosBtn() {
		Element.loadAndClick(nodalPosBtnBy);
	}

}