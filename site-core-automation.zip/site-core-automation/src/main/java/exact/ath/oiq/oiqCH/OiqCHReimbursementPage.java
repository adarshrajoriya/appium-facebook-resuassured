package exact.ath.oiq.oiqCH;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqCHReimbursementPage extends ExactNavNavigation {

	private final By oPASLinkBy = By.xpath(oiqenCHPagesProperties.getProperty("oPASLinkBy"));
	private final By ordonnanceDuDFILinkBy = By.xpath(oiqenCHPagesProperties.getProperty("ordonnanceDuDFILinkBy"));
	private final By kLVLinkBy = By.xpath(oiqenCHPagesProperties.getProperty("kLVLinkBy"));
	private final By verordnungKLVLinkBy = By.xpath(oiqenCHPagesProperties.getProperty("verordnungKLVLinkBy"));
	private final By enSavoirPlusBtnBy = By.xpath(oiqenCHPagesProperties.getProperty("enSavoirPlusBtnBy"));
	private final By erfahrenSieMehrBtnBy = By.xpath(oiqenCHPagesProperties.getProperty("erfahrenSieMehrBtnBy"));

	public void clickOPASLink() {
		Element.loadAndClick(oPASLinkBy);
	}

	public void clickOrdonnanceDuDFILink() {
		Element.loadAndClick(ordonnanceDuDFILinkBy);
	}

	public void clickKLVLink() {
		Element.loadAndClick(kLVLinkBy);
	}

	public void clickVerordnungKLVLink() {
		Element.loadAndClick(verordnungKLVLinkBy);
	}

	public void clickEnSavoirPlusBtn() {
		Element.loadAndClick(enSavoirPlusBtnBy);
	}

	public void clickErfahrenSieMehrBtn() {
		Element.loadAndClick(erfahrenSieMehrBtnBy);
	}

}
