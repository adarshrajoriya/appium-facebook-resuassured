package exact.ath.oiq.oiqCH;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.sys.DriverManager;
import exact.util.Sleeper;

public class OiqCHHomePage extends ExactNavNavigation {

	private final String searchIcon = oiqenCHPagesProperties.getProperty("searchIconBy");

	private final By oiqPageTittleBy = By.cssSelector(oiqenCHPagesProperties.getProperty("oiqPageTittleBy"));
	private final By oncotypeDxLogoBy = By.cssSelector(oiqenCHPagesProperties.getProperty("oncotypeDxLogoBy"));
	private final By popupHeadingTextBy = By.cssSelector(oiqenCHPagesProperties.getProperty("popupHeadingTextBy"));
	private final By popupbutton1By = By.cssSelector(oiqenCHPagesProperties.getProperty("popupbutton1By"));
	private final By popupbutton2By = By.cssSelector(oiqenCHPagesProperties.getProperty("popupbutton2By"));
	private final By popupClosebuttonBy = By.cssSelector(oiqenCHPagesProperties.getProperty("popupClosebuttonBy"));
	private final By patientProfileNavigatorBy = By
			.cssSelector(oiqenCHPagesProperties.getProperty("patientProfileNavigatorBy"));
	private final By searchBoxInputBy = By.cssSelector(oiqenCHPagesProperties.getProperty("searchBoxInputBy"));

	private final By pageTitleBy = By.cssSelector(oiqenCHPagesProperties.getProperty("pageTitleBy"));
	private final By profileHeaderBy = By.cssSelector(oiqenCHPagesProperties.getProperty("profileHeaderBy"));
	private final By orderingPortalBtnBy = By.xpath(oiqenCHPagesProperties.getProperty("orderingPortalBtnBy"));
	private final By iconCard1By = By.cssSelector(oiqenCHPagesProperties.getProperty("iconCard1By"));
	private final By iconCard2By = By.cssSelector(oiqenCHPagesProperties.getProperty("iconCard2By"));
	private final By visitOurVirtualBoothLinkBy = By
			.xpath(oiqenCHPagesProperties.getProperty("visitOurVirtualBoothLinkBy"));
	private final By enSavoirPlusLinkBy = By.xpath(oiqenCHPagesProperties.getProperty("enSavoirPlusLinkBy"));
	private final By meherErfahrenLinkBy = By.xpath(oiqenCHPagesProperties.getProperty("meherErfahrenLinkBy"));
	private final By getInTouchBtnBy = By.xpath(oiqenCHPagesProperties.getProperty("getInTouchBtnBy"));
	private final By followUsBy = By.xpath(oiqenCHPagesProperties.getProperty("followUsBy"));
	private final By headerOption1By = By.cssSelector(oiqenCHPagesProperties.getProperty("headerOption1By"));
	private final By headerOption2By = By.cssSelector(oiqenCHPagesProperties.getProperty("headerOption2By"));
	private final By headerOption3By = By.cssSelector(oiqenCHPagesProperties.getProperty("headerOption3By"));
	private final By headerOption4By = By.cssSelector(oiqenCHPagesProperties.getProperty("headerOption4By"));

	public String getOiqPageTitle() {
		return Element.getElementText(oiqPageTittleBy);
	}

//	public String getpopupHeading() {
//		return Element.getElementText(popupHeadingTextBy);
//	}

	public String getPageTitle() {
		return Element.getElementText(pageTitleBy);
	}

	public String getProfileHeaderTitle() {
		return Element.getElementText(profileHeaderBy);
	}

	public String enterSearchBoxText(String value) {
		return Element.enterText(searchBoxInputBy, value);
	}

	public void clickOncotypeDxLogo() {
		Element.loadAndClick(oncotypeDxLogoBy);
	}

	public void clickpopupbutton1(String optionToClick) {
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(3);
		if (Element.isElementDisplayed(popupbutton1By)) {
			Element.loadAndClick(popupbutton1By);
			logInfo("Clicked on '" + optionToClick + "' option");
		}
	}

	public void clickpopupbutton2(String optionToClick) {
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(3);
		if (Element.isElementDisplayed(popupbutton2By)) {
			Element.loadAndClick(popupbutton2By);
			logInfo("Clicked on '" + optionToClick + "' option");
		}
	}

	public void clickpopupWeiAngMedFacOption() {
		Element.loadAndClick(popupbutton1By);
		logInfo("Clicked on 'Weiter – ich bin Angehöriger der Medizinischen Fachkreise' option");
	}

	public void clickpopupFürPatientenOption() {
		Element.loadAndClick(popupbutton2By);
		logInfo("Clicked on 'FÜR PATIENTEN' option");
	}

	public void clickpopupClosebutton() {
		Element.loadAndClick(popupClosebuttonBy);
	}

	public void clickPatientProfileNavigator() {
		Element.loadAndClick(patientProfileNavigatorBy);
	}

	public void clickOrderingPortalBtn() {
		Element.loadAndClick(orderingPortalBtnBy);
	}

	public void clickIconCard1() {
		Element.loadAndClick(iconCard1By);
	}

	public void clickIconCard2() {
		Element.loadAndClick(iconCard2By);
	}

	public void clickVirtualBoothLink() {
		Element.loadAndClick(visitOurVirtualBoothLinkBy);
	}

	public void clickEnSavoirPlusLink() {
		Element.loadAndClick(enSavoirPlusLinkBy);
	}

	public void clickMeherErfahrenLink() {
		Element.loadAndClick(meherErfahrenLinkBy);
	}

	public void clickGetInTouchBtn() {
		Element.loadAndClick(getInTouchBtnBy);
	}

	public void clickFollowUsBtn() {
		Element.loadAndClick(followUsBy);
	}

	public void clickHeaderOption1() {
		Element.loadAndClick(headerOption1By);
	}

	public void clickHeaderOption2() {
		Element.loadAndClick(headerOption2By);
	}

	public void clickHeaderOption3() {
		Element.loadAndClick(headerOption3By);
	}

	public void clickHeaderOption4() {
		Element.loadAndClick(headerOption4By);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(3);

	}

	public void clickSearchIcon() {
		((JavascriptExecutor) DriverManager.getCurrent())
				.executeScript("document.querySelector(arguments[0],':after').click();", searchIcon);
	}

	public boolean isGetInTouchBtnDisplayed() {
		return Element.isElementDisplayed(getInTouchBtnBy);
	}

	public boolean isFollowUsBtnDisplayed() {
		return Element.isElementDisplayed(followUsBy);
	}

}
