package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEKlinischeEvidenzPage extends ExactNavNavigation {

	private final By erSiMeUbUnZwPrPrLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("erSiMeUbUnZwPrPrLinkBy"));
	private final By viWiInLeLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("viWiInLeLinkBy"));
	private final By viWiInLeLinkABy = By.xpath(oiqdeDEPagesProperties.getProperty("viWiInLeLinkABy"));
	private final By besSieDenTesBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("besSieDenTesBtnBy"));
	private final By konSieUnsBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("konSieUnsBtnBy"));
	private final By konSieUnsBtnH2By = By.xpath(oiqdeDEPagesProperties.getProperty("konSieUnsBtnH2By"));
	private final By konSieUnsPREHdrBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("konSieUnsPREHdrBtnBy"));
	private final By klinischeValidierungPosARTIKELBtnBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("klinischeValidierungPosARTIKELBtnBy"));
	private final By klinischeValidierungNegARTIKELBtnBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("klinischeValidierungNegARTIKELBtnBy"));

	public void clickErSiMeUbUnZwPrPrLink() {
		Element.loadAndClick(erSiMeUbUnZwPrPrLinkBy);
	}

	public void clickViWiInLeLink() {
		Element.loadAndClick(viWiInLeLinkBy);
	}

	public void clickViWiInLeLinkA() {
		Element.loadAndClick(viWiInLeLinkABy);
	}

	public void clickBesSieDenTesBtn() {
		Element.loadAndClick(besSieDenTesBtnBy);
	}

	public void clickKonSieUnsBtn() {
		Element.loadAndClick(konSieUnsBtnBy);
	}

	public void clickKonSieUnsH2Btn() {
		Element.loadAndClick(konSieUnsBtnH2By);
	}

	public void clickKonSieUnsPREHdrBtn() {
		Element.loadAndClick(konSieUnsPREHdrBtnBy);
	}

	public void clickKlinischeValidierungPosARTIKELBtn() {
		Element.loadAndClick(klinischeValidierungPosARTIKELBtnBy);
	}

	public void clickKlinischeValidierungNegARTIKELBtn() {
		Element.loadAndClick(klinischeValidierungNegARTIKELBtnBy);
	}

}
