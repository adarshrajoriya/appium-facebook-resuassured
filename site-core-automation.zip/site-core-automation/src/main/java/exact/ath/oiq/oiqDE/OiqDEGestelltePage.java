package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEGestelltePage extends ExactNavNavigation {

	private final By funktioniertLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("funktioniertLinkBy"));
	private final By testergebnisLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("testergebnisLinkBy"));
	private final By geeignetLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("geeignetLinkBy"));
	private final By erfBehBruFruOncTstLinkBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("erfBehBruFruOncTstLinkBy"));
	private final By patientenbroschüreLinkBy = By
			.xpath(oiqdeDEPagesProperties.getProperty("patientenbroschüreLinkBy"));
	private final By ergebnisseTAILORxLinkBy = By.xpath(oiqdeDEPagesProperties.getProperty("ergebnisseTAILORxLinkBy"));

	public void clickFunktioniertLink() {
		Element.loadAndClick(funktioniertLinkBy);
	}

	public void clickTestergebnisseBtn() {
		Element.loadAndClick(testergebnisLinkBy);
	}

	public void clickGeeignetLink() {
		Element.loadAndClick(geeignetLinkBy);
	}

	public void clickErfBehBruFruOncTstLink() {
		Element.loadAndClick(erfBehBruFruOncTstLinkBy);
	}

	public void clickPatientenbroschüreLink() {
		Element.loadAndClick(patientenbroschüreLinkBy);
	}

	public void clickErgebnisseTAILORxLink() {
		Element.loadAndClick(ergebnisseTAILORxLinkBy);
	}

}
