package exact.ath.oiq.oiqCH;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class OiqCHContactUsPage extends ExactNavNavigation {

	private final By submitBtnBy = By.cssSelector(oiqenCHPagesProperties.getProperty("submitBtnBy"));
	private final By errorMessageBy = By.cssSelector(oiqenCHPagesProperties.getProperty("errorMessageBy"));
	private final By countryCHSelectedBy = By.cssSelector(oiqenCHPagesProperties.getProperty("countryCHSelectedBy"));
	private final By countryDESelectedBy = By.cssSelector(oiqenCHPagesProperties.getProperty("countryDESelectedBy"));
	private final By countryCHContactBy = By.cssSelector(oiqenCHPagesProperties.getProperty("countryCHContactBy"));
	private final By phoneFieldBy = By.cssSelector(oiqenCHPagesProperties.getProperty("phoneFieldBy"));
	private final By submitFormMessageBy = By.cssSelector(oiqenCHPagesProperties.getProperty("submitFormMessageBy"));

	public void clickSubmitBtnBy() {
		Element.loadAndClick(submitBtnBy);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(5);
	}

	public boolean isErrorMessageDisplayed() {
		return Element.isElementDisplayed(errorMessageBy);
	}

	public boolean isCountryCHSelected() {
		return Element.isElementDisplayed(countryCHSelectedBy);
	}

	public boolean isCountryDESelected() {
		return Element.isElementDisplayed(countryDESelectedBy);
	}

	public boolean isCountryCHContactDisplayed() {
		return Element.isElementDisplayed(countryCHContactBy);
	}

	public String getcountryCHContact() {
		return Element.getElementText(countryCHContactBy);
	}

	public void enterPhone(String phone) {
		Element.enterText(phoneFieldBy, phone);
	}

	public String getsubmitFormMessage() {
		return Element.getElementText(submitFormMessageBy);
	}

}
