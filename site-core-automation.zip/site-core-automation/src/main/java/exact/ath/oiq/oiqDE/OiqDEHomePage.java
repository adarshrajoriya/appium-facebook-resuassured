package exact.ath.oiq.oiqDE;

import exact.navigation.ExactNavNavigation;

public class OiqDEHomePage extends ExactNavNavigation {

}
