package exact.ath.oiq.oiqDE;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDETestenSolltePage extends ExactNavNavigation {

	private final By pognVsPradBtnBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("pognVsPradBtnBy"));
	private final By nCCNGuidInsBrCanLinkBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("nCCNGuidInsBrCanLinkBy"));
	private final By nicDiaGuiDGLinkBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("nicDiaGuiDGLinkBy"));

	public void clickPognVsPradBtn() {
		Element.loadAndClick(pognVsPradBtnBy);
	}

	public void clickNCCNGuidInsBrCanLink() {
		Element.loadAndClick(nCCNGuidInsBrCanLinkBy);
	}

	public void clickNicDiaGuiDGLink() {
		Element.loadAndClick(nicDiaGuiDGLinkBy);
	}

}
