package exact.ath.oiq.oiqDE;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OiqDEWebcastsPage extends ExactNavNavigation {

	private String videoOpenBtnBy = oiqdeDEPagesProperties.getProperty("videoOpenBtnBy");
	private final By videoTimeBy = By.xpath(oiqdeDEPagesProperties.getProperty("videoTimeBy"));
	private final By vedioPlayBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("vedioPlayBtnBy"));
	private final By vedioPauseBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("vedioPauseBtnBy"));
	private final By vedioHoverBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("vedioHoverBy"));
	private final By videoPlayerHoverBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("videoPlayerHoverBy"));
	private final By videoPlayerBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("videoPlayerBy"));
	private final By videoFrameBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("videoFrameBy"));
	private final By webcasts2ndPageLinkBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("webcasts2ndPageLinkBy"));
	private final By webcasts2ndPageDisplayedBy = By
			.cssSelector(oiqdeDEPagesProperties.getProperty("webcasts2ndPageDisplayedBy"));
	private final By abSofortOnDemandBtnBy = By.xpath(oiqdeDEPagesProperties.getProperty("abSofortOnDemandBtnBy"));

	public void clickVideo(String videoName) {
		Element.loadAndClick(By.xpath(videoOpenBtnBy.replace("{videoLabel}", videoName)));
		logInfo("Opened Video: " + videoName + "");
	}

	public String getVideoTime() {
		return Element.getElementText(videoTimeBy);
	}

	public void clickPlayButton() {
		Element.loadAndClick(vedioPlayBtnBy);
	}

	public void clickVideoPlayer() {
		Element.loadAndClick(videoPlayerBy);
	}

	public void videoHover() {
		Element.mouseHover(vedioHoverBy);
	}

	public void oiqVideoHover() {
		Element.mouseHover(videoPlayerHoverBy);
	}

	public void clickPauseButton() {
		Element.loadAndClick(vedioPauseBtnBy);
	}

	public void click2ndPageLink() {
		Element.loadAndClick(webcasts2ndPageLinkBy);
	}

	public void clickAbSofortOnDemandBtn() {
		Element.loadAndClick(abSofortOnDemandBtnBy);
	}

	public void switchToVideoFrame() {
		driver.switchToFrame(videoFrameBy);
	}

	public void switchToOIQVideoFrame() {
		driver.switchToFrame(videoPlayerBy);
	}

	public boolean is2ndPageDisplayed() {
		return Element.isElementDisplayed(webcasts2ndPageDisplayedBy);
	}

}
