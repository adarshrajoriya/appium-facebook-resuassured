package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class SchedulePickupPage extends ExactNavNavigation {

	private final By pickupDateBy = By.cssSelector(cologuardPagesProperties.getProperty("pickupDateBy"));
	private final By trackingNmbrBy = By.cssSelector(cologuardPagesProperties.getProperty("trackingNmbrBy"));
	private final By contactNameBy = By.cssSelector(cologuardPagesProperties.getProperty("contactNameBy"));
	private final By streetAddressBy = By.cssSelector(cologuardPagesProperties.getProperty("streetAddressBy"));
	private final By cityBy = By.cssSelector(cologuardPagesProperties.getProperty("cityBy"));
	private final By stateBy = By.cssSelector(cologuardPagesProperties.getProperty("stateBy"));
	private final By zipBy = By.cssSelector(cologuardPagesProperties.getProperty("zipBy"));
	private final By phnNmbrBy = By.cssSelector(cologuardPagesProperties.getProperty("phnNmbrBy"));
	private final By confirmationMsgBy = By.cssSelector(cologuardPagesProperties.getProperty("confirmationMsgBy"));
	private final By pickupRequestNmbrBy = By.cssSelector(cologuardPagesProperties.getProperty("pickupRequestNmbrBy"));
	private final By submitBtnBy = By.cssSelector(cologuardPagesProperties.getProperty("submitBtnBy"));

	public void enterPickupDate() {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 1);
		String date = new SimpleDateFormat("MM/dd/yyyy").format(c.getTime());
		Element.enterText(pickupDateBy, date);
		logInfo("Entered 'Pickup date': " + date);
	}

	public void enterTrackingNumber(String trackingNumber) {
		Element.enterText(trackingNmbrBy, trackingNumber);
		Element.waitForDOMToLoad();
		logInfo("Entered 'Tracking Number': " + trackingNumber);
	}

	public void enterContactName(String contactName) {
		Element.enterText(contactNameBy, contactName);
		Element.waitForDOMToLoad();
		logInfo("Entered 'Contact name': " + contactName);
	}

	public void enterStreetAddress(String streetAddress) {
		Element.enterText(streetAddressBy, streetAddress);
		Element.waitForDOMToLoad();
		logInfo("Entered 'Street Address': " + streetAddress);
	}

	public void enterCity(String city) {
		Element.enterText(cityBy, city);
		Element.waitForDOMToLoad();
		logInfo("Entered 'Pity': " + city);
	}

	public void selectState(String state) {
		Select select = new Select(Element.waitForVisible(stateBy));
		select.selectByVisibleText(state);
		Element.waitForDOMToLoad();
		logInfo("Selected 'State': " + state);
	}

	public void enterZIPCode(String zip) {
		Element.enterText(zipBy, zip);
		Element.waitForDOMToLoad();
		logInfo("Entered 'ZIP': " + zip);
	}

	public void enterPhoneNumber(String phoneNumber) {
		Element.enterText(phnNmbrBy, phoneNumber);
		Element.waitForDOMToLoad();
		logInfo("Entered 'Phone Number': " + phoneNumber);
	}

	public boolean isPickupConfirmationMessageDisplayed() {
		return Element.isElementDisplayed(confirmationMsgBy);
	}

	public String getUPSPickupRequestNumber() {
		return Element.getText(pickupRequestNmbrBy);
	}

	public void clickSubmitBtn() {
		Element.loadAndClick(submitBtnBy);
		Element.waitForDisappear(submitBtnBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked Submit button");
	}
}
