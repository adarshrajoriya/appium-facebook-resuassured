package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class HowToGetCologuardPage extends ExactNavNavigation {

	private final By requestCologuardOnlineLabelBy = By
			.linkText(cologuardPagesProperties.getProperty("requestCologuardOnlineLabel"));
	private final By getDiscussionGuideLabelBy = By
			.linkText(cologuardPagesProperties.getProperty("getDiscussionGuideLabel"));

	private final By howToUseCologuardBy = By.cssSelector(cologuardPagesProperties.getProperty("howToUseCologuardBy"));
	private final By signupNowBy = By.cssSelector(cologuardPagesProperties.getProperty("signupNowBy"));

	public void clickRequestCologuardOnlineLink() {
		Element.loadAndClick(requestCologuardOnlineLabelBy);
		driver.switchToCurrentWindow();
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Request Colouard online' link");
	}

	public void clickGetDiscussionGuideLink() {
		Element.loadAndClick(getDiscussionGuideLabelBy);
		driver.switchToCurrentWindow();
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Get Disucssion guide' link");
	}

	public void clickHowToUseCologuard() {
		Element.loadAndClick(howToUseCologuardBy);
		logInfo("Clicked on 'How to use Cologuard' link");
	}

	public void clickSignupNow() {
		Element.loadAndClick(signupNowBy);
		logInfo("Clicked on 'Sign up now' link");
	}
}
