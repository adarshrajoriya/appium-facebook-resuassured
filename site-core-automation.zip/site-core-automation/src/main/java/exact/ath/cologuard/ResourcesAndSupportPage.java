package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class ResourcesAndSupportPage extends ExactNavNavigation {

	private final By playVideoButtonBy = By.xpath(cologuardPagesProperties.getProperty("playVideoButtonSelector"));

	private final By loginInToAccountLinkBy = By
			.xpath(cologuardPagesProperties.getProperty("loginInToAccountLinkSelector"));

	private final By downloadPatientBrochureBy = By
			.xpath(cologuardPagesProperties.getProperty("downloadPatientBrochureSelector"));

	private final By downloadDoctorDiscussionGuideBrochureBy = By
			.xpath(cologuardPagesProperties.getProperty("downloadDoctorDiscussionGuideBrochureSelector"));

	private final By downloadPatientGuideBrochureBy = By
			.xpath(cologuardPagesProperties.getProperty("downloadPatientGuideBrochureSelector"));

	private final By downloadKitReturnInstructionsBrochureBy = By
			.xpath(cologuardPagesProperties.getProperty("downloadKitReturnInstructionsBrochureSelector"));

	private final By downloadCologuardBrochureBy = By
			.xpath(cologuardPagesProperties.getProperty("downloadCologuardBrochureSelector"));

	public void clickPlayVideoButton() {
		Element.loadAndClick(playVideoButtonBy);
		Element.waitForDOMToLoad();

	}

	public void clickLoginInToAccountLinkBy() {
		Element.loadAndClick(loginInToAccountLinkBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on  'Log in to your account' hyperlink");

	}

	public void clickDownloadPatientBrochure() {
		Element.loadAndClick(downloadPatientBrochureBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Download Patient Brochure' under 'Waiting for a Cologuard kit?'");

	}

	public void clickSelectAnotherLanguage(int resultLinkIndex) {
		Sleeper.sleepTightInSeconds(1);
		By resultLinksSelectorBy = By.xpath(cologuardPagesProperties.getProperty("selectAnotherLanguageSelector"));

		List<WebElement> elements = Element.getMultiple(resultLinksSelectorBy);

		Element.loadAndClick(elements.get(resultLinkIndex));
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Select another language' dropdown.");

	}

	public boolean isDropdownExpandsAndMultipleLanguageLinksDisplayed(int resultLinkIndex) {

		By resultLinksSelectorBy = By
				.xpath(cologuardPagesProperties.getProperty("dropdownExpandsAndMultipleLanguageLinksSelector"));

		List<WebElement> elements = Element.getMultiple(resultLinksSelectorBy);
		return Element.isElementDisplayed(elements.get(resultLinkIndex));

	}

	public void clickDownloadDoctorDiscussionGuideBrochure() {
		Element.loadAndClick(downloadDoctorDiscussionGuideBrochureBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Download Doctor Discussion Guide Brochure' under 'Ready to talk to a healthcare provider about Cologuard?'");
	}

	public void clickDownloadPatientGuideBrochure() {
		Element.loadAndClick(downloadPatientGuideBrochureBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Download Patient Guide Brochure' under 'Want to learn more about Cologuard?'");
	}

	public void clickDownloadKitReturnInstructionsBrochure() {
		Element.loadAndClick(downloadKitReturnInstructionsBrochureBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Download Kit Return Instructions Brochure' under 'Ready to return your Cologuard kit?'");
	}

	public void clickDownloadCologuardBrochure() {
		Element.loadAndClick(downloadCologuardBrochureBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Download Cologuard Brochure' under 'Considering Cologuard for yourself or a loved one?'");
	}

}
