package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class CologuardInsuranceAndBillingPage extends ExactNavNavigation {

	private final By accordionLinkBy = By.cssSelector(cologuardPagesProperties.getProperty("accordionLinkBy"));
	private final By closeAllBy = By.cssSelector(cologuardPagesProperties.getProperty("closeAllBy"));
	private final By openAllBy = By.cssSelector(cologuardPagesProperties.getProperty("openAllBy"));
	private final By accordionActiveBy = By.xpath(cologuardPagesProperties.getProperty("accordionActiveBy"));
	private final By readStoriesBy = By.cssSelector(cologuardPagesProperties.getProperty("readStoriesBy"));
	private final By seeResourcesAndSupportBy = By
			.cssSelector(cologuardPagesProperties.getProperty("seeResourcesAndSupportBy"));

	private final String accordionBodyBy = cologuardPagesProperties.getProperty("accordionBodyBy");

	public void closeAllAccordion() {
		Element.loadAndClick(closeAllBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Close all' accordion");
	}

	public void openAllAccordion() {
		Element.loadAndClick(openAllBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Open all' accordion");
	}

	public void clickReadStories() {
		Element.loadAndClick(readStoriesBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Read Stories' link");

	}

	public void clickSeeResourcesAndSupport() {
		Element.loadAndClick(seeResourcesAndSupportBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'See resources & support' link");
	}

	public void clickAccordionWithLabel(String label) {
		List<WebElement> elements = Element.getMultiple(accordionLinkBy);
		for (WebElement webElement : elements) {
			if (Element.getText(webElement).contains(label)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + label + "' accordion");
				return;
			}
		}
	}

	public boolean isAccordionSectionExpanded(String label) {
		By selector = By.xpath(accordionBodyBy.replace("{accordionLabel}", label));
		return Element.isElementDisplayed(selector);
	}

	public boolean areAccordionsOpen() {
		List<WebElement> accordions = Element.getMultiple(accordionActiveBy);
		List<Boolean> results = new ArrayList<>();

		for (WebElement webElement : accordions) {
			boolean currentElementResult = Element.isElementDisplayed(webElement);
			results.add(currentElementResult);
		}
		if (results.contains(false)) {
			return false;
		} else {
			return true;
		}
	}

	public boolean areAccordionsClosed() {
		List<WebElement> accordions = Element.getMultiple(accordionActiveBy);
		List<Boolean> results = new ArrayList<>();

		for (WebElement webElement : accordions) {
			boolean currentElementResult = Element.isElementDisplayed(webElement);
			results.add(currentElementResult);
		}
		if (results.contains(true)) {
			return false;
		} else {
			return true;
		}
	}
}
