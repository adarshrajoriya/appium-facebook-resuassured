package exact.ath.cologuard;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class PatientStoriesPage extends ExactNavNavigation {

	private final By meetScottPlayVideoBy = By
			.cssSelector(cologuardPagesProperties.getProperty("meetScottPlayVideoSelector"));
	private final By readMoreSpotlightPatientStoriesLinkBy = By
			.xpath(cologuardPagesProperties.getProperty("readMoreSpotlightPatientStoriesLinkBy"));
	private final By readMoreFeaturedPatientStoriesLinkBy = By
			.xpath(cologuardPagesProperties.getProperty("readMoreFeaturedPatientStoriesLinkBy"));
	private final By patientNamePageTitleBy = By
			.cssSelector(cologuardPagesProperties.getProperty("patientNamePageTitleBy"));
	private final By submitStoryBtnBy = By.xpath(cologuardPagesProperties.getProperty("submitStoryBtnBy"));
	private final By formPhoneFieldBy = By.xpath(cologuardPagesProperties.getProperty("formPhoneFieldBy"));
	private final By formYourExperienceFieldBy = By
			.xpath(cologuardPagesProperties.getProperty("formYourExperienceFieldBy"));
	private final By formYourExperienceFieldOptionSatisfiedBy = By
			.cssSelector(cologuardPagesProperties.getProperty("formYourExperienceFieldOptionSatisfiedBy"));
	private final By thankYouPageBy = By.xpath(cologuardPagesProperties.getProperty("thankYouPageBy"));
	private final By patientMoreStoriesBtnBy = By
			.cssSelector(cologuardPagesProperties.getProperty("patientMoreStoriesBtnBy"));
	private final String readMoreOtherPatientStoriesLinkBy = cologuardPagesProperties
			.getProperty("readMoreOtherPatientStoriesLinkBy");

	public PatientStoriesPage clickMeetScottPlayVideo() {
		Element.loadAndClick(meetScottPlayVideoBy);
		return this;
	}

	public PatientStoriesPage clickReadMoreSpotlightPatientStoriesLink() {
		Element.loadAndClick(readMoreSpotlightPatientStoriesLinkBy);
		Element.waitForDOMToLoad();
		return this;
	}

	public PatientStoriesPage clickReadMoreFeaturedPatientStoriesLink() {
		Element.loadAndClick(readMoreFeaturedPatientStoriesLinkBy);
		Element.waitForDOMToLoad();
		return this;
	}

	public PatientStoriesPage clickReadMoreOtherPatientStoriesLink(String sectionLabel) {
		Element.loadAndClick(By.xpath(readMoreOtherPatientStoriesLinkBy.replace("{sectionLabel}", sectionLabel)));
		Element.waitForDOMToLoad();
		return this;
	}

	public PatientStoriesPage clickMoreStoriesBtn() {
		Element.loadAndClick(patientMoreStoriesBtnBy);
		Element.waitForDOMToLoad();
		return this;
	}

	public PatientStoriesPage clickSubmitStoryBtn() {
		Element.loadAndClick(submitStoryBtnBy);
		Element.waitForDOMToLoad();
		return this;
	}

	public PatientStoriesPage selectYourExperience() {
		Element.loadAndClick(formYourExperienceFieldBy);
		Element.loadAndClick(formYourExperienceFieldOptionSatisfiedBy);
		return this;
	}

	public boolean isThankYouPageDisplayed() {
		return Element.isElementDisplayed(thankYouPageBy);
	}

	public String getPatientNamePageTitle() {
		return Element.getElementText(patientNamePageTitleBy);
	}

	public void enterPhoneNumber(String number) {
		Element.enterText(formPhoneFieldBy, number);
	}

}
