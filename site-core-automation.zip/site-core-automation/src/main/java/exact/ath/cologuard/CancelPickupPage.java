package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class CancelPickupPage extends ExactNavNavigation {

	private final By pickupRequestNmbrInputBy = By
			.cssSelector(cologuardPagesProperties.getProperty("pickupRequestNmbrInputBy"));
	private final By submitBtnBy = By.cssSelector(cologuardPagesProperties.getProperty("submitBtnBy"));
	private final By pickupCancellationMsgBy = By
			.cssSelector(cologuardPagesProperties.getProperty("pickupCancellationMsgBy"));

	public void enterRequestNumber(String requestNumber) {
		Element.enterText(pickupRequestNmbrInputBy, requestNumber);
		logInfo("Entered 'Pickup request number': " + requestNumber);
	}

	public void clickSubmitBtn() {
		Element.loadAndClick(submitBtnBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked Submit button");
	}

	public boolean isCancellationSuccessfulMsgDisplayed() {
		Sleeper.sleepTightInSeconds(2);
		return Element.isElementDisplayed(pickupCancellationMsgBy);
	}
}
