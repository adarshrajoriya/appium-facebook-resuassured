package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class FAQsPage extends ExactNavNavigation {
	private final By seeResourcesAndSupportBtnBy = By
			.cssSelector(cologuardPagesProperties.getProperty("seeResourcesAndSupportBtnBy"));
	private final By signUpNowBy = By.cssSelector(cologuardPagesProperties.getProperty("signupNowBy"));
	private final By searchInputFieldBy = By.cssSelector(cologuardPagesProperties.getProperty("searchInputFieldBy"));
	private final By searchResultsBy = By.cssSelector(cologuardPagesProperties.getProperty("searchResultsBy"));
	private final By openAllQuestionsBy = By.cssSelector(cologuardPagesProperties.getProperty("openAllQuestionsBy"));
	private final By closeAllQuestionsBy = By.cssSelector(cologuardPagesProperties.getProperty("closeAllQuestionsBy"));
	private final By accordionItemBy = By.cssSelector(cologuardPagesProperties.getProperty("accordionItemBy"));

	public void clickSeeResourcesAndSupportBtn() {
		Element.loadAndClick(seeResourcesAndSupportBtnBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on See resources & support button");
	}

	public void clickSignUpNowBtn() {
		Element.loadAndClick(signUpNowBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on Sign up now button");
	}

	public void expandAllAccordionsOneByOne() {
		List<WebElement> items = Element.getMultiple(accordionItemBy);
		for (WebElement webElement : items) {
			Element.loadAndClick(webElement);
			Sleeper.sleepTightInSeconds(2);
			Element.waitForDOMToLoad();
			logInfo("Expanding accordions one by one");
		}
	}

	private List<Boolean> getAccordionResultsStatus() {
		List<WebElement> items = Element.getMultiple(accordionItemBy);
		List<Boolean> results = new ArrayList<>();

		for (WebElement webElement : items) {
			if (webElement.getAttribute("class").contains("active")) {
				results.add(true);
			} else {
				results.add(false);
			}
		}
		return results;
	}

	public boolean areAllQuestionsExpanded() {
		return !getAccordionResultsStatus().contains(false);
	}

	public boolean areAllQuestionsCollapsed() {
		return !getAccordionResultsStatus().contains(true);
	}

	public FAQsPage search(String searchtext) {
		Element.enterText(searchInputFieldBy, searchtext);
		Sleeper.sleepTightInSeconds(2);
		logInfo("Searched for text '" + searchtext + "' on FAQs page");
		return this;
	}

	public String getFirstSearchResult() {
		return Element.getText(searchResultsBy);
	}

	public void clickOpenAllQuestions() {
		Element.loadAndClick(openAllQuestionsBy);
		Sleeper.sleepTightInSeconds(2);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Open All' Quesions");
	}

	public void clickCloseAllQuestions() {
		Element.loadAndClick(closeAllQuestionsBy);
		Sleeper.sleepTightInSeconds(2);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Close All' Quesions");
	}

}
