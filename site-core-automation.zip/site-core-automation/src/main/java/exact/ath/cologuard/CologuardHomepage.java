package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class CologuardHomepage extends ExactNavNavigation {

	private final By cologuardHomepageIconBy = By
			.cssSelector(cologuardPagesProperties.getProperty("cologuardHomepageIconBy"));
	private final By cologuardHompageNavBy = By
			.cssSelector(cologuardPagesProperties.getProperty("cologuardHompageNavBy"));
	private final By fieldLinksBy = By.cssSelector(cologuardPagesProperties.getProperty("fieldLinksBy"));
	private final By signUpForInfoBy = By.cssSelector(cologuardPagesProperties.getProperty("signUpForInfoBy"));
	private final By searchIconBy = By.cssSelector(cologuardPagesProperties.getProperty("searchIconBy"));
	private final By loginBtnBy = By.cssSelector(cologuardPagesProperties.getProperty("loginBtnBy"));
	private final By popularSearchesListBy = By
			.cssSelector(cologuardPagesProperties.getProperty("popularSearchesListBy"));

	private final By whyStartAt45By = By.cssSelector(cologuardPagesProperties.getProperty("whyStartAt45By"));
	private final By requestNowBy = By.cssSelector(cologuardPagesProperties.getProperty("requestNowBy"));
	private final By bannerItemBy = By.cssSelector(cologuardPagesProperties.getProperty("bannerItemBy"));
	private final By footerLinksPageBannerTextBy = By
			.xpath(cologuardPagesProperties.getProperty("FooterLinksPageBannerText"));
	private final By medWatchLinkBy = By.xpath(cologuardPagesProperties.getProperty("MedWatchLink"));

	public void clickLinkOnPage(String linkText) throws Exception {
		List<WebElement> listElements = Element.getMultiple(fieldLinksBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(linkText)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + linkText + "' link");
				return;
			}
		}
		throw new Exception("Unable to find '" + linkText + "' link on the page. - " + BasicUtils.takeScreenshot());
	}

	public void clickCologuardIcon() {
		Element.loadAndClick(cologuardHomepageIconBy);
		driver.switchToCurrentWindow();
		logInfo("Clicked on 'cologuard' icon");
	}

	public void clickSearchIcon() {
		Element.loadAndClick(searchIconBy);
		Element.waitForVisible(popularSearchesListBy);
		logInfo("Clicked on 'Search' icon");
	}

	public void clickSignUpForInformation() {
		Element.loadAndClick(signUpForInfoBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Sign up for information' link");
	}

	public boolean isSearchIconAndBoxDisplayed() {
		return Element.isElementDisplayed(searchIconBy);
	}

	public boolean isLoginBtnDisplayed() {
		return Element.isElementDisplayed(loginBtnBy);
	}

	public void clickLoginButton() {
		Element.loadAndClick(loginBtnBy);
		driver.switchToCurrentWindow();
		logInfo("Clicked on 'Login' button");
	}

	public boolean isHeaderOptionDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(cologuardHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public boolean isPopularSearchItemDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(popularSearchesListBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public boolean isSubItemDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(cologuardHompageSubOptionsBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public boolean isBannerItemDisplayed(String itemLabel) {
		List<WebElement> listElements = Element.getMultiple(bannerItemBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				return true;
			}
		}
		return false;
	}

	public void clickWhyStartAt45() {
		Element.loadAndClick(whyStartAt45By);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Why start at 45?' link");
	}

	public void clickRequestNow() {
		Element.loadAndClick(requestNowBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Request Now' link");
	}

	public void clickBannerItem(String itemLabel) throws Exception {
		List<WebElement> listElements = Element.getMultiple(bannerItemBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + itemLabel + "' banner item");
				return;
			}
		}
		throw new Exception("Unable to find '" + itemLabel + "' option in the banner below slides. - "
				+ BasicUtils.takeScreenshot());
	}

	public CologuardHomepage clickFooterLinks(String Count) {
		By footerLinksBy = By.xpath(cologuardPagesProperties.getProperty("FooterLinks") + "[" + Count + "]");
		Element.loadAndClick(footerLinksBy);
		return this;
	}

	public String getPageBannerText() {
		Element.waitForVisible(footerLinksPageBannerTextBy);
		return Element.getElementText(footerLinksPageBannerTextBy);
	}

	public String getFooterLinksText(String Count) {
		By footerLinksBy = By.xpath(cologuardPagesProperties.getProperty("FooterLinks") + "[" + Count + "]");
		Element.waitForVisible(footerLinksBy);
		return Element.getElementText(footerLinksBy);
	}

	public CologuardHomepage clickMedWatchLink() {
		Element.loadAndClick(medWatchLinkBy);
		return this;
	}
}
