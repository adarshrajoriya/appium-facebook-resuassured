package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class UnderstandingYourResultPage extends ExactNavNavigation {

	private final By negativeResultAccordion = By
			.xpath(cologuardPagesProperties.getProperty("negativeResultAccordionSelector"));

	private final By playNegativeResultVideo = By
			.cssSelector(cologuardPagesProperties.getProperty("playNegativeResultVideo"));

	private final By positiveResultAccordion = By
			.xpath(cologuardPagesProperties.getProperty("positiveResultAccordionSelector"));

	private final By loginButtonBy = By.xpath(cologuardPagesProperties.getProperty("loginButtonSelector"));

	public void clickNegativeResultAccordion() {
		Element.loadAndClick(negativeResultAccordion);
		logInfo("Clicked on 'Negative Result' accordion");
	}

	public void playNegativeResultVideo() {
		Element.loadAndClick(playNegativeResultVideo);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(5);
	}

	public void clickPositiveResultAccordion() {
		Element.loadAndClick(positiveResultAccordion);
		logInfo("Clicked on 'Positive Result' accordion");
	}

	public void clickLoginButtonBy() {
		Element.loadAndClick(loginButtonBy);
		logInfo("Clicked on  'Log in' button ");

	}

}
