package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class CollectingAndReturningYourSamplePage extends ExactNavNavigation {

	private final By playReadyToReturnVideo = By
			.cssSelector(cologuardPagesProperties.getProperty("playReadyToReturnVideo"));
	private final By schedulePickupBy = By.cssSelector(cologuardPagesProperties.getProperty("schedulePickupBy"));
	private final By dropOffAtUPSBy = By.cssSelector(cologuardPagesProperties.getProperty("dropOffAtUPSBy"));
	private final By englishShippingInstructionsBy = By
			.cssSelector(cologuardPagesProperties.getProperty("englishShippingInstructionsBy"));
	private final By toggleHeaderBy = By.cssSelector(cologuardPagesProperties.getProperty("toggleHeaderBy"));
	private final By cancelUPSPickupBy = By.cssSelector(cologuardPagesProperties.getProperty("cancelUPSPickupBy"));
	private final By understandingResultsBy = By
			.cssSelector(cologuardPagesProperties.getProperty("understandingResultsBy"));
	private final By readStoriesBy = By.cssSelector(cologuardPagesProperties.getProperty("readStoriesBy"));

	private final String accordionBody = cologuardPagesProperties.getProperty("accordionBodyBy");

	public void playReadyToReturnYourKitVideo() {
		Element.loadAndClick(playReadyToReturnVideo);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(5);
	}

	public SchedulePickupPage clickSchedulePickup() {
		Element.loadAndClick(schedulePickupBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked Schedule Pickup button");
		return new SchedulePickupPage();
	}

	public StoreLocatorPage clickDropOffAtUPSBtn() {
		Element.loadAndClick(dropOffAtUPSBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked 'Drop off at UPS' button under 'Return your kit two ways'");
		return new StoreLocatorPage();
	}

	public void clickDownloadShippingInstructions(String language) throws Exception {
		List<WebElement> elements = Element.getMultiple(englishShippingInstructionsBy);
		for (WebElement webElement : elements) {
			if (Element.getText(webElement).equalsIgnoreCase(language)) {
				Element.loadAndClick(webElement);
				driver.switchToCurrentWindow();
				Element.waitForDOMToLoad();
				logInfo("Clicked '" + language + "' shipping instructions link");
				return;
			}
		}
		throw new Exception("Cannot find '" + language + "' download link for downloading shipping instructions");
	}

	public void expandAccordion(String accordionLabel) throws Exception {
		List<WebElement> elements = Element.getMultiple(toggleHeaderBy);
		for (WebElement webElement : elements) {
			if (Element.getText(webElement).equalsIgnoreCase(accordionLabel)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Expanded " + accordionLabel + " accordion");
				return;
			}
		}
		throw new Exception("Cannot find '" + accordionLabel + "' accordion on the page");
	}

	public boolean isAccordionExpanded(String accordionLabel) {
		By accordionBodyBy = By.xpath(accordionBody.replace("{accordionLabel}", accordionLabel));
		return Element.isElementDisplayed(accordionBodyBy);
	}

	public CancelPickupPage clickCancelUPSPickup() {
		Element.loadAndClick(cancelUPSPickupBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked 'Cancel UPS Pickup'");
		return new CancelPickupPage();
	}

	public void clickUnderstandingResults() {
		Element.loadAndClick(understandingResultsBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked 'Understanding results' button");
	}

	public void clickReadStoriesBtn() {
		Element.loadAndClick(readStoriesBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked 'Read Stories' button");
	}

}
