package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class CGStartScreeningAt45Page extends ExactNavNavigation {

	private final By learnMoreLinkBy = By.cssSelector(cologuardPagesProperties.getProperty("learnMoreLinkBy"));
	private final By getTheConversationStartedLinkBy = By
			.cssSelector(cologuardPagesProperties.getProperty("getTheConversationStartedLinkBy"));

	public void clickLearnMoreLink() {
		Element.loadAndClick(learnMoreLinkBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Learn More' link");
	}

	public void clickGetTheConversationStartedLink() {
		Element.loadAndClick(getTheConversationStartedLinkBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked 'Get The Conversation Started' link");
	}

}
