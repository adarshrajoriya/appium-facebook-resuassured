package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class CGAffordablePage extends ExactNavNavigation {

	private final By appealsPageBy = By.cssSelector(cologuardPagesProperties.getProperty("appealsPageBy"));
	private final By referencesLinkBy = By.cssSelector(cologuardPagesProperties.getProperty("referencesLinkBy"));
	private final By moreAboutRequestingCGBy = By
			.cssSelector(cologuardPagesProperties.getProperty("moreAboutRequestingCGBy"));
	private final By cologuardAndInsuranceBy = By
			.cssSelector(cologuardPagesProperties.getProperty("cologuardAndInsuranceBy"));
	private final By affordableReadMoreLinkBy = By
			.cssSelector(cologuardPagesProperties.getProperty("affordableReadMoreLinkBy"));
	private final By affordableReadLessLinkBy = By
			.xpath(cologuardPagesProperties.getProperty("affordableReadLessLinkBy"));

	public void clickAppealsPage() {
		Element.loadAndClick(appealsPageBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Appeal' page");
	}

	@Override
	public void clickReadMoreLink() {
		Element.loadAndClick(affordableReadMoreLinkBy);
		logInfo("Clicked on 'Read More' link");
	}

	@Override
	public boolean isReadLessDisplayed() {
		return Element.isElementDisplayed(affordableReadLessLinkBy);
	}

	public void clickReferencesLink() {
		Element.loadAndClick(referencesLinkBy);
		driver.switchToCurrentWindow();
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'References' link");
	}

	public void clickMoreAboutRequestingCG() {
		Element.loadAndClick(moreAboutRequestingCGBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'More About Requesting CG' link");
	}

	public void clickCologuardAndInsurance() {
		Element.loadAndClick(cologuardAndInsuranceBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Cologuard And Insurance' link");
	}
}
