package exact.ath.cologuard;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class TheCologuardDifferencePage extends ExactNavNavigation {

	private final By readOurPatientStoriesBtnBy = By
			.cssSelector(cologuardPagesProperties.getProperty("readOurPatientStoriesBtnBy"));

	public TheCologuardDifferencePage clickReadOurPatientStoriesBtn() {
		Element.loadAndClick(readOurPatientStoriesBtnBy);
		Element.waitForDOMToLoad();
		return this;
	}

	private final By theCologuardDifferenceVideoBy = By
			.cssSelector(cologuardPagesProperties.getProperty("theCologuardDifferenceVideoSelector"));

	private final By theScienceBehindCologuardVideoBy = By
			.cssSelector(cologuardPagesProperties.getProperty("theScienceBehindCologuardVideoSelector"));

	public TheCologuardDifferencePage clickTheCologuardDifferenceVideo() {
		Element.loadAndClick(theCologuardDifferenceVideoBy);
		return this;
	}

	public TheCologuardDifferencePage clickTheScienceBehindCologuardVideo() {
		Element.loadAndClick(theScienceBehindCologuardVideoBy);

		return this;
	}

}
