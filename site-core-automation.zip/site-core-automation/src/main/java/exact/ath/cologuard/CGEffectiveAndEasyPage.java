package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class CGEffectiveAndEasyPage extends ExactNavNavigation {

	private final By cologuardIsConvenientVideoBy = By
			.cssSelector(cologuardPagesProperties.getProperty("cologuardIsConvenientVideoBy"));
	private final By readStoriesBy = By.cssSelector(cologuardPagesProperties.getProperty("readStoriesBy"));
	private final By moreAboutRequestingCologuardBy = By
			.cssSelector(cologuardPagesProperties.getProperty("moreAboutRequestingCGBy"));

	private final String accordionBy = cologuardPagesProperties.getProperty("divAccordionSelector");
	private final String accordionBodyBy = cologuardPagesProperties.getProperty("divAccordionBodySelector");
	private final By playReadyToReturnVideo = By
			.cssSelector(cologuardPagesProperties.getProperty("playReadyToReturnVideo"));

	public void clickAccordion(String sectionLabel) {
		Element.loadAndClick(By.xpath(accordionBy.replace("{sectionLabel}", sectionLabel)));
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(2);
		logInfo("Expanded '" + sectionLabel + "' accordion");
	}

	public boolean isAccordionExpandedFor(String sectionLabel) {
		return Element.isElementDisplayed(By.xpath(accordionBodyBy.replace("{sectionLabel}", sectionLabel)));
	}

	public void playCologuardIsConvenientVideo() {
		Element.loadAndClick(cologuardIsConvenientVideoBy);
		Element.waitForDOMToLoad();
		logInfo("User is able to play the 'Cologuard is convenient' Video");
	}

	public void clickReadStories() {
		Element.loadAndClick(readStoriesBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Read Stories' button");
	}

	public void clickMoreAboutRequestingCGBtn() {
		Element.loadAndClick(moreAboutRequestingCologuardBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'More about requesting Cologuard' button");
	}

	public void clickCologuardIsConvenientVideoInCard() {
		Element.loadAndClick(playReadyToReturnVideo);
		Element.waitForDOMToLoad();

	}

}
