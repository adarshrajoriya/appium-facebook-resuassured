package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;
import exact.util.Sleeper;

public class AboutScreeningPage extends ExactNavNavigation {

	private final By flagQuestionsBy = By.cssSelector(cologuardPagesProperties.getProperty("flagQuestionSelector"));
	private final By quizRadioBtnsBy = By.cssSelector(cologuardPagesProperties.getProperty("flagRadiosSelector"));
	private final By flagResultsBy = By
			.cssSelector(cologuardPagesProperties.getProperty("firstFlagResultTextSelector"));
	private final By whyScreeningMattersBy = By
			.cssSelector(cologuardPagesProperties.getProperty("whyScreeningMattersSelector"));
	private final By whoShouldGetScreenedBy = By
			.cssSelector(cologuardPagesProperties.getProperty("whoShouldGetScreenedSelector"));
	private final By waysToGetScreenedBy = By
			.cssSelector(cologuardPagesProperties.getProperty("waysToGetScreenedSelector"));
	private final By howToGetCologuardBy = By
			.cssSelector(cologuardPagesProperties.getProperty("howToGetCologuardSelector"));

	private final By whyScreeningMattersVideoBy = By
			.cssSelector(cologuardPagesProperties.getProperty("whyScreeningMattersVideoSelector"));
	private final By learnfactsForColonCancerVideoBy = By
			.cssSelector(cologuardPagesProperties.getProperty("learnFactsForClonCancelVideoSelector"));

	public AboutScreeningPage clickLearnFactsForColonCancerVideo() {
		Element.loadAndClick(learnfactsForColonCancerVideoBy);
		return this;
	}

	public AboutScreeningPage clickWhyScreeningMattersVideo() {
		Element.loadAndClick(whyScreeningMattersVideoBy);
		return this;
	}

	public AboutScreeningPage clickWhyScreeningMattersBtn() {
		Element.loadAndClick(whyScreeningMattersBy);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(2);
		logInfo("Clicked on 'Why screening matters' button and it navigates to section");
		return this;
	}

	public AboutScreeningPage clickWhoShouldGetScreenedBtn() {
		Element.loadAndClick(whoShouldGetScreenedBy);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(2);
		logInfo("Clicked on 'Who should get screened' button and it navigates to section");
		return this;
	}

	public AboutScreeningPage clickWaysToGetScreenedBtn() {
		Element.loadAndClick(waysToGetScreenedBy);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(2);
		logInfo("Clicked on 'Ways to get screened' button and it navigates to section");
		return this;
	}

	public AboutScreeningPage clickHowToGetCologuard() {
		Element.loadAndClick(howToGetCologuardBy);
		logInfo("Clicked on 'How to get Cologuard'");
		return this;
	}

	public AboutScreeningPage selectTrueFalseFlag(int flagNumber, boolean flag) throws Exception {
		String flagValue = flag ? "True" : "False";
		List<WebElement> quizQuestions = Element.getMultiple(flagQuestionsBy);
		WebElement quizElement = quizQuestions.get(flagNumber - 1);
		List<WebElement> radioBtnsBy = Element.getElementsFromWithin(quizElement, quizRadioBtnsBy);
		for (WebElement webElement : radioBtnsBy) {
			if (Element.getText(webElement).contains(flagValue)) {
				Element.loadAndClick(webElement);
				logInfo("Clicked on 'true' for first true/flag option");
				return this;
			}
		}
		throw new Exception(
				"Exception occurred while clicking quiz true/false button - " + BasicUtils.takeScreenshot());
	}

	public String getFlagResultText(int flagNum) throws Exception {
		List<WebElement> quizQuestions = Element.getMultiple(flagQuestionsBy);
		WebElement quizElement = quizQuestions.get(flagNum - 1);
		List<WebElement> radioBtnsBy = Element.getElementsFromWithin(quizElement, flagResultsBy);
		for (WebElement webElement : radioBtnsBy) {
			if (Element.isElementDisplayed(webElement)) {
				return Element.getText(webElement);
			}
		}
		throw new Exception("Exception occurred while getting true/false flag text - " + BasicUtils.takeScreenshot());
	}

	public String getVideoTime(int resultLinkIndex) {
		Sleeper.sleepTightInSeconds(1);
		By resultLinksSelectorBy = By.xpath(cologuardPagesProperties.getProperty("videoTimeSelector"));

		List<WebElement> elements = Element.getMultiple(resultLinksSelectorBy);

		return Element.getText(elements.get(resultLinkIndex));

	}
}
