package exact.ath.cologuard;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class StoreLocatorPage extends ExactNavNavigation {

	private final By zipcodeBy = By.cssSelector(cologuardPagesProperties.getProperty("zipcodeBy"));
	private final By submitBtnBy = By.cssSelector(cologuardPagesProperties.getProperty("submitBtnBy"));
	private final By nearestStoreResultBy = By
			.cssSelector(cologuardPagesProperties.getProperty("nearestStoreResultBy"));

	public void enterZipcode(String zipcode) {
		Element.enterText(zipcodeBy, zipcode);
		logInfo("Entered 'Zipcode': " + zipcode);
	}

	public void clickSubmitBtn() {
		Element.loadAndClick(submitBtnBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked Submit button");
		Sleeper.sleepTightInSeconds(5);
	}

	public boolean isNearestStoreDisplayed() {
		return Element.isElementDisplayed(nearestStoreResultBy);
	}
}
