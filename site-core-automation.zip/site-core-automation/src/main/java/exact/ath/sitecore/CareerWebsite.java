package exact.ath.sitecore;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

/**
 * @author qas_tgupta
 *
 */
public class CareerWebsite extends ExactNavNavigation {

	private final By careerWebsiteTittleBy = By.xpath(exactPagesProperties.getProperty("CareerWebsiteTitle"));
	private final By headerSectionDisplayed = By.xpath(exactPagesProperties.getProperty("HeaderSectionDisplayed"));
	private final By ourCoreValuesCard = By.xpath(exactPagesProperties.getProperty("OurCoreValuesCard"));
	private final By inclusiveCultureCard = By.xpath(exactPagesProperties.getProperty("InclusiveCultureCard"));
	private final By ourBenefitsCard = By.xpath(exactPagesProperties.getProperty("OurBenefitsCard"));
	private final By diverseTeamsSingularMissionCard = By
			.xpath(exactPagesProperties.getProperty("DiverseTeamsSingularMissionCard"));
	private final By discoverLifeInMadisonButton = By
			.xpath(exactPagesProperties.getProperty("DiscoverLifeInMadisonButton"));
	private final By seeOpenPositionsButton = By.xpath(exactPagesProperties.getProperty("SeeOpenPositionsButton"));
	private final By legalDisclaimerLinks = By.xpath(exactPagesProperties.getProperty("LegalDisclaimerLinks"));
	private final By careerFooterBy = By.xpath(exactPagesProperties.getProperty("CareerFooter"));
	private final By careerWebsiteExactSciencesLogo = By
			.xpath(exactPagesProperties.getProperty("CareerWebsiteExactSciencesLogo"));
	private final By whyExactSciencesTab = By.xpath(exactPagesProperties.getProperty("WhyExactSciencesTab"));
	private final By lifeAtExactTab = By.xpath(exactPagesProperties.getProperty("LifeAtExactTab"));
	private final By locationsTab = By.xpath(exactPagesProperties.getProperty("LocationsTab"));
	private final By benefitsTab = By.xpath(exactPagesProperties.getProperty("BenefitsTab"));
	private final By currentOpeningsTab = By.xpath(exactPagesProperties.getProperty("CurrentOpeningsTab"));
	private final By coreValuesTitleDisplayedInFirstIconCard = By
			.xpath(exactPagesProperties.getProperty("CoreValuesTitleDisplayedInFirstIconCard"));
	private final By exploreMoreButtonDisplayedInFirstIconCard = By
			.xpath(exactPagesProperties.getProperty("ExploreMoreButtonDisplayedInFirstIconCard"));
	private final By inclusiveCultureTitleDisplayedInSecondIconCard = By
			.xpath(exactPagesProperties.getProperty("InclusiveCultureTitleDisplayedInSecondIconCard"));
	private final By exploreMoreButtonDisplayedInSecondIconCard = By
			.xpath(exactPagesProperties.getProperty("ExploreMoreButtonDisplayedInSecondIconCard"));
	private final By ourBenefitsTitleDisplayedInThirdIconCard = By
			.xpath(exactPagesProperties.getProperty("OurBenefitsTitleDisplayedInThirdIconCard"));
	private final By exploreMoreButtonDisplayedInThirdIconCard = By
			.xpath(exactPagesProperties.getProperty("ExploreMoreButtonDisplayedInThirdIconCard"));
	private final By fiveCoreValues = By.xpath(exactPagesProperties.getProperty("FiveCoreValues"));
	private final By whyExactSciencesTabDisplayedHighlighted = By
			.xpath(exactPagesProperties.getProperty("WhyExactSciencesTabDisplayedHighlighted"));
	private final By lifeAtExactSciences = By.xpath(exactPagesProperties.getProperty("LifeAtExactSciences"));
	private final By totalRewards = By.xpath(exactPagesProperties.getProperty("TotalRewards"));
	private final By viewOpenings = By.xpath(exactPagesProperties.getProperty("ViewOpenings"));
	private final By hereLinkInLegal = By.xpath(exactPagesProperties.getProperty("HereLinkInLegal"));
	private final By exactScienceGroupPrivacy = By.xpath(exactPagesProperties.getProperty("ExactScienceGroupPrivacy"));
	private final By equalOpportunityEmployment = By
			.xpath(exactPagesProperties.getProperty("EqualOpportunityEmployment"));
	private final By posterSupplement = By.xpath(exactPagesProperties.getProperty("PosterSupplement"));
	private final By rightToWork = By.xpath(exactPagesProperties.getProperty("RightToWork"));
	private final By participationNotice = By.xpath(exactPagesProperties.getProperty("ParticipationNotice"));
	private final By payTransparency = By.xpath(exactPagesProperties.getProperty("PayTransparency"));
	private final By espanolOne = By.xpath(exactPagesProperties.getProperty("EspanolOne"));
	private final By espanolTwo = By.xpath(exactPagesProperties.getProperty("EspanolTwo"));
	private final By espanolThree = By.xpath(exactPagesProperties.getProperty("EspanolThree"));
	private final By chineseOne = By.xpath(exactPagesProperties.getProperty("ChineseOne"));
	private final By chineseTwo = By.xpath(exactPagesProperties.getProperty("ChineseTwo"));
	private final By popupPhoneNumber = By.xpath(exactPagesProperties.getProperty("PopupPhoneNumber"));
	private final By popupEmail = By.xpath(exactPagesProperties.getProperty("PopupEmail"));

	private final By integrityIconLogo = By.xpath(exactPagesProperties.getProperty("IntegrityIconLogo"));
	private final By innovationIconLogo = By.xpath(exactPagesProperties.getProperty("InnovationIconLogo"));
	private final By teamworkIconLogo = By.xpath(exactPagesProperties.getProperty("TeamworkIconLogo"));
	private final By accountabilityIconLogo = By.xpath(exactPagesProperties.getProperty("AccountabilityIconLogo"));
	private final By qualityIconLogo = By.xpath(exactPagesProperties.getProperty("QualityIconLogo"));
	private final By innovationCard = By.xpath(exactPagesProperties.getProperty("InnovationCard"));
	private final By innovationIconLogoHighlightedInBlue = By
			.xpath(exactPagesProperties.getProperty("InnovationIconLogoHighlightedInBlue"));
	private final By slickDotInBottomHighlighted = By
			.xpath(exactPagesProperties.getProperty("SlickDotInBottomHighlighted"));
	private final By teamworkCard = By.xpath(exactPagesProperties.getProperty("TeamworkCard"));
	private final By accountabilityCard = By.xpath(exactPagesProperties.getProperty("AccountabilityCard"));
	private final By qualityCard = By.xpath(exactPagesProperties.getProperty("QualityCard"));
	private final By backwardSlickArrow = By.xpath(exactPagesProperties.getProperty("BackwardSlickArrow"));

	private final By oliviaFinnDisplayed = By.xpath(exactPagesProperties.getProperty("OliviaFinnDisplayed"));
	private final By blaiseRussoDisplayed = By.xpath(exactPagesProperties.getProperty("BlaiseRussoDisplayed"));
	private final By domoniqueTuckerDisplayed = By.xpath(exactPagesProperties.getProperty("DomoniqueTuckerDisplayed"));

	private final By lakshmiSampathDisplayed = By.xpath(exactPagesProperties.getProperty("LakshmiSampathDisplayed"));
	private final By kongXiongDisplayed = By.xpath(exactPagesProperties.getProperty("KongXiongDisplayed"));
	private final By uzomaIwuagwuDisplayed = By.xpath(exactPagesProperties.getProperty("UzomaIwuagwuDisplayed"));

	private final By kyleStaceyDisplayed = By.xpath(exactPagesProperties.getProperty("KyleStaceyDisplayed"));
	private final By emmaTumiltyDisplayed = By.xpath(exactPagesProperties.getProperty("EmmaTumiltyDisplayed"));
	private final By andreaAdkinsDisplayed = By.xpath(exactPagesProperties.getProperty("AndreaAdkinsDisplayed"));
	private final By jamiePuckettDisplayed = By.xpath(exactPagesProperties.getProperty("JamiePuckettDisplayed"));
	private final By showMore = By.xpath(exactPagesProperties.getProperty("ShowMore"));
	private final By showLess = By.xpath(exactPagesProperties.getProperty("ShowLess"));

	private final By sharingRespect = By.xpath(exactPagesProperties.getProperty("SharingRespect"));
	private final By fosteringTogetherness = By.xpath(exactPagesProperties.getProperty("FosteringTogetherness"));
	private final By developingPeople = By.xpath(exactPagesProperties.getProperty("DevelopingPeople"));
	private final By employeeRecognition = By.xpath(exactPagesProperties.getProperty("EmployeeRecognition"));
	private final By greatPlaceToWork = By.xpath(exactPagesProperties.getProperty("GreatPlaceToWork"));
	private final By exactSciencesWorkplaces = By.xpath(exactPagesProperties.getProperty("ExactSciencesWorkplaces"));
	private final By viewOurProfile = By.xpath(exactPagesProperties.getProperty("ViewOurProfile"));

	private final By volunteerTimeOff = By.xpath(exactPagesProperties.getProperty("VolunteerTimeOff"));
	private final By unitedWayCampaign = By.xpath(exactPagesProperties.getProperty("UnitedWayCampaign"));
	private final By communityCommittee = By.xpath(exactPagesProperties.getProperty("CommunityCommittee"));
	private final By corporateSocialResponsibility = By
			.xpath(exactPagesProperties.getProperty("CorporateSocialResponsibility"));

	private final By fitnessClasses = By.xpath(exactPagesProperties.getProperty("FitnessClasses"));
	private final By ourFoodPhilosophy = By.xpath(exactPagesProperties.getProperty("OurFoodPhilosophy"));

	private final By wellnessPointsProgram = By.xpath(exactPagesProperties.getProperty("WellnessPointsProgram"));
	private final By careCom = By.xpath(exactPagesProperties.getProperty("CareCom"));
	private final By fitnessReimbursement = By.xpath(exactPagesProperties.getProperty("FitnessReimbursement"));
	private final By hydroponicFarm = By.xpath(exactPagesProperties.getProperty("HydroponicFarm"));
	private final By locationsPage = By.xpath(exactPagesProperties.getProperty("LocationsPage"));
	private final By findYourLocation = By.xpath(exactPagesProperties.getProperty("FindYourLocation"));
	private final By listOfNations = By.xpath(exactPagesProperties.getProperty("ListOfNations"));
	private final By canadaNation = By.xpath(exactPagesProperties.getProperty("CanadaNation"));
	private final By franceNation = By.xpath(exactPagesProperties.getProperty("FranceNation"));
	private final By germanyNation = By.xpath(exactPagesProperties.getProperty("GermanyNation"));
	private final By irelandNation = By.xpath(exactPagesProperties.getProperty("IrelandNation"));
	private final By italyNation = By.xpath(exactPagesProperties.getProperty("ItalyNation"));
	private final By japanNation = By.xpath(exactPagesProperties.getProperty("JapanNation"));

	private final By netherlandsNation = By.xpath(exactPagesProperties.getProperty("NetherlandsNation"));
	private final By swedenNation = By.xpath(exactPagesProperties.getProperty("SwedenNation"));
	private final By switzerlandNation = By.xpath(exactPagesProperties.getProperty("SwitzerlandNation"));
	private final By unitedStatesNation = By.xpath(exactPagesProperties.getProperty("UnitedStatesNation"));
	private final By unitedKingdomNation = By.xpath(exactPagesProperties.getProperty("UnitedKingdomNation"));
	private final By transparencyInCoverageUrl = By
			.xpath(exactPagesProperties.getProperty("TransparencyInCoverageUrl"));
	private final By transparencyInCoverageHeading = By
			.xpath(exactPagesProperties.getProperty("TransparencyInCoverageHeading"));
	private final By transparencyInCoveragePageLink = By
			.xpath(exactPagesProperties.getProperty("TransparencyInCoveragePageLink"));
	private final By transparencyInCoverageRuleHeading = By
			.xpath(exactPagesProperties.getProperty("TransparencyInCoverageRuleHeading"));
	private final By exactScienceEmail = By.xpath(exactPagesProperties.getProperty("ExactScienceEmail"));

	private final By exactSciencesFooterLogo = By
			.xpath(exactPagesProperties.getProperty("CareerWebsiteExactSciencesFooterLogo"));
	private final By addressDetails = By.xpath(exactPagesProperties.getProperty("CareerWebsiteAddressDetails"));
	private final By contactUsHyperLink = By.xpath(exactPagesProperties.getProperty("CareerWebsiteContactUsHyperLink"));

	private final By quickLinks = By.xpath(exactPagesProperties.getProperty("CareerWebsiteQuickLinks"));
	private final By about = By.xpath(exactPagesProperties.getProperty("CareerWebsiteAbout"));
	private final By termsOfUse = By.xpath(exactPagesProperties.getProperty("CareerWebsiteTermsOfUse"));
	private final By purchasingTerms = By.xpath(exactPagesProperties.getProperty("CareerWebsitePurchasingTerms"));
	private final By patentsTrademarks = By.xpath(exactPagesProperties.getProperty("CareerWebsitePatentsTrademarks"));

	private final By privacyPolicy = By.xpath(exactPagesProperties.getProperty("CareerWebsitePrivacyPolicy"));
	private final By hipaaNotice = By.xpath(exactPagesProperties.getProperty("CareerWebsiteHippaNotice"));
	private final By doNotSellMyInfo = By.xpath(exactPagesProperties.getProperty("CareerWebsiteDoNotSellMyInfo"));
	private final By cologuard = By.xpath(exactPagesProperties.getProperty("CareerWebsiteCologuard"));
	private final By followUsOn = By.xpath(exactPagesProperties.getProperty("CareerWebsiteFollowUsOn"));
	private final By contactUsHeading = By.xpath(exactPagesProperties.getProperty("ContactUsHeading"));
	private final By aboutHeading = By.xpath(exactPagesProperties.getProperty("AboutHeading"));
	private final By termsOfUseHeading = By.xpath(exactPagesProperties.getProperty("TermsOfUseHeading"));
	private final By patentsTrademarksHeading = By.xpath(exactPagesProperties.getProperty("PatentsTrademarksHeading"));
	private final By privacyPolicyHeading = By.xpath(exactPagesProperties.getProperty("PrivacyPolicyHeading"));
	private final By hippaNoticeHeading = By.xpath(exactPagesProperties.getProperty("HippaNoticeHeading"));
	private final By doNotSellMyInfoHeading = By.xpath(exactPagesProperties.getProperty("DoNotSellMyInfoHeading"));
	private final By videoHover = By.xpath(exactPagesProperties.getProperty("CareerWebsiteVideoHover"));
	private final By pauseButton = By.xpath(exactPagesProperties.getProperty("CareerWebsitePauseButton"));
	private final By videoTime = By.xpath(exactPagesProperties.getProperty("CareerWebsiteVideoTime"));
	private final By closeVideoButton = By.xpath(exactPagesProperties.getProperty("CloseVideoButton"));

	public boolean isCareerWebsiteHomePageDisplayed() {
		Element.waitForVisible(careerWebsiteTittleBy);
		return Element.isElementDisplayed(careerWebsiteTittleBy);
	}

	public String getCareerWebsiteHeading() {
		Element.waitForVisible(careerWebsiteTittleBy);
		return Element.getElementText(careerWebsiteTittleBy);
	}

	public boolean isHeaderSectionDisplayed() {
		Element.waitForVisible(headerSectionDisplayed);
		return Element.isElementDisplayed(headerSectionDisplayed);
	}

	public boolean isPageTitleDisplayed() {
		Element.waitForVisible(careerWebsiteTittleBy);
		return Element.isElementDisplayed(careerWebsiteTittleBy);
	}

	public boolean isOurCoreValuesCardDisplayed() {
		Element.waitForVisible(ourCoreValuesCard);
		return Element.isElementDisplayed(ourCoreValuesCard);
	}

	public boolean isInclusiveCultureCardDisplayed() {
		Element.waitForVisible(inclusiveCultureCard);
		return Element.isElementDisplayed(inclusiveCultureCard);
	}

	public boolean isOurBenefitsCardDisplayed() {
		Element.waitForVisible(ourBenefitsCard);
		return Element.isElementDisplayed(ourBenefitsCard);
	}

	public boolean isDiverseTeamsSingularMissionCardDisplayed() {
		Element.waitForVisible(diverseTeamsSingularMissionCard);
		return Element.isElementDisplayed(diverseTeamsSingularMissionCard);
	}

	public boolean isDiscoverLifeInMadisonButtonDisplayed() {
		Element.waitForVisible(discoverLifeInMadisonButton);
		return Element.isElementDisplayed(discoverLifeInMadisonButton);
	}

	public boolean isSeeOpenPositionsButtonDisplayed() {
		Element.waitForVisible(seeOpenPositionsButton);
		return Element.isElementDisplayed(seeOpenPositionsButton);
	}

	public boolean isLegalDisclaimerLinksDisplayed() {
		Element.waitForVisible(legalDisclaimerLinks);
		return Element.isElementDisplayed(legalDisclaimerLinks);
	}

	public boolean isCareerWebsiteFooterDisplayed() {
		return Element.isElementDisplayed(careerFooterBy);
	}

	public boolean isCareerWebsiteExactSciencesLogoDisplayed() {
		return Element.isElementDisplayed(careerWebsiteExactSciencesLogo);
	}

	public boolean isWhyExactSciencesTabDisplayed() {
		return Element.isElementDisplayed(whyExactSciencesTab);
	}

	public boolean isLifeAtExactTabDisplayed() {
		return Element.isElementDisplayed(lifeAtExactTab);
	}

	public boolean isLocationsTabDisplayed() {
		return Element.isElementDisplayed(locationsTab);
	}

	public boolean isBenefitsTabDisplayed() {
		return Element.isElementDisplayed(benefitsTab);
	}

	public boolean isCurrentOpeningsTabDisplayed() {
		return Element.isElementDisplayed(currentOpeningsTab);
	}

	public String getCoreValuesTitleDisplayedInFirstIconCard() {
		Element.waitForVisible(coreValuesTitleDisplayedInFirstIconCard);
		return Element.getElementText(coreValuesTitleDisplayedInFirstIconCard);
	}

	public boolean isExploreMoreButtonDisplayedInFirstIconCard() {
		return Element.isElementDisplayed(exploreMoreButtonDisplayedInFirstIconCard);
	}

	public String getInclusiveCultureTitleDisplayedInSecondIconCard() {
		Element.waitForVisible(inclusiveCultureTitleDisplayedInSecondIconCard);
		return Element.getElementText(inclusiveCultureTitleDisplayedInSecondIconCard);
	}

	public boolean isExploreMoreButtonDisplayedInSecondIconCard() {
		return Element.isElementDisplayed(exploreMoreButtonDisplayedInSecondIconCard);
	}

	public String getOurBenefitsTitleDisplayedInThirdIconCard() {
		Element.waitForVisible(ourBenefitsTitleDisplayedInThirdIconCard);
		return Element.getElementText(ourBenefitsTitleDisplayedInThirdIconCard);
	}

	public boolean isExploreMoreButtonDisplayedInThirdIconCard() {
		return Element.isElementDisplayed(exploreMoreButtonDisplayedInThirdIconCard);
	}

	public void clickExploreMoreButtonDisplayedInFirstIconCard() {
		Element.loadAndClick(exploreMoreButtonDisplayedInFirstIconCard);
	}

	public String getFiveCoreValues() {
		Element.waitForVisible(fiveCoreValues);
		return Element.getElementText(fiveCoreValues);
	}

	public boolean isWhyExactSciencesTabDisplayedHighlighted() {
		return Element.isElementDisplayed(whyExactSciencesTabDisplayedHighlighted);
	}

	public void clickExploreMoreButtonDisplayedInSecondIconCard() {
		Element.loadAndClick(exploreMoreButtonDisplayedInSecondIconCard);
	}

	public String getLifeAtExactSciences() {
		Element.waitForVisible(lifeAtExactSciences);
		return Element.getElementText(lifeAtExactSciences);
	}

	public void clickExploreMoreButtonDisplayedInThirdIconCard() {
		Element.loadAndClick(exploreMoreButtonDisplayedInThirdIconCard);
	}

	public String getTotalRewards() {
		Element.waitForVisible(totalRewards);
		return Element.getElementText(totalRewards);
	}

	public void clickViewOpenings() {
		Element.loadAndClick(viewOpenings);
	}

	public void clickDiscoverLifeInMadisonButton() {
		Element.waitForVisible(discoverLifeInMadisonButton);
		Element.loadAndClick(discoverLifeInMadisonButton);
	}

	public void clickSeeOpenPositionsButton() {
		Element.waitForVisible(seeOpenPositionsButton);
		Element.loadAndClick(seeOpenPositionsButton);
	}

	public void clickHereLinkInLegal() {
		Element.waitForVisible(hereLinkInLegal);
		Element.loadAndClick(hereLinkInLegal);
	}

	public String getExactScienceGroupPrivacy() {
		Element.waitForVisible(exactScienceGroupPrivacy);
		return Element.getElementText(exactScienceGroupPrivacy);
	}

	public void clickEqualOpportunityEmployment() {
		Element.waitForVisible(equalOpportunityEmployment);
		Element.loadAndClick(equalOpportunityEmployment);
	}

	public void clickPosterSupplement() {
		Element.waitForVisible(posterSupplement);
		Element.loadAndClick(posterSupplement);
	}

	public void clickRightToWork() {
		Element.waitForVisible(rightToWork);
		Element.loadAndClick(rightToWork);
	}

	public void clickParticipationNotice() {
		Element.waitForVisible(participationNotice);
		Element.loadAndClick(participationNotice);
	}

	public void clickPayTransparency() {
		Element.waitForVisible(payTransparency);
		Element.loadAndClick(payTransparency);
	}

	public void clickEspanolOne() {
		Element.waitForVisible(espanolOne);
		Element.loadAndClick(espanolOne);
	}

	public void clickEspanolTwo() {
		Element.waitForVisible(espanolTwo);
		Element.loadAndClick(espanolTwo);
	}

	public void clickEspanolThree() {
		Element.waitForVisible(espanolThree);
		Element.loadAndClick(espanolThree);
	}

	public void clickChineseOne() {
		Element.waitForVisible(chineseOne);
		Element.loadAndClick(chineseOne);
	}

	public void clickChineseTwo() {
		Element.waitForVisible(chineseTwo);
		Element.loadAndClick(chineseTwo);
	}

	public boolean isPopupPhoneNumber() {
		Element.waitForVisible(popupPhoneNumber);
		return Element.isElementDisplayed(popupPhoneNumber);
	}

	public boolean isPopupEmail() {
		Element.waitForVisible(popupEmail);
		return Element.isElementDisplayed(popupEmail);
	}

	public void clickWhyExactSciencesTab() {
		Element.waitForVisible(whyExactSciencesTab);
		Element.loadAndClick(whyExactSciencesTab);
	}

	public boolean isIntegrityIconLogoDisplayed() {
		Element.waitForVisible(integrityIconLogo);
		return Element.isElementDisplayed(integrityIconLogo);
	}

	public boolean isInnovationIconLogoDisplayed() {
		Element.waitForVisible(innovationIconLogo);
		return Element.isElementDisplayed(innovationIconLogo);
	}

	public boolean isTeamworkIconLogoDisplayed() {
		Element.waitForVisible(teamworkIconLogo);
		return Element.isElementDisplayed(teamworkIconLogo);
	}

	public boolean isAccountabilityIconLogoDisplayed() {
		Element.waitForVisible(accountabilityIconLogo);
		return Element.isElementDisplayed(accountabilityIconLogo);
	}

	public boolean isQualityIconLogoDisplayed() {
		Element.waitForVisible(qualityIconLogo);
		return Element.isElementDisplayed(qualityIconLogo);
	}

	public void clickInnovationIconLogo() {
		Element.loadAndClick(innovationIconLogo);
	}

	public boolean isInnovationCardDisplayed() {
		Element.waitForVisible(innovationCard);
		return Element.isElementDisplayed(innovationCard);
	}

	public boolean isInnovationIconLogoHighlightedInBlue() {
		Element.waitForVisible(innovationIconLogoHighlightedInBlue);
		return Element.isElementDisplayed(innovationIconLogoHighlightedInBlue);
	}

	public boolean isSlickDotInBottomHighlighted() {
		Element.waitForVisible(slickDotInBottomHighlighted);
		return Element.isElementDisplayed(slickDotInBottomHighlighted);
	}

	public void clickTeamworkIconLogo() {
		Sleeper.sleepTightInSeconds(5);
		Element.loadAndClick(teamworkIconLogo);
	}

	public boolean isTeamworkCardDisplayed() {
		Element.waitForVisible(teamworkCard);
		return Element.isElementDisplayed(teamworkCard);
	}

	public void clickAccountabilityIconLogo() {
		Sleeper.sleepTightInSeconds(5);
		Element.loadAndClick(accountabilityIconLogo);
	}

	public boolean isAccountabilityCardDisplayed() {
		Element.waitForVisible(accountabilityCard);
		return Element.isElementDisplayed(accountabilityCard);
	}

	public void clickQualityIconLogo() {
		Sleeper.sleepTightInSeconds(5);
		Element.loadAndClick(qualityIconLogo);
	}

	public boolean isQualityCardDisplayed() {
		Element.waitForVisible(qualityCard);
		return Element.isElementDisplayed(qualityCard);
	}

	public void clickBackwardSlickArrow() {
		Sleeper.sleepTightInSeconds(5);
		Element.loadAndClick(backwardSlickArrow);
	}

	public boolean isOliviaFinnDisplayed() {
		Sleeper.sleepTightInSeconds(10);
		return Element.isElementDisplayed(oliviaFinnDisplayed);
	}

	public boolean isBlaiseRussoDisplayed() {
		Sleeper.sleepTightInSeconds(10);
		return Element.isElementDisplayed(blaiseRussoDisplayed);
	}

	public boolean isDomoniqueTuckerDisplayed() {
		Sleeper.sleepTightInSeconds(10);
		return Element.isElementDisplayed(domoniqueTuckerDisplayed);
	}

	public boolean isLakshmiSampathDisplayed() {
		Sleeper.sleepTightInSeconds(5);
		return Element.isElementDisplayed(lakshmiSampathDisplayed);
	}

	public boolean isKongXiongDisplayed() {
		Sleeper.sleepTightInSeconds(5);
		return Element.isElementDisplayed(kongXiongDisplayed);
	}

	public boolean isUzomaIwuagwuDisplayed() {
		Sleeper.sleepTightInSeconds(5);
		return Element.isElementDisplayed(uzomaIwuagwuDisplayed);
	}

	public boolean isKyleStaceyDisplayed() {
		Sleeper.sleepTightInSeconds(5);
		return Element.isElementDisplayed(kyleStaceyDisplayed);
	}

	public boolean isEmmaTumiltyDisplayed() {
		Sleeper.sleepTightInSeconds(5);
		return Element.isElementDisplayed(emmaTumiltyDisplayed);
	}

	public boolean isAndreaAdkinsDisplayed() {
		Sleeper.sleepTightInSeconds(5);
		return Element.isElementDisplayed(andreaAdkinsDisplayed);
	}

	public boolean isJamiePuckettDisplayed() {
		Sleeper.sleepTightInSeconds(5);
		return Element.isElementDisplayed(jamiePuckettDisplayed);
	}

	public void clickShowMore() {
		Element.waitForVisible(showMore);
		Element.loadAndClick(showMore);
		Sleeper.sleepTightInSeconds(5);
	}

	public void clickShowLess() {
		Element.waitForVisible(showLess);
		Element.loadAndClick(showLess);
		Sleeper.sleepTightInSeconds(5);
	}

	public void clickLifeAtExactTab() {
		Element.waitForVisible(lifeAtExactTab);
		Element.loadAndClick(lifeAtExactTab);
	}

	public String getSharingRespect() {
		Element.waitForVisible(sharingRespect);
		return Element.getElementText(sharingRespect);
	}

	public String getFosteringTogetherness() {
		Element.waitForVisible(fosteringTogetherness);
		return Element.getElementText(fosteringTogetherness);
	}

	public String getDevelopingPeople() {
		Element.waitForVisible(developingPeople);
		return Element.getElementText(developingPeople);
	}

	public String getEmployeeRecognition() {
		Element.waitForVisible(employeeRecognition);
		return Element.getElementText(employeeRecognition);
	}

	public void clickGreatPlaceToWork() {
		Element.waitForVisible(greatPlaceToWork);
		Element.loadAndClick(greatPlaceToWork);
	}

	public String getExactSciencesWorkplaces() {
		Element.waitForVisible(exactSciencesWorkplaces);
		return Element.getElementText(exactSciencesWorkplaces);
	}

	public void clickViewOurProfile() {
		Element.waitForVisible(viewOurProfile);
		Element.loadAndClick(viewOurProfile);
		Sleeper.sleepTightInSeconds(10);

	}

	public String getVolunteerTimeOff() {
		Element.waitForVisible(volunteerTimeOff);
		return Element.getElementText(volunteerTimeOff);
	}

	public String getUnitedWayCampaign() {
		Element.waitForVisible(unitedWayCampaign);
		return Element.getElementText(unitedWayCampaign);
	}

	public String getCommunityCommittee() {
		Element.waitForVisible(communityCommittee);
		return Element.getElementText(communityCommittee);
	}

	public void clickCorporateSocialResponsibility() {
		Element.waitForVisible(corporateSocialResponsibility);
		Element.loadAndClick(corporateSocialResponsibility);
	}

	public String getFitnessClasses() {
		Element.waitForVisible(fitnessClasses);
		return Element.getElementText(fitnessClasses);
	}

	public String getOurFoodPhilosophy() {
		Element.waitForVisible(ourFoodPhilosophy);
		return Element.getElementText(ourFoodPhilosophy);
	}

	public String getWellnessPointsProgram() {
		Element.waitForVisible(wellnessPointsProgram);
		return Element.getElementText(wellnessPointsProgram);
	}

	public String getCareCom() {
		Element.waitForVisible(careCom);
		return Element.getElementText(careCom);
	}

	public String getFitnessReimbursement() {
		Sleeper.sleepTightInSeconds(3);
		Element.waitForVisible(fitnessReimbursement);
		return Element.getElementText(fitnessReimbursement);
	}

	public String getHydroponicFarm() {
		Sleeper.sleepTightInSeconds(3);
		Element.waitForVisible(hydroponicFarm);
		return Element.getElementText(hydroponicFarm);
	}

	public void clickForwardSlickArrow(int resultLinkIndex) {
		Sleeper.sleepTightInSeconds(1);
		By resultLinksSelectorBy = By.xpath(exactPagesProperties.getProperty("ForwardSlickArrow"));

		List<WebElement> elements = Element.getMultiple(resultLinksSelectorBy);

		Element.loadAndClick(elements.get(resultLinkIndex));

	}

	public void clickLocationsTab() {
		Element.waitForVisible(locationsTab);
		Element.loadAndClick(locationsTab);
	}

	public String getLocationsPage() {
		Element.waitForVisible(locationsPage);
		return Element.getElementText(locationsPage);
	}

	public boolean isSwiperSlideDisplayed(int resultLinkIndex) {

		By resultLinksSelectorBy = By.xpath(exactPagesProperties.getProperty("SwiperSlide"));

		List<WebElement> elements = Element.getMultiple(resultLinksSelectorBy);
		return Element.isElementDisplayed(elements.get(resultLinkIndex));

	}

	public void clickBenefitsTab() {
		Element.waitForVisible(benefitsTab);
		Element.loadAndClick(benefitsTab);
		Sleeper.sleepTightInSeconds(3);
	}

	public void clickFindYourLocation() {
		Element.waitForVisible(findYourLocation);
		Element.loadAndClick(findYourLocation);
		Sleeper.sleepTightInSeconds(3);
	}

	public boolean isListOfNationsDisplayed() {
		Element.waitForVisible(listOfNations);
		return Element.isElementDisplayed(listOfNations);
	}

	public void clickCanadaNation() {
		Element.waitForVisible(canadaNation);
		Element.loadAndClick(canadaNation);
	}

	public void clickFranceNation() {
		Element.waitForVisible(franceNation);
		Element.loadAndClick(franceNation);
	}

	public void clickGermanyNation() {
		Element.waitForVisible(germanyNation);
		Element.loadAndClick(germanyNation);
	}

	public void clickIrelandNation() {
		Element.waitForVisible(irelandNation);
		Element.loadAndClick(irelandNation);
	}

	public void clickItalyNation() {
		Element.waitForVisible(italyNation);
		Element.loadAndClick(italyNation);
	}

	public void clickJapanNation() {
		Element.waitForVisible(japanNation);
		Element.loadAndClick(japanNation);
	}

	public void clickNetherlandsNation() {
		Element.waitForVisible(netherlandsNation);
		Element.loadAndClick(netherlandsNation);
	}

	public void clickSwedenNation() {
		Element.waitForVisible(swedenNation);
		Element.loadAndClick(swedenNation);
	}

	public void clickSwitzerlandNation() {
		Element.waitForVisible(switzerlandNation);
		Element.loadAndClick(switzerlandNation);
	}

	public void clickUnitedStatesNation() {
		Element.waitForVisible(unitedStatesNation);
		Element.loadAndClick(unitedStatesNation);
	}

	public void clickUnitedKingdomNation() {
		Element.waitForVisible(unitedKingdomNation);
		Element.loadAndClick(unitedKingdomNation);
	}

	public void clickTransparencyInCoverageUrl() {
		Element.waitForVisible(transparencyInCoverageUrl);
		Element.loadAndClick(transparencyInCoverageUrl);
	}

	public String getTransparencyInCoverageHeading() {
		Element.waitForVisible(transparencyInCoverageHeading);
		return Element.getElementText(transparencyInCoverageHeading);
	}

	public void clickTransparencyInCoveragePageLink() {
		Element.waitForVisible(transparencyInCoveragePageLink);
		Element.loadAndClick(transparencyInCoveragePageLink);
	}

	public String getTransparencyInCoverageRuleHeading() {
		Element.waitForVisible(transparencyInCoverageRuleHeading);
		return Element.getElementText(transparencyInCoverageRuleHeading);
	}

	public boolean isExactScienceEmailDisplayed() {
		Element.waitForVisible(exactScienceEmail);
		return Element.isElementDisplayed(exactScienceEmail);
	}

	public void clickCurrentOpeningsTab() {
		Element.waitForVisible(currentOpeningsTab);
		Element.loadAndClick(currentOpeningsTab);
		Sleeper.sleepTightInSeconds(3);
	}

	public boolean isExactSciencesFooterLogoDisplayed() {
		return Element.isElementDisplayed(exactSciencesFooterLogo);
	}

	public boolean isAddressDetailsDisplayed() {
		return Element.isElementDisplayed(addressDetails);
	}

	public boolean isContactUsHyperLinkDisplayed() {
		return Element.isElementDisplayed(contactUsHyperLink);
	}

	public boolean isQuickLinksDisplayed() {
		return Element.isElementDisplayed(quickLinks);
	}

	public boolean isAboutDisplayed() {
		return Element.isElementDisplayed(about);
	}

	public boolean isTermsOfUseDisplayed() {
		return Element.isElementDisplayed(termsOfUse);
	}

	public boolean isPurchasingTermsDisplayed() {
		return Element.isElementDisplayed(purchasingTerms);
	}

	public boolean isPatentsTrademarksDisplayed() {
		return Element.isElementDisplayed(patentsTrademarks);
	}

	public boolean isPrivacyPolicyDisplayed() {
		return Element.isElementDisplayed(privacyPolicy);
	}

	public boolean isHippaNoticeDisplayed() {
		return Element.isElementDisplayed(hipaaNotice);
	}

	public boolean isDoNotSellMyInfoDisplayed() {
		return Element.isElementDisplayed(doNotSellMyInfo);
	}

	public boolean isCologuardDisplayed() {
		return Element.isElementDisplayed(cologuard);
	}

	public boolean isFollowUsOnDisplayed() {
		return Element.isElementDisplayed(followUsOn);
	}

	public void clickContactUsHyperLink() {
		Element.waitForVisible(contactUsHyperLink);
		Element.loadAndClick(contactUsHyperLink);
	}

	public String getContactUsHeading() {
		Element.waitForVisible(contactUsHeading);
		return Element.getElementText(contactUsHeading);
	}

	public void clickAboutLink() {
		Element.waitForVisible(about);
		Element.loadAndClick(about);
	}

	public String getAboutHeading() {
		Element.waitForVisible(aboutHeading);
		return Element.getElementText(aboutHeading);
	}

	public void clickTermsOfUseLink() {
		Element.waitForVisible(termsOfUse);
		Element.loadAndClick(termsOfUse);
	}

	public String getTermsOfUseHeading() {
		Element.waitForVisible(termsOfUseHeading);
		return Element.getElementText(termsOfUseHeading);
	}

	public void clickPurchasingTermsLink() {
		Element.waitForVisible(purchasingTerms);
		Element.loadAndClick(purchasingTerms);
	}

	public void clickPatentsTrademarksLink() {
		Element.waitForVisible(patentsTrademarks);
		Element.loadAndClick(patentsTrademarks);
	}

	public String getPatentsTrademarksHeading() {
		Element.waitForVisible(patentsTrademarksHeading);
		return Element.getElementText(patentsTrademarksHeading);
	}

	public void clickPrivacyPolicyLink() {
		Element.waitForVisible(privacyPolicy);
		Element.loadAndClick(privacyPolicy);
	}

	public String getPrivacyPolicyHeading() {
		Element.waitForVisible(privacyPolicyHeading);
		return Element.getElementText(privacyPolicyHeading);
	}

	public void clickHippaNoticeLink() {
		Element.waitForVisible(hipaaNotice);
		Element.loadAndClick(hipaaNotice);
	}

	public String getHippaNoticeHeading() {
		Element.waitForVisible(hippaNoticeHeading);
		return Element.getElementText(hippaNoticeHeading);
	}

	public void clickDoNotSellMyInfoLink() {
		Element.waitForVisible(doNotSellMyInfo);
		Element.loadAndClick(doNotSellMyInfo);
	}

	public String getDoNotSellMyInfoHeading() {
		Element.waitForVisible(doNotSellMyInfoHeading);
		return Element.getElementText(doNotSellMyInfoHeading);
	}

	public void clickCologuardLink() {
		Element.waitForVisible(cologuard);
		Element.loadAndClick(cologuard);
		Sleeper.sleepTightInSeconds(10);
	}

	public void clickPlayButton(int resultLinkIndex) {
		Sleeper.sleepTightInSeconds(1);
		By resultLinksSelectorBy = By.xpath(exactPagesProperties.getProperty("CareerWebsitePlayButton"));

		List<WebElement> elements = Element.getMultiple(resultLinksSelectorBy);

		Element.loadAndClick(elements.get(resultLinkIndex));

	}

	public void videoHover() {
		Element.mouseHover(videoHover);
	}

	public void clickPauseButton() {
		Element.loadAndClick(pauseButton);
	}

	public String getVideoTime() {
		return Element.getElementText(videoTime);
	}

	public void clickCloseVideoButton() {
		Element.loadAndClick(closeVideoButton);
	}

	public void clickCareerWebsiteExactSciencesLogo() {
		Element.loadAndClick(careerWebsiteExactSciencesLogo);
	}

	public void clickPause() {
		Element.loadAndClick(videoHover);
	}

}
