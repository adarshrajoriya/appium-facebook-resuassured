package exact.ath.sitecore;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class CorporateWebsite extends ExactNavNavigation {

	private final By corporateWebsiteTittleBy = By
			.cssSelector(exactPagesProperties.getProperty("CorporateWebsiteTitle"));
	private final By ourTestsCardBy = By.xpath(exactPagesProperties.getProperty("OurTestsCard"));
	private final By ourPipelineCardBy = By.xpath(exactPagesProperties.getProperty("OurPipelineCard"));
	private final By ourNewsroomCard = By.xpath(exactPagesProperties.getProperty("OurNewsroomCard"));
	private final By ourTestsCardLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OurTestsCardLearnMoreLink"));
	private final By ourTestsPageBy = By.xpath(exactPagesProperties.getProperty("OurTestsPage"));
	private final By ourTestsHeaderHighlightBy = By.xpath(exactPagesProperties.getProperty("OurTestsHeaderHighlight"));
	private final By exactSciencesLogoBy = By
			.xpath(exactPagesProperties.getProperty("CorporateWebsiteExactSciencesLogo"));
	private final By ourPipelineCardLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OurPipelineCardLearnMoreLink"));
	private final By pipelineDataPageBy = By.xpath(exactPagesProperties.getProperty("PipelineDataPage"));
	private final By pipelineDataHeaderHighlightBy = By
			.xpath(exactPagesProperties.getProperty("PipelineDataHeaderHighlight"));
	private final By ourNewsroomCardLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OurNewsroomCardLearnMoreLink"));
	private final By newsroomPageBy = By.xpath(exactPagesProperties.getProperty("NewsroomPage"));
	private final By newsroomHeaderHighlightBy = By.xpath(exactPagesProperties.getProperty("NewsroomHeaderHighlight"));
	private final By exploreTheTestLinkBy = By.xpath(exactPagesProperties.getProperty("ExploreTheTestLink"));
	private final By oncoExTraPageBy = By.xpath(exactPagesProperties.getProperty("OncoExTraPage"));
	private final By oncoExTraHeaderOptionActiveBy = By
			.xpath(exactPagesProperties.getProperty("OncoExTraHeaderOptionActive"));
	private final By publicationsLinkBy = By.xpath(exactPagesProperties.getProperty("PublicationsLink"));
	private final By publicationsPageBy = By.xpath(exactPagesProperties.getProperty("PublicationsPage"));
	private final By publicationsHeaderOptionActiveBy = By
			.xpath(exactPagesProperties.getProperty("PublicationsHeaderOptionActive"));
	private final By aboutHeaderOptionBy = By.xpath(exactPagesProperties.getProperty("AboutHeaderOption"));
	private final By ourTestsOptionBy = By.xpath(exactPagesProperties.getProperty("OurTestsOption"));
	private final By pipelineHeaderOptionBy = By.xpath(exactPagesProperties.getProperty("PipelineHeaderOption"));
	private final By aboutUsPageBy = By.xpath(exactPagesProperties.getProperty("AboutUsPage"));
	private final By aboutHeaderOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("AboutHeaderOptionHighlight"));
	private final By leadershipOptionBy = By.xpath(exactPagesProperties.getProperty("LeadershipOption"));
	private final By leadershipPageBy = By.xpath(exactPagesProperties.getProperty("LeadershipPage"));
	private final By leadershipOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("LeadershipOptionHighlight"));
	private final By profilePageTittleBy = By.xpath(exactPagesProperties.getProperty("ProfilePageTittle"));
	private final By medicalLeadersOptionBy = By.xpath(exactPagesProperties.getProperty("MedicalLeadersOption"));
	private final By boardOfDirectorsOptionBy = By.xpath(exactPagesProperties.getProperty("BoardOfDirectorsOption"));
	private final By boardOfDirectorsPageBy = By.xpath(exactPagesProperties.getProperty("BoardOfDirectorsPage"));
	private final By boardOfDirectorsOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("BoardOfDirectorsOptionHighlight"));
	private final By companyHistoryOptionBy = By.xpath(exactPagesProperties.getProperty("CompanyHistoryOption"));
	private final By companyHistoryPageBy = By.xpath(exactPagesProperties.getProperty("CompanyHistoryPage"));
	private final By companyHistoryOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("CompanyHistoryOptionHighlight"));
	private final By corporateImpactandCommunityRelationsOptionBy = By
			.xpath(exactPagesProperties.getProperty("CorporateImpactandCommunityRelationsOption"));
	private final By ourCollaborationsOptionBy = By.xpath(exactPagesProperties.getProperty("OurCollaborationsOption"));
	private final By ourCollaborationsPageBy = By.xpath(exactPagesProperties.getProperty("OurCollaborationsPage"));
	private final By ourCollaborationsOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("OurCollaborationsOptionHighlight"));
	private final By contactUsOptionBy = By.xpath(exactPagesProperties.getProperty("ContactUsOption"));
	private final By contactUsPageBy = By.xpath(exactPagesProperties.getProperty("ContactUsPage"));
	private final By contactUsOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("ContactUsOptionHighlight"));
	private final By moreInfoPageTittleBy = By.xpath(exactPagesProperties.getProperty("MoreInfoPageTittle"));
	private final By laboratoriesContactUsLinkBy = By
			.xpath(exactPagesProperties.getProperty("LaboratoriesContactUsLink"));
	private final By humanResourcesContactUsLinkBy = By
			.xpath(exactPagesProperties.getProperty("HumanResourcesContactUsLink"));
	private final By investorContactUsLinkBy = By.xpath(exactPagesProperties.getProperty("InvestorContactUsLink"));
	private final By generalContactUsLinkBy = By.xpath(exactPagesProperties.getProperty("GeneralContactUsLink"));
	private final By mediaContactUsLinkBy = By.xpath(exactPagesProperties.getProperty("MediaContactUsLink"));
	private final By medicalContactUsLinkBy = By.xpath(exactPagesProperties.getProperty("MedicalContactUsLink"));

	private final By breastRadiationScorePageBy = By
			.xpath(exactPagesProperties.getProperty("BreastRadiationScorePage"));
	private final By breastRadiationScoreOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("BreastRadiationScoreOptionHighlight"));
	private final By cologuardPageBy = By.xpath(exactPagesProperties.getProperty("CologuardPage"));
	private final By cologuardOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("CologuardOptionHighlight"));
	private final By colorectalCancerBloodPageBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerBloodPage"));
	private final By colorectalCancerBloodOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerBloodOptionHighlight"));
	private final By lBgardBloodTubesPageBy = By.xpath(exactPagesProperties.getProperty("LBgardBloodTubesPage"));
	private final By lBgardBloodTubesOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("LBgardBloodTubesOptionHighlight"));
	private final By molecularResidualDiseasePageBy = By
			.xpath(exactPagesProperties.getProperty("MolecularResidualDiseasePage"));
	private final By molecularResidualDiseaseOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("MolecularResidualDiseaseOptionHighlight"));
	private final By multiCancerEarlyDetectionPageBy = By
			.xpath(exactPagesProperties.getProperty("MultiCancerEarlyDetectionPage"));
	private final By multiCancerEarlyDetectionOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("MultiCancerEarlyDetectionOptionHighlight"));
	private final By publicationsAndAbstractsPageBy = By
			.xpath(exactPagesProperties.getProperty("PublicationsAndAbstractsPage"));
	private final By publicationsAndAbstractsOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("PublicationsAndAbstractsOptionHighlight"));
	private final By lBGardBloodTubesSDSButtonBy = By
			.xpath(exactPagesProperties.getProperty("LBGardBloodTubesSDSButton"));
	private final By lBGardBloodTubesIFUButtonBy = By
			.xpath(exactPagesProperties.getProperty("LBGardBloodTubesIFUButton"));

	private final By firstNameFieldBy = By.xpath(exactPagesProperties.getProperty("FirstNameField"));
	private final By lastNameFieldBy = By.xpath(exactPagesProperties.getProperty("LastNameField"));
	private final By titleFieldBy = By.xpath(exactPagesProperties.getProperty("TitleField"));
	private final By companyInstitutionFieldBy = By.xpath(exactPagesProperties.getProperty("CompanyInstitutionField"));
	private final By addressFieldBy = By.xpath(exactPagesProperties.getProperty("AddressField"));
	private final By emailFieldBy = By.xpath(exactPagesProperties.getProperty("EmailField"));
	private final By areaOfFocusFieldBy = By.xpath(exactPagesProperties.getProperty("AreaOfFocusField"));
	private final By commentsFieldBy = By.xpath(exactPagesProperties.getProperty("CommentsField"));

	private final By colugaurdRXOnlyCardLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("ColugaurdRXOnlyCardLearnMoreLink"));
	private final By colugaurdRxOnlyPageBy = By.xpath(exactPagesProperties.getProperty("ColugaurdRxOnlyPage"));
	private final By submitButtonBy = By.xpath(exactPagesProperties.getProperty("SubmitButton"));
	private final By thankYouMessageBy = By.xpath(exactPagesProperties.getProperty("ThankYouMessage"));
	private final By validationMessageBy = By.xpath(exactPagesProperties.getProperty("ValidationMessage"));

	private final By highlightedPublicationsSlide1TextBy = By
			.xpath(exactPagesProperties.getProperty("HighlightedPublicationsSlide1Text"));
	private final By highlightedPublicationsSlide2HeadingBy = By
			.xpath(exactPagesProperties.getProperty("HighlightedPublicationsSlide2Heading"));
	private final By highlightedPublicationsSlide3HeadingBy = By
			.xpath(exactPagesProperties.getProperty("HighlightedPublicationsSlide3Heading"));
	private final By highlightedPublicationsSlide4HeadingBy = By
			.xpath(exactPagesProperties.getProperty("HighlightedPublicationsSlide4Heading"));
	private final By highlightedPublicationsSlide5HeadingBy = By
			.xpath(exactPagesProperties.getProperty("HighlightedPublicationsSlide5Heading"));
	private final By highlightedPublicationsSlide6HeadingBy = By
			.xpath(exactPagesProperties.getProperty("HighlightedPublicationsSlide6Heading"));
	private final By highlightedPublicationsSlide7HeadingBy = By
			.xpath(exactPagesProperties.getProperty("HighlightedPublicationsSlide7Heading"));
	private final By viewSlideLinkBy = By.xpath(exactPagesProperties.getProperty("ViewSlideLink"));
	private final By viewSlideLink2By = By.xpath(exactPagesProperties.getProperty("ViewSlideLink2"));
	private final By viewAllPublicationsAbstractsLinkBy = By
			.xpath(exactPagesProperties.getProperty("ViewAllPublicationsAbstractsLink"));

	private final By nextArrowSignBy = By.xpath(exactPagesProperties.getProperty("NextArrowSign"));
	private final By advancedCancerOptionBy = By.xpath(exactPagesProperties.getProperty("AdvancedCancerOption"));
	private final By selectLabelBy = By.xpath(exactPagesProperties.getProperty("SelectLabel"));

	private final By appliedFilterValueBy = By.xpath(exactPagesProperties.getProperty("AppliedFilterValue"));
	private final By resetAllFilterButtonnBy = By.xpath(exactPagesProperties.getProperty("ResetAllFilterButton"));
	private final By publicationAdvancedCancerTypeBy = By
			.xpath(exactPagesProperties.getProperty("PublicationAdvancedCancerType"));

	private final By breastCancerOptionBy = By.xpath(exactPagesProperties.getProperty("BreastCancerOption"));
	private final By oncotypeDXBreastRecurrenceScoreTestBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeDXBreastRecurrenceScoreTest"));
	private final By publicationTypeAbstractOptionBy = By
			.xpath(exactPagesProperties.getProperty("PublicationTypeAbstractOption"));
	private final By dXGenomicProstateScoreTestOptionBy = By
			.xpath(exactPagesProperties.getProperty("DXGenomicProstateScoreTestOption"));
	private final By publicationTypeManuscriptOptionBy = By
			.xpath(exactPagesProperties.getProperty("PublicationTypeManuscriptOption"));
	private final By publicationYear2022OptionBy = By
			.xpath(exactPagesProperties.getProperty("PublicationYear2022Option"));
	private final By selectProductLabelBy = By.xpath(exactPagesProperties.getProperty("SelectProductLabel"));
	private final By selectPublicationLabelBy = By.xpath(exactPagesProperties.getProperty("SelectPublicationLabel"));
	private final By selectPublicationYearLabelBy = By
			.xpath(exactPagesProperties.getProperty("SelectPublicationYearLabel"));
	private final By publicationYear2022By = By.xpath(exactPagesProperties.getProperty("PublicationYear2022"));
	private final By publicationBreastCancerTypeBy = By
			.xpath(exactPagesProperties.getProperty("PublicationBreastCancerType"));
	private final By publicationProstateCancerTypeBy = By
			.xpath(exactPagesProperties.getProperty("PublicationProstateCancerType"));
	private final By publicationTypeAbstractBy = By.xpath(exactPagesProperties.getProperty("PublicationTypeAbstract"));
	private final By publicationTypeManuscriptBy = By
			.xpath(exactPagesProperties.getProperty("PublicationTypeManuscript"));

	private final By clinicalStudiesOptionBy = By.xpath(exactPagesProperties.getProperty("ClinicalStudiesOption"));
	private final By clinicalStudiesPageBy = By.xpath(exactPagesProperties.getProperty("ClinicalStudiesPage"));
	private final By clinicalStudiesOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("ClinicalStudiesOptionHighlight"));
	private final By colorectalCancerScreeningTabBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerScreeningTab"));
	private final By diagnosedColorectalCancerTabBy = By
			.xpath(exactPagesProperties.getProperty("DiagnosedColorectalCancerTab"));
	private final By multiCancerScreeningTabBy = By.xpath(exactPagesProperties.getProperty("MultiCancerScreeningTab"));
	private final By colorectalCancerScreeningTabSelectedBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerScreeningTabSelected"));
	private final By diagnosedColorectalCancerTabSelectedBy = By
			.xpath(exactPagesProperties.getProperty("DiagnosedColorectalCancerTabSelected"));
	private final By multiCancerScreeningTabSelectedBy = By
			.xpath(exactPagesProperties.getProperty("MultiCancerScreeningTabSelected"));
	private final By compassNowEnrollingButtonBy = By
			.xpath(exactPagesProperties.getProperty("CompassNowEnrollingButton"));
	private final By crrect2CardBy = By.xpath(exactPagesProperties.getProperty("Crrect2Card"));
	private final By comingSoonCardBy = By.xpath(exactPagesProperties.getProperty("ComingSoonCard"));
	private final By aboutUsLinkBy = By.xpath(exactPagesProperties.getProperty("AboutUsLink"));
	private final By researchOptionBy = By.xpath(exactPagesProperties.getProperty("ResearchOption"));
	private final By researchPageBy = By.xpath(exactPagesProperties.getProperty("ResearchPage"));
	private final By researchOptionHighlightBy = By.xpath(exactPagesProperties.getProperty("ResearchOptionHighlight"));

//	private final By pipelineDataHeaderHighlightBy = By.xpath(exactPagesProperties.getProperty("PipelineDataHeaderHighlight"));

//	Our Tests
	private final By cologuardRxOnlyBy = By.xpath(exactPagesProperties.getProperty("CologuardRxOnlyTestCard"));
	private final By oncoExtraBy = By.xpath(exactPagesProperties.getProperty("OncoExtraTestCard"));
	private final By oncoguardLiverBy = By.xpath(exactPagesProperties.getProperty("OncoguardLiverTestCard"));
	private final By breastDCISscoreBy = By.xpath(exactPagesProperties.getProperty("BreastDCISscoreTestCard"));
	private final By breastRecurrencescoreBy = By
			.xpath(exactPagesProperties.getProperty("BreastRecurrencescoreTestCard"));
	private final By colonRecurrencescoreBy = By
			.xpath(exactPagesProperties.getProperty("ColonRecurrencescoreTestCard"));
	private final By riskguardBy = By.xpath(exactPagesProperties.getProperty("RiskguardTestCard"));
	private final By ourCologaurdOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("ourCologaurdOptionHighlight"));
	private final By visitColugaurdRXLinkBy = By.xpath(exactPagesProperties.getProperty("VisitColugaurdRXLink"));
	private final By cologaurdOptionBy = By.xpath(exactPagesProperties.getProperty("CologaurdOption"));
	private final By stoolDNAIsolationcardBy = By.xpath(exactPagesProperties.getProperty("StoolDNAIsolationcard"));
	private final By dnastabilitytechnologycardBy = By
			.xpath(exactPagesProperties.getProperty("DNAstabilitytechnologycard"));
	private final By dnabiomarkerdetectioncardBy = By
			.xpath(exactPagesProperties.getProperty("DNAbiomarkerdetectioncard"));
	private final By hemoglobinbiomarkerdetectionandstabilitytechnologycardBy = By
			.xpath(exactPagesProperties.getProperty("Hemoglobinbiomarkerdetectionandstabilitytechnologycard"));
	private final By powerfulMechanicalAlgorithmcardBy = By
			.xpath(exactPagesProperties.getProperty("PowerfulMechanicalAlgorithmcard"));
	private final By stoolDNAIsolationSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("StoolDNAIsolationSilkySlider"));
	private final By dnastabilitytechnologySilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("DNAstabilitytechnologySilkySlider"));
	private final By dnabiomarkerdetectionSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("DNAbiomarkerdetectionSilkySlider"));
	private final By hemoglobinbiomarkerdetectionandstabilitytechnologySilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("HemoglobinbiomarkerdetectionandstabilitytechnologySilkySlider"));
	private final By powerfulMechanicalAlgorithmSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("PowerfulMechanicalAlgorithmSilkySlider"));
	private final By referenceLinkOnOurTestBy = By.xpath(exactPagesProperties.getProperty("ReferenceLinkOnOurTest"));
	private final By oncoExtraCardLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncoExtraCardLearnMoreLink"));
	private final By oncoextraPageBy = By.xpath(exactPagesProperties.getProperty("OncoextraPage"));
	private final By ourOncoextraOptionHighlightBy = By
			.xpath(exactPagesProperties.getProperty("ourOncoextraOptionHighlight"));
	private final By oncextrapageLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("oncextrapageLearnMoreLink"));
	private final By oncoectraoptionBy = By.xpath(exactPagesProperties.getProperty("oncoectraoption"));
	private final By ultraComprehensiveGenomicProfilingcardBy = By
			.xpath(exactPagesProperties.getProperty("UltraComprehensiveGenomicProfilingcard"));
	private final By patientMatchedTumorNormalSequencingcardBy = By
			.xpath(exactPagesProperties.getProperty("PatientMatchedTumorNormalSequencingcard"));
	private final By clinicallyActionablecardBy = By
			.xpath(exactPagesProperties.getProperty("ClinicallyActionablecard"));
	private final By ultraComprehensiveGenomicProfilingSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("UltraComprehensiveGenomicProfilingSilkySlider"));
	private final By patientMatchedTumorNormalSequencingSilkySlideBy = By
			.xpath(exactPagesProperties.getProperty("PatientMatchedTumorNormalSequencingSilkySlide"));
	private final By clinicallyActionableSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("ClinicallyActionableSilkySlider"));
	private final By oncogaurdLiverCardLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncogaurdLiverCardLearnMoreLink"));
	private final By oncogaurdLiverPageBy = By.xpath(exactPagesProperties.getProperty("OncogaurdLiverPage"));
	private final By oncogaurdLiverOptionHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("OncogaurdLiverOptionHighlighted"));
	private final By visitOncogaurdLiverlinkBy = By.xpath(exactPagesProperties.getProperty("VisitOncogaurdLiverlink"));
	private final By oncogaurdLiverOptionBy = By.xpath(exactPagesProperties.getProperty("OncogaurdLiverOption"));
	private final By advancedperformanceyoucanrelyoncardBy = By
			.xpath(exactPagesProperties.getProperty("Advancedperformanceyoucanrelyoncard"));
	private final By innovationwithoutinconveniencecardBy = By
			.xpath(exactPagesProperties.getProperty("Innovationwithoutinconveniencecard"));
	private final By supportthatdrivesadherencecardBy = By
			.xpath(exactPagesProperties.getProperty("Supportthatdrivesadherencecard"));
	private final By advancedperformanceyoucanrelyonSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("AdvancedperformanceyoucanrelyonSilkySlider"));
	private final By innovationwithoutinconvenienceSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("InnovationwithoutinconvenienceSilkySlider"));
	private final By supportthatdrivesadherenceSilkySliderBy = By
			.xpath(exactPagesProperties.getProperty("SupportthatdrivesadherenceSilkySlider"));
	private final By oncotypeBreastDCISScoreLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeBreastDCISScoreLearnMoreLink"));
	private final By oncotypeBreastDCISScorePageBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeBreastDCISScorePage"));
	private final By oncoTypeDXBy = By.xpath(exactPagesProperties.getProperty("OncoTypeDX"));
	private final By oncotypeDXBreastDCISScoreOptionHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeDXBreastDCISScoreOptionHighlighted"));
	private final By oncotypeBreastDCISScorePageLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeBreastDCISScorePageLearnMoreLink"));
	private final By oncotypeBreastRecurrenceScoreLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeBreastRecurrenceScoreLearnMoreLink"));
	private final By oncotypeBreastRecurrenceScorePageBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeBreastRecurrenceScorePage"));
	private final By oncotypeDXBreastRecurrenceScoreOptionHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeDXBreastRecurrenceScoreOptionHighlighted"));
	private final By oncotypeBreastRecurrenceScorePageLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeBreastRecurrenceScorePageLearnMoreLink"));
	private final By oncotypeColonRecurrenceScoreLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeColonRecurrenceScoreLearnMoreLink"));
	private final By oncotypeColonRecurrenceScorePageBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeColonRecurrenceScorePage"));
	private final By oncotypeDXColonRecurrenceScoreOptionHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeDXColonRecurrenceScoreOptionHighlighted"));
	private final By oncotypeColonRecurrenceScorePageLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("OncotypeColonRecurrenceScorePageLearnMoreLink"));
	private final By riskguardLearnMoreLinkBy = By.xpath(exactPagesProperties.getProperty("RiskguardLearnMoreLink"));
	private final By riskguardPageBy = By.xpath(exactPagesProperties.getProperty("RiskguardPage"));
	private final By riskguardOptionHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("RiskguardOptionHighlighted"));
	private final By riskguardOptionBy = By.xpath(exactPagesProperties.getProperty("RiskguardOption"));
	private final By riskguardPageLearnMoreAboutPreventiongenticsBy = By
			.xpath(exactPagesProperties.getProperty("RiskguardPageLearnMoreAboutPreventiongentics"));
	private final By riskguardInsuranceCoveragePageLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("RiskguardInsuranceCoveragePageLearnMoreLink"));
	private final By individualizedReportcardBy = By
			.xpath(exactPagesProperties.getProperty("IndividualizedReportcard"));
	private final By clinicallyActionableRiskguardcardBy = By
			.xpath(exactPagesProperties.getProperty("ClinicallyActionableRiskguardcard"));
	private final By trustedPartnercardBy = By.xpath(exactPagesProperties.getProperty("TrustedPartnercard"));
	private final By downloadAsamplePatientReportBy = By
			.xpath(exactPagesProperties.getProperty("DownloadAsamplePatientReport"));
	private final By downloadRiskguardFactSheetBy = By
			.xpath(exactPagesProperties.getProperty("DownloadRiskguardFactSheet"));
	private final By trustedPartnerLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("TrustedPartnerLearnMoreLink"));
	private final By trustedPartnerDailogBoxBy = By.xpath(exactPagesProperties.getProperty("TrustedPartnerDailogBox"));
	private final By trustedPartnerContinueToGenomeBy = By
			.xpath(exactPagesProperties.getProperty("TrustedPartnerContinueToGenome"));
	private final By cancelButtonBy = By.xpath(exactPagesProperties.getProperty("CancelButton"));
	private final By downloadTheRiskguardFactSheetBy = By
			.xpath(exactPagesProperties.getProperty("DownloadTheRiskguardFactSheet"));
	private final By downloadOrderFormBy = By.xpath(exactPagesProperties.getProperty("DownloadOrderForm"));
	private final By forPatientsBy = By.xpath(exactPagesProperties.getProperty("ForPatients"));
	private final By positivecardBy = By.xpath(exactPagesProperties.getProperty("Positivecard"));
	private final By negativecardBy = By.xpath(exactPagesProperties.getProperty("Negativecard"));
	private final By varientOfUncertainSignificancecardBy = By
			.xpath(exactPagesProperties.getProperty("VarientOfUncertainSignificancecard"));
	private final By howTestingHelpLearnMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("HowTestingHelpLearnMoreLink"));
	private final By howTestingHelpLearnMoreLinkDailogBoxBy = By
			.xpath(exactPagesProperties.getProperty("HowTestingHelpLearnMoreLinkDailogBox"));
	private final By howTestingHelpLearnMoreLinkContinueToGenomeBy = By
			.xpath(exactPagesProperties.getProperty("HowTestingHelpLearnMoreLinkContinueToGenome"));
	private final By howTestingHelpLearnMoreLinkCancelButtonBy = By
			.xpath(exactPagesProperties.getProperty("HowTestingHelpLearnMoreLinkCancelButton"));
	private final By downloadaSamplePatientReportBy = By
			.xpath(exactPagesProperties.getProperty("DownloadaSamplePatientReport"));
	private final By forProvidersBy = By.xpath(exactPagesProperties.getProperty("ForProviders"));
	private final By needAccesstothePatientReportsHubBy = By
			.xpath(exactPagesProperties.getProperty("NeedAccesstothePatientReportsHub"));
	private final By needAccessToTheOpenOrClosedClientTicketsBy = By
			.xpath(exactPagesProperties.getProperty("NeedAccessToTheOpenOrClosedClientTickets"));
	private final By needNYStateProviderInformationBy = By
			.xpath(exactPagesProperties.getProperty("NeedNYStateProviderInformation"));
	private final By areyouISO15189CAPandCLIAaccreditedBy = By
			.xpath(exactPagesProperties.getProperty("AreyouISO15189CAPandCLIAaccredited"));
	private final By preventiongeneticsCertificationLinkBy = By
			.xpath(exactPagesProperties.getProperty("PreventiongeneticsCertificationLink"));
	private final By howDoesaPatientFamilyGetTestedBy = By
			.xpath(exactPagesProperties.getProperty("HowDoesaPatientFamilyGetTested"));
	private final By genomeMedicalLinkBy = By.xpath(exactPagesProperties.getProperty("GenomeMedicalLink"));
	private final By genomeMedicalDailogBoxBy = By.xpath(exactPagesProperties.getProperty("GenomeMedicalDailogBox"));
	private final By genomeMedicalContinueToGenomeBy = By
			.xpath(exactPagesProperties.getProperty("GenomeMedicalContinueToGenome"));
	private final By genomeMedicalCancelButtonBy = By
			.xpath(exactPagesProperties.getProperty("GenomeMedicalCancelButton"));
	private final By contactUSFirstCardBy = By.xpath(exactPagesProperties.getProperty("ContactUSFirstCard"));
	private final By contactUSSecondCardBy = By.xpath(exactPagesProperties.getProperty("ContactUSSecondCard"));
	private final By contactUSThirdCardBy = By.xpath(exactPagesProperties.getProperty("ContactUSThirdCard"));
	private final By contactUSSecondCardLearnMoreBy = By
			.xpath(exactPagesProperties.getProperty("ContactUSSecondCardLearnMore"));
	private final By secondCardDailogBoxDisplayedBy = By
			.xpath(exactPagesProperties.getProperty("SecondCardDailogBoxDisplayed"));
	private final By secondCardContinueToGenomeBy = By
			.xpath(exactPagesProperties.getProperty("SecondCardContinueToGenome"));
	private final By secondCardCancelButtonBy = By.xpath(exactPagesProperties.getProperty("SecondCardCancelButton"));
	private final By contactUSThirdCardLearnMoreBy = By
			.xpath(exactPagesProperties.getProperty("ContactUSThirdCardLearnMore"));
	private final By contactUSSecondCardLearnMoreForPatientsBy = By
			.xpath(exactPagesProperties.getProperty("ContactUSSecondCardLearnMoreForPatients"));
	private final By contactUSThirdCardLearnMoreForPatientsBy = By
			.xpath(exactPagesProperties.getProperty("ContactUSThirdCardLearnMoreForPatients"));

//News Room
	private final By newsRoomMenuOptionBy = By.xpath(exactPagesProperties.getProperty("NewsRoomMenuOption"));
	private final By newsStoriesHeaderBy = By.xpath(exactPagesProperties.getProperty("NewsStoriesHeader"));
	private final By testingNewTopicSlideBy = By.xpath(exactPagesProperties.getProperty("TestingNewTopicSlide"));
	private final By nextButtonNewsRoomBy = By.xpath(exactPagesProperties.getProperty("NextButtonNewsRoom"));
	private final By abreastCancerSurgeonsBreastCancerStorySlideby = By
			.xpath(exactPagesProperties.getProperty("ABreastCancerSurgeonsBreastCancerStorySlide"));
	private final By theTollofaDiagnosisSlideBy = By
			.xpath(exactPagesProperties.getProperty("TheTollofaDiagnosisSlide"));
	private final By testingNewTopicSlideReadmoreBy = By
			.xpath(exactPagesProperties.getProperty("TestingNewTopicSlideReadmore"));
	private final By testingNewTopicPageBy = By.xpath(exactPagesProperties.getProperty("TestingNewTopicPage"));
	private final By breastCancerStorySlideReadmoreBy = By
			.xpath(exactPagesProperties.getProperty("BreastCancerStorySlideReadmore"));
	private final By breastCancerStoryPageBy = By.xpath(exactPagesProperties.getProperty("BreastCancerStoryPage"));
	private final By theTollofaDiagnosisSlideReadmoreBy = By
			.xpath(exactPagesProperties.getProperty("TheTollofaDiagnosisSlideReadmore"));
	private final By theTollofaDiagnosisPageBy = By.xpath(exactPagesProperties.getProperty("TheTollofaDiagnosisPage"));
	private final By pressReleaseViewAllBy = By.xpath(exactPagesProperties.getProperty("PressReleaseViewAll"));
	private final By pressReleasePageBy = By.xpath(exactPagesProperties.getProperty("PressReleasePageBy"));
	private final By newesroomOptionBy = By.xpath(exactPagesProperties.getProperty("NewesroomOption"));
	private final By pressReleaseOptionBy = By.xpath(exactPagesProperties.getProperty("PressReleaseOption"));
	private final By patientStoriesIconBy = By.xpath(exactPagesProperties.getProperty("PatientStoriesIcon"));
	private final By breastCancerIconBy = By.xpath(exactPagesProperties.getProperty("BreastCancerIcon"));
	private final By smarterAnswersIconBy = By.xpath(exactPagesProperties.getProperty("SmarterAnswersIcon"));
	private final By patientStoriesIconHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("PatientStoriesIconHighlighted"));
	private final By breastCancerIconHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("BreastCancerIconHighlighted"));
	private final By smarterAnswersIconHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("SmarterAnswersIconHighlighted"));
	private final By breastCancerLinkBy = By.xpath(exactPagesProperties.getProperty("BreastCancerLink"));
	private final By breastCancerPaginationBy = By.xpath(exactPagesProperties.getProperty("BreastCancerPagination"));
	private final By breastCancerFirstGridBy = By.xpath(exactPagesProperties.getProperty("BreastCancerFirstGrid"));
	private final By breastCancerFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("BreastCancerFirstGridPage"));
	private final By multiCancerLinkBy = By.xpath(exactPagesProperties.getProperty("MultiCancerLink"));
	private final By multiCancerLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("MultiCancerLinkHighlighted"));
	private final By multiCancerPaginationBy = By.xpath(exactPagesProperties.getProperty("MultiCancerPagination"));
	private final By multiCancerFirstGridBy = By.xpath(exactPagesProperties.getProperty("MultiCancerFirstGrid"));
	private final By multiCancerFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("MultiCancerFirstGridPage"));
	private final By colorectalCancerLinkBy = By.xpath(exactPagesProperties.getProperty("ColorectalCancerLink"));
	private final By colorectalCancerLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerLinkHighlighted"));
	private final By colorectalCancerPaginationBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerPagination"));
	private final By colorectalCancerFirstGridBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerFirstGrid"));
	private final By colorectalCancerFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("ColorectalCancerFirstGridPage"));
	private final By liverCancerLinkBy = By.xpath(exactPagesProperties.getProperty("LiverCancerLink"));
	private final By liverCancerLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("LiverCancerLinkHighlighted"));
	private final By liverCancerPaginationBy = By.xpath(exactPagesProperties.getProperty("LiverCancerPagination"));
	private final By liverCancerFirstGridBy = By.xpath(exactPagesProperties.getProperty("LiverCancerFirstGrid"));
	private final By liverCancerFirstGridPageDisplayedBy = By
			.xpath(exactPagesProperties.getProperty("LiverCancerFirstGridPageDisplayed"));
	private final By earlierDetectionLinkBy = By.xpath(exactPagesProperties.getProperty("EarlierDetectionLink"));
	private final By earlierDetectionLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("EarlierDetectionLinkHighlighted"));
	private final By earlierDetectionPaginationBy = By
			.xpath(exactPagesProperties.getProperty("EarlierDetectionPagination"));
	private final By earlierDetectionFirstGridBy = By
			.xpath(exactPagesProperties.getProperty("EarlierDetectionFirstGrid"));
	private final By earlierDetectionFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("EarlierDetectionFirstGridPage"));
	private final By healthEquityLinkBy = By.xpath(exactPagesProperties.getProperty("HealthEquityLink"));
	private final By healthEquityLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("HealthEquityLinkHighlighted"));
	private final By healthEquityPaginationBy = By.xpath(exactPagesProperties.getProperty("HealthEquityPagination"));
	private final By healthEquityFirstGridBy = By.xpath(exactPagesProperties.getProperty("HealthEquityFirstGrid"));
	private final By healthEquityFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("HealthEquityFirstGridPage"));
	private final By lifeAtExactLinkBy = By.xpath(exactPagesProperties.getProperty("LifeAtExactLink"));
	private final By lifeAtExactLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("LifeAtExactLinkHighlighted"));
	private final By lifeAtExactPaginationBy = By.xpath(exactPagesProperties.getProperty("LifeAtExactPagination"));
	private final By lifeAtExactFirstGridBy = By.xpath(exactPagesProperties.getProperty("LifeAtExactFirstGrid"));
	private final By lifeAtExactFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("LifeAtExactFirstGridPage"));
	private final By patientStoriesLinkBy = By.xpath(exactPagesProperties.getProperty("PatientStoriesLink"));
	private final By patientStoriesLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("PatientStoriesLinkHighlighted"));
	private final By patientStoriesPaginationBy = By
			.xpath(exactPagesProperties.getProperty("PatientStoriesPagination"));
	private final By patientStoriesFirstGridBy = By.xpath(exactPagesProperties.getProperty("PatientStoriesFirstGrid"));
	private final By patientStoriesFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("PatientStoriesFirstGridPage"));
	private final By pipelineLinkBy = By.xpath(exactPagesProperties.getProperty("PipelineLink"));
	private final By pipelineLinkHighlightedBy = By.xpath(exactPagesProperties.getProperty("PipelineLinkHighlighted"));
	private final By pipelinePaginationBy = By.xpath(exactPagesProperties.getProperty("PipelinePagination"));
	private final By pipelineFirstGridBy = By.xpath(exactPagesProperties.getProperty("PipelineFirstGrid"));
	private final By pipelineFirstGridPageBy = By.xpath(exactPagesProperties.getProperty("PipelineFirstGridPage"));
	private final By smarterAnswersLinkBy = By.xpath(exactPagesProperties.getProperty("SmarterAnswersLink"));
	private final By smarterAnswersLinkHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("SmarterAnswersLinkHighlighted"));
	private final By smarterAnswersPaginationBy = By
			.xpath(exactPagesProperties.getProperty("SmarterAnswersPagination"));
	private final By smarterAnswersFirstGridBy = By.xpath(exactPagesProperties.getProperty("SmarterAnswersFirstGrid"));
	private final By smarterAnswersFirstGridPageBy = By
			.xpath(exactPagesProperties.getProperty("SmarterAnswersFirstGridPage"));
	private final By pressReleaseOptionUnderNewRoomBy = By
			.xpath(exactPagesProperties.getProperty("PressReleaseOptionUnderNewRoom"));
	private final By workflowSlideBy = By.xpath(exactPagesProperties.getProperty("WorkflowSlide"));
	private final By testingSecuritySlideBy = By.xpath(exactPagesProperties.getProperty("TestingSecuritySlide"));
	private final By exactSciencesAnnouncesPreliminarySlideBy = By
			.xpath(exactPagesProperties.getProperty("ExactSciencesAnnouncesPreliminarySlide"));
	private final By workflowSlideReadmoreBy = By.xpath(exactPagesProperties.getProperty("WorkflowSlideReadmore"));
	private final By workflowPageBy = By.xpath(exactPagesProperties.getProperty("WorkflowPage"));
	private final By testingSecuritySlideReadmoreBy = By
			.xpath(exactPagesProperties.getProperty("TestingSecuritySlideReadmore"));
	private final By testingSecurityPageBy = By.xpath(exactPagesProperties.getProperty("TestingSecurityPage"));
	private final By exactSciencesAnnouncesPreliminarySlideReadmoreBy = By
			.xpath(exactPagesProperties.getProperty("ExactSciencesAnnouncesPreliminarySlideReadmore"));
	private final By exactSciencesAnnouncesPreliminaryPageBy = By
			.xpath(exactPagesProperties.getProperty("ExactSciencesAnnouncesPreliminaryPage"));
	private final By pressReleasePaginationBy = By.xpath(exactPagesProperties.getProperty("PressReleasePagination"));
	private final By videoIconBy = By.xpath(exactPagesProperties.getProperty("VideoIcon"));
	private final By photosIconBy = By.xpath(exactPagesProperties.getProperty("PhotosIcon"));
	private final By mutimediaPageBy = By.xpath(exactPagesProperties.getProperty("MutimediaPage"));
	private final By multimediaOptionBy = By.xpath(exactPagesProperties.getProperty("MultimediaOption"));
	private final By videoSubsectionBy = By.xpath(exactPagesProperties.getProperty("VideoSubsection"));
	private final By photosSubsectionBy = By.xpath(exactPagesProperties.getProperty("PhotosSubsection"));
	private final By firstPhotosDownloadBy = By.xpath(exactPagesProperties.getProperty("FirstPhotosDownload"));
	private final By secondPhotosDownloadBy = By.xpath(exactPagesProperties.getProperty("SecondPhotosDownload"));
	private final By thirdPhotosDownloadBy = By.xpath(exactPagesProperties.getProperty("ThirdPhotosDownload"));

	private By viewProfileLinkIndexBy = null;

	// video
	private final By playButtonBy = By.xpath(exactPagesProperties.getProperty("PlayButton"));
	private final By videoPlayBy = By.xpath(exactPagesProperties.getProperty("VideoPlay"));
	private final By pauseButtonBy = By.xpath(exactPagesProperties.getProperty("PauseButton"));
	private final By videoHoverBy = By.xpath(exactPagesProperties.getProperty("VideoHover"));
	private final By videoPausedBy = By.xpath(exactPagesProperties.getProperty("VideoPaused"));
	private final By multiCancerEarlyDetectionBy = By
			.xpath(exactPagesProperties.getProperty("MultiCancerEarlyDetection"));
	private final By multiCancerVideoPlayButtonBy = By
			.xpath(exactPagesProperties.getProperty("PlayButtonMultimediaVideo"));
	private final By videoTimeBy = By.xpath(exactPagesProperties.getProperty("VideoTime"));
	private final By multimediaMenuOptionBy = By.xpath(exactPagesProperties.getProperty("MultimediaMenuOption"));
	private final By multimediaVideoBackgroundBy = By
			.xpath(exactPagesProperties.getProperty("MultimediaVideoBackground"));

//	footer
	private final By contactUsFooterBy = By.xpath(exactPagesProperties.getProperty("ContactUsFooter"));
	private final By aboutHyperlinkBy = By.xpath(exactPagesProperties.getProperty("AboutHyperlink"));
	private final By termOfUseHyperlinkBy = By.xpath(exactPagesProperties.getProperty("TermOfUseHyperlink"));
	private final By purchasingTermseHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("PurchasingTermseHyperlink"));
	private final By vendorCodeofConducteHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("VendorCodeofConducteHyperlink"));
	private final By patentsTrademarksHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("PatentsTrademarksHyperlink"));
	private final By privacyPolicyHyperlinkBy = By.xpath(exactPagesProperties.getProperty("PrivacyPolicyHyperlink"));
	private final By hipaaNoticeHyperlinkBy = By.xpath(exactPagesProperties.getProperty("HipaaNoticeHyperlink"));
	private final By fcoiPolicyHyperlinkBy = By.xpath(exactPagesProperties.getProperty("FcoiPolicyHyperlink"));
	private final By doNotSellMyInfoHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("DoNotSellMyInfoHyperlink"));
	private final By cologuardcomHyperlinkBy = By.xpath(exactPagesProperties.getProperty("CologuardcomHyperlink"));
	private final By noticeofCollectionPolicyHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("NoticeofCollectionPolicyHyperlink"));
	private final By noticeofFinancialIncentivePolicyHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("NoticeofFinancialIncentivePolicyHyperlink"));
	private final By noticeofRighttoOptOutPolicyHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("NoticeofRighttoOptOutPolicyHyperlink"));
	private final By ccpaGDPRPrivacyPolicyHyperlinkBy = By
			.xpath(exactPagesProperties.getProperty("CcpaGDPRPrivacyPolicyHyperlink"));
	private final By dataRetentionHyperlinkBy = By.xpath(exactPagesProperties.getProperty("DataRetentionHyperlink"));
	private final By termOfUsePageBy = By.xpath(exactPagesProperties.getProperty("TermOfUsePage"));
	private final By patentsTrademarksPageBy = By.xpath(exactPagesProperties.getProperty("PatentsTrademarksPage"));
	private final By privacyPolicyPageBy = By.xpath(exactPagesProperties.getProperty("PrivacyPolicyPage"));
	private final By hipaaNoticePageBy = By.xpath(exactPagesProperties.getProperty("HipaaNoticePage"));
	private final By doNotSellMyInfoPageBy = By.xpath(exactPagesProperties.getProperty("DoNotSellMyInfoPage"));
	private final By noticeofCollectionPolicyPageBy = By
			.xpath(exactPagesProperties.getProperty("NoticeofCollectionPolicyPage"));
	private final By noticeofFinancialIncentivePolicyPageBy = By
			.xpath(exactPagesProperties.getProperty("NoticeofFinancialIncentivePolicyPage"));
	private final By noticeofRighttoOptOutPolicyPageBy = By
			.xpath(exactPagesProperties.getProperty("NoticeofRighttoOptOutPolicyPage"));
	private final By ccpaGDPRPrivacyPolicyPageBy = By
			.xpath(exactPagesProperties.getProperty("CcpaGDPRPrivacyPolicyPage"));
	private final By dataRetentionPageBy = By.xpath(exactPagesProperties.getProperty("DataRetentionPage"));
	private final By facebookHyperlinkBy = By.xpath(exactPagesProperties.getProperty("FacebookHyperlink"));
	private final By twitterHyperlinkBy = By.xpath(exactPagesProperties.getProperty("TwitterHyperlink"));
	private final By linkedinHyperlinkBy = By.xpath(exactPagesProperties.getProperty("LinkedinHyperlink"));
	private final By exactSciencesFooterLogoBy = By.xpath(exactPagesProperties.getProperty("ExactSciencesFooterLogo"));
	private final By footerAddressBy = By.xpath(exactPagesProperties.getProperty("FooterAddress"));

	public String getCorporateWebsiteHeading() {
		Element.waitForVisible(corporateWebsiteTittleBy);
		return Element.getElementText(corporateWebsiteTittleBy);
	}

	public boolean isOurTestsCardDisplayed() {
		return Element.isElementDisplayed(ourTestsCardBy);
	}

	public boolean isOurPipelineCardDisplayed() {
		return Element.isElementDisplayed(ourPipelineCardBy);
	}

	public boolean isOurNewsroomCardDisplayed() {
		return Element.isElementDisplayed(ourNewsroomCard);
	}

	public void clickOurTestsCardLearnMoreLink() {
		Element.loadAndClick(ourTestsCardLearnMoreLinkBy);
	}

	public void clickOurTestMenuOption() {
		Element.loadAndClick(ourTestsOptionBy);
	}

	public void clickoncextrapageLearnMoreLink() {
		Element.loadAndClick(oncextrapageLearnMoreLinkBy);
	}

	public void clickOncoextraOption() {
		Element.loadAndClick(oncoectraoptionBy);
	}

	public boolean isOurTestsPageDisplayed() {
		return Element.isElementDisplayed(ourTestsPageBy);
	}

	public boolean isOurTestsHeaderHighlightedDisplayed() {
		return Element.isElementDisplayed(ourTestsHeaderHighlightBy);
	}

	public void clickExactSciencesLogo() {
		Element.waitForVisible(exactSciencesLogoBy);
		Element.loadAndClick(exactSciencesLogoBy);
	}

	public boolean isExactSciencesLogoDisplayed() {
		Element.waitForVisible(exactSciencesLogoBy);
		return Element.isElementDisplayed(exactSciencesLogoBy);
	}

	public void clickOurPipelineCardLearnMoreLink() {
		Element.loadAndClick(ourPipelineCardLearnMoreLinkBy);
	}

	public boolean isPipelineDataPageDisplayed() {
		return Element.isElementDisplayed(pipelineDataPageBy);
	}

	public boolean isPipelineDataHeadeHighlightedDisplayed() {
		return Element.isElementDisplayed(pipelineDataHeaderHighlightBy);
	}

	public void clickNewsroomCardLearnMoreLink() {
		Sleeper.sleepTightInSeconds(3);
		Element.loadAndClick(ourNewsroomCardLearnMoreLinkBy);
	}

	public boolean isNewsroomPageDisplayed() {
		return Element.isElementDisplayed(newsroomPageBy);
	}

	public boolean isNewsroomHeadeHighlightedDisplayed() {
		return Element.isElementDisplayed(newsroomHeaderHighlightBy);
	}

	public void clickExploreTheTestLink() {
		Element.loadAndClick(exploreTheTestLinkBy);
	}

	public boolean isOncoExTraPageDisplayed() {
		return Element.isElementDisplayed(oncoExTraPageBy);
	}

	public boolean isOncoExTraHeaderOptionActiveDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(oncoExTraHeaderOptionActiveBy);
	}

	public void clickPublicationsLink() {
		Element.loadAndClick(publicationsLinkBy);
	}

	public boolean isPublicationsPageDisplayed() {
		return Element.isElementDisplayed(publicationsPageBy);
	}

	public boolean isPublicationsHeaderOptionActiveDisplayed() {
		return Element.isElementDisplayed(publicationsHeaderOptionActiveBy);
	}

	public void clickAboutMenuOption() {
		Element.loadAndClick(aboutHeaderOptionBy);
	}

	public boolean isAboutUsPageDisplayed() {
		return Element.isElementDisplayed(aboutUsPageBy);
	}

	public boolean isAboutHeaderOptionHighlightDisplayed() {
		return Element.isElementDisplayed(aboutHeaderOptionHighlightBy);
	}

	public void hoverOurTestsMenuOption() {
		Element.mouseHover(ourTestsOptionBy);
	}

	public void hoverAboutMenuOption() {
		Element.mouseHover(aboutHeaderOptionBy);
	}

	public void hoverPipelineMenuOption() {
		Element.mouseHover(pipelineHeaderOptionBy);
	}

	public void clickPipelineMenuOption() {
		Element.loadAndClick(pipelineHeaderOptionBy);
	}

	public void clickLeadershipOption() {
		Element.loadAndClick(leadershipOptionBy);
	}

	public void clickLBGardBloodTubesSDSButton() {
		Element.loadAndClick(lBGardBloodTubesSDSButtonBy);
	}

	public void clickLBGardBloodTubesIFUButtonButton() {
		Element.loadAndClick(lBGardBloodTubesIFUButtonBy);
	}

	public void clickViewSlideLink() {
		Element.waitForVisible(viewSlideLinkBy);
		Element.loadAndClick(viewSlideLinkBy);
	}

	public void clickViewSlideLink2() {
		Element.waitForVisible(viewSlideLink2By);
		Element.loadAndClick(viewSlideLink2By);
	}

	public void clickNextArrowSign() {
		Element.loadAndClick(nextArrowSignBy);
		Sleeper.sleepTightInSeconds(5);
	}

	public void clickSubmitButton() {
		Element.loadAndClick(submitButtonBy);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(5);
	}

	public void clickViewAllPublicationsAbstractsLink() {
		Element.loadAndClick(viewAllPublicationsAbstractsLinkBy);
	}

	public void selectAdvancedCancerOption() {
		Element.loadAndClick(advancedCancerOptionBy);
	}

	public void selectBreastCancerOption() {
		Element.loadAndClick(breastCancerOptionBy);
	}

	public void selectOncotypeDXBreastRecurrenceScoreTestOption() {
		Element.loadAndClick(oncotypeDXBreastRecurrenceScoreTestBy);
	}

	public void selectPublicationTypeAbstractOption() {
		Element.loadAndClick(publicationTypeAbstractOptionBy);
	}

	public void selectOncotypeDXGenomicProstateScoreTestOption() {
		Element.loadAndClick(dXGenomicProstateScoreTestOptionBy);
	}

	public void selectPublicationTypeManuscriptOption() {
		Element.loadAndClick(publicationTypeManuscriptOptionBy);
	}

	public void selectPublicationYear2022Option() {
		Element.loadAndClick(publicationYear2022OptionBy);
	}

	public void clickSelectCancerTypeLabel() {
		Element.loadAndClick(selectLabelBy);
	}

	public void clickSelectProductLabel() {
		Element.loadAndClick(selectProductLabelBy);
	}

	public void clickSelectPublicationLabel() {
		Element.loadAndClick(selectPublicationLabelBy);
	}

	public void clickSelectPublicationYearLabel() {
		Element.loadAndClick(selectPublicationYearLabelBy);
	}

	public void clickResetAllFilterButton() {
		Element.loadAndClick(resetAllFilterButtonnBy);
	}

	public String getCurrentFilterValue() {
		return Element.getElementText(appliedFilterValueBy);
	}

	public boolean isLeadershipPageDisplayed() {
		return Element.isElementDisplayed(leadershipPageBy);
	}

	public boolean isLeadershipOptionHighlightDisplayed() {
		return Element.isElementDisplayed(leadershipOptionHighlightBy);
	}

	public void clickViewProfileLink(int executivesLeadersCount) {
		viewProfileLinkIndexBy = By.xpath(
				"(" + (exactPagesProperties.getProperty("ViewProfileLink")) + ")[" + executivesLeadersCount + "]");
		Element.waitForVisible(viewProfileLinkIndexBy);
		Element.loadAndClick(viewProfileLinkIndexBy);
	}

	public String getexecutivesLeadersTittle() {
		Element.waitForVisible(profilePageTittleBy);
		return Element.getElementText(profilePageTittleBy);
	}

	public void clickMedicalLeadersOption() {
		Element.loadAndClick(medicalLeadersOptionBy);
	}

	public void clickBoardOfDirectorsOption() {
		Element.loadAndClick(boardOfDirectorsOptionBy);
	}

	public boolean isBoardOfDirectorsPageDisplayed() {
		return Element.isElementDisplayed(boardOfDirectorsPageBy);
	}

	public boolean isBoardOfDirectorsOptionHighlighted() {
		return Element.isElementDisplayed(boardOfDirectorsOptionHighlightBy);
	}

	public void clickCompanyHistoryOption() {
		Element.loadAndClick(companyHistoryOptionBy);
	}

	public boolean isCompanyHistoryPageDisplayed() {
		return Element.isElementDisplayed(companyHistoryPageBy);
	}

	public boolean isCompanyHistoryHighlighted() {
		return Element.isElementDisplayed(companyHistoryOptionHighlightBy);
	}

	public void clickCorporateImpactandCommunityRelationsOption() {
		Element.loadAndClick(corporateImpactandCommunityRelationsOptionBy);
	}

	public void clickOurCollaborationsOption() {
		Element.loadAndClick(ourCollaborationsOptionBy);
	}

	public boolean isOurCollaborationsPageDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(ourCollaborationsPageBy);
	}

	public boolean isOurCollaborationsHighlighted() {
		return Element.isElementDisplayed(ourCollaborationsOptionHighlightBy);
	}

	public void clickContactUsOption() {
		Element.loadAndClick(contactUsOptionBy);
	}

	public boolean isContactUsPageDisplayed() {
		return Element.isElementDisplayed(contactUsPageBy);
	}

	public boolean isContactUsHighlighted() {
		return Element.isElementDisplayed(contactUsOptionHighlightBy);
	}

	public void clickLaboratoriesContactUsLink() {
		Element.loadAndClick(laboratoriesContactUsLinkBy);
	}

	public void clickHumanResourcesContactUsLink() {
		Element.loadAndClick(humanResourcesContactUsLinkBy);
	}

	public void clickInvestorContactUsLink() {
		Element.loadAndClick(investorContactUsLinkBy);
	}

	public void clickGeneralContactUsLink() {
		Element.loadAndClick(generalContactUsLinkBy);
	}

	public void clickMediaContactUsLink() {
		Element.loadAndClick(mediaContactUsLinkBy);
	}

	public void clickClinicalStudiesOption() {
		Element.loadAndClick(clinicalStudiesOptionBy);
	}

	public void clickColorectalCancerScreeningTab() {
		Element.loadAndClick(colorectalCancerScreeningTabBy);
	}

	public void clickCompassNowEnrollingButton() {
		Element.loadAndClick(compassNowEnrollingButtonBy);
	}

	public void clickDiagnosedColorectalCancerTab() {
		Element.loadAndClick(diagnosedColorectalCancerTabBy);
	}

	public void clickMultiCancerScreeningTab() {
		Element.loadAndClick(multiCancerScreeningTabBy);
	}

	public void clickResearchOption() {
		Element.loadAndClick(researchOptionBy);
	}

	public void clickAboutUsLink() {
		Element.loadAndClick(aboutUsLinkBy);
	}

	public void clickMedicalContactUsLink() {
		Element.loadAndClick(medicalContactUsLinkBy);
	}

	public String getMoreInfoTittle() {
		Element.waitForVisible(moreInfoPageTittleBy);
		return Element.getElementText(moreInfoPageTittleBy);
	}

	public String getHighlightedPublicationsSlide1Text() {
		return Element.getElementText(highlightedPublicationsSlide1TextBy);
	}

	public String getHighlightedPublicationsSlide2Heading() {
		return Element.getElementText(highlightedPublicationsSlide2HeadingBy);
	}

	public String getHighlightedPublicationsSlide3Heading() {
		return Element.getElementText(highlightedPublicationsSlide3HeadingBy);
	}

	public String getHighlightedPublicationsSlide4Heading() {
		return Element.getElementText(highlightedPublicationsSlide4HeadingBy);
	}

	public String getHighlightedPublicationsSlide5Heading() {
		return Element.getElementText(highlightedPublicationsSlide5HeadingBy);
	}

	public String getHighlightedPublicationsSlide6Heading() {
		return Element.getElementText(highlightedPublicationsSlide6HeadingBy);
	}

	public String getHighlightedPublicationsSlide7Heading() {
		return Element.getElementText(highlightedPublicationsSlide7HeadingBy);
	}

	public void clickMoreInfoLink(int count) {
		viewProfileLinkIndexBy = By
				.xpath("(" + (exactPagesProperties.getProperty("MoreInfoLink")) + ")[" + count + "]");
		Element.loadAndClick(viewProfileLinkIndexBy);
	}

	public void clickPipelineDataIconCardLearmMoreLink(int count) {
		viewProfileLinkIndexBy = By.xpath(
				"(" + (exactPagesProperties.getProperty("PipelineDataIconCardLearmMoreLink")) + ")[" + count + "]");
		Element.waitForVisible(viewProfileLinkIndexBy);
		Element.loadAndClick(viewProfileLinkIndexBy);
	}

	public boolean isBreastRadiationScorePageDisplayed() {
		return Element.isElementDisplayed(breastRadiationScorePageBy);
	}

	public boolean isBreastRadiationScoreOptionHighlighted() {
		return Element.isElementDisplayed(breastRadiationScoreOptionHighlightBy);
	}

	public boolean isCologuard2PageDisplayed() {
		return Element.isElementDisplayed(cologuardPageBy);
	}

	public boolean isCologuard2OptionHighlighted() {
		return Element.isElementDisplayed(cologuardOptionHighlightBy);
	}

	public boolean isColorectalCancerBloodPageDisplayed() {
		return Element.isElementDisplayed(colorectalCancerBloodPageBy);
	}

	public boolean isColorectalCancerBloodOptionHighlighted() {
		return Element.isElementDisplayed(colorectalCancerBloodOptionHighlightBy);
	}

	public boolean isMolecularResidualDiseasePageDisplayed() {
		return Element.isElementDisplayed(molecularResidualDiseasePageBy);
	}

	public boolean isMolecularResidualDiseaseOptionHighlighted() {
		return Element.isElementDisplayed(molecularResidualDiseaseOptionHighlightBy);
	}

	public boolean isMultiCancerEarlyDetectionPageDisplayed() {
		return Element.isElementDisplayed(multiCancerEarlyDetectionPageBy);
	}

	public boolean isMultiCancerEarlyDetectionOptionHighlighted() {
		return Element.isElementDisplayed(multiCancerEarlyDetectionOptionHighlightBy);
	}

	public boolean isPublicationsAndAbstractsPageDisplayed() {
		return Element.isElementDisplayed(publicationsAndAbstractsPageBy);
	}

	public boolean isPublicationsAndAbstractsOptionHighlighted() {
		return Element.isElementDisplayed(publicationsAndAbstractsOptionHighlightBy);
	}

	public boolean isPublicationBreastCancerTypeDisplayed() {
		Element.waitForVisible(publicationBreastCancerTypeBy);
		return Element.isElementDisplayed(publicationBreastCancerTypeBy);
	}

	public boolean isPublicationProstateCancerTypeDisplayed() {
		Element.waitForVisible(publicationProstateCancerTypeBy);
		return Element.isElementDisplayed(publicationProstateCancerTypeBy);
	}

	public boolean isPublicationTypeAbstractDisplayed() {
		Element.waitForVisible(publicationTypeAbstractBy);
		return Element.isElementDisplayed(publicationTypeAbstractBy);
	}

	public boolean isPublicationTypeManuscriptDisplayed() {
		Element.waitForVisible(publicationTypeManuscriptBy);
		return Element.isElementDisplayed(publicationTypeManuscriptBy);
	}

	public boolean isPublicationYear2022Displayed() {
		Element.waitForVisible(publicationYear2022By);
		return Element.isElementDisplayed(publicationYear2022By);
	}

	public boolean isLBgardBloodTubesPageDisplayed() {
		return Element.isElementDisplayed(lBgardBloodTubesPageBy);
	}

	public boolean isLBgardBloodTubesOptionHighlighted() {
		return Element.isElementDisplayed(lBgardBloodTubesOptionHighlightBy);
	}

	public boolean isLBGardBloodTubesSDSButtonDisplayed() {
		return Element.isElementDisplayed(lBGardBloodTubesSDSButtonBy);
	}

	public boolean isLBGardBloodTubesIFUButtonDisplayed() {
		return Element.isElementDisplayed(lBGardBloodTubesIFUButtonBy);
	}

	public boolean isMandatoryFieldsDisplayed() {
		return Element.isElementDisplayed(validationMessageBy);
	}

	public boolean isThankYouMessageDisplayed() {
		Element.waitForVisible(thankYouMessageBy);
		return Element.isElementDisplayed(thankYouMessageBy);
	}

	public boolean isPublicationAdvancedCancerTypeDisplayed() {
		Element.waitForVisible(publicationAdvancedCancerTypeBy);
		return Element.isElementDisplayed(publicationAdvancedCancerTypeBy);
	}

	public String getPublicationsCardTittle(int count) {
		viewProfileLinkIndexBy = By
				.xpath("(" + (exactPagesProperties.getProperty("PublicationsCardTittle")) + ")[" + count + "]");
		return Element.getElementText(viewProfileLinkIndexBy);
	}

	public void clickPublicationsCardTittle(int count) {
		viewProfileLinkIndexBy = By
				.xpath("(" + (exactPagesProperties.getProperty("PublicationsCardTittle")) + ")[" + count + "]");
		Element.loadAndClick(viewProfileLinkIndexBy);
	}

	public boolean isClinicalStudiesOptionHighlighted() {
		return Element.isElementDisplayed(clinicalStudiesOptionHighlightBy);
	}

	public boolean isClinicalStudiesPageDisplayed() {
		return Element.isElementDisplayed(clinicalStudiesPageBy);
	}

	public boolean isColorectalCancerScreeningTabSelected() {
		return Element.isElementDisplayed(colorectalCancerScreeningTabSelectedBy);
	}

	public boolean isDiagnosedColorectalCancerTabSelected() {
		return Element.isElementDisplayed(diagnosedColorectalCancerTabSelectedBy);
	}

	public boolean isMultiCancerCancerScreeningTabSelected() {
		return Element.isElementDisplayed(multiCancerScreeningTabSelectedBy);
	}

	public boolean isComingSoonCardDisplayed() {
		return Element.isElementDisplayed(comingSoonCardBy);
	}

	public boolean isResearchOptionHighlighted() {
		return Element.isElementDisplayed(researchOptionHighlightBy);
	}

	public boolean isResearchPageDisplayed() {
		return Element.isElementDisplayed(researchPageBy);
	}

//	Our Test

	public void clickCologaurdOption() {
		Element.loadAndClick(cologaurdOptionBy);
	}

	public void clickStoolDNAIsolationcard() {
		Element.loadAndClick(stoolDNAIsolationcardBy);
	}

	public void clickDNAstabilitytechnologySilkySlider() {
		Element.loadAndClick(dnastabilitytechnologycardBy);
	}

	public void clickDNABiomarkerDetectionSilkySlider() {
		Element.loadAndClick(dnabiomarkerdetectioncardBy);
	}

	public void clickHemoglobinbiomarkerdetectionandstabilitytechnologySilkySlider() {
		Element.loadAndClick(hemoglobinbiomarkerdetectionandstabilitytechnologycardBy);
	}

	public void clickPowerfulMechanicalAlgorithmSilkySlider() {
		Element.loadAndClick(powerfulMechanicalAlgorithmcardBy);
	}

	public void clickReferenceLinkOnOurTest() {
		Element.loadAndClick(referenceLinkOnOurTestBy);
	}

	public boolean isColugaurdRxOnlyPageDisplayed() {
		return Element.isElementDisplayed(colugaurdRxOnlyPageBy);
	}

	public boolean isOncoextraPageDisplayed() {
		return Element.isElementDisplayed(oncoextraPageBy);
	}

	public boolean isCologaurdOptionHighlightedDisplayed() {
		return Element.isElementDisplayed(ourCologaurdOptionHighlightBy);
	}

	public boolean isOncoextraOptionHighlightedDisplayed() {
		return Element.isElementDisplayed(ourOncoextraOptionHighlightBy);
	}

	public boolean isCologuardRxOnlyDispalyed() {
		return Element.isElementDisplayed(cologuardRxOnlyBy);
	}

	public boolean isoncoExtraDisplayed() {
		return Element.isElementDisplayed(oncoExtraBy);
	}

	public boolean isOncoguardLiverDisplayed() {
		return Element.isElementDisplayed(oncoguardLiverBy);
	}

	public boolean isBreastDCISscoreDisplayed() {
		return Element.isElementDisplayed(breastDCISscoreBy);
	}

	public boolean isBreastRecurrenceScoreDisplayed() {
		return Element.isElementDisplayed(breastRecurrencescoreBy);
	}

	public boolean isColonRecurrenceScoreDisplayed() {
		return Element.isElementDisplayed(colonRecurrencescoreBy);
	}

	public boolean isRiskgaurdDisplayed() {
		return Element.isElementDisplayed(riskguardBy);
	}

	public boolean isStoolDNAIsolationcardDisplayed() {
		return Element.isElementDisplayed(stoolDNAIsolationcardBy);
	}

	public boolean isStoolDNAIsolationSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(stoolDNAIsolationSilkySliderBy);
	}

	public boolean isDNAstabilitytechnologycardDisplayed() {
		return Element.isElementDisplayed(dnastabilitytechnologycardBy);
	}

	public boolean isDNAstabilitytechnologySilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(dnastabilitytechnologySilkySliderBy);
	}

	public boolean isDNAbiomarkerdetectioncardDisplayed() {
		return Element.isElementDisplayed(dnabiomarkerdetectioncardBy);
	}

	public boolean isDNAbiomarkerdetectionSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(dnabiomarkerdetectionSilkySliderBy);
	}

	public boolean isPowerfulMechanicalAlgorithmcardDisplayed() {
		return Element.isElementDisplayed(powerfulMechanicalAlgorithmcardBy);
	}

	public boolean isPowerfulMechanicalAlgorithmSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(powerfulMechanicalAlgorithmSilkySliderBy);
	}

	public boolean isHemoglobinbiomarkerdetectionandstabilitytechnologycardDisplayed() {
		return Element.isElementDisplayed(hemoglobinbiomarkerdetectionandstabilitytechnologycardBy);
	}

	public boolean isHemoglobinbiomarkerdetectionandstabilitytechnologySilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(hemoglobinbiomarkerdetectionandstabilitytechnologySilkySliderBy);
	}

	public void clickColugaurdRXOnlyCardLearnMoreLink() {
		Element.loadAndClick(colugaurdRXOnlyCardLearnMoreLinkBy);
	}

	public void clickVisitColugaurdRXLink() {
		Element.loadAndClick(visitColugaurdRXLinkBy);
	}

	public void clickOncoExtraCardLearnMoreLink() {
		Element.loadAndClick(oncoExtraCardLearnMoreLinkBy);
	}

	public boolean isUltraComprehensiveGenomicProfilingcardDisplayed() {
		return Element.isElementDisplayed(ultraComprehensiveGenomicProfilingcardBy);
	}

	public boolean isPatientMatchedTumorNormalSequencingcardDisplayed() {
		return Element.isElementDisplayed(patientMatchedTumorNormalSequencingcardBy);
	}

	public boolean isClinicallyActionablecardDisplayed() {
		return Element.isElementDisplayed(clinicallyActionablecardBy);
	}

	public void clickUltraComprehensiveGenomicProfilingcard() {
		Element.loadAndClick(ultraComprehensiveGenomicProfilingcardBy);
	}

	public boolean isUltraComprehensiveGenomicProfilingSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(ultraComprehensiveGenomicProfilingSilkySliderBy);
	}

	public void clickPatientMatchedTumorNormalSequencingcard() {
		Element.loadAndClick(patientMatchedTumorNormalSequencingcardBy);
	}

	public boolean isPatientMatchedTumorNormalSequencingSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(patientMatchedTumorNormalSequencingSilkySlideBy);
	}

	public void clickClinicallyActionablecard() {
		Element.loadAndClick(clinicallyActionablecardBy);
	}

	public boolean isClinicallyActionableSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(clinicallyActionableSilkySliderBy);
	}

	public void clickOncogaurdLiverCardLearnMoreLink() {
		Element.loadAndClick(oncogaurdLiverCardLearnMoreLinkBy);
	}

	public boolean isOncogaurdLiverPageDisplayed() {
		return Element.isElementDisplayed(oncogaurdLiverPageBy);
	}

	public boolean isOncogaurdLiverOptionHighlightedDisplayed() {
		return Element.isElementDisplayed(oncogaurdLiverOptionHighlightedBy);
	}

	public void clickVisitOncogaurdLiverlink() {
		Element.loadAndClick(visitOncogaurdLiverlinkBy);
	}

	public void clickOncogaurdLiverOption() {
		Element.loadAndClick(oncogaurdLiverOptionBy);
	}

	public boolean isAdvancedperformanceyoucanrelyoncardDisplayed() {
		return Element.isElementDisplayed(advancedperformanceyoucanrelyoncardBy);
	}

	public boolean isInnovationwithoutinconveniencecardDisplayed() {
		return Element.isElementDisplayed(innovationwithoutinconveniencecardBy);
	}

	public boolean isSupportthatdrivesadherencecardDisplayed() {
		return Element.isElementDisplayed(supportthatdrivesadherencecardBy);
	}

	public void clickAdvancedperformanceyoucanrelyoncard() {
		Element.loadAndClick(advancedperformanceyoucanrelyoncardBy);
	}

	public boolean isAdvancedperformanceyoucanrelyonSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(advancedperformanceyoucanrelyonSilkySliderBy);
	}

	public void clickInnovationwithoutinconveniencecard() {
		Element.loadAndClick(innovationwithoutinconveniencecardBy);
	}

	public boolean isInnovationwithoutinconvenienceSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(innovationwithoutinconvenienceSilkySliderBy);
	}

	public void clickSupportthatdrivesadherencecard() {
		Element.loadAndClick(supportthatdrivesadherencecardBy);
	}

	public boolean isSupportthatdrivesadherenceSilkySliderDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(supportthatdrivesadherenceSilkySliderBy);
	}

	public void clickOncotypeBreastDCISScoreLearnMoreLink() {
		Element.loadAndClick(oncotypeBreastDCISScoreLearnMoreLinkBy);
	}

	public boolean isOncotypeBreastDCISScorePageDisplayed() {
		return Element.isElementDisplayed(oncotypeBreastDCISScorePageBy);
	}

	public void hoverOncoTypeDXOption() {
		Element.mouseHover(oncoTypeDXBy);
	}

	public boolean isOncotypeDXBreastDCISScoreOptionHighlightedDisplayed() {
		return Element.isElementDisplayed(oncotypeDXBreastDCISScoreOptionHighlightedBy);
	}

	public void clickOncotypeBreastDCISScorePageLearnMoreLink() {
		Element.loadAndClick(oncotypeBreastDCISScorePageLearnMoreLinkBy);
	}

	public void clickOncotypeBreastRecurrenceScoreLearnMoreLink() {
		Element.loadAndClick(oncotypeBreastRecurrenceScoreLearnMoreLinkBy);
	}

	public boolean isOncotypeBreastRecurrenceScorePageDisplayed() {
		return Element.isElementDisplayed(oncotypeBreastRecurrenceScorePageBy);
	}

	public boolean isOncotypeDXBreastRecurrenceScoreOptionHighlightedDisplayed() {
		return Element.isElementDisplayed(oncotypeDXBreastRecurrenceScoreOptionHighlightedBy);
	}

	public void clickOncotypeBreastRecurrenceScorePageLearnMoreLink() {
		Element.loadAndClick(oncotypeBreastRecurrenceScorePageLearnMoreLinkBy);
	}

	public void clickOncotypeColonRecurrenceScoreLearnMoreLink() {
		Element.loadAndClick(oncotypeColonRecurrenceScoreLearnMoreLinkBy);
	}

	public boolean isOncotypeColonRecurrenceScorePageDisplayed() {
		return Element.isElementDisplayed(oncotypeColonRecurrenceScorePageBy);
	}

	public boolean isOncotypeDXColonRecurrenceScoreOptionHighlightedDisplayed() {
		return Element.isElementDisplayed(oncotypeDXColonRecurrenceScoreOptionHighlightedBy);
	}

	public void clickOncotypeColonRecurrenceScorePageLearnMoreLink() {
		Element.loadAndClick(oncotypeColonRecurrenceScorePageLearnMoreLinkBy);
	}

	public void clickRiskguardLearnMoreLink() {
		Element.loadAndClick(riskguardLearnMoreLinkBy);
	}

	public boolean isRiskguardPageDisplayed() {
		return Element.isElementDisplayed(riskguardPageBy);
	}

	public boolean isRiskguardOptionHighlightedDisplayed() {
		return Element.isElementDisplayed(riskguardOptionHighlightedBy);
	}

	public void clickRiskguardPageLearnMoreAboutPreventiongenticsLink() {
		Element.loadAndClick(riskguardPageLearnMoreAboutPreventiongenticsBy);
	}

	public void clickRiskguardOption() {
		Element.loadAndClick(riskguardOptionBy);
	}

	public void clickRiskguardInsuranceCoveragePageLearnMoreLink() {
		Element.loadAndClick(riskguardInsuranceCoveragePageLearnMoreLinkBy);
	}

	public boolean isIndividualizedReportcardDisplayed() {
		return Element.isElementDisplayed(individualizedReportcardBy);
	}

	public boolean isClinicallyActionableRiskguardcardDisplayed() {
		return Element.isElementDisplayed(clinicallyActionableRiskguardcardBy);
	}

	public boolean isTrustedPartnercardDisplayed() {
		return Element.isElementDisplayed(trustedPartnercardBy);
	}

	public void clickDownloadAsamplePatientReport() {
		Element.loadAndClick(downloadAsamplePatientReportBy);
	}

	public void clickDownloadRiskguardFactSheet() {
		Element.loadAndClick(downloadRiskguardFactSheetBy);
	}

	public void clickTrustedPartnerLearnMoreLink() {
		Element.loadAndClick(trustedPartnerLearnMoreLinkBy);
	}

	public boolean isTrustedPartnerDailogBoxDisplayed() {
		return Element.isElementDisplayed(trustedPartnerDailogBoxBy);
	}

	public boolean isTrustedPartnerContinueToGenomeDisplayed() {
		return Element.isElementDisplayed(trustedPartnerContinueToGenomeBy);
	}

	public void clickCancelButton() {
		Element.loadAndClick(cancelButtonBy);
	}

	public void clickTrustedPartnerContinueToGenome() {
		Element.loadAndClick(trustedPartnerContinueToGenomeBy);
	}

	public void clickDownloadTheRiskguardFactSheet() {
		Element.loadAndClick(downloadTheRiskguardFactSheetBy);
	}

	public void clickDownloadOrderForm() {
		Element.loadAndClick(downloadOrderFormBy);
	}

	public void clickForPatients() {
		Element.loadAndClick(forPatientsBy);
	}

	public boolean isPositivecardDisplayed() {
		return Element.isElementDisplayed(positivecardBy);
	}

	public boolean isNegativecardDisplayed() {
		return Element.isElementDisplayed(negativecardBy);
	}

	public boolean isVarientOfUncertainSignificancecardDisplayed() {
		return Element.isElementDisplayed(varientOfUncertainSignificancecardBy);
	}

	public void clickHowTestingHelpLearnMoreLink() {
		Element.loadAndClick(howTestingHelpLearnMoreLinkBy);
	}

	public boolean isHowTestingHelpLearnMoreLinkDailogBoxDisplayed() {
		return Element.isElementDisplayed(howTestingHelpLearnMoreLinkDailogBoxBy);
	}

	public boolean isHowTestingHelpLearnMoreLinkContinueToGenomeDisplayed() {
		return Element.isElementDisplayed(howTestingHelpLearnMoreLinkContinueToGenomeBy);
	}

	public void clickHowTestingHelpLearnMoreLinkCancelButton() {
		Element.loadAndClick(howTestingHelpLearnMoreLinkCancelButtonBy);
	}

	public void clickDownloadaSamplePatientReport() {
		Element.loadAndClick(downloadaSamplePatientReportBy);
	}

	public void clickForProviders() {
		Element.loadAndClick(forProvidersBy);
	}

	public void clickNeedAccesstothePatientReportsHub() {
		Element.loadAndClick(needAccesstothePatientReportsHubBy);
	}

	public void clickNeedAccessToTheOpenOrClosedClientTickets() {
		Element.loadAndClick(needAccessToTheOpenOrClosedClientTicketsBy);
	}

	public void clickNeedNYStateProviderInformation() {
		Element.loadAndClick(needNYStateProviderInformationBy);
	}

	public void clickAreyouISO15189CAPandCLIAaccredited() {
		Element.loadAndClick(areyouISO15189CAPandCLIAaccreditedBy);
	}

	public void clickPreventiongeneticsCertificationLink() {
		Element.loadAndClick(preventiongeneticsCertificationLinkBy);
	}

	public void clickHowDoesaPatientFamilyGetTested() {
		Element.loadAndClick(howDoesaPatientFamilyGetTestedBy);
	}

	public void clickGenomeMedicalLink() {
		Element.loadAndClick(genomeMedicalLinkBy);
	}

	public boolean isGenomeMedicalDailogBoxDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(genomeMedicalDailogBoxBy);
	}

	public boolean isGenomeMedicalContinueToGenomeDisplayed() {
		return Element.isElementDisplayed(genomeMedicalContinueToGenomeBy);
	}

	public void clickGenomeMedicalCancelButton() {
		Element.loadAndClick(genomeMedicalCancelButtonBy);
	}

	public boolean isContactUSFirstCardDisplayed() {
		return Element.isElementDisplayed(contactUSFirstCardBy);
	}

	public boolean isContactUSSecondCardDisplayed() {
		return Element.isElementDisplayed(contactUSSecondCardBy);
	}

	public boolean isContactUSThirdCardDisplayed() {
		return Element.isElementDisplayed(contactUSThirdCardBy);
	}

	public void clickContactUSSecondCardLearnMore() {
		Element.loadAndClick(contactUSSecondCardLearnMoreBy);
	}

	public boolean isSecondCardDailogBoxDisplayed() {
		return Element.isElementDisplayed(secondCardDailogBoxDisplayedBy);
	}

	public boolean isSecondCardContinueToGenomeDisplayed() {
		return Element.isElementDisplayed(secondCardContinueToGenomeBy);
	}

	public void clickSecondCardCancelButton() {
		Element.loadAndClick(secondCardCancelButtonBy);
	}

	public void clickContactUSThirdCardLearnMore() {
		Element.loadAndClick(contactUSThirdCardLearnMoreBy);
	}

	public void clickContactUSSecondCardLearnMoreForPatients() {
		Element.loadAndClick(contactUSSecondCardLearnMoreForPatientsBy);
	}

	public void clickContactUSThirdCardLearnMoreForPatients() {
		Element.loadAndClick(contactUSThirdCardLearnMoreForPatientsBy);
	}

	public void enterFirstName(String firstName) {
		Element.enterText(firstNameFieldBy, firstName);
	}

	public void enterLastName(String lastName) {
		Element.enterText(lastNameFieldBy, lastName);
	}

	public void enterTitle(String title) {
		Element.enterText(titleFieldBy, title);
	}

	public void enterCompanyInstitution(String companyInstitution) {
		Element.enterText(companyInstitutionFieldBy, companyInstitution);
	}

	public void enterAddress(String address) {
		Element.enterText(addressFieldBy, address);
	}

	public void enterEmail(String email) {
		Element.enterText(emailFieldBy, email);
	}

	public void enterAreaOfFocus(String areaOfFocus) {
		Element.enterText(areaOfFocusFieldBy, areaOfFocus);
	}

	public void enterComments(String comments) {
		Element.enterText(commentsFieldBy, comments);
	}

	// News Room Functions
	public void clickNewsRoomMenuOption() {
		Element.loadAndClick(newsRoomMenuOptionBy);
	}

	public boolean isNewsStoriesHeaderHighlightedDisplayed() {
		return Element.isElementDisplayed(newsStoriesHeaderBy);
	}

	public boolean isTestingNewTopicSlideDisplayed() {
		return Element.isElementDisplayed(testingNewTopicSlideBy);
	}

	public void clickNextButtonNewsRoom() {
		Element.loadAndClick(nextButtonNewsRoomBy);
		Sleeper.sleepTightInSeconds(3);
	}

	public boolean isABreastCancerSurgeonsBreastCancerStorySlideDisplayed() {
		return Element.isElementDisplayed(abreastCancerSurgeonsBreastCancerStorySlideby);
	}

	public boolean isTheTollofaDiagnosisSlideDisplayed() {
		return Element.isElementDisplayed(theTollofaDiagnosisSlideBy);
	}

	public void clickTestingNewTopicSlideReadmore() {
		Element.loadAndClick(testingNewTopicSlideReadmoreBy);
	}

	public boolean isTestingNewTopicPageDisplayed() {
		return Element.isElementDisplayed(testingNewTopicPageBy);
	}

	public void clickBreastCancerStorySlideReadmore() {
		Element.loadAndClick(breastCancerStorySlideReadmoreBy);
	}

	public boolean isBreastCancerStoryPageDisplayed() {
		return Element.isElementDisplayed(breastCancerStoryPageBy);
	}

	public void clickTheTollofaDiagnosisSlideReadmore() {
		Element.loadAndClick(theTollofaDiagnosisSlideReadmoreBy);
	}

	public boolean isTheTollofaDiagnosisPageDisplayed() {
		return Element.isElementDisplayed(theTollofaDiagnosisPageBy);
	}

	public void clickPressReleaseViewAll() {
		Element.loadAndClick(pressReleaseViewAllBy);
	}

	public boolean isPressReleasePageDisplayed() {
		Sleeper.sleepTightInSeconds(3);
		return Element.isElementDisplayed(pressReleasePageBy);
	}

	public void hoverNewsroomMenuOption() {
		Element.mouseHover(newesroomOptionBy);
	}

	public boolean isPressReleaseOptionHighlighted() {
		return Element.isElementDisplayed(pressReleaseOptionBy);
	}

	public boolean isPatientStoriesIconDisplayed() {
		return Element.isElementDisplayed(patientStoriesIconBy);
	}

	public boolean isBreastCancerIconDisplayed() {
		return Element.isElementDisplayed(breastCancerIconBy);
	}

	public boolean isSmarterAnswersIconDisplayed() {
		return Element.isElementDisplayed(smarterAnswersIconBy);
	}

	public void clickPatientStoriesIcon() {
		Element.loadAndClick(patientStoriesIconBy);
	}

	public boolean isPatientStoriesIconHighlighted() {
		return Element.isElementDisplayed(patientStoriesIconHighlightedBy);
	}

	public void clickBreastCancerIcon() {
		Element.loadAndClick(breastCancerIconBy);
	}

	public boolean isBreastCancerIconHighlighted() {
		return Element.isElementDisplayed(breastCancerIconHighlightedBy);
	}

	public void clickSmarterAnswersIcon() {
		Element.loadAndClick(smarterAnswersIconBy);
	}

	public boolean isSmarterAnswersIconHighlighted() {
		return Element.isElementDisplayed(smarterAnswersIconHighlightedBy);
	}

	public void clickBreastCancerLink() {
		Element.loadAndClick(breastCancerLinkBy);
	}

	public boolean isBreastCancerPagination() {
		return Element.isElementDisplayed(breastCancerPaginationBy);
	}

	public void clickBreastCancerFirstGrid() {
		Element.loadAndClick(breastCancerFirstGridBy);
	}

	public boolean isBreastCancerFirstGridPageDisplayed() {
		return Element.isElementDisplayed(breastCancerFirstGridPageBy);
	}

	public void clickMultiCancerLink() {
		Element.loadAndClick(multiCancerLinkBy);
	}

	public boolean isMultiCancerLinkHighlighted() {
		return Element.isElementDisplayed(multiCancerLinkHighlightedBy);
	}

	public boolean isMultiCancerPagination() {
		return Element.isElementDisplayed(multiCancerPaginationBy);
	}

	public void clickMultiCancerFirstGrid() {
		Element.loadAndClick(multiCancerFirstGridBy);
	}

	public boolean isMultiCancerFirstGridPageDisplayed() {
		return Element.isElementDisplayed(multiCancerFirstGridPageBy);
	}

	public void clickColorectalCancerLink() {
		Element.loadAndClick(colorectalCancerLinkBy);
	}

	public boolean isColorectalCancerLinkHighlighted() {
		return Element.isElementDisplayed(colorectalCancerLinkHighlightedBy);
	}

	public boolean isColorectalCancerPagination() {
		return Element.isElementDisplayed(colorectalCancerPaginationBy);
	}

	public void clickColorectalCancerFirstGrid() {
		Element.loadAndClick(colorectalCancerFirstGridBy);
	}

	public boolean isColorectalCancerFirstGridPageDisplayed() {
		return Element.isElementDisplayed(colorectalCancerFirstGridPageBy);
	}

	public void clickLiverCancerLink() {
		Element.loadAndClick(liverCancerLinkBy);
	}

	public boolean isLiverCancerLinkHighlighted() {
		return Element.isElementDisplayed(liverCancerLinkHighlightedBy);
	}

	public boolean isLiverCancerPagination() {
		return Element.isElementDisplayed(liverCancerPaginationBy);
	}

	public void clickLiverCancerFirstGrid() {
		Element.loadAndClick(liverCancerFirstGridBy);
	}

	public boolean isLiverCancerFirstGridPageDisplayed() {
		return Element.isElementDisplayed(liverCancerFirstGridPageDisplayedBy);
	}

	public void clickEarlierDetectionLink() {
		Element.loadAndClick(earlierDetectionLinkBy);
	}

	public boolean isEarlierDetectionLinkHighlighted() {
		return Element.isElementDisplayed(earlierDetectionLinkHighlightedBy);
	}

	public boolean isEarlierDetectionPagination() {
		return Element.isElementDisplayed(earlierDetectionPaginationBy);
	}

	public void clickEarlierDetectionFirstGrid() {
		Element.loadAndClick(earlierDetectionFirstGridBy);
	}

	public boolean isEarlierDetectionFirstGridPageDisplayed() {
		return Element.isElementDisplayed(earlierDetectionFirstGridPageBy);
	}

	public void clickHealthEquityLink() {
		Element.loadAndClick(healthEquityLinkBy);
	}

	public boolean isHealthEquityLinkHighlighted() {
		return Element.isElementDisplayed(healthEquityLinkHighlightedBy);
	}

	public boolean isHealthEquityPagination() {
		return Element.isElementDisplayed(healthEquityPaginationBy);
	}

	public void clickHealthEquityFirstGrid() {
		Element.loadAndClick(healthEquityFirstGridBy);
	}

	public boolean isHealthEquityFirstGridPageDisplayed() {
		return Element.isElementDisplayed(healthEquityFirstGridPageBy);
	}

	public void clickLifeAtExactLink() {
		Element.loadAndClick(lifeAtExactLinkBy);
	}

	public boolean isLifeAtExactLinkHighlighted() {
		return Element.isElementDisplayed(lifeAtExactLinkHighlightedBy);
	}

	public boolean isLifeAtExactPagination() {
		return Element.isElementDisplayed(lifeAtExactPaginationBy);
	}

	public void clickLifeAtExactFirstGrid() {
		Element.loadAndClick(lifeAtExactFirstGridBy);
	}

	public boolean isLifeAtExactFirstGridPageDisplayed() {
		return Element.isElementDisplayed(lifeAtExactFirstGridPageBy);
	}

	public void clickPatientStoriesLink() {
		Element.loadAndClick(patientStoriesLinkBy);
	}

	public boolean isPatientStoriesLinkHighlighted() {
		return Element.isElementDisplayed(patientStoriesLinkHighlightedBy);
	}

	public boolean isPatientStoriesPagination() {
		return Element.isElementDisplayed(patientStoriesPaginationBy);
	}

	public void clickPatientStoriesFirstGrid() {
		Element.loadAndClick(patientStoriesFirstGridBy);
	}

	public boolean isPatientStoriesFirstGridPageDisplayed() {
		return Element.isElementDisplayed(patientStoriesFirstGridPageBy);
	}

	public void clickPipelineLink() {
		Element.loadAndClick(pipelineLinkBy);
	}

	public boolean isPipelineLinkHighlighted() {
		return Element.isElementDisplayed(pipelineLinkHighlightedBy);
	}

	public boolean isPipelinePagination() {
		return Element.isElementDisplayed(pipelinePaginationBy);
	}

	public void clickPipelineFirstGrid() {
		Element.loadAndClick(pipelineFirstGridBy);
	}

	public boolean isPipelineFirstGridPageDisplayed() {
		return Element.isElementDisplayed(pipelineFirstGridPageBy);
	}

	public void clickSmarterAnswersLink() {
		Element.loadAndClick(smarterAnswersLinkBy);
	}

	public boolean isSmarterAnswersLinkHighlighted() {
		return Element.isElementDisplayed(smarterAnswersLinkHighlightedBy);
	}

	public boolean isSmarterAnswersPagination() {
		return Element.isElementDisplayed(smarterAnswersPaginationBy);
	}

	public void clickSmarterAnswersFirstGrid() {
		Element.loadAndClick(smarterAnswersFirstGridBy);
	}

	public boolean isSmarterAnswersFirstGridPageDisplayed() {
		return Element.isElementDisplayed(smarterAnswersFirstGridPageBy);
	}

	public void clickPressReleaseOption() {
		Element.loadAndClick(pressReleaseOptionUnderNewRoomBy);
	}

	public boolean isWorkflowSlideDisplayed() {
		return Element.isElementDisplayed(workflowSlideBy);
	}

	public boolean isTestingSecuritySlideDisplayed() {
		return Element.isElementDisplayed(testingSecuritySlideBy);
	}

	public boolean isExactSciencesAnnouncesPreliminarySlideDisplayed() {
		return Element.isElementDisplayed(exactSciencesAnnouncesPreliminarySlideBy);
	}

	public void clickWorkflowSlide() {
		Element.loadAndClick(workflowSlideReadmoreBy);
	}

	public boolean isWorkflowPageDisplayed() {
		return Element.isElementDisplayed(workflowPageBy);
	}

	public void clickTestingSecuritySlide() {
		Element.loadAndClick(testingSecuritySlideReadmoreBy);
	}

	public boolean isTestingSecurityPageDisplayed() {
		return Element.isElementDisplayed(testingSecurityPageBy);
	}

	public void clickExactSciencesAnnouncesPreliminarySlide() {
		Element.loadAndClick(exactSciencesAnnouncesPreliminarySlideReadmoreBy);
	}

	public boolean isExactSciencesAnnouncesPreliminaryPageDisplayed() {
		return Element.isElementDisplayed(exactSciencesAnnouncesPreliminaryPageBy);
	}

	public boolean isPressReleasePagination() {

		return Element.isElementPresent(pressReleasePaginationBy);
	}

	public boolean isVideoIconDisplayed() {
		return Element.isElementDisplayed(videoIconBy);
	}

	public boolean isPhotosIconDisplayed() {
		return Element.isElementDisplayed(photosIconBy);
	}

	public void clickVideoIcon() {
		Element.loadAndClick(videoIconBy);
	}

	public void clickPhotosIcon() {
		Element.loadAndClick(photosIconBy);
	}

	public boolean isMutimediaPageDisplayed() {
		return Element.isElementDisplayed(mutimediaPageBy);
	}

	public boolean isMultimediaOptionHighlighted() {
		return Element.isElementDisplayed(multimediaOptionBy);
	}

	public boolean isVideoSubsectionDisplayed() {
		return Element.isElementDisplayed(videoSubsectionBy);
	}

	public boolean isPhotosSubsectionDisplayed() {
		return Element.isElementDisplayed(photosSubsectionBy);
	}

	public void clickFirstPhotosDownload() {
		Element.loadAndClick(firstPhotosDownloadBy);
	}

	public void clickSecondPhotosDownload() {
		Element.loadAndClick(secondPhotosDownloadBy);
	}

	public void clickThirdPhotosDownload() {
		Element.loadAndClick(thirdPhotosDownloadBy);
	}

	// video
	public void clickPlayButton() {
		Element.loadAndClick(playButtonBy);
	}

	public boolean isVideoPlay() {
		return Element.isElementDisplayed(videoPlayBy);
	}

	public void clickPauseButton() {
		Element.loadAndClick(pauseButtonBy);
	}

	public void videoHover() {
		Element.mouseHover(videoHoverBy);
	}

	public boolean isVideoPaused() {
		return Element.isElementDisplayed(videoPausedBy);
	}

	public void clickMultiCancerEarlyDetection() {
		Element.loadAndClick(multiCancerEarlyDetectionBy);
	}

	public void clickMultiCancerVideoPlayButton() {
		Element.loadAndClick(multiCancerVideoPlayButtonBy);
	}

	public String getVideoTime() {
		return Element.getElementText(videoTimeBy);
	}

	public String getVideoTime(int count) {
		viewProfileLinkIndexBy = By.xpath("(" + (exactPagesProperties.getProperty("VideoTime")) + ")[" + count + "]");
		return Element.getElementText(viewProfileLinkIndexBy);
	}

	public void clickPlayButton(int count) {
		viewProfileLinkIndexBy = By
				.xpath("(" + (exactPagesProperties.getProperty("PlayButtonMultimediaVideo")) + ")[" + count + "]");
		Element.loadAndClick(viewProfileLinkIndexBy);
	}

	public void videoHover(int count) {
		viewProfileLinkIndexBy = By.xpath("(" + (exactPagesProperties.getProperty("VideoHover")) + ")[" + count + "]");
		Element.mouseHover(viewProfileLinkIndexBy);
	}

	public void clickMultimediaOption() {
		Element.loadAndClick(multimediaMenuOptionBy);
	}

	public void clickMultimediaVideoBackground() {
		Element.loadAndClick(multimediaVideoBackgroundBy);
	}

	// footer
	public void clickContactUsFooter() {
		Element.loadAndClick(contactUsFooterBy);
	}

	public boolean isExactSciencesFooterLogoDisplayed() {
		return Element.isElementDisplayed(exactSciencesFooterLogoBy);
	}

	public boolean isContactUsFooterDisplayed() {
		return Element.isElementDisplayed(contactUsFooterBy);
	}

	public boolean isAboutHyperlinkDisplayed() {
		return Element.isElementDisplayed(aboutHyperlinkBy);
	}

	public boolean isTermOfUseHyperlinkDisplayed() {
		return Element.isElementDisplayed(termOfUseHyperlinkBy);
	}

	public boolean isPurchasingTermsHyperlinkDisplayed() {
		return Element.isElementDisplayed(purchasingTermseHyperlinkBy);
	}

	public boolean isVendorCodeofConductHyperlinkDisplayed() {
		return Element.isElementDisplayed(vendorCodeofConducteHyperlinkBy);
	}

	public boolean isPatentsTrademarksHyperlinkDisplayed() {
		return Element.isElementDisplayed(patentsTrademarksHyperlinkBy);
	}

	public boolean isPrivacyPolicyHyperlinkDisplayed() {
		return Element.isElementDisplayed(privacyPolicyHyperlinkBy);
	}

	public boolean isHIPAANoticeHyperlinkDisplayed() {
		return Element.isElementDisplayed(hipaaNoticeHyperlinkBy);
	}

	public boolean isFCOIPolicyHyperlinkDisplayed() {
		return Element.isElementDisplayed(fcoiPolicyHyperlinkBy);
	}

	public boolean isDoNotSellMyInfoHyperlinkDisplayed() {
		return Element.isElementDisplayed(doNotSellMyInfoHyperlinkBy);
	}

	public boolean isCologuardcomHyperlinkDisplayed() {
		return Element.isElementDisplayed(cologuardcomHyperlinkBy);
	}

	public boolean isNoticeofCollectionPolicyHyperlinkDisplayed() {
		return Element.isElementDisplayed(noticeofCollectionPolicyHyperlinkBy);
	}

	public boolean isNoticeofFinancialIncentivePolicyHyperlinkDisplayed() {
		return Element.isElementDisplayed(noticeofFinancialIncentivePolicyHyperlinkBy);
	}

	public boolean isNoticeofRighttoOptOutPolicyHyperlinkDisplayed() {
		return Element.isElementDisplayed(noticeofRighttoOptOutPolicyHyperlinkBy);
	}

	public boolean isCCPAGDPRPrivacyPolicyHyperlinkDisplayed() {
		return Element.isElementDisplayed(ccpaGDPRPrivacyPolicyHyperlinkBy);
	}

	public boolean isDataRetentionHyperlinkDisplayed() {
		return Element.isElementDisplayed(dataRetentionHyperlinkBy);
	}

	public void clickAboutHyperlink() {
		Element.loadAndClick(aboutHyperlinkBy);
	}

	public void clickTermOfUseHyperlink() {
		Element.loadAndClick(termOfUseHyperlinkBy);
	}

	public boolean isTermOfUsePageDisplayed() {
		return Element.isElementDisplayed(termOfUsePageBy);
	}

	public void clickPurchasingTermsHyperlink() {
		Element.loadAndClick(purchasingTermseHyperlinkBy);
	}

	public void clickVendorCodeofConductHyperlink() {
		Element.loadAndClick(vendorCodeofConducteHyperlinkBy);
	}

	public void clickPatentsTrademarksHyperlink() {
		Element.loadAndClick(patentsTrademarksHyperlinkBy);
	}

	public boolean isPatentsTrademarksPageDisplayed() {
		return Element.isElementDisplayed(patentsTrademarksPageBy);
	}

	public void clickPrivacyPolicyHyperlink() {
		Element.loadAndClick(privacyPolicyHyperlinkBy);
	}

	public boolean isPrivacyPolicyPageDisplayed() {
		return Element.isElementDisplayed(privacyPolicyPageBy);
	}

	public void clickHIPAANoticeHyperlink() {
		Element.loadAndClick(hipaaNoticeHyperlinkBy);
	}

	public boolean isHIPAANoticePageDisplayed() {
		return Element.isElementDisplayed(hipaaNoticePageBy);
	}

	public void clickFCOIPolicyHyperlink() {
		Element.loadAndClick(fcoiPolicyHyperlinkBy);
	}

	public void clickDoNotSellMyInfoHyperlink() {
		Element.loadAndClick(doNotSellMyInfoHyperlinkBy);
	}

	public boolean isDoNotSellMyInfoPageDisplayed() {
		return Element.isElementDisplayed(doNotSellMyInfoPageBy);
	}

	public void clickCologuardcomHyperlink() {
		Element.loadAndClick(cologuardcomHyperlinkBy);
	}

	public void clickNoticeofCollectionPolicyHyperlink() {
		Element.loadAndClick(noticeofCollectionPolicyHyperlinkBy);
	}

	public boolean isNoticeofCollectionPolicyPageDisplayed() {
		return Element.isElementDisplayed(noticeofCollectionPolicyPageBy);
	}

	public void clickNoticeofFinancialIncentivePolicyHyperlink() {
		Element.loadAndClick(noticeofFinancialIncentivePolicyHyperlinkBy);
	}

	public boolean isNoticeofFinancialIncentivePolicyPageDisplayed() {
		return Element.isElementDisplayed(noticeofFinancialIncentivePolicyPageBy);
	}

	public void clickNoticeofRighttoOptOutPolicyHyperlink() {
		Element.loadAndClick(noticeofRighttoOptOutPolicyHyperlinkBy);
	}

	public boolean isNoticeofRighttoOptOutPolicyPageDisplayed() {
		return Element.isElementDisplayed(noticeofRighttoOptOutPolicyPageBy);
	}

	public void clickCCPAGDPRPrivacyPolicyHyperlink() {
		Element.loadAndClick(ccpaGDPRPrivacyPolicyHyperlinkBy);
	}

	public boolean isCCPAGDPRPrivacyPolicyPageDisplayed() {
		return Element.isElementDisplayed(ccpaGDPRPrivacyPolicyPageBy);
	}

	public void clickDataRetentionHyperlink() {
		Element.loadAndClick(dataRetentionHyperlinkBy);
	}

	public boolean isDataRetentionPageDisplayed() {
		return Element.isElementDisplayed(dataRetentionPageBy);
	}

	public boolean isFacebookHyperlinkDisplayed() {
		return Element.isElementDisplayed(facebookHyperlinkBy);
	}

	public boolean isTwitterHyperlinkDisplayed() {
		return Element.isElementDisplayed(twitterHyperlinkBy);
	}

	public boolean isLinkedinHyperlinkDisplayed() {
		return Element.isElementDisplayed(linkedinHyperlinkBy);
	}

	public void clickFacebookHyperHyperlink() {
		Element.loadAndClick(facebookHyperlinkBy);
	}

	public void clickTwitterHyperHyperlink() {
		Element.loadAndClick(twitterHyperlinkBy);
	}

	public void clickLinkedinHyperHyperlink() {
		Element.loadAndClick(linkedinHyperlinkBy);
	}

	public String getFooterAddress() {
		return Element.getElementText(footerAddressBy);
	}

}
