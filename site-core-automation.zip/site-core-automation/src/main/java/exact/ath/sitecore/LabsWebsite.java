package exact.ath.sitecore;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.sys.DriverManager;
import exact.util.Sleeper;

public class LabsWebsite extends ExactNavNavigation {
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	// Home

	private final By homeMenuHeaderHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("HomeMenuHeaderHighlighted"));
	private final By homeMenuHeaderBy = By.xpath(exactPagesProperties.getProperty("HomeMenuHeader"));
	private final By labClientServicesMenuHeaderBy = By
			.xpath(exactPagesProperties.getProperty("LabClientServicesMenuHeader"));
	private final By qualityAndComplianceMenuHeaderBy = By
			.xpath(exactPagesProperties.getProperty("QualityAndComplianceMenuHeader"));
	private final By aboutUsMenuHeaderBy = By.xpath(exactPagesProperties.getProperty("AboutUsMenuHeader"));
	private final By pageTitleBy = By.xpath(exactPagesProperties.getProperty("PageTitle"));
	private final By nCT01397747LinkBy = By.xpath(exactPagesProperties.getProperty("NCT01397747Link"));
	private final By newEnglandJournalofMedicineLinkBy = By
			.xpath(exactPagesProperties.getProperty("NewEnglandJournalofMedicineLink"));
	private final By orderCologuardByFaxIconCardBy = By
			.xpath(exactPagesProperties.getProperty("OrderCologuardByFaxIconCard"));
	private final By epiccareLinkProviderPortalIconCardBy = By
			.xpath(exactPagesProperties.getProperty("EpiccareLinkProviderPortalIconCard"));
	private final By downloadAnOrderFormButtonBy = By
			.xpath(exactPagesProperties.getProperty("DownloadAnOrderFormButton"));
	private final By setUpMyEpiccareLinkProviderPortalButtonBy = By
			.xpath(exactPagesProperties.getProperty("SetUpMyEpiccareLinkProviderPortalButton"));
	private final By cALL18448708870ButtonBy = By.xpath(exactPagesProperties.getProperty("CALL18448708870Button"));

	// Client
	private final By becomingAClientSubmenuBy = By.xpath(exactPagesProperties.getProperty("BecomingAClientSubmenu"));
	private final By sampleReportSubmenuBy = By.xpath(exactPagesProperties.getProperty("SampleReportSubmenu"));
	private final By patientBillingSubmenuBy = By.xpath(exactPagesProperties.getProperty("PatientBillingSubmenu"));
	private final By visualMapOfTestingProcessSubmenuBy = By
			.xpath(exactPagesProperties.getProperty("VisualMapOfTestingProcessSubmenu"));
	private final By covid19TestingSubmenuBy = By.xpath(exactPagesProperties.getProperty("Covid19TestingSubmenu"));
	private final By downloadAnOrderFormLinkBy = By.xpath(exactPagesProperties.getProperty("DownloadAnOrderFormLink"));
	private final By hereLinkBy = By.xpath(exactPagesProperties.getProperty("HereLink"));
	private final By cologuardLinkBy = By.xpath(exactPagesProperties.getProperty("CologuardLink"));
	private final By clickHereLinkBy = By.xpath(exactPagesProperties.getProperty("ClickHereLink"));
	private final By requestAdditionalDetailsBy = By
			.xpath(exactPagesProperties.getProperty("RequestAdditionalDetails"));
	private final By companyNameFieldBy = By.xpath(exactPagesProperties.getProperty("CompanyNameFieldLabs"));
	private final By companyAddressFieldBy = By.xpath(exactPagesProperties.getProperty("CompanyAddressFieldLabs"));
	private final By cityNameFieldBy = By.xpath(exactPagesProperties.getProperty("CityNameFieldLabs"));
	private final By stateNameFieldBy = By.xpath(exactPagesProperties.getProperty("StateNameFieldLabs"));
	private final By postelNumberFieldBy = By.xpath(exactPagesProperties.getProperty("PostelNumberFieldLabs"));
	private final By firstNameFieldBy = By.xpath(exactPagesProperties.getProperty("FirstNameFieldLabs"));
	private final By lastNameFieldBy = By.xpath(exactPagesProperties.getProperty("LastNameFieldLabs"));
	private final By emailFieldBy = By.xpath(exactPagesProperties.getProperty("EmailFieldLabs"));
	private final By phoneNumberFieldBy = By.xpath(exactPagesProperties.getProperty("PhoneNumberFieldLabs"));
	private final By bestTimeToContactFieldBy = By
			.xpath(exactPagesProperties.getProperty("BestTimeToContactFieldLabs"));
	private final By estimatedNumberFieldBy = By.xpath(exactPagesProperties.getProperty("EstimatedNumberFieldLabs"));
	private final By dropdownListBy = By.xpath(exactPagesProperties.getProperty("DropdownList"));
	private final By dropdownListEmployBy = By.xpath(exactPagesProperties.getProperty("DropdownListEmployLabs"));
	private final By additionalCommentsFieldBy = By
			.xpath(exactPagesProperties.getProperty("AdditionalCommentsFieldLabs"));
	private final By submitButtonBy = By.xpath(exactPagesProperties.getProperty("SubmitButtonLabs"));
	private final By formSubmittingTextBy = By.xpath(exactPagesProperties.getProperty("FormSubmittingText"));
	private final By donationProgramLinkBy = By.xpath(exactPagesProperties.getProperty("DonationProgramLink"));
	private final By pDFRequestFormLinkBy = By.xpath(exactPagesProperties.getProperty("PDFRequestFormLink"));
	private final By covid19TestingIconCardBy = By.xpath(exactPagesProperties.getProperty("Covid19TestingIconCard"));
	private final By covid19FluPanelTestingIconCardBy = By
			.xpath(exactPagesProperties.getProperty("Covid19FluPanelTestingIconCard"));
	private final By covid19TestingIconCardExploreMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("Covid19TestingIconCardExploreMoreLink"));
	private final By pleaseGohereLinkBy = By.xpath(exactPagesProperties.getProperty("PleaseGohereLink"));
	private final By cdcLinkBy = By.xpath(exactPagesProperties.getProperty("CdcLinkBy"));
	private final By specimenCollectionSubsectionBy = By
			.xpath(exactPagesProperties.getProperty("SpecimenCollectionSubsection"));
	private final By specimenHandlingAndShippingToExactSciencesLaboratoriesSubsectionBy = By.xpath(
			exactPagesProperties.getProperty("SpecimenHandlingAndShippingToExactSciencesLaboratoriesSubsection"));
	private final By resultsDeliverySubsectionBy = By
			.xpath(exactPagesProperties.getProperty("ResultsDeliverySubsection"));
	private final By subsectionExpandBy = By.xpath(exactPagesProperties.getProperty("SubsectionExpand"));
	private final By faqsTestingSarsCov2LinkBy = By.xpath(exactPagesProperties.getProperty("FaqsTestingSarsCov2Link"));
	private final By guidelinesClinicalSpecimensLinkBy = By
			.xpath(exactPagesProperties.getProperty("GuidelinesClinicalSpecimensLink"));
	private final By nasalCollectionInstructionsIconCardBy = By
			.xpath(exactPagesProperties.getProperty("NasalCollectionInstructionsIconCard"));
	private final By nasalHealthcareProviderFactSheetIconCardBy = By
			.xpath(exactPagesProperties.getProperty("NasalHealthcareProviderFactSheetIconCard"));
	private final By patientFactSheetIconCardBy = By
			.xpath(exactPagesProperties.getProperty("PatientFactSheetIconCard"));
	private final By covid19FluPanelTestingIconCardExploreMoreLinkBy = By
			.xpath(exactPagesProperties.getProperty("Covid19FluPanelTestingIconCardExploreMoreLink"));
	private final By exactSciencesLogoLabBy = By.xpath(exactPagesProperties.getProperty("ExactSciencesLogoLab"));

	// quality and compliance
	private final By patientPrivacyPolicySubmenuBy = By
			.xpath(exactPagesProperties.getProperty("PatientPrivacyPolicySubmenu"));
	private final By licensingAndAccreditaionSubmenuBy = By
			.xpath(exactPagesProperties.getProperty("LicensingAndAccreditaionSubmenu"));
	private final By informationSecuritySubmenuBy = By
			.xpath(exactPagesProperties.getProperty("InformationSecuritySubmenu"));

	// about us
	private final By frequentlyAskedQuestionsSubmenuBy = By
			.xpath(exactPagesProperties.getProperty("FrequentlyAskedQuestionsSubmenu"));
	private final By labLeadershipBiosSubmenuBy = By
			.xpath(exactPagesProperties.getProperty("LabLeadershipBiosSubmenu"));
	private final By frequentlyaskedquestionsPageTitleBy = By
			.xpath(exactPagesProperties.getProperty("FrequentlyaskedquestionsPageTitle"));
	private final By patientBrochureLinkBy = By.xpath(exactPagesProperties.getProperty("PatientBrochureLink"));
	private final By cologuardpatientwebsiteLinkBy = By
			.xpath(exactPagesProperties.getProperty("CologuardpatientwebsiteLink"));
// footer 
	private final By footerBy = By.xpath(exactPagesProperties.getProperty("Footer"));

	// HomeFunctions

	public boolean isHomeMenuHeaderHighlighted() {
		return Element.isElementDisplayed(homeMenuHeaderHighlightedBy);
	}

	public boolean isHomeMenuHeaderDisplayed() {
		return Element.isElementDisplayed(homeMenuHeaderBy);
	}

	public boolean isLabClientServicesMenuHeaderDisplayed() {
		return Element.isElementDisplayed(labClientServicesMenuHeaderBy);
	}

	public boolean isQualityAndComplianceMenuHeaderDisplayed() {
		return Element.isElementDisplayed(qualityAndComplianceMenuHeaderBy);
	}

	public boolean isAboutUsMenuHeaderDisplayed() {
		return Element.isElementDisplayed(aboutUsMenuHeaderBy);
	}

	public String getPageTitle() {
		Element.waitForVisible(pageTitleBy);
		return Element.getElementText(pageTitleBy);
	}

	public void clickLabClientServicesMenuOption() {
		Element.loadAndClick(labClientServicesMenuHeaderBy);
	}

	public void clickQualityAndComplianceMenuOption() {
		Element.loadAndClick(qualityAndComplianceMenuHeaderBy);
	}

	public void clickAboutUsMenuOption() {
		Element.loadAndClick(aboutUsMenuHeaderBy);
	}

	public void clickHomeMenuOption() {
		Element.loadAndClick(homeMenuHeaderBy);
	}

	public String getNCT01397747LinkDisplayed() {
		return Element.getElementText(nCT01397747LinkBy);
	}

	public String getNewEnglandJournalofMedicineLinkDisplayed() {
		return Element.getElementText(newEnglandJournalofMedicineLinkBy);
	}

	public void clickNCT01397747Link() {
		Element.loadAndClick(nCT01397747LinkBy);
	}

	public void clickNewEnglandJournalofMedicineLink() {
		Element.loadAndClick(newEnglandJournalofMedicineLinkBy);
	}

	public String getOrderCologuardByFaxIconCardDisplayed() {
		return Element.getElementText(orderCologuardByFaxIconCardBy);
	}

	public String getEpiccareLinkProviderPortalIconCardDisplayed() {
		return Element.getElementText(epiccareLinkProviderPortalIconCardBy);
	}

	public void clickDownloadAnOrderFormButton() {
		Element.loadAndClick(downloadAnOrderFormButtonBy);
	}

	public void clickSetUpMyEpiccareLinkProviderPortalButton() {
		Element.loadAndClick(setUpMyEpiccareLinkProviderPortalButtonBy);
	}

	public boolean isCALL18448708870Displayed() {
		return Element.isElementDisplayed(cALL18448708870ButtonBy);
	}

	// ClientFunction
	public void hoverLabClientServicesMenu() {
		Element.mouseHover(labClientServicesMenuHeaderBy);
	}

	public boolean isBecomingAClientSubmenuDisplayed() {
		return Element.isElementDisplayed(becomingAClientSubmenuBy);
	}

	public boolean isSampleReportSubmenuDisplayed() {
		return Element.isElementDisplayed(sampleReportSubmenuBy);
	}

	public boolean isPatientBillingSubmenuDisplayed() {
		return Element.isElementDisplayed(patientBillingSubmenuBy);
	}

	public boolean isVisualMapOfTestingProcessSubmenuDisplayed() {
		return Element.isElementDisplayed(visualMapOfTestingProcessSubmenuBy);
	}

	public boolean isCovid19TestingSubmenuDisplayed() {
		return Element.isElementDisplayed(covid19TestingSubmenuBy);
	}

	public void clickBecomingAClientSubmenuOption() {
		Element.loadAndClick(becomingAClientSubmenuBy);
	}

	public void clickDownloadAnOrderFormLink() {
		Element.loadAndClick(downloadAnOrderFormLinkBy);
	}

	public void clickHereLink() {
		Element.loadAndClick(hereLinkBy);
	}

	public void clickSampleReportSubmenuOption() {
		Element.loadAndClick(sampleReportSubmenuBy);
	}

	public void clickPatientBillingSubmenuOption() {
		hoverLabClientServicesMenu();
		Element.loadAndClick(patientBillingSubmenuBy);
	}

	public void clickCologuardLink() {
		Element.loadAndClick(cologuardLinkBy);
	}

	public void clickVisualMapOfTestingProcessSubmenuOption() {
		Element.loadAndClick(visualMapOfTestingProcessSubmenuBy);
	}

	public void clickCovid19TestingSubmenuOption() {
		Element.loadAndClick(covid19TestingSubmenuBy);
	}

	public void clickClickHereLink() {
		Element.loadAndClick(clickHereLinkBy);
	}

	public void clickRequestAdditionalDetailsButton() {
		Element.loadAndClick(requestAdditionalDetailsBy);
	}

	public void enterComapanyName(String ComapanyName) {
		Element.enterText(companyNameFieldBy, ComapanyName);
	}

	public void enterComapanyAddress(String ComapanyAddress) {
		Element.enterText(companyAddressFieldBy, ComapanyAddress);
	}

	public void enterCityName(String CityName) {
		Element.enterText(cityNameFieldBy, CityName);
	}

	public void enterStateName(String StateName) {
		Element.enterText(stateNameFieldBy, StateName);
	}

	public void enterPostelNumber(String PostelNumber) {
		Element.enterText(postelNumberFieldBy, PostelNumber);
	}

	public void enterFirstName(String FirstName) {
		Element.enterText(firstNameFieldBy, FirstName);
	}

	public void enterLastName(String LastName) {
		Element.enterText(lastNameFieldBy, LastName);
	}

	public void enterEmail(String Email) {
		Element.enterText(emailFieldBy, Email);
	}

	public void enterPhoneNumber(String PhoneNumber) {
		Element.enterText(phoneNumberFieldBy, PhoneNumber);
	}

	public void enterBestTimeToContact(String BestTimeToContact) {
		Element.enterText(bestTimeToContactFieldBy, BestTimeToContact);
	}

	public void enterEstimatedNumber(String EstimatedNumber) {
		Element.enterText(estimatedNumberFieldBy, EstimatedNumber);
	}

	public void selectDropdownListEmploy() {
		Element.loadAndClick(dropdownListBy);
		Element.loadAndClick(dropdownListEmployBy);
		;
	}

	public void enterAdditionalComments(String AdditionalComments) {
		Element.enterText(additionalCommentsFieldBy, AdditionalComments);
	}

	public void clickSubmitButton() {
		Element.loadAndClick(submitButtonBy);
		Sleeper.sleepTightInSeconds(3);
	}

	public boolean isFormSubmittingTextDisplayed() {
		return Element.isElementPresent(formSubmittingTextBy);
	}

	public void clickDonationProgramLink() {
		Element.loadAndClick(donationProgramLinkBy);
	}

	public void clickPDFRequestFormLink() {
		Element.loadAndClick(pDFRequestFormLinkBy);
	}

	public String getCovid19TestingIconCardDisplayed() {
		return Element.getElementText(covid19TestingIconCardBy);
	}

	public String getCovid19FluPanelTestingIconCardDisplayed() {
		return Element.getElementText(covid19FluPanelTestingIconCardBy);
	}

	public void clickCovid19TestingIconCardExploreMoreLink() {
		Element.loadAndClick(covid19TestingIconCardExploreMoreLinkBy);
	}

	public void clickPleaseGohereLink() {
		Element.loadAndClick(pleaseGohereLinkBy);
	}

	public void clickCdcLink() {
		Element.loadAndClick(cdcLinkBy);
	}

	public String getSpecimenCollectionSubsectionText() {
		return Element.getElementText(specimenCollectionSubsectionBy);
	}

	public String getSpecimenHandlingAndShippingToExactSciencesLaboratoriesSubsectionText() {
		return Element.getElementText(specimenHandlingAndShippingToExactSciencesLaboratoriesSubsectionBy);
	}

	public String getResultsDeliverySubsectionText() {
		return Element.getElementText(resultsDeliverySubsectionBy);
	}

	public boolean isSubsectionExpand() {
		return Element.isElementDisplayed(subsectionExpandBy);
	}

	public boolean isSubsectionCollapse(String Count) {
		By subsectionCollapseBy = By.xpath(exactPagesProperties.getProperty("SubsectionCollapse")
				+ getSectionHeadingText(Count).substring(0, 19) + "')]");
		return Element.isElementDisplayed(subsectionCollapseBy);
	}

	public void clickFaqsTestingSarsCov2Link() {
		Element.loadAndClick(faqsTestingSarsCov2LinkBy);
	}

	public void clickGuidelinesClinicalSpecimensLink() {
		Element.loadAndClick(guidelinesClinicalSpecimensLinkBy);
	}

	public void clickNasalCollectionInstructionsIconCard() {
		Element.loadAndClick(nasalCollectionInstructionsIconCardBy);
	}

	public void clickNasalHealthcareProviderFactSheetIconCard() {
		Element.loadAndClick(nasalHealthcareProviderFactSheetIconCardBy);
	}

	public void clickPatientFactSheetIconCard() {
		Element.loadAndClick(patientFactSheetIconCardBy);
	}

	public void clickHeadingToExpandCollapseSection(String Count) {
		By sectionHeadingBy = By.xpath(exactPagesProperties.getProperty("SectionHeading") + "[" + Count + "]");
		Element.waitForVisible(sectionHeadingBy);
		Element.loadAndClick(sectionHeadingBy);
		Sleeper.sleepTightInSeconds(3);
	}

	public String getSectionHeadingText(String Count) {
		By sectionHeadingBy = By.xpath(exactPagesProperties.getProperty("SectionHeading") + "[" + Count + "]");
		return Element.getElementText(sectionHeadingBy);
	}

	public void clickCovid19FluPanelTestingIconCardExploreMoreLink() {
		Element.loadAndClick(covid19FluPanelTestingIconCardExploreMoreLinkBy);
	}

	public void clickExactSciencesLogolab() {
		Element.loadAndClick(exactSciencesLogoLabBy);
	}

	// Quality and compliance function
	public void hoverQualityAndComplianceMenu() {
		Element.mouseHover(qualityAndComplianceMenuHeaderBy);
	}

	public boolean isPatientPrivacyPolicySubmenuDisplayed() {
		return Element.isElementDisplayed(patientPrivacyPolicySubmenuBy);
	}

	public boolean isLicensingAndAccreditaionSubmenuDisplayed() {
		return Element.isElementDisplayed(licensingAndAccreditaionSubmenuBy);
	}

	public boolean isInformationSecuritySubmenuDisplayed() {
		return Element.isElementDisplayed(informationSecuritySubmenuBy);
	}

	public void clickPatientPrivacyPolicySubmenuOption() {
		Element.loadAndClick(patientPrivacyPolicySubmenuBy);
	}

	public void clickLicensingAndAccreditaionSubmenuOption() {
		Element.loadAndClick(licensingAndAccreditaionSubmenuBy);
	}

	public void clickViewCertificateLicensePermitLink(String Count) {
		By viewCertificateLicensePermitLinkBy = By
				.xpath(exactPagesProperties.getProperty("ViewCertificateLicensePermitLink") + "[" + Count + "]");
		Element.loadAndClick(viewCertificateLicensePermitLinkBy);
	}

	public void clickInformationSecuritySubmenuOption() {
		Element.loadAndClick(informationSecuritySubmenuBy);
	}

	// About us Functions
	public void hoverAboutUsMenu() {
		Element.mouseHover(aboutUsMenuHeaderBy);
	}

	public boolean isFrequentlyAskedQuestionsSubmenuDisplayed() {
		return Element.isElementDisplayed(frequentlyAskedQuestionsSubmenuBy);
	}

	public boolean isLabLeadershipBiosSubmenuDisplayed() {
		return Element.isElementDisplayed(labLeadershipBiosSubmenuBy);
	}

	public void clickFrequentlyAskedQuestionsSubmenu() {
		Element.loadAndClick(frequentlyAskedQuestionsSubmenuBy);
	}

	public String getFrequentlyaskedquestionsPageTitle() {
		return Element.getElementText(frequentlyaskedquestionsPageTitleBy);
	}

	public void clickPatientBrochureLink() {
		Element.loadAndClick(patientBrochureLinkBy);
	}

	public void clickCologuardpatientwebsiteLink() {
		Element.loadAndClick(cologuardpatientwebsiteLinkBy);
	}

	public void clickLabLeadershipBiosSubmenu() {
		Element.loadAndClick(labLeadershipBiosSubmenuBy);
	}

	public void checkForExUSSiteForAboutPage(String url) {
		Element.waitForDOMToLoad();
		while (driver.getURL().contains("ex-us")) {
			logInfo(driver.getURL() + " Ex-US site detected, closing the browser and relaunching");
			driver.close();
			DriverManager.getCurrent();
			driver.open(url);
			if (annualReportsPage.acceptCookiesDisplayed()) {
				annualReportsPage.acceptCookies();
			}
			clickCologuardpatientwebsiteLink();
		}
	}

	// footer
	public boolean isFooterDisplayed() {
		return Element.isElementPresent(footerBy);
	}

	public void clickFooterLinks(String Count) {
		By footerLinksBy = By.xpath(exactPagesProperties.getProperty("FooterLinks") + "[" + Count + "]");
		Element.loadAndClick(footerLinksBy);
	}

	public String getFooterLinksText(String Count) {
		By footerLinksBy = By.xpath(exactPagesProperties.getProperty("FooterLinks") + "[" + Count + "]");
		return Element.getElementText(footerLinksBy);
	}

	public void checkForExUSSiteOnFooter(String Count, String url) {
		Element.waitForDOMToLoad();
		while (driver.getURL().contains("ex-us")) {
			logInfo(driver.getURL() + " Ex-US site detected, closing the browser and relaunching");
			driver.close();
			DriverManager.getCurrent();
			driver.open(url);
			if (annualReportsPage.acceptCookiesDisplayed()) {
				annualReportsPage.acceptCookies();
			}
			clickFooterLinks(Count);
		}
	}
}
