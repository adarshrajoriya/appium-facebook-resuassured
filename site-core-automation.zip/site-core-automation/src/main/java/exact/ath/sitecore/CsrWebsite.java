package exact.ath.sitecore;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class CsrWebsite extends ExactNavNavigation {

	private By sampleBy = null;
	private final By csrCIandCRHeaderHighlightBy = By
			.xpath(exactPagesProperties.getProperty("CsrCIandCRHeaderHighlight"));
	private final By csrCtoECHeaderBy = By.xpath(exactPagesProperties.getProperty("CsrCtoECHeader"));
	private final By csrCommunityEngagementHeaderBy = By
			.xpath(exactPagesProperties.getProperty("CsrCommunityEngagementHeader"));
	private final By csrSustainabilityHeaderBy = By.xpath(exactPagesProperties.getProperty("CsrSustainabilityHeader"));
	private final By csrEmailLinkBy = By.xpath(exactPagesProperties.getProperty("CsrEmailLink"));
	private final By uSRequestsClickHereButtonBy = By
			.xpath(exactPagesProperties.getProperty("USRequestsClickHereButton"));
	private final By outsideUSRequestsClickHereButtonBy = By
			.xpath(exactPagesProperties.getProperty("OutsideUSRequestsClickHereButton"));
	private final By csrHeaderOptionBy = By.xpath(exactPagesProperties.getProperty("CsrHeaderOption"));
	private final By investorRelationsCorporateGovernanceSustainabilityLinkBy = By
			.cssSelector(exactPagesProperties.getProperty("InvestorRelationsCorporateGovernanceSustainabilityLink"));
	private final By csrCtoECHeaderHighlightedBy = By
			.xpath(exactPagesProperties.getProperty("CsrCtoECHeaderHighlighted"));
	private final By csrCommunityEngagementHeaderHighlightBy = By
			.xpath(exactPagesProperties.getProperty("CsrCommunityEngagementHeaderHighlight"));
	private final By csrSustainabilityHeaderHighlightBy = By
			.xpath(exactPagesProperties.getProperty("CsrSustainabilityHeaderHighlight"));
	private final By exactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairPageBy = By
			.xpath(exactPagesProperties
					.getProperty("ExactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairPage"));
	private final By csrJumpLink1HighlightedBy = By.xpath(exactPagesProperties.getProperty("CsrJumpLink1Highlighted"));
	private final By csrJumpLink2HighlightedBy = By.xpath(exactPagesProperties.getProperty("CsrJumpLink2Highlighted"));
	private final By csrJumpLink2By = By.xpath(exactPagesProperties.getProperty("CsrJumpLink2"));
	private final By csrJumpLink3HighlightedBy = By.xpath(exactPagesProperties.getProperty("CsrJumpLink3Highlighted"));
	private final By csrJumpLink3By = By.xpath(exactPagesProperties.getProperty("CsrJumpLink3"));
	private final By csrJumpLink4HighlightedBy = By.xpath(exactPagesProperties.getProperty("CsrJumpLink4Highlighted"));
	private final By csrJumpLink4By = By.xpath(exactPagesProperties.getProperty("CsrJumpLink4"));
	private final By csrJumpLink5HighlightedBy = By.xpath(exactPagesProperties.getProperty("CsrJumpLink5Highlighted"));
	private final By csrJumpLink5By = By.xpath(exactPagesProperties.getProperty("CsrJumpLink5"));
	private final By exactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairLinkBy = By
			.xpath(exactPagesProperties
					.getProperty("ExactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairLink"));
	private final By nMQFLinkBy = By.xpath(exactPagesProperties.getProperty("NMQFLink"));
	private final By cancerStageShiftingInitiativeLinkBy = By
			.xpath(exactPagesProperties.getProperty("CancerStageShiftingInitiativeLink"));
	private final By csrHereLinkBy = By.cssSelector(exactPagesProperties.getProperty("CsrHereLink"));
	private final By csrSeeMoreEntriesBy = By.cssSelector(exactPagesProperties.getProperty("CsrSeeMoreEntries"));
	private final By csrReadMoreBy = By.cssSelector(exactPagesProperties.getProperty("CsrReadMore"));
	private final By csrCtoECPageTittleBy = By.cssSelector(exactPagesProperties.getProperty("CsrCtoECPageTittle"));
	private final By csrViewAllPostsBy = By.xpath(exactPagesProperties.getProperty("CsrViewAllPosts"));
	private final By uWCarboneLinkBy = By.xpath(exactPagesProperties.getProperty("CsrUWCarboneLink"));
	private final By pPERecyclingInitiativeLinkBy = By
			.xpath(exactPagesProperties.getProperty("PPERecyclingInitiativeLink"));

	public boolean isCsrCiAndCrHeaderHighlightedDisplayed() {
		return Element.isElementDisplayed(csrCIandCRHeaderHighlightBy);
	}

	public boolean isCsrCtoECHeaderDisplayed() {
		return Element.isElementDisplayed(csrCtoECHeaderBy);
	}

	public boolean isCsrCommunityEngagementHeaderDisplayed() {
		return Element.isElementDisplayed(csrCommunityEngagementHeaderBy);
	}

	public boolean isCsrSustainabilityHeaderDisplayed() {
		return Element.isElementDisplayed(csrSustainabilityHeaderBy);
	}

	public void clickCsrEmailLink() {
		Element.loadAndClick(csrEmailLinkBy);
	}

	public void clickUSRequestsClickHereButton() {
		Element.loadAndClick(uSRequestsClickHereButtonBy);
	}

//	public boolean isEmailPopUpOpened() {
//		return Element.isElementDisplayed();
//	}

	public boolean isUSRequestsClickHereButtonDisplayed() {
		return Element.isElementDisplayed(uSRequestsClickHereButtonBy);
	}

	public boolean isOutsideUSRequestsClickHereButtonDisplayed() {
		return Element.isElementDisplayed(outsideUSRequestsClickHereButtonBy);
	}

	public boolean isHeaderOptionDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(csrHeaderOptionBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public void clickOutsideUSRequestsClickHereButton() {
		Element.loadAndClick(outsideUSRequestsClickHereButtonBy);
	}

	public void clickInvestorRelationsCorporateGovernanceSustainabilityLink() {
		Element.loadAndClick(investorRelationsCorporateGovernanceSustainabilityLinkBy);
	}

	public boolean isCsrCtoECHeaderHighlightedDisplayed() {
		return Element.isElementDisplayed(csrCtoECHeaderHighlightedBy);
	}

	public boolean isCsrCmnEngHeaderHighlightedDisplayed() {
		return Element.isElementDisplayed(csrCommunityEngagementHeaderHighlightBy);
	}

	public boolean isCsrSustainabilityHeaderHighlightedDisplayed() {
		return Element.isElementDisplayed(csrSustainabilityHeaderHighlightBy);
	}

	public boolean isExactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairPageDisplayed() {
		return Element
				.isElementDisplayed(exactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairPageBy);
	}

	public boolean isJumpLink1Highlighted() {
		return Element.isElementDisplayed(csrJumpLink1HighlightedBy);
	}

	public boolean isJumpLink2Highlighted() {
		return Element.isElementDisplayed(csrJumpLink2HighlightedBy);
	}

	public boolean isJumpLink3Highlighted() {
		return Element.isElementDisplayed(csrJumpLink3HighlightedBy);
	}

	public boolean isJumpLink4Highlighted() {
		return Element.isElementDisplayed(csrJumpLink4HighlightedBy);
	}

	public boolean isJumpLink5Highlighted() {
		return Element.isElementDisplayed(csrJumpLink5HighlightedBy);
	}

	public void clickExactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairLink() {
		Element.loadAndClick(exactSciencesNMQFPartnerIncreaseCancerScreeningsThroughCommunityHealthFairLinkBy);
	}

	public void clickCsrCtoECHeader() {
		Element.loadAndClick(csrCtoECHeaderBy);
	}

	public void clickCsrCmnEngHeader() {
		Element.loadAndClick(csrCommunityEngagementHeaderBy);
	}

	public void clickCsrSustainabilityHeader() {
		Element.loadAndClick(csrSustainabilityHeaderBy);
	}

	public void clickNMQFLink() {
		Element.loadAndClick(nMQFLinkBy);
	}

	public void clickCancerStageShiftingInitiativeLink() {
		Element.loadAndClick(cancerStageShiftingInitiativeLinkBy);
	}

	public void clickHereLink() {
		Element.loadAndClick(csrHereLinkBy);
	}

	public void clickCsrCtoECCard(int count) {
		sampleBy = By.xpath("(" + (exactPagesProperties.getProperty("CsrCtoECCard")) + ")[" + count + "]");
		Element.loadAndClick(sampleBy);
	}

	public void clickCsrCiAndCrIconCardTittle(int count) {
		sampleBy = By.xpath("(" + (exactPagesProperties.getProperty("CsrCiAndCrIconCardTittle")) + ")[" + count + "]");
		Element.loadAndClick(sampleBy);
	}

	public void clickSeeMoreEntries() {
		Element.loadAndClick(csrSeeMoreEntriesBy);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(5);
	}

	public void clickReadMore() {
		Element.loadAndClick(csrReadMoreBy);
	}

	public void clickJumpLink2() {
		Sleeper.sleepTightInSeconds(3);
		Element.loadAndClick(csrJumpLink2By);
	}

	public void clickJumpLink3() {
		Element.loadAndClick(csrJumpLink3By);
	}

	public void clickJumpLink4() {
		Element.loadAndClick(csrJumpLink4By);
	}

	public void clickJumpLink5() {
		Element.loadAndClick(csrJumpLink5By);
	}

	public void clickCsrViewAllPostsLink() {
		Element.loadAndClick(csrViewAllPostsBy);
	}

	public void clickUWCarboneLink() {
		Element.loadAndClick(uWCarboneLinkBy);
	}

	public void clickPPERecyclingInitiativeLink() {
		Element.loadAndClick(pPERecyclingInitiativeLinkBy);
	}

	public String getCsrCtoECPageTittle() {
		Element.waitForVisible(csrCtoECPageTittleBy);
		return Element.getElementText(csrCtoECPageTittleBy);
	}

	public String getCsrCtoECCardTittle(int count) {
		sampleBy = By.xpath("(" + (exactPagesProperties.getProperty("CsrCtoECCard")) + ")[" + count + "]");
		Element.waitForVisible(sampleBy);
		return Element.getElementText(sampleBy);
	}

	public String getCsrCiAndCrIconCardTittle(int count) {
		sampleBy = By.xpath("(" + (exactPagesProperties.getProperty("CsrCiAndCrIconCardTittle")) + ")[" + count + "]");
		return Element.getElementText(sampleBy);
	}

}
