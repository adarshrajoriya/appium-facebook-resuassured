package exact.ath.sitecore;

import org.openqa.selenium.By;

import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;
import exact.Element;

public class AnnualReportsPage extends ExactNavNavigation {
	
	private final By annualReportsPageBy = By.xpath(exactPagesProperties.getProperty("AnnualReportsPage"));
	private final By exactSciencesLogoBy = By.xpath(exactPagesProperties.getProperty("ExactSciencesLogo"));
	private final By annualReportLinkBy = By.xpath(exactPagesProperties.getProperty("AnnualReportLink"));
	private final By proxyStatementLinkBy = By.xpath(exactPagesProperties.getProperty("ProxyStatementLink"));
	private final By eSGReportLinkBy = By.xpath(exactPagesProperties.getProperty("2021ESGReportLink"));
	private final By whenCardBy = By.xpath(exactPagesProperties.getProperty("WhenCard"));
	private final By whereCardBy = By.xpath(exactPagesProperties.getProperty("WhereCard"));
	private final By toVoteCardBy = By.xpath(exactPagesProperties.getProperty("ToVoteCard"));
	private final By virtualShareholderMeetingLink1By = By.xpath(exactPagesProperties.getProperty("VirtualShareholderMeetingLink1"));
	private final By virtualShareholderMeetingLink2By = By.xpath(exactPagesProperties.getProperty("VirtualShareholderMeetingLink2"));
	private final By proxyVoteLinkBy = By.xpath(exactPagesProperties.getProperty("ProxyVoteLink"));
	private final By annualReportsPageFooterBy = By.xpath(exactPagesProperties.getProperty("AnnualReportsPageFooter"));
	private final By acceptCookiesBy = By.cssSelector(exactPagesProperties.getProperty("AcceptCookies"));
	private final By reportTittleBy = By.xpath(exactPagesProperties.getProperty("ReportTittle"));
	private final By contactUsLinkBy = By.xpath(exactPagesProperties.getProperty("ContactUsLink"));
	private final By facebookIconBy = By.xpath(exactPagesProperties.getProperty("FacebookIcon"));
	private final By twitterIconBy = By.xpath(exactPagesProperties.getProperty("TwitterIcon"));
	private final By linkedInIconBy = By.xpath(exactPagesProperties.getProperty("LinkedInIcon"));
	
	public boolean isannualReportsPageDisplayed() {
		Element.waitForVisible(annualReportsPageBy);
		return Element.isElementDisplayed(annualReportsPageBy);
	}
	
	public boolean isexactSciencesLogoDisplayed() {
		return Element.isElementDisplayed(exactSciencesLogoBy);
	}
	
	public boolean isAnnualReportDisplayed() {
		return Element.isElementDisplayed(annualReportLinkBy);
	}
	
	public boolean isProxyStatementDisplayed() {
		return Element.isElementDisplayed(proxyStatementLinkBy);
	}
	
	public boolean is2021ESGReportDisplayed() {
		return Element.isElementDisplayed(eSGReportLinkBy);
	}
	
	public boolean isWhenCardDisplayed() {
		return Element.isElementDisplayed(whenCardBy);
	}
	
	public boolean isWhereCardDisplayed() {
		return Element.isElementDisplayed(whereCardBy);
	}
	
	public boolean isToVoteCardDisplayed() {
		return Element.isElementDisplayed(toVoteCardBy);
	}
	
	public boolean isVirtualShareholderMeetingLink1Displayed() {
		return Element.isElementDisplayed(virtualShareholderMeetingLink1By);
	}
	
	public boolean isVirtualShareholderMeetingLink2Displayed() {
		return Element.isElementDisplayed(virtualShareholderMeetingLink2By);
	}
	
	public boolean isProxyVoteLinkDisplayed() {
		return Element.isElementDisplayed(proxyVoteLinkBy);
	}
	
	public boolean isAnnualReportsPageFooterDisplayed() {
		return Element.isElementDisplayed(annualReportsPageFooterBy);
	}
	
	public String getAnnualReportsPageFooterText() {
		return Element.getElementText(annualReportsPageFooterBy);
	}
	
	public void clickExactSciencesLogoLink() {
		Element.loadAndClick(exactSciencesLogoBy);		
	}
	
	public void clickAnnualReportLink() {
		Element.loadAndClick(annualReportLinkBy);		
	}
	
	public void clickProxyStatementLink() {
		Element.loadAndClick(proxyStatementLinkBy);		
	}
	
	public void click2021ESGReportLink() {
		Element.loadAndClick(eSGReportLinkBy);		
	}
	
	public void clickFacebookIcon() {
		Element.loadAndClick(facebookIconBy);		
	}
	
	public void clickVirtualShareholderMeetingLink2() {
		Element.loadAndClick(virtualShareholderMeetingLink2By);		
	}
	
	public void clickProxyVoteLink() {
		Element.loadAndClick(proxyVoteLinkBy);		
	}
	
	public void acceptCookies() {
	    Element.loadAndClick(acceptCookiesBy);		
	}
	
	public boolean acceptCookiesDisplayed() {
		Sleeper.sleepTightInSeconds(7);
	    return Element.isElementDisplayed(acceptCookiesBy);		
	}
	
	public String getReportTittle() {
		return Element.getElementText(reportTittleBy);		
	}
	
	public void clickContactUsLink() {
		Element.loadAndClick(contactUsLinkBy);		
	}
	
	public void clickVirtualShareholderMeetingLink1() {
		Element.loadAndClick(virtualShareholderMeetingLink1By);		
	}
	
	public void clickTwitterIcon() {
		Element.loadAndClick(twitterIconBy);		
	}
	
	public void clickLinkedInIcon() {
		Element.loadAndClick(linkedInIconBy);		
	}

}
