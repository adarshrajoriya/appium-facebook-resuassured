package exact.ath.corporateUk;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class CorporateUkProductPage extends ExactNavNavigation {

	private final By precisionOncologyBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("precisionOncologyBy"));
	private final By screeningBy = By.cssSelector(corporateUkPagesProperties.getProperty("screeningBy"));
	private final By pipelineBy = By.cssSelector(corporateUkPagesProperties.getProperty("pipelineBy"));

	public void clickPrecisionOncology() {
		Element.loadAndClick(precisionOncologyBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button below 'PRECISION ONCOLOGY' heading");
	}

	public void clickScreening() {
		Element.loadAndClick(screeningBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button below 'SCREENING' heading");
	}

	public void clickpipeline() {
		Element.loadAndClick(pipelineBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button below 'THE PIPELINE' heading");
	}

}
