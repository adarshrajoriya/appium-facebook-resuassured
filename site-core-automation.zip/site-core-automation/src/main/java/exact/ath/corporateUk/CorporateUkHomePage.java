package exact.ath.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class CorporateUkHomePage extends ExactNavNavigation {

	private final By pageHeadingDisplayedHomePage = By
			.cssSelector(corporateUkPagesProperties.getProperty("pageHeadingDisplayedHomePage"));
	private final By unitedKingdomBy = By.cssSelector(corporateUkPagesProperties.getProperty("unitedKingdomBy"));
	private final By corporateUkHeaderOptionsBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("corporateUkHeaderOptionsBy"));
	private final By titleOnPopupBy = By.cssSelector(corporateUkPagesProperties.getProperty("titleOnPopupBy"));
	private final By agreeButtonBy = By.cssSelector(corporateUkPagesProperties.getProperty("agreeButtonBy"));
	private final By contactUsLinkBy = By.cssSelector(corporateUkPagesProperties.getProperty("contactUsLinkBy"));
	private final By closeButtonBy = By.cssSelector(corporateUkPagesProperties.getProperty("closeButtonBy"));
	private final By footerLinksBy = By.cssSelector(corporateUkPagesProperties.getProperty("footerLinksBy"));

	private final By learnMoreButtonBelowPursuingEarlierBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("learnMoreButtonBelowPursuingEarlierBy"));

	private final By learnMoreButtonBelowProvidingBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("learnMoreButtonBelowProvidingBy"));
	private final By learnMoreButtonBelowDeliveringBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("learnMoreButtonBelowDeliveringBy"));
	private final By learnMoreButtonBelowKeepingBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("learnMoreButtonBelowKeepingBy"));

	public String getPageHeadingDisplayedHomePage() {
		return Element.getText(pageHeadingDisplayedHomePage);

	}

	public boolean isUnitedKingdomDisplayed() {
		return Element.isElementDisplayed(corporateUkHomepageIconBy);
	}

	public boolean isExactScienceLogoDisplayed() {
		return Element.isElementDisplayed(unitedKingdomBy);
	}

	/**
	 * @param To verify the menu options of page
	 * @return
	 */
	public boolean isHeaderOptionDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(corporateUkHeaderOptionsBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public void clickExactScienceLogo() {
		Element.loadAndClick(unitedKingdomBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'EXACT SCIENCES' logo");
	}

	/**
	 * @param To click the header menu of the page
	 * @throws Exception
	 */
	public void clickHeaderOption(String linkText) throws Exception {
		WebElement foundElement = Element.getFromHtml(corporateUkHeaderOptionsBy, linkText);
		if (foundElement != null) {
			Element.loadAndClick(foundElement);
			Element.waitForDOMToLoad();
			logInfo("Clicked on '" + linkText + "' link");
			return;
		}
		throw new Exception("Unable to find '" + linkText + "' link on the page. - " + BasicUtils.takeScreenshot());

	}

	public String getPopUpText() {
		return Element.getText(titleOnPopupBy);
	}

	public void clickAgreeButton() {
		Element.loadAndClick(agreeButtonBy);
		Element.waitForDOMToLoad();
	}

	public void clickCloseButton() {
		Element.loadAndClick(closeButtonBy);
		Element.waitForDOMToLoad();
	}

	/**
	 * @param Hover over the menu Header
	 * @throws Exception
	 */
	public void hoverTopNavOption(String option) throws Exception {
		WebElement foundElement = Element.getFromHtml(corporateUkHompageNavBy, option);
		if (foundElement != null) {
			Element.mouseHover(foundElement);
			Element.waitForDOMToLoad();
			logInfo("Clicked on '" + option + "' link");
			return;
		}
		throw new Exception("Unable to find '" + option + "' link on the page. - " + BasicUtils.takeScreenshot());
	}

	/**
	 * @param To verify the sub menu item
	 * @return
	 */
	public boolean isSubItemDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(corporateUkHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public void clickContactUsLink() {
		Element.loadAndClick(contactUsLinkBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Contact Us' Link from the Footer section.");
	}

	/**
	 * @param To click on the Footer Link Text
	 * @throws Exception
	 */
	public void clickFooterLink(String footerText) throws Exception {
		WebElement foundElement = Element.getFromHtml(footerLinksBy, footerText);
		if (foundElement != null) {
			Element.loadAndClick(foundElement);
			Element.waitForDOMToLoad();
			logInfo("Clicked on '" + footerText + "' link");
			return;
		}
		throw new Exception("Unable to find '" + footerText + "' link on the page. - " + BasicUtils.takeScreenshot());
	}

	public void clickLearnMoreButtonBelowPursuingEarlier() {
		Element.loadAndClick(learnMoreButtonBelowPursuingEarlierBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button below 'PURSUING EARLIER DETECTION AND LIFE-CHANGING ANSWERS' heading");
	}

	public void clickLearnMoreButtonBelowProviding() {
		Element.loadAndClick(learnMoreButtonBelowProvidingBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button below 'PROVIDING EARLIER, SMARTER ANSWERS' heading");
	}

	public void clickLearnMoreButtonBelowDelivering() {
		Element.loadAndClick(learnMoreButtonBelowDeliveringBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button below 'DELIVERING LIFE-CHANGING INNOVATIONS' heading");
	}

	public void clickLearnMoreButtonBelowKeeping() {
		Element.loadAndClick(learnMoreButtonBelowKeepingBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button below 'KEEPING PEOPLE FIRST' heading");
	}

}
