package exact.ath.corporateUk;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class CorporateUkAboutUsPage extends ExactNavNavigation {

	private final By cardItemBy = By.cssSelector(corporateUkPagesProperties.getProperty("cardItemBy"));

	/**
	 * @param To verify the cards present on the page
	 * @return
	 */
	public boolean isCardItemDisplayed(String itemLabel) {
		List<WebElement> listElements = Element.getMultiple(cardItemBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				return true;
			}
		}
		return false;
	}

}
