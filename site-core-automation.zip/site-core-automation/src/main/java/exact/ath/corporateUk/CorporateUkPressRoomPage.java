package exact.ath.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;
import exact.util.Sleeper;

public class CorporateUkPressRoomPage extends ExactNavNavigation {

	private final By pressReleasesOptionBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("pressReleasesOptionBy"));
	private final By plusIconButtonBy = By.xpath(corporateUkPagesProperties.getProperty("plusIconButtonBy"));
	private final By accordionItemBy = By.cssSelector(corporateUkPagesProperties.getProperty("accordionItemBy"));

	/**
	 * @param To click on Press Releases Option present on the page
	 * @throws Exception
	 */
	public void clickPressReleasesOption(String linkText) throws Exception {
		Element.waitForVisible(pressReleasesOptionBy);
		WebElement foundElement = Element.getFromHtml(pressReleasesOptionBy, linkText);
		if (foundElement != null) {
			Element.loadAndClick(foundElement);
			Element.waitForDOMToLoad();
			Sleeper.sleepTightInSeconds(2);
			logInfo("Clicked on '" + linkText + "' link");
			return;
		}
		throw new Exception("Unable to find '" + linkText + "' link on the page. - " + BasicUtils.takeScreenshot());
	}

//		List<WebElement> listElements = Element.getMultiple(pressReleasesOptionBy);
//		for (WebElement webElement : listElements) {
//			if (Element.getText(webElement).equalsIgnoreCase(linkText)) {
//				Element.loadAndClick(webElement);
//				Element.waitForDOMToLoad();
//				Sleeper.sleepTightInSeconds(2);
//				logInfo("Clicked on '" + linkText + "' link");
//				return;
//			}
//		}
//		throw new Exception("Unable to find '" + linkText + "' link on the page. - " + BasicUtils.takeScreenshot());
//	}

	/**
	 * @param To click on the accordion
	 */
	public void clickPlusIconButton(int resultLinkIndex) {
		List<WebElement> elements = Element.getMultiple(plusIconButtonBy);
		Element.loadAndClick(elements.get(resultLinkIndex));
		Element.waitForDOMToLoad();

	}

	private List<Boolean> getAccordionResultsStatus() {
		List<WebElement> items = Element.getMultiple(accordionItemBy);
		List<Boolean> results = new ArrayList<>();

		for (WebElement webElement : items) {
			if (webElement.getAttribute("class").contains("active")) {
				results.add(true);
			} else {
				results.add(false);
			}
		}
		return results;
	}

	public boolean isYearExpanded() {
		return getAccordionResultsStatus().contains(true);
	}

}
