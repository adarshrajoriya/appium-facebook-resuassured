package exact.ath.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class CorporateUkOncoTypeDxTestPage extends ExactNavNavigation {

	private final By portalButtonBy = By.xpath(corporateUkPagesProperties.getProperty("portalButtonBy"));
	private final By oncotypeDxTestBy = By.cssSelector(corporateUkPagesProperties.getProperty("oncotypeDxTestBy"));

	/**
	 * @param To click on buttons to visit to the different links
	 */
	public void clickPortalButton(int resultLinkIndex) {
		List<WebElement> elements = Element.getMultiple(portalButtonBy);
		Element.loadAndClick(elements.get(resultLinkIndex));
		Element.waitForDOMToLoad();
	}

	public void clickOncotypeDxTest() {
		Element.loadAndClick(oncotypeDxTestBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button from 'ONCOTYPE DX TEST FOR BREAST CANCER' card");
	}

}
