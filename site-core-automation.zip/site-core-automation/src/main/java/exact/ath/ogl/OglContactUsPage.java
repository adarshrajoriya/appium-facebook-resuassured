package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class OglContactUsPage extends ExactNavNavigation {

	private final By contactUsProvidersOnly = By.cssSelector(oglPagesProperties.getProperty("contactUsProvidersOnly"));
	private final By contactUsProvidersOnlyCardBy = By
			.cssSelector(oglPagesProperties.getProperty("contactUsProvidersOnlyCardSelector"));
	private final By submitButtonUnderContactUsProvidersOnlyTitleBy = By
			.cssSelector(oglPagesProperties.getProperty("submitButtonUnderContactUsProvidersOnlyTitleBy"));
	private final By validationMessageBy = By.cssSelector(oglPagesProperties.getProperty("validationMessageBy"));
	private final By firstNameFieldBy = By.cssSelector(oglPagesProperties.getProperty("firstNameFieldBy"));
	private final By lastNameFieldBy = By.cssSelector(oglPagesProperties.getProperty("lastNameFieldBy"));
	private final By emailFieldBy = By.cssSelector(oglPagesProperties.getProperty("emailFieldBy"));
	private final By phoneNumberFieldBy = By.cssSelector(oglPagesProperties.getProperty("phoneNumberFieldBy"));
	private final By zipCodeFieldBy = By.cssSelector(oglPagesProperties.getProperty("zipCodeFieldBy"));
	private final By preferrredContactMethodBy = By
			.cssSelector(oglPagesProperties.getProperty("preferrredContactMethodBy"));
	private final By preferrredEmailContactMethodBy = By
			.cssSelector(oglPagesProperties.getProperty("preferrredEmailContactMethodBy"));
	private final By whichBestDescribesYouBy = By
			.cssSelector(oglPagesProperties.getProperty("whichBestDescribesYouBy"));
	private final By whichBestDescribesPrimaryCarePhysicianBy = By
			.cssSelector(oglPagesProperties.getProperty("whichBestDescribesPrimaryCarePhysicianBy"));
	private final By confirmationMessageBy = By.cssSelector(oglPagesProperties.getProperty("confirmationMessageBy"));

	private final By firstNameFieldSignUpBy = By.cssSelector(oglPagesProperties.getProperty("firstNameFieldSignUpBy"));
	private final By lastNameFieldSignUpBy = By.cssSelector(oglPagesProperties.getProperty("lastNameFieldSignUpBy"));
	private final By emailFieldSignUpBy = By.cssSelector(oglPagesProperties.getProperty("emailFieldSignUpBy"));
	private final By phoneNumberFieldSignUpBy = By
			.cssSelector(oglPagesProperties.getProperty("phoneNumberFieldSignUpBy"));
	private final By zipCodeFieldSignUpBy = By.cssSelector(oglPagesProperties.getProperty("zipCodeFieldSignUpBy"));
	private final By specialtyBy = By.cssSelector(oglPagesProperties.getProperty("specialtyBy"));
	private final By specialtyPrimaryCarePhysicianBy = By
			.cssSelector(oglPagesProperties.getProperty("specialtyPrimaryCarePhysicianBy"));
	private final By institutionFieldSignUpBy = By
			.cssSelector(oglPagesProperties.getProperty("institutionFieldSignUpBy"));
	private final By submitButtonUnderSignUpInformationTitleBy = By
			.cssSelector(oglPagesProperties.getProperty("submitButtonUnderSignUpInformationTitleBy"));

	public String getContactUsProvidersOnly() {
		return Element.getText(contactUsProvidersOnly);
	}

	public boolean isContactUsProvidersOnlyCardDisplayed() {
		return Element.isElementDisplayed(contactUsProvidersOnlyCardBy);
	}

	public void clickSubmitButtonUnderContactUsProvidersOnlyTitle() {
		Element.loadAndClick(submitButtonUnderContactUsProvidersOnlyTitleBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Submit Button' Under 'Contact Us Providers Only' Title");

	}

	public boolean isMandatoryFieldsDisplayed() {
		return Element.isElementDisplayed(validationMessageBy);
	}

	public void enterFirstName(String firstName) {
		Element.enterText(firstNameFieldBy, firstName);
		logInfo("Entered First Name '" + firstName + "'");
	}

	public void enterLastName(String lastName) {
		Element.enterText(lastNameFieldBy, lastName);
		logInfo("Entered Last Name '" + lastName + "'");
	}

	public void enterEmail(String email) {
		Element.enterText(emailFieldBy, email);
		logInfo("Entered email '" + email + "'");
	}

	public void enterPhoneNumber(String phoneNumber) {
		Element.enterText(phoneNumberFieldBy, phoneNumber);
		logInfo("Entered phoneNumber '" + phoneNumber + "'");
	}

	public void enterZipCode(String zipCode) {
		Element.enterText(zipCodeFieldBy, zipCode);
		logInfo("Entered zipCode '" + zipCode + "'");
	}

	public void selectPreferredContactMethod(String preferredContactMethod) throws Exception {
		Element.loadAndClick(preferrredContactMethodBy);
		List<WebElement> listElements = Element.getMultiple(preferrredEmailContactMethodBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(preferredContactMethod)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Selected 'Preferrred Contact Method*' '" + preferredContactMethod + "'");
				return;
			}
		}

		throw new Exception("Unable to find '" + preferredContactMethod + "' option " + BasicUtils.takeScreenshot());

	}

	public void selectWhichBestDescribesYou(String whichBestDescribesYou) throws Exception {
		Element.loadAndClick(whichBestDescribesYouBy);
		List<WebElement> listElements = Element.getMultiple(whichBestDescribesPrimaryCarePhysicianBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(whichBestDescribesYou)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Selected 'Which Best Describes You*' '" + whichBestDescribesYou + "'");
				return;
			}
		}

		throw new Exception("Unable to find '" + whichBestDescribesYou + "' option " + BasicUtils.takeScreenshot());
	}

	public boolean isConfirmationMessageDisplayed() {
		Element.waitForVisible(confirmationMessageBy);
		return Element.isElementDisplayed(confirmationMessageBy);
	}

	public void enterFirstNameSignUp(String firstName) {
		Element.enterText(firstNameFieldSignUpBy, firstName);
		logInfo("Entered First Name '" + firstName + "'");
	}

	public void enterLastNameSignUp(String lastName) {
		Element.enterText(lastNameFieldSignUpBy, lastName);
		logInfo("Entered Last Name '" + lastName + "'");
	}

	public void enterEmailSignUp(String email) {
		Element.enterText(emailFieldSignUpBy, email);
		logInfo("Entered email '" + email + "'");
	}

	public void enterPhoneNumberSignUp(String phoneNumber) {
		Element.enterText(phoneNumberFieldSignUpBy, phoneNumber);
		logInfo("Entered phoneNumber '" + phoneNumber + "'");
	}

	public void enterZipCodeSignUp(String zipCode) {
		Element.enterText(zipCodeFieldSignUpBy, zipCode);
		logInfo("Entered zipCode '" + zipCode + "'");
	}

	public void selectSpecialty(String specialty) throws Exception {
		Element.loadAndClick(specialtyBy);
		List<WebElement> listElements = Element.getMultiple(specialtyPrimaryCarePhysicianBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(specialty)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Selected 'Specialty*' '" + specialty + "'");
				return;
			}
		}

		throw new Exception("Unable to find '" + specialty + "' option " + BasicUtils.takeScreenshot());

	}

	public void enterInstitutionSignUp(String institution) {
		Element.enterText(institutionFieldSignUpBy, institution);
		logInfo("Entered institution '" + institution + "'");
	}

	public void clickSubmitButtonUnderSignUpInformationTitle() {
		Element.loadAndClick(submitButtonUnderSignUpInformationTitleBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Submit Button' Under 'Sign up for Information' Title");

	}

}
