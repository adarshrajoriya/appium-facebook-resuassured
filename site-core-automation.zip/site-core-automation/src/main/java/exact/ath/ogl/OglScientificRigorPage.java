package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OglScientificRigorPage extends ExactNavNavigation {

	private final By learnMoreButtonUnderTitles = By
			.xpath(oglPagesProperties.getProperty("learnMoreButtonUnderTitles"));

	public void clickOnLearnMoreUnderOncoguardSolution() {
		Element.loadAndClick(learnMoreButtonUnderTitles);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button under 'The Oncoguard Liver solution. Exactly what's needed today.' title");
	}

}
