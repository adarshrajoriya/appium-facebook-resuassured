package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class OglOrdersAndResultsPage extends ExactNavNavigation {

	private final By oncoguarLiverTestResultsBy = By
			.cssSelector(oglPagesProperties.getProperty("oncoguarLiverTestResultsSelector"));

	private final By convenientOrderingProcessesWorkflowHeading = By
			.cssSelector(oglPagesProperties.getProperty("convenientOrderingProcessesWorkflowHeading"));

	private final By oncoguardLiverTestResultsHeading = By
			.xpath(oglPagesProperties.getProperty("oncoguardLiverTestResultsHeading"));

	private final By orderingWithRequisitionFormLink = By
			.xpath(oglPagesProperties.getProperty("orderingWithRequisitionFormLink"));

	private final By orderingThroughEpicCareLink = By
			.xpath(oglPagesProperties.getProperty("orderingThroughEpicCareLink"));

	private final By epicCareLink = By.xpath(oglPagesProperties.getProperty("epicCareLink"));

	private final By theResourcePageLink = By.xpath(oglPagesProperties.getProperty("theResourcePageLink"));

	private final By seeOrderSuppliesSectionLink = By
			.xpath(oglPagesProperties.getProperty("seeOrderSuppliesSectionLink"));

	public void clickOnOncoguarLiverTestResultsIconCard() {
		Element.loadAndClick(oncoguarLiverTestResultsBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Oncoguard Liver test results' icon card from 'Jump to a section:' banner.");
	}

	public String getConvenientOrderingProcessesWorkflowHeading() {
		return Element.getText(convenientOrderingProcessesWorkflowHeading);
	}

	public String getOncoguardLiverTestResultsHeading() {
		return Element.getText(oncoguardLiverTestResultsHeading);
	}

	public void clickOnOrderingWithRequisitionFormLink() {
		Element.loadAndClick(orderingWithRequisitionFormLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Ordering with a Requisition Form' or (-) sign under 'Convenient ordering processes that work with your workflow' title.");
	}

	public void clickOnOrderingThroughEpicCareLink() {
		Element.loadAndClick(orderingThroughEpicCareLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Ordering through EpicCare® LinkTM' or (-) sign under 'Convenient ordering processes that work with your workflow' title.");
	}

	/**
	 * @param Verify the expansion of accordions on page
	 * @return
	 */
	public boolean isAccordionContentExpanded(int resultLinkIndex) {
		By resultLinksSelectorBy = By.xpath(oglPagesProperties.getProperty("accordionItemBy"));
		List<WebElement> elements = Element.getMultiple(resultLinksSelectorBy);
		return Element.isElementDisplayed(elements.get(resultLinkIndex));

	}

	public void clickOnEpicCareLink() {
		Sleeper.sleepTightInSeconds(2);
		Element.loadAndClick(epicCareLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'EpicCare® LinkTM'");
	}

	public void clickOnTheResoucePageLink() {
		Element.loadAndClick(theResourcePageLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'the Resource Page' Link");
	}

	public void clickOnSeeOrderSuppliesSectionLink() {
		Element.loadAndClick(seeOrderSuppliesSectionLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'See the Order Supplies section for more details' Link");
	}

}
