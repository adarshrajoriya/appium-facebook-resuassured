package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.sys.DriverManager;
import exact.util.BasicUtils;
import exact.util.Sleeper;

public class OglEducationPage extends ExactNavNavigation {

	private final By readWhitePaperLink = By.cssSelector(oglPagesProperties.getProperty("readWhitePaperLink"));

	private final By enquiryFormBy = By.xpath(oglPagesProperties.getProperty("enquiryFormSelector"));
	private final By webinarsWhitePapersMoreHeadingBy = By
			.cssSelector(oglPagesProperties.getProperty("webinarsWhitePapersMoreHeadingBy"));
	private final By publicationsHeadingBy = By.cssSelector(oglPagesProperties.getProperty("publicationsHeadingBy"));
	private final By blogInsightsHeadingBy = By.cssSelector(oglPagesProperties.getProperty("blogInsightsHeadingBy"));
	private final By hepatocellularCarcinomaSurveillanceHeadingBy = By
			.cssSelector(oglPagesProperties.getProperty("hepatocellularCarcinomaSurveillanceHeadingBy"));
	private final By viewAllButtonBy = By.xpath(oglPagesProperties.getProperty("viewAllButtonBy"));
	private final By cardsUnderWebinarsWhitePapersMoreTitleBy = By
			.xpath(oglPagesProperties.getProperty("cardsUnderWebinarsWhitePapersMoreTitleBy"));
	private final By signUpButtonButtonBy = By.cssSelector(oglPagesProperties.getProperty("signUpButtonButtonBy"));
	private final By emailFieldWebinarBy = By.cssSelector(oglPagesProperties.getProperty("emailFieldWebinarBy"));
	private final By subscribingMessageBy = By.cssSelector(oglPagesProperties.getProperty("subscribingMessageBy"));
	private final By publicationTitleBy = By.cssSelector(oglPagesProperties.getProperty("publicationTitleBy"));
	private final By seeMoreLinkBy = By.xpath(oglPagesProperties.getProperty("seeMoreLinkBy"));
	private final By viewBlogButtonBy = By.xpath(oglPagesProperties.getProperty("viewBlogButtonBy"));
	private final By leftNavigationLearnMoreButtonButtonBy = By
			.cssSelector(oglPagesProperties.getProperty("leftNavigationLearnMoreButtonButtonBy"));
	private final By textLinksBy = By.cssSelector(oglPagesProperties.getProperty("textLinksBy"));
	private final String signUpdatesCardBy = oglPagesProperties.getProperty("signUpdatesCardBy");
	private final By notificationMessageBy = By.cssSelector(oglPagesProperties.getProperty("notificationMessageBy"));

	public void clickOnReadWhitePaperLink() {
		Element.loadAndClick(readWhitePaperLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'READ WHITE PAPER' link from the banner");

	}

	public boolean isEnquiryFormDisplayed() {
		Sleeper.sleepTightInSeconds(1);
		return Element.isElementDisplayed(enquiryFormBy);
	}

	public String getWebinarsWhitePapersMoreHeading() {
		return Element.getText(webinarsWhitePapersMoreHeadingBy);
	}

	public String getPublicationsHeading() {
		return Element.getText(publicationsHeadingBy);
	}

	public String getBlogInsightsHeading() {
		return Element.getText(blogInsightsHeadingBy);
	}

	/**
	 * @param Click    on cards present under "Webinars White Papers & More" Title
	 * @param linkText
	 */
	public void clickOnTheCardsUnderWebinarsWhitePapersMoreTitle(int resultLinkIndex, String linkText) {
		List<WebElement> elements = Element.getMultiple(cardsUnderWebinarsWhitePapersMoreTitleBy);
		Element.loadAndClick(elements.get(resultLinkIndex));
		Element.waitForDOMToLoad();
		logInfo("Clicked on the '" + linkText + "' card present under 'Webinars, White Papers & More' title.");

	}

	public String getHepatocellularCarcinomaSurveillanceHeading() {
		return Element.getText(hepatocellularCarcinomaSurveillanceHeadingBy);
	}

	public void clickOnViewAllButton() {
		Element.loadAndClick(viewAllButtonBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'VIEW ALL' button");

	}

	public void clickOnSignUpButton() {
		Element.loadAndClick(signUpButtonButtonBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'SIGN UP' button under sitecore form");

	}

	public void enterEmail(String email) {
		Element.enterText(emailFieldWebinarBy, email);
		logInfo("Entered Email '" + email + "'");
	}

	public boolean isSubscribingMessageDisplayed() {
		Element.waitForVisible(notificationMessageBy);
		return Element.isElementDisplayed(subscribingMessageBy);
	}

	/**
	 * @param Click on Publications cards on Page
	 * @throws Exception
	 */
	public void clickPublicationsCardsOnPage(String linkText) throws Exception {
		Element.waitForVisible(publicationTitleBy);
		List<WebElement> listElements = Element.getMultiple(publicationTitleBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(linkText)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + linkText + "' card");
				return;
			}
		}
		throw new Exception("Unable to find '" + linkText + "' card on the page. - " + BasicUtils.takeScreenshot());
	}

	public void clickOnSeeMoreLink() {
		Element.loadAndClick(seeMoreLinkBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'SEE MORE' links.");

	}

	public void clickOnViewBlogButton() {
		Element.loadAndClick(viewBlogButtonBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'VIEW BLOG' button.");

	}

	public void clickOnLeftNavigationLearnMoreButton() {
		Element.loadAndClick(leftNavigationLearnMoreButtonButtonBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on LEARN MORE>' button from 'Be part of HCC surveillance research' card present under left navigation bar.");

	}

	public void clickOnSignUpdatesCard() {
		((JavascriptExecutor) DriverManager.getCurrent())
				.executeScript("document.querySelector(arguments[0],':before').click();", signUpdatesCardBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Sign Up For Updates' card under left navigation bar");
	}

	/**
	 * @param Click on a tag links present on Page
	 * @throws Exception
	 */
	public void clickTextLinksOnPage(String linkText) throws Exception {
		Element.waitForVisible(textLinksBy);
		List<WebElement> listElements = Element.getMultiple(textLinksBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(linkText)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + linkText + "' link");
				return;
			}
		}
		throw new Exception("Unable to find '" + linkText + "' link on the page. - " + BasicUtils.takeScreenshot());
	}

}
