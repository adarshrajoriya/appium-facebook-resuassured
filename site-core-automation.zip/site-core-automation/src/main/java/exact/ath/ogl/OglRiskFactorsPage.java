package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OglRiskFactorsPage extends ExactNavNavigation {

	private final By surveillanceLink = By.cssSelector(oglPagesProperties.getProperty("surveillanceLink"));
	private final By americanLiverFoundationLink = By
			.cssSelector(oglPagesProperties.getProperty("americanLiverFoundationLink"));

	public void clickOnSurveillanceLink() {
		Element.loadAndClick(surveillanceLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Surveillance' Link");

	}

	public void clickOnAmericanLiverFoundationLink() {
		Element.loadAndClick(americanLiverFoundationLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'American Liver Foundation' Link");

	}

}
