package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OglAddingToWorkflowPage extends ExactNavNavigation {

	private final By phoneLinkUnderLetUsHelpTitleBy = By
			.cssSelector(oglPagesProperties.getProperty("phoneLinkUnderLetUsHelpTitleSelector"));

	private final By fillFormLinkBy = By.xpath(oglPagesProperties.getProperty("fillFormLinkSelector"));

	public boolean isPhoneLinkUnderLetUsHelpTitleDisplayed() {
		return Element.isElementDisplayed(phoneLinkUnderLetUsHelpTitleBy);
	}

	public void clickOnFillFormLink() {
		Element.loadAndClick(fillFormLinkBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'fill out a form' link under 'Let us help you get started' title");
	}

}
