package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class OglWebinarPage extends ExactNavNavigation {

	private final By downloadNowLinkBy = By.xpath(oglPagesProperties.getProperty("downloadNowLinkBy"));
	private final By listOfCardsBy = By.xpath(oglPagesProperties.getProperty("listOfCardsBy"));
	private final By titleBy = By.cssSelector(oglPagesProperties.getProperty("titleBy"));

	public boolean isListOfCardsDisplayed() {
		return Element.isElementDisplayed(listOfCardsBy);
	}

	public void clickOnDownloadNowLink() {
		Element.waitForVisible(downloadNowLinkBy);
		Element.loadAndClick(downloadNowLinkBy);
		Element.waitForDOMToLoad();

	}

	/**
	 * @param Click on Webinar cards on Page
	 * @throws Exception
	 */
	public void clickCardsOnPage(String linkText) throws Exception {
		Element.waitForVisible(titleBy);
		List<WebElement> listElements = Element.getMultiple(titleBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(linkText)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + linkText + "' card");
				return;
			}
		}
		throw new Exception("Unable to find '" + linkText + "' card on the page. - " + BasicUtils.takeScreenshot());
	}

}
