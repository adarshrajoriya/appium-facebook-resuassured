package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;
import exact.util.Sleeper;

public class OglOverviewPage extends ExactNavNavigation {

	private final By advancedPerformanceYouCanRelyOnHeading = By
			.cssSelector(oglPagesProperties.getProperty("advancedPerformanceYouCanRelyOnHeading"));
	private final By innovationWithoutInconvenienceHeading = By
			.cssSelector(oglPagesProperties.getProperty("innovationWithoutInconvenienceHeading"));
	private final By supportDrivesAdherenceHeading = By
			.cssSelector(oglPagesProperties.getProperty("supportDrivesAdherenceHeading"));
	private final By learnMoreUnderOncoguardSolutionBy = By
			.xpath(oglPagesProperties.getProperty("learnMoreUnderOncoguardSolutionSelector"));

	private final By bannerItemOverviewPageBy = By
			.cssSelector(oglPagesProperties.getProperty("bannerItemOverviewPageBy"));

	public String getAdvancedPerformanceYouCanRelyOnHeading() {
		return Element.getText(advancedPerformanceYouCanRelyOnHeading);
	}

	public String getInnovationWithoutInconvenienceHeading() {
		return Element.getText(innovationWithoutInconvenienceHeading);
	}

	public String getSupportDrivesAdherenceHeading() {
		return Element.getText(supportDrivesAdherenceHeading);
	}

	public void clickOnLearnMoreUnderOncoguardSolution() {
		Element.loadAndClick(learnMoreUnderOncoguardSolutionBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'LEARN MORE' button under 'The Oncoguard Liver solution. Exactly what's needed today.' title");
	}

	/**
	 * @param Click on Banner Items of OverviewPage
	 * @throws Exception
	 */
	public void clickBannerItemOverviewPage(String itemLabel) throws Exception {
		Sleeper.sleepTightInSeconds(1);
		Element.waitForVisible(bannerItemOverviewPageBy);
		List<WebElement> listElements = Element.getMultiple(bannerItemOverviewPageBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + itemLabel + "' banner item");
				return;
			}
		}
		throw new Exception("Unable to find '" + itemLabel + "' option in the banner below slides. - "
				+ BasicUtils.takeScreenshot());
	}

	/**
	 * @param Verify the Banner Items of OverviewPage
	 * @return
	 */
	public boolean isBannerItemDisplayed(String itemLabel) {
		List<WebElement> listElements = Element.getMultiple(bannerItemOverviewPageBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				return true;
			}
		}
		return false;
	}

}
