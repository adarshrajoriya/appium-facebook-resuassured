package exact.ath.ogl;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OglClinicalPerformancePage extends ExactNavNavigation {

	private final By learnMoreAboutClinicalTrialsButtonBy = By
			.xpath(oglPagesProperties.getProperty("learnMoreAboutClinicalTrialsButtonSelector"));

	public void clickLearnMoreAboutClinicalTrialsButton() {
		Element.loadAndClick(learnMoreAboutClinicalTrialsButtonBy);
		Element.waitForDOMToLoad();

	}

}
