package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class OglResourcePage extends ExactNavNavigation {

	private final By fieldLinksResourceBy = By.cssSelector(oglPagesProperties.getProperty("fieldLinksResourceBy"));
	private final By orderSuppliesOncoguardLiverTestHeadingBy = By
			.cssSelector(oglPagesProperties.getProperty("orderSuppliesOncoguardLiverTestHeadingBy"));
	private final By downloadFormsHereHeadingBy = By
			.cssSelector(oglPagesProperties.getProperty("downloadFormsHereHeadingBy"));
	private final By specimenCollectionOncoguardLiverTestHeadingBy = By
			.cssSelector(oglPagesProperties.getProperty("specimenCollectionOncoguardLiverTestHeadingBy"));
	private final By implementingOncoguardLiverTestingPracticeHeadingBy = By
			.cssSelector(oglPagesProperties.getProperty("implementingOncoguardLiverTestingPracticeHeadingBy"));
	private final By epicCareLinkHeadingBy = By.cssSelector(oglPagesProperties.getProperty("epicCareLinkHeadingBy"));
	private final By cardsUnderDownloadTheFormsHereTitleBy = By
			.xpath(oglPagesProperties.getProperty("cardsUnderDownloadTheFormsHereTitleBy"));
	private final By learnMoreButtonInAdvocacyPageBy = By
			.xpath(oglPagesProperties.getProperty("learnMoreButtonInAdvocacyPageBy"));
	private final By bannerItemResouceBy = By.cssSelector(oglPagesProperties.getProperty("bannerItemResouceBy"));
	private final By playSpecimenCollectionVideoLinkBy = By
			.cssSelector(oglPagesProperties.getProperty("playSpecimenCollectionVideoLinkBy"));
	private final By playSpecimenCollectionVideoCloseButtonBy = By
			.cssSelector(oglPagesProperties.getProperty("playSpecimenCollectionVideoCloseButtonBy"));

	/**
	 * @param Click on Links present on Page
	 * @throws Exception
	 */
	public void clickResourceLink(String resourceLinkText) throws Exception {
		List<WebElement> listElements = Element.getMultiple(fieldLinksResourceBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(resourceLinkText)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + resourceLinkText + "' link");
				return;
			}
		}
		throw new Exception(
				"Unable to find '" + resourceLinkText + "' link on the page. - " + BasicUtils.takeScreenshot());
	}

	public String getOrderSuppliesOncoguardLiverTestHeading() {
		Element.waitForVisible(orderSuppliesOncoguardLiverTestHeadingBy);
		return Element.getElementText(orderSuppliesOncoguardLiverTestHeadingBy);
	}

	/**
	 * @param Verify the links of Resource Page
	 * @return
	 */
	public boolean isLinksOnPageDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(fieldLinksResourceBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public String getdownloadFormsHereHeading() {
		Element.waitForVisible(downloadFormsHereHeadingBy);
		return Element.getElementText(downloadFormsHereHeadingBy);
	}

	/**
	 * @param Click    on Icon Cards Under Download The Forms Here Title
	 * @param linkText
	 */
	public void clickOnIconCardsUnderDownloadTheFormsHereTitle(int resultLinkIndex, String linkText) {
		List<WebElement> elements = Element.getMultiple(cardsUnderDownloadTheFormsHereTitleBy);
		Element.loadAndClick(elements.get(resultLinkIndex));
		Element.waitForDOMToLoad();
		logInfo("Clicked on the '" + linkText + "' card present under 'Download the forms you need here' title.");

	}

	public String getSpecimenCollectionOncoguardLiverTestHeading() {
		Element.waitForVisible(specimenCollectionOncoguardLiverTestHeadingBy);
		return Element.getElementText(specimenCollectionOncoguardLiverTestHeadingBy);
	}

	public String getImplementingOncoguardLiverTestingPracticeHeading() {
		Element.waitForVisible(implementingOncoguardLiverTestingPracticeHeadingBy);
		return Element.getElementText(implementingOncoguardLiverTestingPracticeHeadingBy);
	}

	public String getEpicCareLinkHeading() {
		Element.waitForVisible(epicCareLinkHeadingBy);
		return Element.getElementText(epicCareLinkHeadingBy);
	}

	/**
	 * @param Click    on Learn More Button of Advocacy Page
	 * @param linkText
	 */
	public void clickOnLearnMoreButtonInAdvocacyPage(int resultLinkIndex, String linkText) {
		List<WebElement> elements = Element.getMultiple(learnMoreButtonInAdvocacyPageBy);
		Element.loadAndClick(elements.get(resultLinkIndex));
		Element.waitForDOMToLoad();
		logInfo("Clicked on the Learn More Button under '" + linkText + "'");

	}

	/**
	 * @param Click on Banner Items of Page
	 * @throws Exception
	 */
	public void clickBannerItemResource(String itemLabel) throws Exception {
		List<WebElement> listElements = Element.getMultiple(bannerItemResouceBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + itemLabel + "' banner item");
				return;
			}
		}
		throw new Exception("Unable to find '" + itemLabel + "' option in the banner below slides. - "
				+ BasicUtils.takeScreenshot());
	}

	public void clickOnPlaySpecimenCollectionVideoLink() {
		Element.loadAndClick(playSpecimenCollectionVideoLinkBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Play Specimen Collection' Video Link");
	}

	public void clickOnPlaySpecimenCollectionVideoCloseButton() {
		Element.loadAndClick(playSpecimenCollectionVideoCloseButtonBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on Closed Button");
	}

}
