package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.BasicUtils;

public class OglHomepage extends ExactNavNavigation {

	private final By pageHeadingDisplayedOglHomePage = By
			.cssSelector(oglPagesProperties.getProperty("pageHeadingDisplayedOglHomePage"));
	private final By exactlyWhatsNeededTodayButtonBy = By
			.cssSelector(oglPagesProperties.getProperty("exactlyWhatsNeededTodayButtonSelector"));

	private final By signUpForInformationCard = By
			.cssSelector(oglPagesProperties.getProperty("signUpForInformationCardSelector"));
	private final By oglHompageSubOptionsBy = By.cssSelector(oglPagesProperties.getProperty("oglHompageSubOptionsBy"));
	private final By bannerItemHomePageBy = By.cssSelector(oglPagesProperties.getProperty("bannerItemHomePageBy"));

	private final By learnMoreButtonUnderTitlesBy = By
			.xpath(oglPagesProperties.getProperty("learnMoreButtonUnderTitles"));
	private final By footerBy = By.cssSelector(oglPagesProperties.getProperty("footerBy"));
	private final By exactSciencesLogoBy = By.cssSelector(oglPagesProperties.getProperty("exactSciencesLogoBy"));
	private final By addressDetailsBy = By.cssSelector(oglPagesProperties.getProperty("addressDetailsBy"));
	private final By contactUsHyperLinkBy = By.cssSelector(oglPagesProperties.getProperty("contactUsHyperLinkBy"));
	private final By fieldLinksFooterBy = By.cssSelector(oglPagesProperties.getProperty("fieldLinksFooterBy"));
	private final By videoBelowJumpSectionBy = By
			.cssSelector(oglPagesProperties.getProperty("videoBelowJumpSectionBy"));
	private final By videoTimeSelectorBy = By.cssSelector(oglPagesProperties.getProperty("videoTimeSelectorBy"));
	private final By playBarSelectorBy = By.cssSelector(oglPagesProperties.getProperty("playBarSelectorBy"));

	public String getPageHeadingDisplayedOglHomePage() {
		return Element.getText(pageHeadingDisplayedOglHomePage);
	}

	public void clickExactlyWhatsNeededTodayButton() {
		Element.loadAndClick(exactlyWhatsNeededTodayButtonBy);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'EXACTLY WHAT'S NEEDED TODAY' under the 'A solution for early HCC detection? Exactly.'");
	}

	/**
	 * @param Verify Menu Options
	 * @return
	 */
	public boolean isHeaderOptionDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(oglHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	public boolean isSignUpForInformationCardDisplayed() {
		return Element.isElementDisplayed(signUpForInformationCard);
	}

	/**
	 * @param To       click on Learn More Buttons present on page.
	 * @param linkText
	 */
	public void clickLearnMoreButtonUnderTitles(int resultLinkIndex, String linkText) {
		List<WebElement> elements = Element.getMultiple(learnMoreButtonUnderTitlesBy);
		Element.loadAndClick(elements.get(resultLinkIndex));
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Learn More Button' Under '" + linkText + "' Title");

	}

	/**
	 * Click on Menu Options
	 */
	public void clickTopNavOption(String option) {
		List<WebElement> listElements = Element.getMultiple(oglHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(option)) {
				Element.loadAndClick(webElement);
				break;
			}
		}
		Element.waitForDOMToLoad();
		logInfo("Clicked on '" + option + "' Option");
	}

	/**
	 * @param Verify Sub Menu Options
	 * @return
	 */
	public boolean isSubItemDisplayed(String optionLabel) {
		List<WebElement> listElements = Element.getMultiple(oglHompageSubOptionsBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(optionLabel)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Click on Sub Menu Options
	 * 
	 * @throws Exception
	 */
	public void clickSubItemOption(String option) throws Exception {
		List<WebElement> listElements = Element.getMultiple(oglHompageSubOptionsBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(option)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + option + "' Option");
				return;
			}
		}
		throw new Exception(
				"Unable to find '" + option + "' option in the banner below slides. - " + BasicUtils.takeScreenshot());

	}

	/**
	 * Hover over Menu Options
	 * 
	 * @throws Exception
	 */
	public void hoverTopNavOption(String option) throws Exception {
		List<WebElement> listElements = Element.getMultiple(oglHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(option)) {
				Element.mouseHover(webElement);
				Element.waitForDOMToLoad();
				logInfo("Hover on '" + option + "' Option");
				return;
			}
		}

		throw new Exception(
				"Unable to hover '" + option + "' option in the banner below slides. - " + BasicUtils.takeScreenshot());

	}

	/**
	 * @param Click on Banner Items of Page
	 * @throws Exception
	 */
	public void clickBannerItemHomePage(String itemLabel) throws Exception {
		List<WebElement> listElements = Element.getMultiple(bannerItemHomePageBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + itemLabel + "' banner item");
				return;
			}
		}
		throw new Exception("Unable to find '" + itemLabel + "' option in the banner below slides. - "
				+ BasicUtils.takeScreenshot());
	}

	/**
	 * @param Verify the Banner Items of Page
	 * @return
	 */
	public boolean isBannerItemDisplayed(String itemLabel) {
		List<WebElement> listElements = Element.getMultiple(bannerItemHomePageBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(itemLabel)) {
				return true;
			}
		}
		return false;
	}

	public boolean isFooterDisplayed() {
		return Element.isElementPresent(footerBy);
	}

	public boolean isExactSciencesLogoDisplayed() {
		return Element.isElementDisplayed(exactSciencesLogoBy);
	}

	public boolean isAddressDetailsDisplayed() {
		return Element.isElementDisplayed(addressDetailsBy);
	}

	public boolean isContactUsHyperLinkDisplayed() {
		return Element.isElementDisplayed(contactUsHyperLinkBy);
	}

	/**
	 * @param Click on Footer Links
	 * @throws Exception
	 */
	public void clickFooterLink(String footerLinkText) throws Exception {
		Element.waitForVisible(fieldLinksFooterBy);
		List<WebElement> listElements = Element.getMultiple(fieldLinksFooterBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(footerLinkText)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + footerLinkText + "' link");
				return;
			}
		}
		throw new Exception(
				"Unable to find '" + footerLinkText + "' link on the page. - " + BasicUtils.takeScreenshot());
	}

	public OglHomepage clickVideoBelowJumpSection() {
		Element.loadAndClick(videoBelowJumpSectionBy);
		return this;
	}

	public String getVideoTime() {
		Element.mouseClickAndHold(videoBelowJumpSectionBy);
		Element.waitForVisible(playBarSelectorBy);
		return Element.getElementText(videoTimeSelectorBy);
	}

}
