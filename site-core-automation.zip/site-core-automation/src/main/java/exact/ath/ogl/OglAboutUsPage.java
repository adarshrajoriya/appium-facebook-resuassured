package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class OglAboutUsPage extends ExactNavNavigation {

	private final By oncoguardLiverSolutionLink = By
			.cssSelector(oglPagesProperties.getProperty("oncoguardLiverSolutionLink"));

	public void clickOnOncoguardLiverSolutionLink() {
		Element.loadAndClick(oncoguardLiverSolutionLink);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Oncoguard Liver Solution Link'");

	}

}
