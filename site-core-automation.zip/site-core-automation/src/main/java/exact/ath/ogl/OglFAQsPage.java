package exact.ath.ogl;

import static exact.ReportLogMain.logInfo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.util.Sleeper;

public class OglFAQsPage extends ExactNavNavigation {

	private final By searchInputFieldBy = By.xpath(oglPagesProperties.getProperty("searchInputFieldSelector"));
	private final By searchResultsBy = By.cssSelector(oglPagesProperties.getProperty("searchResultsBy"));
	private final By openAllQuestionsBy = By.xpath(oglPagesProperties.getProperty("openAllQuestionsBy"));
	private final By closeAllQuestionsBy = By.xpath(oglPagesProperties.getProperty("closeAllQuestionsBy"));
	private final By accordionItemsBy = By.cssSelector(oglPagesProperties.getProperty("accordionItemsSelector"));
	private final By collapseAccordionItemsBy = By
			.cssSelector(oglPagesProperties.getProperty("collapseAccordionItemsSelector"));

	public OglFAQsPage enterInputInSearchBox(String username) {
		Element.enterText((searchInputFieldBy), username);
		Sleeper.sleepTightInSeconds(2);
		logInfo("Searched for text '" + username + "' on FAQs page");
		return this;

	}

	public String getFirstSearchResult() {
		return Element.getText(searchResultsBy);
	}

	public void clickOpenAllQuestions() {
		Element.waitForVisible(openAllQuestionsBy);
		Element.loadAndClick(openAllQuestionsBy);
		Sleeper.sleepTightInSeconds(2);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Open All' Quesions");
	}

	public void clickCloseAllQuestions() {
		Element.waitForVisible(closeAllQuestionsBy);
		Element.loadAndClick(closeAllQuestionsBy);
		Sleeper.sleepTightInSeconds(2);
		Element.waitForDOMToLoad();
		logInfo("Clicked on 'Close All' Quesions");
	}

	public boolean areAllQuestionsExpanded() {
		return !getAccordionResultsStatus().contains(false);
	}

	public boolean areAllQuestionsCollapsed() {
		return !getAccordionResultsStatus().contains(true);
	}

	private List<Boolean> getAccordionResultsStatus() {
		List<WebElement> items = Element.getMultiple(accordionItemsBy);
		List<Boolean> results = new ArrayList<>();

		for (WebElement webElement : items) {
			if (webElement.getAttribute("class").contains("active")) {
				results.add(true);
			} else {
				results.add(false);
			}
		}
		return results;
	}

	public void expandAllAccordionsOneByOne() {
		List<WebElement> items = Element.getMultiple(accordionItemsBy);
		for (WebElement webElement : items) {
			Element.loadAndClick(webElement);
			Sleeper.sleepTightInSeconds(2);
			Element.waitForDOMToLoad();
		}
	}

	public void collapseAllAccordionsOneByOne() {
		List<WebElement> items = Element.getMultiple(collapseAccordionItemsBy);
		for (WebElement webElement : items) {
			Element.loadAndClick(webElement);
			Sleeper.sleepTightInSeconds(2);
			Element.waitForDOMToLoad();

		}

	}

}
