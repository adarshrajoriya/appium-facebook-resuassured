package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteBillingAndCoveragePage extends ExactNavNavigation {

	private final By goToCostCoverageForPatientsLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("GoToCostCoverageForPatientsLink"));
	private final By costCoverageLearnMoreLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("CostCoverageLearnMoreLink"));
	private final By financialAssistanceDisclosureAndApplicationFormLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("FinancialAssistanceDisclosureAndApplicationFormLink"));
	private final By spanishLinkBy = By.cssSelector(productsitePagesProperties.getProperty("SpanishLink"));
	private final By backButtonBy = By.cssSelector(productsitePagesProperties.getProperty("BackButton"));
	private final By financialAssistanceFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("FinancialAssistanceForm"));
	private final By oNCOTYPE8886626897LinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("ONCOTYPE8886626897Link"));
	private final By providerPortalLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("ProviderPortalLink"));
	private final By seeTheSpecificCoverageCriteriaForEachTestLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("SeeTheSpecificCoverageCriteriaForEachTest"));
	private final By download14DayRuleProviderGuideLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("Download14DayRuleProviderGuide"));
	private final By gAPBrochureLinkBy = By.cssSelector(productsitePagesProperties.getProperty("GAPBrochureLink"));
	private final By dayRuleLinkBy = By.cssSelector(productsitePagesProperties.getProperty("DayRuleLink"));
	private final By downloadInOtherLanguageSpanishLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("DownloadInOtherLanguageSpanishLink"));
	private final By downloadInOtherLanguageTraditionalChineseLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("DownloadInOtherLanguageTraditionalChineseLink"));

	private final By downloadInOtherLanguageSimplifiedChineseLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("DownloadInOtherLanguageSimplifiedChineseLink"));
	private final By medicareCoverageCriteriaForEachTestSectionHeadingBy = By
			.cssSelector(productsitePagesProperties.getProperty("MedicareCoverageCriteriaForEachTestSectionHeading"));

	public void clicGoToCostCoverageForPatientsLink() {
		Element.loadAndClick(goToCostCoverageForPatientsLinkBy);
		logInfo("Clicked on 'Go to Cost & Coverage for Patients' link");
	}

	public void clicLearnMoreLink() {
		Element.loadAndClick(costCoverageLearnMoreLinkBy);
		logInfo("Clicked on 'Learn More' link");
	}

	public void clickFinancialAssistanceDisclosureAndApplicationFormLink() {
		Element.loadAndClick(financialAssistanceDisclosureAndApplicationFormLinkBy);
		logInfo("Clicked on 'Financial Assistance Disclosure and Application Form' link");
	}

	public void clickSpanishLink() {
		Element.loadAndClick(spanishLinkBy);
		logInfo("Clicked on 'Spanish' link");
	}

	public void clickBackButton() {
		Element.loadAndClick(backButtonBy);
		logInfo("Clicked on 'Back' button");
	}

	public boolean isFinancialAssistanceFormDisplayed() {
		return Element.isElementDisplayed(financialAssistanceFormBy);
	}

	public boolean isONCOTYPE8886626897LinkDisplayed() {
		return Element.isElementDisplayed(oNCOTYPE8886626897LinkBy);
	}

	public void clickProviderPortalLink() {
		Element.loadAndClick(providerPortalLinkBy);
		logInfo("Clicked on 'Provider Portal' link");
	}

	public void clickSeeTheSpecificCoverageCriteriaForEachTestLink() {
		Element.loadAndClick(seeTheSpecificCoverageCriteriaForEachTestLinkBy);
		logInfo("Clicked on 'See the specific coverage criteria for each test' link");
	}

	public void clickDownload14DayRuleProviderGuideLink() {
		Element.loadAndClick(download14DayRuleProviderGuideLinkBy);
		logInfo("Clicked on 'Download 14-Day Rule Provider Guide' link");
	}

	public void clickGAPBrochureLink() {
		Element.loadAndClick(gAPBrochureLinkBy);
		logInfo("Clicked on 'GAP Brochure' link");
	}

	public void click14DayRuleLink() {
		Element.loadAndClick(dayRuleLinkBy);
		logInfo("Clicked on '14-Day Rule' link");
	}

	public void clickDownloadInOtherLanguageSpanishLink() {
		Element.loadAndClick(downloadInOtherLanguageSpanishLinkBy);
		logInfo("Clicked on 'Download In Other Language Spanish' link");
	}

	public void clickDownloadInOtherLanguageTraditionalChineseLink() {
		Element.loadAndClick(downloadInOtherLanguageTraditionalChineseLinkBy);
		logInfo("Clicked on 'Download In Other Language Traditional Chinese' link");
	}

	public void clickDownloadInOtherLanguageSimplifiedChineseLink() {
		Element.loadAndClick(downloadInOtherLanguageSimplifiedChineseLinkBy);
		logInfo("Clicked on 'Download In Other Language Simplified Chinese' link");
	}

	public void clickMedicareCoverageCriteriaForEachTestSections(String section) {
		By medicareCoverageCriteriaForEachTestSectionsBy = By.xpath(
				productsitePagesProperties.getProperty("MedicareCoverageCriteriaForEachTestSections") + section + "']");
		Element.loadAndClick(medicareCoverageCriteriaForEachTestSectionsBy);
		logInfo("Clicked on '" + section + "' Under Medicare Coverage Criteria for Each Test");
	}

	public String getMedicareCoverageCriteriaForEachTestSectionHeading() {
		return Element.getElementText(medicareCoverageCriteriaForEachTestSectionHeadingBy);
	}

}
