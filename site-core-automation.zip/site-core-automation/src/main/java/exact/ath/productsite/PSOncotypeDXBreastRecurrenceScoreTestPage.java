package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class PSOncotypeDXBreastRecurrenceScoreTestPage extends ExactNavNavigation {

	private final By readTheGroundbreakingResultsBy = By
			.xpath(productsitePagesProperties.getProperty("ReadTheGroundbreakingResults"));
	private final By seeHowToOrderBy = By.xpath(productsitePagesProperties.getProperty("SeeHowToOrder"));
	private final By contactUsUnderOrangeBannerBy = By
			.xpath(productsitePagesProperties.getProperty("ContactUsUnderOrangeBanner"));
	private final By referencesAccordionBy = By
			.cssSelector(productsitePagesProperties.getProperty("ReferencesAccordion"));
	private final By referencesAccordionExpandBy = By
			.xpath(productsitePagesProperties.getProperty("ReferencesAccordionExpand"));
	private final By whatItMeansForTheOncotypeDXBreastRecurrenceScoretestBy = By
			.xpath(productsitePagesProperties.getProperty("WhatItMeansForTheOncotypeDXBreastRecurrenceScoretest"));
	private final By viewPublicationLinkBy = By.xpath(productsitePagesProperties.getProperty("ViewPublicationLink"));
	private final By viewClinicalUtilityInTheLocoregionalLinkBy = By
			.xpath(productsitePagesProperties.getProperty("ViewClinicalUtilityInTheLocoregionalLink"));
	private final By exploreClinicalEvidenceLinkBy = By
			.xpath(productsitePagesProperties.getProperty("ExploreClinicalEvidenceLink"));
	private final By hereHowToOrderBy = By.xpath(productsitePagesProperties.getProperty("HereHowToOrder"));
	private final By tailorxLinkBy = By.xpath(productsitePagesProperties.getProperty("TailorxLink"));
	private final By ascoGuidelinesLinkBy = By.xpath(productsitePagesProperties.getProperty("AscoGuidelinesLink"));
	private final By gapAndBillingBrochureLinkBy = By
			.xpath(productsitePagesProperties.getProperty("GapAndBillingBrochureLink"));
	private final By pathologyGuidelinesLinkBy = By
			.xpath(productsitePagesProperties.getProperty("PathologyGuidelinesLink"));
	private final By oncotypeDXBreastRecurrenceScoreRequisitionFormLinkBy = By
			.xpath(productsitePagesProperties.getProperty("OncotypeDXBreastRecurrenceScoreRequisitionFormLink"));
	private final By learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkOncotypeDXBreastRecurrenceScoreBy = By
			.xpath(productsitePagesProperties.getProperty(
					"LearnAboutCostsCoverageAndHowExactSciencesCanHelpLinkOncotypeDXBreastRecurrenceScore"));
	private final By downloadTheGenomicAccessProgramGuideButtonBy = By
			.xpath(productsitePagesProperties.getProperty("DownloadTheGenomicAccessProgramGuideButton"));
	private final By tailorxVideoPlayButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("TailorxVideoPlayButton"));
	private final By tailorxFrameBy = By.cssSelector(productsitePagesProperties.getProperty("TailorxFrame"));

	public void clickBannerTabs(String bannerTabName) {
		By bannerTabsBy = By.xpath(productsitePagesProperties.getProperty("BannerTabs") + bannerTabName + "']");
		Element.loadAndClick(bannerTabsBy);
		logInfo("Clicked on '" + bannerTabName + "' banner tab");
	}

	public boolean isBannerTabOpen(String bannerTabName) {
		By bannerTabsOpenBy = By.xpath(productsitePagesProperties.getProperty("BannerTabsOpen") + bannerTabName + "']");
		return Element.isElementDisplayed(bannerTabsOpenBy);
	}

	public void clickOnLinks(String linkname) {
		By oncotypeDXBreastRecurrenceScoreTestPageLinkBy = By
				.xpath(productsitePagesProperties.getProperty("BannerTabs") + linkname + "']");
		Element.loadAndClick(oncotypeDXBreastRecurrenceScoreTestPageLinkBy);
		logInfo("Clicked on '" + linkname + "' link");
	}

	public void clickReadTheGroundbreakingResults() {
		Element.loadAndClick(readTheGroundbreakingResultsBy);
		logInfo("Clicked on 'Read The Groundbreaking Results' link");
	}

	public void clickSeeHowToOrder() {
		Element.loadAndClick(seeHowToOrderBy);
		logInfo("Clicked on 'See how to order' link");
	}

	public void clickOnContactUsUnderOrangeBanner() {
		Element.waitForVisible(contactUsUnderOrangeBannerBy);
		Element.loadAndClick(contactUsUnderOrangeBannerBy);
		logInfo("Clicked on 'Contact us' button");
	}

	public void clickReferencesAccordion() {
		Element.loadAndClick(referencesAccordionBy);
		logInfo("Clicked on 'References' Accordion");
	}

	public boolean isReferencesAccordionExpand() {
		return Element.isElementDisplayed(referencesAccordionExpandBy);
	}

	public boolean isClinicalEvidenceCardDisplayed(String clinicalEvidenceCardName) {
		By clinicalEvidenceCardBy = By.xpath(
				productsitePagesProperties.getProperty("ClinicalEvidenceCard") + clinicalEvidenceCardName + "']");
		return Element.isElementDisplayed(clinicalEvidenceCardBy);
	}

	public void clickOnClinicalEvidenceCard(String clinicalEvidenceCardName) {
		By clinicalEvidenceCardBy = By.xpath(
				productsitePagesProperties.getProperty("ClinicalEvidenceCard") + clinicalEvidenceCardName + "']");
		Element.loadAndClick(clinicalEvidenceCardBy);
		logInfo("Clicked on '" + clinicalEvidenceCardName + "' card");
	}

	public boolean isClinicalEvidenceCardOpen(String clinicalEvidenceCardName) {
		By clinicalEvidenceCardOpenBy = By.xpath(
				productsitePagesProperties.getProperty("ClinicalEvidenceCardOpen") + clinicalEvidenceCardName + "']");
		return Element.isElementDisplayed(clinicalEvidenceCardOpenBy);
	}

	public void clickWhatItMeansForTheOncotypeDXBreastRecurrenceScoretest() {
		Element.loadAndClick(whatItMeansForTheOncotypeDXBreastRecurrenceScoretestBy);
		logInfo("Clicked on 'Watch Dr. Sharma and Dr. Pusztai talk about TAILORx and what it means for the Oncotype DX Breast Recurrence Score test' link");
	}

	public void clickViewPublicationLink() {
		Element.loadAndClick(viewPublicationLinkBy);
		logInfo("Clicked on 'View publication' link");
	}

	public void clickViewClinicalUtilityInTheLocoregionalLink() {
		Element.loadAndClick(viewClinicalUtilityInTheLocoregionalLinkBy);
		logInfo("Clicked on 'View clinical utility in the locoregional and late-recurrence setting ' link");
	}

	public void clickExploreClinicalEvidenceLink() {
		Element.loadAndClick(exploreClinicalEvidenceLinkBy);
		logInfo("Clicked on 'Explore clinical evidence' link");
	}

	public void clickHereHowToOrder() {
		Element.loadAndClick(hereHowToOrderBy);
		logInfo("Clicked on 'Here's how to order' link");
	}

	public void clickTailorxLink() {
		Element.loadAndClick(tailorxLinkBy);
		logInfo("Clicked on 'TAILORx' link");
	}

	public void clickAscoGuidelinesLink() {
		Element.loadAndClick(ascoGuidelinesLinkBy);
		logInfo("Clicked on 'ASCO Guidelines' link");
	}

	public void clickGapAndBillingBrochureLink() {
		Element.loadAndClick(gapAndBillingBrochureLinkBy);
		logInfo("Clicked on 'GAP and Billing Brochure' link");
	}

	public void clickPathologyGuidelinesLink() {
		Element.loadAndClick(pathologyGuidelinesLinkBy);
		logInfo("Clicked on 'Pathology Guidelines' link");
	}

	public void clickOncotypeDXBreastRecurrenceScoreRequisitionFormLink() {
		Element.loadAndClick(oncotypeDXBreastRecurrenceScoreRequisitionFormLinkBy);
		logInfo("Clicked on 'Oncotype DX Breast Recurrence Score Requisition Form' link");
	}

	public void clickHowToOrderPageButtons(String howToOrderPageButtonsName) {
		By howToOrderPageButtonsBy = By.xpath(
				productsitePagesProperties.getProperty("HowToOrderPageButtons") + howToOrderPageButtonsName + "']");
		Element.loadAndClick(howToOrderPageButtonsBy);
		logInfo("Clicked on '" + howToOrderPageButtonsName + "' button");
	}

	public void clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpLink() {
		Element.loadAndClick(learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkOncotypeDXBreastRecurrenceScoreBy);
		logInfo("Clicked on 'Learn about costs, coverage, and how Exact Sciences can help' button");
	}

	public void clickDownloadTheGenomicAccessProgramGuideButton() {
		Element.loadAndClick(downloadTheGenomicAccessProgramGuideButtonBy);
		logInfo("Clicked on 'Download the Genomic Access Program guide' button");
	}

	public void clickOnTailorxVideoPlayButton() {
		driver.switchToFrame(tailorxFrameBy);
		Element.loadAndClick(tailorxVideoPlayButtonBy);
		logInfo("Clicked on Tailorx video play button");
	}

}
