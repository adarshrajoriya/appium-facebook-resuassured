package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class PSOncotypeDXColonRecurrenceScoreTestPage extends ExactNavNavigation {
	private final By overviewTabHighlightedBy = By
			.xpath(productsitePagesProperties.getProperty("OverviewTabHighlighted"));
	private final By exploreTheResultsBy = By.xpath(productsitePagesProperties.getProperty("ExploreTheResults"));
	private final By seeTheClinicalUtilityOfTheTestBy = By
			.xpath(productsitePagesProperties.getProperty("SeeTheClinicalUtilityOfTheTest"));
	private final By learnWhyColonRecurrenceScoreIsTheTestOfChoiceBy = By
			.xpath(productsitePagesProperties.getProperty("LearnWhyColonRecurrenceScoreIsTheTestOfChoice"));
	private final By seeHowToOrderColonBy = By.xpath(productsitePagesProperties.getProperty("SeeHowToOrderColon"));
	private final By viewMoreBillingAndCoverageDetailsColonBy = By
			.xpath(productsitePagesProperties.getProperty("ViewMoreBillingAndCoverageDetailsColon"));
	private final By viewStudyDetailsButtonBy = By
			.xpath(productsitePagesProperties.getProperty("ViewStudyDetailsButton"));
	private final By learnHowToReadTheTestResultsButtonBy = By
			.xpath(productsitePagesProperties.getProperty("LearnHowToReadTheTestResultsButton"));
	private final By downloadSampleStageIIIReportButtonBy = By
			.xpath(productsitePagesProperties.getProperty("DownloadSampleStageIIIReportButton"));
	private final By downloadSampleStageIIReportButtonBy = By
			.xpath(productsitePagesProperties.getProperty("DownloadSampleStageIIReportButton"));
	private final By orderTheTestNowButtonBy = By
			.xpath(productsitePagesProperties.getProperty("OrderTheTestNowButton"));

	public boolean isOverviewTabHighlighted() {
		return Element.isElementDisplayed(overviewTabHighlightedBy);
	}

	public void clickExploreTheResultsButton() {
		Element.loadAndClick(exploreTheResultsBy);
		logInfo("Clicked on 'Explore The Results' button");
	}

	public void clickSeeTheClinicalUtilityOfTheTestLink() {
		Element.loadAndClick(seeTheClinicalUtilityOfTheTestBy);
		logInfo("Clicked on 'See the clinical utility of the test' link");
	}

	public void clickLearnWhyColonRecurrenceScoreIsTheTestOfChoiceLink() {
		Element.loadAndClick(learnWhyColonRecurrenceScoreIsTheTestOfChoiceBy);
		logInfo("Clicked on 'Learn why Colon Recurrence Score is the test of choice' link");
	}

	public void clickSeeHowToOrderColonLink() {
		Element.loadAndClick(seeHowToOrderColonBy);
		logInfo("Clicked on 'See How to Order' link");
	}

	public void clickViewMoreBillingAndCoverageDetailsColonLink() {
		Element.loadAndClick(viewMoreBillingAndCoverageDetailsColonBy);
		logInfo("Clicked on 'View more billing and coverage details' link");
	}

	public void clickViewStudyDetailsButton() {
		Element.loadAndClick(viewStudyDetailsButtonBy);
		logInfo("Clicked on 'VIEW STUDY DETAILS' button");
	}

	public void clickViewStudyDetailsButtonsUnderClinicallyValidatedIn4Studies(String studyname) {
		By viewStudyDetailsButtonsUnderClinicallyValidatedIn4StudiesBy = By.cssSelector(
				productsitePagesProperties.getProperty("ViewStudyDetailsButtonsUnderClinicallyValidatedIn4Studies")
						+ studyname + "']");
		Element.loadAndClick(viewStudyDetailsButtonsUnderClinicallyValidatedIn4StudiesBy);
		logInfo("Clicked on '" + studyname + "' view study details link");
	}

	public void clickLearnHowToReadTheTestResultsButton() {
		Element.loadAndClick(learnHowToReadTheTestResultsButtonBy);
		logInfo("Clicked on 'Learn how to read the test results' button");
	}

	public void clickDownloadSampleStageIIIReportButton() {
		Element.loadAndClick(downloadSampleStageIIIReportButtonBy);
		logInfo("Clicked on 'Download Sample Stage III Report' button");
	}

	public void clickDownloadSampleStageIIReportButton() {
		Element.loadAndClick(downloadSampleStageIIReportButtonBy);
		logInfo("Clicked on 'Download Sample Stage II Report' button");
	}

	public void clickOrderTheTestNowButton() {
		Element.loadAndClick(orderTheTestNowButtonBy);
		logInfo("Clicked on 'Order the Test Now ' button");
	}

	public void clickOnLinksOnOncotypeDXColonRecurrenceScoreTestPageForPatientAndCaregivers(String linkname) {
		By oncotypeDXColonRecurrenceScoreTestPageLinksForPatientAndCaregiversSectionBy = By
				.cssSelector(productsitePagesProperties.getProperty(
						"OncotypeDXColonRecurrenceScoreTestPageLinksForPatientAndCaregiversSection") + linkname + "']");
		String linkText = Element
				.getElementText(oncotypeDXColonRecurrenceScoreTestPageLinksForPatientAndCaregiversSectionBy);
		Element.loadAndClick(oncotypeDXColonRecurrenceScoreTestPageLinksForPatientAndCaregiversSectionBy);
		logInfo("Clicked on '" + linkText + "' link");
	}

}
