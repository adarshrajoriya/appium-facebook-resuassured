package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteCostsAndCoveragePage extends ExactNavNavigation {
	private final By patientStateDropdownListBy = By
			.cssSelector(productsitePagesProperties.getProperty("PatientStateDropdownList"));
	private final By householdSizeDropdownListBy = By
			.cssSelector(productsitePagesProperties.getProperty("HouseholdSizeDropdownList"));
	private final By annualIncomeBy = By.cssSelector(productsitePagesProperties.getProperty("AnnualIncome"));
	private final By costsAndCoveragePageSubmitButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("CostsAndCoveragePageSubmitButton"));
	private final By qualifyTextBy = By.cssSelector(productsitePagesProperties.getProperty("QualifyText"));
	private final By downloadTheGapGuideForHelpNavigatingTheInsuranceProcessBy = By.cssSelector(
			productsitePagesProperties.getProperty("DownloadTheGapGuideForHelpNavigatingTheInsuranceProcess"));
	private final By contactUsToGetStartedWithGapBy = By
			.cssSelector(productsitePagesProperties.getProperty("ContactUsToGetStartedWithGap"));

	public boolean isCostsAndCoverageTabsDisplayed(String tabsName) {
		By costsAndCoverageTabsBy = By
				.xpath(productsitePagesProperties.getProperty("CostsAndCoverageTabs") + tabsName + "']");
		return Element.isElementDisplayed(costsAndCoverageTabsBy);
	}

	public void clickCostsAndCoverageTabs(String tabsName) {
		By costsAndCoverageTabsBy = By
				.xpath(productsitePagesProperties.getProperty("CostsAndCoverageTabs") + tabsName + "']");
		Element.loadAndClick(costsAndCoverageTabsBy);
		logInfo("Clicked on '" + tabsName + "' tab");
	}

	public boolean isCostsAndCoverageTabsOpened(String tabsName) {
		By costsAndCoverageTabsOpenedBy = By
				.xpath(productsitePagesProperties.getProperty("CostsAndCoverageTabsOpened") + tabsName + "']");
		return Element.isElementDisplayed(costsAndCoverageTabsOpenedBy);
	}

	public void selectPatientState(String state) {
		Element.loadAndClick(patientStateDropdownListBy);
		By patientStateBy = By.xpath(productsitePagesProperties.getProperty("PatientState") + state + "']");
		Element.loadAndClick(patientStateBy);
		logInfo("Select '" + state + "' as patient state option");
	}

	public void selectHouseholdSize(String houseHoldSize) {
		Element.loadAndClick(householdSizeDropdownListBy);
		By householdSizeBy = By.xpath(productsitePagesProperties.getProperty("HouseholdSize") + houseHoldSize + "']");

		Element.loadAndClick(householdSizeBy);
		logInfo("Select '" + houseHoldSize + "' as household size option");
	}

	public void enterAnnualIncome(String annualIncome) {
		Element.enterText(annualIncomeBy, annualIncome);
		logInfo("Entered 'Annual Income' : " + annualIncome);
	}

	public void clickOnSubmitButton() {
		Element.loadAndClick(costsAndCoveragePageSubmitButtonBy);
		logInfo("Clicked on 'Submit' button");
	}

	public boolean isQualifyTextDisplayed() {
		return Element.isElementDisplayed(qualifyTextBy);
	}

	public void clickDownloadTheGapGuideForHelpNavigatingTheInsuranceProcess() {
		Element.loadAndClick(downloadTheGapGuideForHelpNavigatingTheInsuranceProcessBy);
		logInfo("Clicked on 'Download the GAP guide for help navigating the insurance process' button");
	}

	public void clickContactUsToGetStartedWithGap() {
		Element.loadAndClick(contactUsToGetStartedWithGapBy);
		logInfo("Clicked on 'Contact us to get started with gap' button");
	}

	public void clickOnfAqs(String faq) {
		By fAqsBy = By.xpath(productsitePagesProperties.getProperty("CostsAndCoverageFaq") + faq + "']");
		Element.loadAndClick(fAqsBy);
		logInfo("Clicked on '" + faq + "' faq");
	}

	public boolean isFaqExpaned(String faq) {
		By costsAndCoveragefaqExpandBy = By
				.xpath(productsitePagesProperties.getProperty("CostsAndCoverageFaqExpand") + faq + "']");
		return Element.isElementDisplayed(costsAndCoveragefaqExpandBy);
	}
}
