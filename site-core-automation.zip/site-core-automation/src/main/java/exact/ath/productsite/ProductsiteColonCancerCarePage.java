package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteColonCancerCarePage extends ExactNavNavigation {

	private final By colonCancerPageIconCardExploreTestBy = By
			.xpath(productsitePagesProperties.getProperty("ColonCancerPageIconCardExploreTest"));
	private final By colonCancerPageIconCardExploreTestForPatientAndCaregiversSectionBy = By.cssSelector(
			productsitePagesProperties.getProperty("ColonCancerPageIconCardExploreTestForPatientAndCaregiversSection"));
	private final By learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkColonCancerBy = By.cssSelector(
			productsitePagesProperties.getProperty("LearnAboutCostsCoverageAndHowExactSciencesCanHelpLinkColonCancer"));

	public void clickColonCancerPageIconCardExploreTest() {
		Element.loadAndClick(colonCancerPageIconCardExploreTestBy);
		logInfo("Clicked on 'Explore Test' button under icon card");
	}

	public void clickColonCancerPageIconCardExploreTestForPatientAndCaregiversSection() {
		Element.loadAndClick(colonCancerPageIconCardExploreTestForPatientAndCaregiversSectionBy);
		logInfo("Clicked on 'Explore Test' button under icon card");
	}

	public void clickOnLinksOnColonCancerPageForPatientAndCaregivers(String linkname) {
		By colonCancerPageLinksForPatientAndCaregiversSectionBy = By.cssSelector(
				productsitePagesProperties.getProperty("ColonCancerPageLinksForPatientAndCaregiversSection") + linkname
						+ "']");
		String linkText = Element.getElementText(colonCancerPageLinksForPatientAndCaregiversSectionBy);
		Element.loadAndClick(colonCancerPageLinksForPatientAndCaregiversSectionBy);
		logInfo("Clicked on '" + linkText + "' link");
	}

	public void clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpButton() {
		Element.loadAndClick(learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkColonCancerBy);
		logInfo("Clicked on 'Learn about costs, coverage, and how Exact Sciences can help' button");

	}

}
