package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class PSOncotypeDXBreastDcisScoreTestPage extends ExactNavNavigation {

	private final By downloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCISBy = By
			.cssSelector(productsitePagesProperties
					.getProperty("DownloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCIS"));
	private final By oncotypeDXBreastRecurrenceScoreTestLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("OncotypeDXBreastRecurrenceScoreTestLink"));

	public void clickOncotypeDXBreastDcisScoreTestPageLinks(String linkname) {
		By oncotypeDXBreastDcisScoreTestPageLinksBy = By.xpath(
				productsitePagesProperties.getProperty("OncotypeDXBreastDcisScoreTestPageLinks") + linkname + "']");
		Element.loadAndClick(oncotypeDXBreastDcisScoreTestPageLinksBy);
		logInfo("Clicked on '" + linkname + "' link");
	}

	public void clickDownloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCIS() {
		Element.loadAndClick(downloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCISBy);
		logInfo("Clicked on 'Download the Brochure for Breast Cancer Patients with Stage 0, Non-Invasive DCIS' button");
	}

	public void clickOncotypeDXBreastRecurrenceScoreTestLink() {
		Element.loadAndClick(oncotypeDXBreastRecurrenceScoreTestLinkBy);
		logInfo("Clicked on 'Oncotype DX Breast Recurrence Score test' link");
	}

	public void clickOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection(String linkname) {
		By oncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSectionBy = By
				.cssSelector(productsitePagesProperties.getProperty(
						"OncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection") + linkname + "']");
		String linkText = Element
				.getElementText(oncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSectionBy);
		Element.loadAndClick(oncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSectionBy);
		logInfo("Clicked on '" + linkText + "' link");
	}

}
