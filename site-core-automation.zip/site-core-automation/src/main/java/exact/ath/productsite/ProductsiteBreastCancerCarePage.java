package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteBreastCancerCarePage extends ExactNavNavigation {

	private final By callButtonBy = By.cssSelector(productsitePagesProperties.getProperty("CallButton"));
	private final By howToOrderOncotypeBreastTestLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("HowToOrderOncotypeBreastTestLink"));
	private final By orderThroughPhysicianPortalBy = By
			.xpath(productsitePagesProperties.getProperty("OrderThroughPhysicianPortal"));
	private final By signUpForPhysicianPortalBy = By
			.cssSelector(productsitePagesProperties.getProperty("SignUpForPhysicianPortal"));
	private final By oncotypeDXBreastRecurrenceScoreTestLinkForCostsAndCoveragesPageBy = By.cssSelector(
			productsitePagesProperties.getProperty("OncotypeDXBreastRecurrenceScoreTestLinkForCostsAndCoveragesPage"));
	private final By learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkBreastCancerBy = By
			.cssSelector(productsitePagesProperties
					.getProperty("LearnAboutCostsCoverageAndHowExactSciencesCanHelpLinkBreastCancer"));

	public boolean isBreastCancerPageIconCardsDisplayed(String subpartsName) {
		By breastCancerPageIconCardsBy = By
				.xpath(productsitePagesProperties.getProperty("BreastCancerPageIconCards") + subpartsName + "']");
		return Element.isElementDisplayed(breastCancerPageIconCardsBy);
	}

	public void clickBreastCancerPageIconCardsExploreTest(String subpartsName) {
		By breastCancerPageIconCardsExploreTestBy = By.xpath(
				productsitePagesProperties.getProperty("BreastCancerPageIconCardsExploreTest") + subpartsName + "']");
		Element.loadAndClick(breastCancerPageIconCardsExploreTestBy);
		logInfo("Clicked on 'Explore Test' button under icon card");
	}

	public boolean isCallButtonDispalyed() {
		return Element.isElementDisplayed(callButtonBy);
	}

	public void clickHowToOrderOncotypeBreastTestLink() {
		Element.loadAndClick(howToOrderOncotypeBreastTestLinkBy);
		logInfo("Clicked on 'How To Order Oncotype Breast Test' link");
	}

	public void clickOrderThroughPhysicianPortal() {
		Element.loadAndClick(orderThroughPhysicianPortalBy);
		logInfo("Clicked on 'Order Through Physician Portal' button");
	}

	public void clickSignUpForPhysicianPortal() {
		Element.loadAndClick(signUpForPhysicianPortalBy);
		logInfo("Clicked on 'Sign up for Physician Portal' link");
	}

	// Costs And Coverages Page
	public void clickOncotypeDXBreastRecurrenceScoreTestLinkForCostsAndCoveragesPage() {
		Element.loadAndClick(oncotypeDXBreastRecurrenceScoreTestLinkForCostsAndCoveragesPageBy);
		logInfo("Clicked on 'Oncotype DX Breast Recurrence Score test' link");
	}

	public void clickOnLinksOnCostsAndCoveragesBreadtCancerPage(String nameOfLink) {
		By linksOnCostsAndCoveragesBreadtCancerPageBy = By.cssSelector(
				productsitePagesProperties.getProperty("LinksOnCostsAndCoveragesBreadtCancerPage") + nameOfLink + "']");
		String linkText = Element.getElementText(linksOnCostsAndCoveragesBreadtCancerPageBy);
		Element.loadAndClick(linksOnCostsAndCoveragesBreadtCancerPageBy);
		logInfo("Clicked on '" + linkText + "' link");
	}

	public void clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpLink() {
		Element.loadAndClick(learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkBreastCancerBy);
		logInfo("Clicked on 'Learn about costs, coverage, and how Exact Sciences can help' link");
	}

}
