package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteAboutUsPage extends ExactNavNavigation {

	private final By downloadBrochureButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("DownloadBrochureButton"));
	private final By riskguardLinkUnderHereditaryTestBy = By
			.xpath(productsitePagesProperties.getProperty("RiskguardLinkUnderHereditaryTest"));
	private final By riskguardLinkUnderPrognosisTreatmentGuidanceBy = By
			.xpath(productsitePagesProperties.getProperty("RiskguardLinkUnderPrognosisTreatmentGuidance"));
	private final By riskguardLinkUnderTherapySelectionBy = By
			.xpath(productsitePagesProperties.getProperty("RiskguardLinkUnderTherapySelection"));
	private final By learnMoreLinkUnderMolecularResidualDiseaseBy = By
			.cssSelector(productsitePagesProperties.getProperty("LearnMoreLinkUnderMolecularResidualDisease"));
	private final By oncoExTraLinkUnderTherapySelectionBy = By
			.cssSelector(productsitePagesProperties.getProperty("OncoExTraLinkUnderTherapySelection"));
	private final By definingANewApproachToOncologyGenomicsFrameBy = By
			.cssSelector(productsitePagesProperties.getProperty("DefiningANewApproachToOncologyGenomicsFrame"));
	private final By definingANewApproachToOncologyGenomicsVideoPlayButtonBy = By.cssSelector(
			productsitePagesProperties.getProperty("DefiningANewApproachToOncologyGenomicsVideoPlayButton"));
	private final By definingANewApproachToOncologyGenomicsVideoProgressBarBy = By
			.cssSelector(productsitePagesProperties.getProperty("VideoProgressBar"));
	private final By definingANewApproachToOncologyGenomicsVideoPauseButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("DnaRnaVideoPauseButton"));
	private final By anthemOnVimeoVideoPlayButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("AnthemOnVimeoVideoPlayButton"));
	private final By anthemOnVimeoVideoFrameBy = By.cssSelector(productsitePagesProperties.getProperty("DnaRnaFrame"));
	private final By anthemOnVimeoVideoProgressBarBy = By
			.cssSelector(productsitePagesProperties.getProperty("DnaRnaVideoProgressBar"));
	private final By anthemOnVimeoVideoPauseButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("DnaRnaVideoPauseButton"));

	public void clickProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinks(String linkName) {
		By progressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksBy = By
				.cssSelector(productsitePagesProperties.getProperty(
						"ProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinks") + linkName + "']");
		String linkText = Element
				.getElementText(progressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksBy);
		Element.loadAndClick(progressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksBy);
		logInfo("Clicked on '" + linkText + "' link");
	}

	public void clickDownloadBrochureButton() {
		Element.loadAndClick(downloadBrochureButtonBy);
		logInfo("Clicked on 'Download Brochure' button");
	}

	public boolean isIconCardDisplayed(String cardName) {
		By iconCardAboutUsPageBy = By
				.xpath(productsitePagesProperties.getProperty("IconCardAboutUsPage") + cardName + "']");
		return Element.isElementDisplayed(iconCardAboutUsPageBy);
	}

	public void clickOnRiskguardLinkUnderHereditaryTest() {
		Element.loadAndClick(riskguardLinkUnderHereditaryTestBy);
		logInfo("Clicked on 'Riskguard' link Under Hereditary Test icon card");

	}

	public void clickOnRiskguardLinkUnderPrognosisTreatmentGuidance() {
		Element.loadAndClick(riskguardLinkUnderPrognosisTreatmentGuidanceBy);
		logInfo("Clicked on 'Riskguard' link Under Prognosis/Treatment Guidance icon card");

	}

	public void clickOnRiskguardLinkUnderTherapySelection() {
		Element.loadAndClick(riskguardLinkUnderTherapySelectionBy);
		logInfo("Clicked on 'Riskguard' link Under Therapy Selection icon card");

	}

	public void clickOnLinksUnderScreeningSurveillance(String linkName) {
		By linksUnderScreeningSurveillanceBy = By.cssSelector(
				productsitePagesProperties.getProperty("LinksUnderScreeningSurveillance") + linkName + "']");
		String linkText = Element.getElementText(linksUnderScreeningSurveillanceBy);
		Element.loadAndClick(linksUnderScreeningSurveillanceBy);
		logInfo("Clicked on '" + linkText + "' link under Screening Surveillance icon card");
	}

	public void clickOnLinksUnderPrognosisTreatmentGuidance(String linkName) {
		By linksUnderPrognosisTreatmentBy = By
				.cssSelector(productsitePagesProperties.getProperty("LinksUnderPrognosisTreatment") + linkName + "']");
		String linkText = Element.getElementText(linksUnderPrognosisTreatmentBy);
		Element.loadAndClick(linksUnderPrognosisTreatmentBy);
		logInfo("Clicked on '" + linkText + "' link under Prognosis/Treatment Guidance icon card");
	}

	public void clickOnLearnMoreLinkUnderMolecularResidualDisease() {
		Element.loadAndClick(learnMoreLinkUnderMolecularResidualDiseaseBy);
		logInfo("Clicked on 'Learn more' link under Molecular Residual Disease icon card");
	}

	public void clickOnOncoExTraLinkUnderTherapySelection() {
		Element.loadAndClick(oncoExTraLinkUnderTherapySelectionBy);
		logInfo("Clicked on 'OncoExTra' link under Thearpy Selection icon card");
	}

	public void clickOnDefiningANewApproachToOncologyGenomicsVideoPlayButton() {
		driver.switchToFrame(definingANewApproachToOncologyGenomicsFrameBy);
		Element.loadAndClick(definingANewApproachToOncologyGenomicsVideoPlayButtonBy);
		logInfo("Clicked on Defining a new approach to oncology genomics video play button");
	}

	public void clickOnDefiningANewApproachToOncologyGenomicsVideoPauseButton() {
		Element.mouseHover(definingANewApproachToOncologyGenomicsVideoProgressBarBy);
		Element.loadAndClick(definingANewApproachToOncologyGenomicsVideoPauseButtonBy);
		logInfo("Clicked on Defining a new approach to oncology genomics video pause button");

	}

	public void clickOnAnthemOnVimeoVideoPlayButton() {
		Element.loadAndClick(anthemOnVimeoVideoPlayButtonBy);
		driver.switchToFrame(anthemOnVimeoVideoFrameBy);
		logInfo("Clicked on Anthem On Vimeo video play button");
	}

	public void clickOnAnthemOnVimeoVideoPauseButton() {
		Element.mouseHover(anthemOnVimeoVideoProgressBarBy);
		Element.loadAndClick(anthemOnVimeoVideoPauseButtonBy);
		logInfo("Clicked on Anthem On Vimeo video pause button");

	}

}
