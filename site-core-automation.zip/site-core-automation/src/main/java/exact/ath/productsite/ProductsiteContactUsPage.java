package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteContactUsPage extends ExactNavNavigation {

	private final By firstNameOfContactUsFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("FirstNameOfContactUsForm"));
	private final By lastNameOfContactUsFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("LastNameOfContactUsForm"));
	private final By emailAddressOfContactUsFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("EmailAddressOfContactUsForm"));
	private final By phoneNumberOfContactUsFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("PhoneNumberOfContactUsForm"));
	private final By precisionOncologyTestListOfContactUsFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("PrecisionOncologyTestListOfContactUsForm"));
	private final By messageOfContactUsFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("MessageOfContactUsForm"));
	private final By submitButtonOfContactUsFormBy = By
			.cssSelector(productsitePagesProperties.getProperty("SubmitButtonOfContactUsForm"));
	private final By verificationMessageOfContactUsFormBy = By
			.xpath(productsitePagesProperties.getProperty("VeificationMessageOfContactUsForm"));

	public void enterFirstNameOfContactUsForm(String firstName) {
		Element.enterText(firstNameOfContactUsFormBy, firstName);
		logInfo("Entered 'First Name' : " + firstName);
	}

	public void enterLastNameOfContactUsForm(String lastName) {
		Element.enterText(lastNameOfContactUsFormBy, lastName);
		logInfo("Entered 'Last Name' : " + lastName);
	}

	public void enterEmailAddressOfContactUsForm(String emailAddress) {
		Element.enterText(emailAddressOfContactUsFormBy, emailAddress);
		logInfo("Entered 'Email Address' : " + emailAddress);
	}

	public void enterPhoneNumberOfContactUsForm(String phoneNumber) {
		Element.enterText(phoneNumberOfContactUsFormBy, phoneNumber);
		logInfo("Entered 'Phone Number' : " + phoneNumber);
	}

	public void selectPrecisionOncologyTestOfContactUsForm(String option) {
		Element.loadAndClick(precisionOncologyTestListOfContactUsFormBy);
		By precisionOncologyTestNameOfContactUsFormBy = By.cssSelector(
				productsitePagesProperties.getProperty("PrecisionOncologyTestNameOfContactUsForm") + option + "']");
		Element.loadAndClick(precisionOncologyTestNameOfContactUsFormBy);
		logInfo("Selected 'Precision Oncology Test' : " + option);
	}

	public void enterMessageOfContactUsForm(String message) {
		Element.enterText(messageOfContactUsFormBy, message);
		logInfo("Entered 'Message' : " + message);
	}

	public void clickSubmitButtonOfContactUsForm() {
		Element.loadAndClick(submitButtonOfContactUsFormBy);
		logInfo("Clicked on 'Submit' button");
	}

	public String getVerificationMessageOfContactUsForm() {
		Element.waitForVisible(verificationMessageOfContactUsFormBy);
		return Element.getElementText(verificationMessageOfContactUsFormBy);
	}

	public boolean isPhoneLinksDisplayedOnContactUsPage(String phoneNumber) {
		By phoneLinksDisplayedOnContactUsPageBy = By.xpath(
				productsitePagesProperties.getProperty("PhoneLinksDisplayedOnContactUsPage") + phoneNumber + "']");
		return Element.isElementDisplayed(phoneLinksDisplayedOnContactUsPageBy);
	}

	public boolean isEmailLinksDisplayedOnContactUsPage(String email) {
		By emailLinksDisplayedOnContactUsPageBy = By.cssSelector(
				productsitePagesProperties.getProperty("EmailLinksDisplayedOnContactUsPage") + email + "']");
		return Element.isElementDisplayed(emailLinksDisplayedOnContactUsPageBy);
	}

	public String getEmailLinksNameOnContactUsPage(String email) {
		By emailLinksNameOnContactUsPageBy = By.cssSelector(
				productsitePagesProperties.getProperty("EmailLinksDisplayedOnContactUsPage") + email + "']");
		return Element.getElementText(emailLinksNameOnContactUsPageBy);
	}

}
