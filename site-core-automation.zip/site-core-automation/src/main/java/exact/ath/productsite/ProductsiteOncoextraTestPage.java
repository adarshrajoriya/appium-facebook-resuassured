package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteOncoextraTestPage extends ExactNavNavigation {
	private final By downloadAnalyticValidationButtonBy = By
			.xpath(productsitePagesProperties.getProperty("DownloadAnalyticValidationButton"));
	private final By downloadPublicationButtonBy = By
			.xpath(productsitePagesProperties.getProperty("DownloadPublicationButton"));
	private final By contactMedicalTeamButtonBy = By
			.xpath(productsitePagesProperties.getProperty("ContactMedicalTeamButton"));
	private final By billingCoverageOverviewLinkBy = By
			.xpath(productsitePagesProperties.getProperty("BillingCoverageOverviewLink"));
	private final By getTheStarterKitButtonBy = By
			.xpath(productsitePagesProperties.getProperty("GetTheStarterKitButton"));
	private final By getTheWhitePaperButtonBy = By
			.xpath(productsitePagesProperties.getProperty("GetTheWhitePaperButton"));
	private final By learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkOncoExtraBy = By.cssSelector(
			productsitePagesProperties.getProperty("LearnAboutCostsCoverageAndHowExactSciencesCanHelpLinkOncoExtra"));
	private final By dnaRnaVideoPlayButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("DnaRnaVideoPlayButton"));
	private final By dnaRnaFrameBy = By.cssSelector(productsitePagesProperties.getProperty("DnaRnaFrame"));
	private final By dnaRnaVideoPauseButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("DnaRnaVideoPauseButton"));
	private final By dnaRnaVideoProgressBarBy = By
			.cssSelector(productsitePagesProperties.getProperty("DnaRnaVideoProgressBar"));

	public void clickDownloadAnalyticValidationButton() {
		Element.loadAndClick(downloadAnalyticValidationButtonBy);
		logInfo("Clicked on 'Download analytic validation' button");
	}

	public void clickDownloadPublicationButton() {
		Element.loadAndClick(downloadPublicationButtonBy);
		logInfo("Clicked on 'Download Publication' button");
	}

	public void clickOncoExTraReportsButtons(String reportName) {
		By oncoExTraReportsButtonBy = By
				.xpath(productsitePagesProperties.getProperty("OncoExTraReportsButton") + reportName + "']");
		Element.loadAndClick(oncoExTraReportsButtonBy);
		logInfo("Clicked on '" + reportName + "' download button");
	}

	public boolean isContactMedicalTeamButtonDisplayed() {
		return Element.isElementDisplayed(contactMedicalTeamButtonBy);

	}

	public void clickBillingCoverageOverviewlink() {
		Element.loadAndClick(billingCoverageOverviewLinkBy);
		logInfo("Clicked on 'Billing & Coverage Overview' link");
	}

	public void clickGetTheStarterKitButton() {
		Element.loadAndClick(getTheStarterKitButtonBy);
		logInfo("Clicked on 'Get The Starter Kit' button");
	}

	public void clickGetTheWhitePaperButton() {
		Element.loadAndClick(getTheWhitePaperButtonBy);
		logInfo("Clicked on 'Get the white paper' button");
	}

	public String getOncoExTraResourceFaqLinksName(String resourceFaqUrl) {
		By oncoExTraResourceFaqLinksBy = By.cssSelector(
				productsitePagesProperties.getProperty("OncoExTraResourceFaqLinks") + resourceFaqUrl + "']");
		return Element.getElementText(oncoExTraResourceFaqLinksBy);
	}

	public void clickOncoExTraResourceFaqLinks(String resourceFaqUrl) {
		By oncoExTraResourceFaqLinksBy = By.cssSelector(
				productsitePagesProperties.getProperty("OncoExTraResourceFaqLinks") + resourceFaqUrl + "']");
		Element.loadAndClick(oncoExTraResourceFaqLinksBy);
		logInfo("Clicked on '" + getOncoExTraResourceFaqLinksName(resourceFaqUrl) + "' button");
	}

	public void clickFaqAndReferenceAccordion(String accordionName) {
		By faqAndReferenceAccordionBy = By
				.xpath(productsitePagesProperties.getProperty("FaqAndReferenceAccordion") + accordionName + "']");
		Element.loadAndClick(faqAndReferenceAccordionBy);
		logInfo("Clicked on '" + accordionName + "' accordion");
	}

	public boolean isFaqAndReferenceAccordionExpand(String accordionName) {
		By faqAndReferenceAccordionExpandBy = By
				.xpath(productsitePagesProperties.getProperty("FaqAndReferenceAccordionExpand") + accordionName + "']");
		return Element.isElementDisplayed(faqAndReferenceAccordionExpandBy);

	}

	public void clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpLink() {
		Element.loadAndClick(learnAboutCostsCoverageAndHowExactSciencesCanHelpLinkOncoExtraBy);
		logInfo("Clicked on 'Learn about costs, coverage, and how Exact Sciences can help' link");
	}

	public void clickOnDnaRnaVideoPlayButton() {
		Element.loadAndClick(dnaRnaVideoPlayButtonBy);
		driver.switchToFrame(dnaRnaFrameBy);
		logInfo("Clicked on DNA + RNA video play button");
	}

	public void clickOnDnaRnaVideoPauseButton() {
		Element.mouseHover(dnaRnaVideoProgressBarBy);
		Element.loadAndClick(dnaRnaVideoPauseButtonBy);
		logInfo("Clicked on DNA + RNA video pause button");

	}

}
