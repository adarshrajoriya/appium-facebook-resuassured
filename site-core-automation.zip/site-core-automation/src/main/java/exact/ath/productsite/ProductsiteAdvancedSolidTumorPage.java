package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;

import exact.Element;
import exact.navigation.ExactNavNavigation;

public class ProductsiteAdvancedSolidTumorPage extends ExactNavNavigation {

	private final By advancedSolidTumorPageIconCardExploreTestBy = By
			.xpath(productsitePagesProperties.getProperty("AdvancedSolidTumorPageIconCardExploreTest"));
	private final By orderNowButtonBy = By.xpath(productsitePagesProperties.getProperty("OrderNowButton"));
	private final By headerValueForOncoextraPageBy = By
			.xpath(productsitePagesProperties.getProperty("HeaderValueForOncoextraPage"));
	private final By advancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversSectionBy = By
			.cssSelector(productsitePagesProperties
					.getProperty("AdvancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversSection"));

	public void clickAdvancedSolidTumorPageIconCardExploreTest() {
		Element.loadAndClick(advancedSolidTumorPageIconCardExploreTestBy);
		logInfo("Clicked on 'Explore Test' button under icon card");
	}

	public void clickOrderNowButton() {
		Element.loadAndClick(orderNowButtonBy);
		logInfo("Clicked on 'Order Now' button");
	}

	public String getHeaderValueForOncoextraPage() {
		return Element.getElementText(headerValueForOncoextraPageBy);
	}

	public void clickAdvancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversSection() {
		Element.loadAndClick(advancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversSectionBy);
		logInfo("Clicked on 'Explore Test' button under icon card");
	}

	public void clickOnLinksOnAdvancedSolidTumorPageForPatientAndCaregivers(String linkname) {
		By advancedSolidTumorPageLinksForPatientAndCaregiversSectionBy = By.cssSelector(
				productsitePagesProperties.getProperty("AdvancedSolidTumorPageLinksForPatientAndCaregiversSection")
						+ linkname + "']");
		String linkText = Element.getElementText(advancedSolidTumorPageLinksForPatientAndCaregiversSectionBy);
		Element.loadAndClick(advancedSolidTumorPageLinksForPatientAndCaregiversSectionBy);
		logInfo("Clicked on '" + linkText + "' link");
	}

}
