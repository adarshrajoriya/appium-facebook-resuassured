package exact.ath.productsite;

import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import exact.Element;
import exact.navigation.ExactNavNavigation;
import exact.sys.DriverManager;

public class ProductsiteHomepage extends ExactNavNavigation {

	private final By pageHeaderBy = By.xpath(productsitePagesProperties.getProperty("PageHeader"));
	private final By heroLinkBy = By.cssSelector(productsitePagesProperties.getProperty("HeroLink"));
	private final By downloadWhitePaperLinkBy = By
			.xpath(productsitePagesProperties.getProperty("DownloadWhitePaperLink"));
	private final By precisionOncologyLogoBy = By
			.xpath(productsitePagesProperties.getProperty("PrecisionOncologyLogo"));
	private final By searchBarBy = By.xpath(productsitePagesProperties.getProperty("SearchBar"));
	private final String searchIcon = productsitePagesProperties.getProperty("SearchIcon");
	private final By createAnAccountBy = By.xpath(productsitePagesProperties.getProperty("CreateAnAccount"));
	private final By contactUsTabHighlightedBy = By
			.xpath(productsitePagesProperties.getProperty("ContactUsTabHighlighted"));
	private final By physicianLoginBy = By.xpath(productsitePagesProperties.getProperty("PhysicianLogin"));
	private final By regionTabDisplayedBy = By.xpath(productsitePagesProperties.getProperty("RegionTabDisplayed"));
	private final By learnMoreLinkBy = By.xpath(productsitePagesProperties.getProperty("LearnMoreLink"));
	private final By breastCancerTestsBy = By.xpath(productsitePagesProperties.getProperty("BreastCancerTests"));
	private final By healthcareProvidersTabHighlightedBy = By
			.xpath(productsitePagesProperties.getProperty("HealthcareProvidersHighlighted"));
	private final By colonCancerTestsBy = By.xpath(productsitePagesProperties.getProperty("ColonCancerTests"));
	private final By advancedSolidTumorsCancerTestsBy = By
			.xpath(productsitePagesProperties.getProperty("AdvancedSolidTumorsCancer"));
	private final By beckerHealthcareWhitePaperBy = By
			.xpath(productsitePagesProperties.getProperty("BeckerHealthcareWhitePaper"));
	private final By getRecapOfTheAnnualMeetingBy = By
			.xpath(productsitePagesProperties.getProperty("GetRecapOfTheAnnualMeeting"));
	private final By learnMoreAboutGenomicTestingLinkBy = By
			.xpath(productsitePagesProperties.getProperty("LearnMoreAboutGenomicTestingLink"));
	private final By patientsCaregiversTabHighlightedBy = By
			.xpath(productsitePagesProperties.getProperty("PatientsCaregiversTabHighlighted"));
	private final By exploreBillingCoverageoptionsLinkBy = By
			.xpath(productsitePagesProperties.getProperty("ExploreBillingCoverageoptionsLink"));
	private final By billingCoverageTabHighlightedBy = By
			.xpath(productsitePagesProperties.getProperty("BillingCoverageTabHighlighted"));
	private final By firstNameOfSignUpforOurHealthcareProfessionalUpdatesFieldsBy = By.cssSelector(
			productsitePagesProperties.getProperty("FirstNameOfSignUpforOurHealthcareProfessionalUpdatesFields"));
	private final By lastNameOfSignUpforOurHealthcareProfessionalUpdatesFieldsBy = By.cssSelector(
			productsitePagesProperties.getProperty("LastNameOfSignUpforOurHealthcareProfessionalUpdatesFields"));
	private final By emailsOfSignUpforOurHealthcareProfessionalUpdatesFieldsBy = By.cssSelector(
			productsitePagesProperties.getProperty("EmailsOfSignUpforOurHealthcareProfessionalUpdatesFields"));
	private final By submitButtonBy = By.cssSelector(productsitePagesProperties.getProperty("SubmitButton"));
	private final By emailCustomerServiceButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("EmailCustomerServiceButton"));
	private final By contactUsPageHeaderBy = By
			.cssSelector(productsitePagesProperties.getProperty("ContactUsPageHeader"));
	private final By orangeBackgroundPageHeaderBy = By
			.xpath(productsitePagesProperties.getProperty("OrangeBackgroundPageHeader"));
	private final By contactUsTabAfterClickedOnContactUsButtonHighlightedBy = By
			.xpath(productsitePagesProperties.getProperty("ContactUsTabAfterClickedOnContactUsButtonHighlighted"));
	private final By learnAboutCostsAndCoverageButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("LearnAboutCostsAndCoverageButton"));
	private final By exactSciencesLogoDisplayedInFooterBy = By
			.cssSelector(productsitePagesProperties.getProperty("ExactSciencesLogoDisplayedInFooter"));
	private final By addressDetailsDisplayedInFooterBy = By
			.cssSelector(productsitePagesProperties.getProperty("AddressDetailsDisplayedInFooter"));
	private final By licensesFooterLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("LicensesFooterLink"));
	private final By medicareBillingPolicyFooterLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("MedicareBillingPolicyFooterLink"));
	private final By privacyPolicyFooterLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("PrivacyPolicyFooterLink"));
	private final By hIPPANoticeFooterLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("HIPPANoticeFooterLink"));
	private final By doNotSellMyInformationFooterLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("DoNotSellMyInformationFooterLink"));
	private final By cookieSettingsFooterLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("CookieSettingsFooterLink"));
	private final By termsConditionsFooterLinkBy = By
			.cssSelector(productsitePagesProperties.getProperty("TermsConditionsFooterLink"));
	private final By pageHeaderWithImageBy = By
			.cssSelector(productsitePagesProperties.getProperty("PageHeaderWithImage"));
	private final By hippaCompliancePageHeaderBy = By
			.cssSelector(productsitePagesProperties.getProperty("HippaCompliancePageHeader"));
	private final By deepaVideoPlayButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("DeepaVideoPlayButton"));
	private final By videoFrameBy = By.cssSelector(productsitePagesProperties.getProperty("VideoFrame"));
	private final By videoCurrentTimeBy = By.cssSelector(productsitePagesProperties.getProperty("VideoCurrentTime"));
	private final By videoProgressBarBy = By.cssSelector(productsitePagesProperties.getProperty("VideoProgressBar"));
	private final By videoPauseButtonBy = By.cssSelector(productsitePagesProperties.getProperty("VideoPauseButton"));
	private final By amyVideoPlayButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("AmyVideoPlayButton"));
	private final By laurieVideoPlayButtonBy = By
			.cssSelector(productsitePagesProperties.getProperty("LaurieVideoPlayButton"));

	public ProductsiteHomepage clickHeaderTab(String tabName) {
		By headerTabBy = By.xpath(productsitePagesProperties.getProperty("HeaderTab") + tabName + "']");
		Element.loadAndClick(headerTabBy);
		logInfo("Clicked on '" + tabName + "' tab");
		return this;
	}

	public String getHealthcareProviderSubsection(String subsectionName) {
		By healthcareProviderSubsectionBy = By
				.xpath(productsitePagesProperties.getProperty("HealthcareProviderSubsection") + subsectionName + "')]");
		return Element.getElementText(healthcareProviderSubsectionBy);

	}

	public boolean isHealthcareProviderSubmenuDisplayed(String submenuName) {
		By healthcareProviderSubmenuBy = By
				.xpath(productsitePagesProperties.getProperty("HealthcareProviderSubmenu") + submenuName + "']");
		return Element.isElementDisplayed(healthcareProviderSubmenuBy);

	}

	public boolean isHealthcareProviderSubpartsDisplayed(String subpartsName) {
		By healthcareProviderSubpartsBy = By
				.xpath(productsitePagesProperties.getProperty("HealthcareProviderSubparts") + subpartsName + "']");
		return Element.isElementDisplayed(healthcareProviderSubpartsBy);

	}

	public void clickHealthcareProviderSubmenu(String submenuName) {
		By healthcareProviderSubmenuBy = By
				.xpath(productsitePagesProperties.getProperty("HealthcareProviderSubmenu") + submenuName + "']");
		Element.loadAndClick(healthcareProviderSubmenuBy);
		logInfo("Clicked on '" + submenuName + "' submenu");
	}

	public String getPageHeader() {
		return Element.getElementText(pageHeaderBy);
	}

	public void clickHealthcareProviderSubparts(String subpartsName) {
		By healthcareProviderSubpartsBy = By
				.xpath(productsitePagesProperties.getProperty("HealthcareProviderSubparts") + subpartsName + "']");
		Element.loadAndClick(healthcareProviderSubpartsBy);
		logInfo("Clicked on '" + subpartsName + "' subparts");
	}

	public void clickHeroLink() {
		String heroLinkName = Element.getElementText(heroLinkBy);
		Element.loadAndClick(heroLinkBy);
		logInfo("Clicked on '" + heroLinkName + "' herolink");
	}

	public void clickDownloadWhitePaperLink() {
		Element.loadAndClick(downloadWhitePaperLinkBy);
		logInfo("Clicked on 'Download White Paper' link");
	}

	public void clickPrecisionOncologyLogo() {
		Element.loadAndClick(precisionOncologyLogoBy);
		logInfo("Clicked on 'Precision Oncology' logo");
	}

	public void enterTextInSearchField(String search) {
		Element.enterText(searchBarBy, search);
		logInfo("Enter text '" + search + "' in search field");
	}

	public void clickOnSearchButton() {
		((JavascriptExecutor) DriverManager.getCurrent())
				.executeScript("document.querySelector(arguments[0],':after').click();", searchIcon);
		logInfo("Clicked on 'Search' button");
	}

	public void clickCreateAnAccount() {
		Element.loadAndClick(createAnAccountBy);
		logInfo("Clicked on 'Create An Account' button");
	}

	public boolean isContactUsTabHighlighted() {
		return Element.isElementDisplayed(contactUsTabHighlightedBy);
	}

	public void clickPhysicianLogin() {
		Element.loadAndClick(physicianLoginBy);
		logInfo("Clicked on 'Physician Login' button");
	}

	public boolean isHeaderTabDisplayed(String tabName) {
		By headerTabDisplayedBy = By
				.xpath(productsitePagesProperties.getProperty("HeaderTabDisplayed") + tabName + "']");
		return Element.isElementDisplayed(headerTabDisplayedBy);
	}

	public boolean isRegionTabDisplayed() {
		return Element.isElementDisplayed(regionTabDisplayedBy);
	}

	public void clickLearnMoreLink() {
		Element.loadAndClick(learnMoreLinkBy);
		logInfo("Clicked on 'Learn More' link");
	}

	public void clickBreastCancerTestsLink() {
		Element.loadAndClick(breastCancerTestsBy);
		logInfo("Clicked on 'Breast Cancer Tests' link");
	}

	public boolean isHealthcareProvidersHighlighted() {
		return Element.isElementDisplayed(healthcareProvidersTabHighlightedBy);
	}

	public void clickColonCancerTestsLink() {
		Element.loadAndClick(colonCancerTestsBy);
		logInfo("Clicked on 'Colon Cancer Tests' link");
	}

	public void clickAdvancedSolidTumorsCancerTestsLink() {
		Element.loadAndClick(advancedSolidTumorsCancerTestsBy);
		logInfo("Clicked on 'Advanced Solid Tumors Cancer Tests' link");
	}

	public void clickBeckersHealthcareWhitePaper() {
		Element.loadAndClick(beckerHealthcareWhitePaperBy);
		logInfo("Clicked on 'Becker's Healthcare White Paper' link");
	}

	public void clickGetRecapOfTheAnnualMeeting() {
		Element.loadAndClick(getRecapOfTheAnnualMeetingBy);
		logInfo("Clicked on'Get Recap Of The Annual Meeting' link");
	}

	public void clickLearnMoreAboutGenomicTestingLink() {
		Element.loadAndClick(learnMoreAboutGenomicTestingLinkBy);
		logInfo("Clicked on'Learn More About Genomic Testing' link");
	}

	public boolean isPatientsCaregiversHighlighted() {
		return Element.isElementDisplayed(patientsCaregiversTabHighlightedBy);
	}

	public void clickExploreBillingCoverageoptionsLink() {
		Element.loadAndClick(exploreBillingCoverageoptionsLinkBy);
		logInfo("Clicked on'Explore Billing & Coverage options' link");
	}

	public boolean isBillingCoverageHighlighted() {
		return Element.isElementDisplayed(billingCoverageTabHighlightedBy);
	}

	public void enterFirstNameOfSignUpforOurHealthcareProfessionalUpdatesFields(String firstName) {
		Element.enterText(firstNameOfSignUpforOurHealthcareProfessionalUpdatesFieldsBy, firstName);
		logInfo("Entered 'First Name' : " + firstName);
	}

	public void enterLastNameOfSignUpforOurHealthcareProfessionalUpdatesFields(String lastName) {
		Element.enterText(lastNameOfSignUpforOurHealthcareProfessionalUpdatesFieldsBy, lastName);
		logInfo("Entered 'Last Name' : " + lastName);
	}

	public void clickEmailsOfSignUpforOurHealthcareProfessionalUpdatesFields(String email) {
		Element.enterText(emailsOfSignUpforOurHealthcareProfessionalUpdatesFieldsBy, email);
		logInfo("Entered 'Email' : " + email);
	}

	public void clickSubmitButton() {
		Element.loadAndClick(submitButtonBy);
		logInfo("Clicked on 'Submit' button");
	}

	public boolean isEmailCustomerServiceButtonDispalyed() {
		return Element.isElementDisplayed(emailCustomerServiceButtonBy);
	}

	public String getContactUsPageHeader() {
		return Element.getElementText(contactUsPageHeaderBy);
	}

	public String getOrangeBackgroundPageHeader() {
		return Element.getText(orangeBackgroundPageHeaderBy);
	}

	public boolean isContactUsTabAfterClickedOnContactUsButtonHighlighted() {
		return Element.isElementDisplayed(contactUsTabAfterClickedOnContactUsButtonHighlightedBy);
	}

	public String getPatientsAndCaregiversSubsection(String subsectionName) {
		By patientsAndCaregiversSubsectionBy = By.xpath(
				productsitePagesProperties.getProperty("PatientsAndCaregiversSubsection") + subsectionName + "')]");
		return Element.getElementText(patientsAndCaregiversSubsectionBy);

	}

	public boolean isPatientsAndCaregiversSubmenuDisplayed(String submenuName) {
		By patientsAndCaregiversSubmenuBy = By
				.xpath(productsitePagesProperties.getProperty("PatientsAndCaregiversSubmenu") + submenuName + "']");
		return Element.isElementDisplayed(patientsAndCaregiversSubmenuBy);

	}

	public boolean isPatientsAndCaregiversSubpartsDisplayed(String subpartsName) {
		By patientsAndCaregiversSubpartsBy = By
				.xpath(productsitePagesProperties.getProperty("PatientsAndCaregiversSubparts") + subpartsName + "']");
		return Element.isElementDisplayed(patientsAndCaregiversSubpartsBy);

	}

	public void clickPatientsAndCaregiversSubmenu(String submenuName) {
		By patientsAndCaregiversSubmenuBy = By
				.xpath(productsitePagesProperties.getProperty("PatientsAndCaregiversSubmenu") + submenuName + "']");
		Element.loadAndClick(patientsAndCaregiversSubmenuBy);
		logInfo("Clicked on '" + submenuName + "' submenu");
	}

	public void clickPatientsAndCaregiversSubparts(String subpartsName) {
		By patientsAndCaregiversSubpartsBy = By
				.xpath(productsitePagesProperties.getProperty("PatientsAndCaregiversSubparts") + subpartsName + "']");
		Element.loadAndClick(patientsAndCaregiversSubpartsBy);
		logInfo("Clicked on '" + subpartsName + "' subparts");
	}

	public void clickLearnAboutCostsAndCoverageButton() {
		Element.loadAndClick(learnAboutCostsAndCoverageButtonBy);
		logInfo("Clicked on 'Learn about costs and coverage' button");
	}

	public boolean isExactSciencesLogoDisplayedInFooter() {
		return Element.isElementDisplayed(exactSciencesLogoDisplayedInFooterBy);

	}

	public boolean isAddressDetailsDisplayedInFooter() {
		return Element.isElementDisplayed(addressDetailsDisplayedInFooterBy);

	}

	public boolean isQuickLinksDisplayedInFooter(String quickLinks) {
		By quickLinksInFooterBy = By
				.xpath(productsitePagesProperties.getProperty("QuickLinksInFooter") + quickLinks + "']");
		return Element.isElementDisplayed(quickLinksInFooterBy);

	}

	public boolean isFollowUsLinksDisplayedInFooter(String followUsLinks) {
		By followUsLinksInFooterBy = By.cssSelector(
				productsitePagesProperties.getProperty("FollowUsBottomLinksInFooter") + followUsLinks + "']");
		return Element.isElementDisplayed(followUsLinksInFooterBy);

	}

	public boolean isLinksAtBottomOfFooterIsDisplayed(String linksAtBottom) {
		By linksAtBottomOfFooterBy = By.cssSelector(
				productsitePagesProperties.getProperty("FollowUsBottomLinksInFooter") + linksAtBottom + "']");
		return Element.isElementDisplayed(linksAtBottomOfFooterBy);

	}

	public void clickQuickLinksInFooter(String quickLinks) {
		By quickLinksInFooterBy = By
				.xpath(productsitePagesProperties.getProperty("QuickLinksInFooter") + quickLinks + "']");
		Element.loadAndClick(quickLinksInFooterBy);
		logInfo("Clicked on '" + quickLinks + "' link");

	}

	public void clickFollowUsLinksInFooter(String followUsLinks) {
		By followUsLinksInFooterBy = By.cssSelector(
				productsitePagesProperties.getProperty("FollowUsBottomLinksInFooter") + followUsLinks + "']");
		String linkText = Element.getElementText(followUsLinksInFooterBy);
		Element.loadAndClick(followUsLinksInFooterBy);
		logInfo("Clicked on '" + linkText + "' link");

	}

	public void clickLicensesFooterLink() {
		Element.loadAndClickUsingExecutor(licensesFooterLinkBy);
		logInfo("Clicked on 'Licenses' link");

	}

	public void clickMedicareBillingPolicyFooterLink() {
		Element.loadAndClickUsingExecutor(medicareBillingPolicyFooterLinkBy);
		logInfo("Clicked on 'Medicare Billing Policy' link");

	}

	public void clickPrivacyPolicyFooterLink() {
		Element.loadAndClickUsingExecutor(privacyPolicyFooterLinkBy);
		logInfo("Clicked on 'Privacy Policy' link");

	}

	public void clickHIPPANoticeFooterLink() {
		Element.loadAndClickUsingExecutor(hIPPANoticeFooterLinkBy);
		logInfo("Clicked on 'HIPPA Notice' link");

	}

	public void clickDoNotSellMyInformationFooterLink() {
		Element.loadAndClickUsingExecutor(doNotSellMyInformationFooterLinkBy);
		logInfo("Clicked on 'Do Not Sell My Information' link");

	}

	public void clickCookieSettingsFooterLink() {
		Element.loadAndClickUsingExecutor(cookieSettingsFooterLinkBy);
		logInfo("Clicked on 'Cookie Settings' link");

	}

	public void clickTermsConditionsFooterLink() {
		Element.loadAndClickUsingExecutor(termsConditionsFooterLinkBy);
		logInfo("Clicked on 'Terms & Conditions' link");

	}

	public String getPageHeaderWithImage() {
		return Element.getElementText(pageHeaderWithImageBy);
	}

	public String getHippaCompliancePageHeader() {
		return Element.getElementText(hippaCompliancePageHeaderBy);
	}

	public void clickOnDeepaVideoPlayButton() {
		Element.loadAndClick(deepaVideoPlayButtonBy);
		driver.switchToFrame(videoFrameBy);
		logInfo("Clicked on Deepa's video play button");
	}

	public void clickOnVideoPauseButton() {
		Element.mouseHover(videoProgressBarBy);
		Element.loadAndClick(videoPauseButtonBy);
		logInfo("Clicked on video pause button");
	}

	public String getVideoCurrentTime() {
		return Element.getElementText(videoCurrentTimeBy);
	}

	public void clickOnAmyVideoPlayButton() {
		Element.loadAndClick(amyVideoPlayButtonBy);
		driver.switchToFrame(videoFrameBy);
		logInfo("Clicked on video play button");
	}

	public void clickOnLaurieVideoPlayButton() {
		Element.loadAndClick(laurieVideoPlayButtonBy);
		driver.switchToFrame(videoFrameBy);
		logInfo("Clicked on Laurie's video play button");
	}

}
