package exact.sys;

import static exact.ReportLogMain.logError;

import java.time.Duration;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import exact.util.BasicUtils;

public class Wait extends WebDriverWait {

	public Wait(WebDriver driver, Duration timeout) {
		super(driver, timeout);
	}

	// @Override
	protected RuntimeException timeoutException(String message, RuntimeException lastException) {
		String screenShot = BasicUtils.takeScreenshot();
		logError("Failed to find clickable element!");
		logError("Screenshot = " + screenShot);
		throw new TimeoutException(message + " - " + screenShot, lastException);
	}
}
