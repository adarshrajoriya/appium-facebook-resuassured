package exact.sys;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

public class DriverManager {

	private DriverManager() {
	}

	private static final ThreadLocal<WebDriver> webDriver = new ThreadLocal<WebDriver>() {
		@Override
		protected WebDriver initialValue() {
			return WebDriverFactory.getConfiguredWebDriver();
		}
	};

	private static final ThreadLocal<Boolean> driverStartedValue = new ThreadLocal<Boolean>() {
		private boolean driverStarted;

		@Override
		protected Boolean initialValue() {
			return driverStarted;
		}
	};

	public static WebDriver getCurrent() {
		driverStartedValue.set(true);
		return webDriver.get();

	}

	public static Wait getWait(Duration timeout) {
		return new Wait(getCurrent(), timeout);
	}

	protected static void close(WebDriver driver) {
		driverStartedValue.set(false);
		webDriver.remove();
		driver.quit();
	}

	/**
	 * @return : true if driver is Started, false otherwise
	 */
	public static boolean isDriverStarted() {
		return driverStartedValue.get();
	}
}
