package exact.sys;

import java.net.MalformedURLException;
import java.util.HashMap;

import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public enum BrowserType {
	// @formatter:off
		CHROME ("chrome"),
		FIREFOX ("firefox"),
		SAFARI("safari"),
		EDGE ("edge");
		// @formatter:on

	private final String name; // usable external name

	private static final String USERNAME = "sansingh_1zdHm8";
	private static final String AUTOMATE_KEY = "KCtf6wkpc7tpfxk3nzRD";
	private static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";

	public static BrowserType getBrowserType(String name) throws Exception {
		for (BrowserType browserType : BrowserType.values()) {
			if (browserType.getName().equalsIgnoreCase(name)) {
				return browserType;
			}
		}

		String errMessage = name + " is not a valid browser name. Valid names are [";

		for (BrowserType browserType : BrowserType.values()) {
			errMessage += browserType.getName() + ", ";
		}
		errMessage = errMessage.substring(0, errMessage.length() - 2) + "]";

		throw new Exception(errMessage);
	}

	BrowserType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public WebDriver getInstance() throws Exception {
		if (this == BrowserType.EDGE) {
			WebDriverManager.edgedriver().setup();
			return new EdgeDriver();
//			EdgeOptions options = new EdgeOptions();
//			options.addArguments("--remote-allow-origins=*");
//			return new EdgeDriver(options);
		} else if (this == BrowserType.FIREFOX) {
			WebDriverManager.firefoxdriver().setup();
			return new FirefoxDriver();
//			FirefoxOptions options = new FirefoxOptions();
//			options.addArguments("--remote-allow-origins=*");
//			return new FirefoxDriver(options);
		} else if (this == BrowserType.CHROME) {
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--remote-allow-origins=*");
			chromeOptions.addArguments("force-device-scale-factor=0.80");
			chromeOptions.addArguments("high-dpi-support=0.80");
			WebDriverManager.chromedriver().setup();
			return new ChromeDriver(chromeOptions);
//			ChromeOptions options = new ChromeOptions();
//			options.addArguments("--remote-allow-origins=*");
//			options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-logging"));
//			return new ChromeDriver(options);
		}
		return null;
	}

	/**
	 * This methods returns BrowserStack instance of Browser set in execution
	 * 
	 * @return {@link WebDriver}
	 * @throws MalformedURLException
	 */
	public WebDriver getBrowserStackInstance() throws MalformedURLException {
		MutableCapabilities capabilities = new MutableCapabilities();

		HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();
		browserstackOptions.put("os", "Windows");
		browserstackOptions.put("osVersion", "10");
		browserstackOptions.put("local", "false");
		browserstackOptions.put("seleniumVersion", "4.8.0");

		if (this == BrowserType.EDGE) {

			capabilities.setCapability("browserName", "Edge");
			browserstackOptions.put("browserVersion", "111.0");
			capabilities.setCapability("bstack:options", browserstackOptions);
		} else if (this == BrowserType.FIREFOX) {

			capabilities.setCapability("browserName", "Firefox");
			browserstackOptions.put("browserVersion", "110.0");
			capabilities.setCapability("bstack:options", browserstackOptions);
		} else if (this == BrowserType.SAFARI) {
			browserstackOptions.put("os", "OS X");
			capabilities.setCapability("browserName", "Safari");
			browserstackOptions.put("osVersion", "Ventura");
			browserstackOptions.put("browserVersion", "16.3");
			browserstackOptions.put("local", "false");
			browserstackOptions.put("browserVersion", "16.3");
			capabilities.setCapability("bstack:options", browserstackOptions);
		} else if (this == BrowserType.CHROME) {

			capabilities.setCapability("browserName", "Chrome");
			browserstackOptions.put("browserVersion", "111.0");
			capabilities.setCapability("bstack:options", browserstackOptions);
			System.setProperty("webdriver.chrome.silentOutput", "true");
		}
		WebDriver driver = new RemoteWebDriver(new java.net.URL(URL), capabilities);
		return driver;
	}

	public static String getBrowserTypeConfiguration() {
		String browserType = System.getProperty("browserType");
		if (browserType == null) {
			browserType = "Chrome";
		}
		return browserType;
	}
}
