package exact.sys;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import exact.Element;
import exact.util.Sleeper;

public class Driver {

	public static final Duration TIMEOUT = Duration.ofSeconds(20);

	private static final String URL = System.getProperty("exactURL");

	private static String parentHandle;

	/**
	 * Navigates to the specified URL directly, as though typed into the address
	 * bar.
	 * 
	 * @param url URL to navigate to. Defaults to value specified in configuration
	 *            value <patientHubURL>
	 */
	public void open(String url) {
		if (url == null) {
			DriverManager.getCurrent().get(URL);
		} else {
			DriverManager.getCurrent().get(url);
		}

		// Close out Alert popup if any
		try {
			Alert alert = DriverManager.getCurrent().switchTo().alert();
			alert.accept();
		} catch (Exception e) {
		}

		DriverManager.getCurrent().manage().window().maximize();

	}

	/**
	 * @return : number of window handlers created using same instance of driver
	 */
	public int getNumberOfWindowHandles() {
		return DriverManager.getCurrent().getWindowHandles().size();
	}

	/**
	 * @return : handlers created using same instance of driver
	 */
	public Set<String> getWindowHandles() {
		return DriverManager.getCurrent().getWindowHandles();
	}

	/**
	 * @return : number of window handlers created using same instance of driver
	 */
	public String getWindowHandle() {
		return DriverManager.getCurrent().getWindowHandle();
	}

	/**
	 * Refresh current page.
	 */
	public void refresh() {
		DriverManager.getCurrent().navigate().refresh();
		Element.waitForDOMToLoad();
	}

	/**
	 * Browse backward page.
	 */
	public void back() {
		DriverManager.getCurrent().navigate().back();
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(5);
	}

	/**
	 * Switch focus to the given iframe. Be sure to call
	 * {@link #switchToMainWindow()} when finished working in the frame!
	 * 
	 * @param frame iframe to switch focus to.
	 */
	public void switchToFrame(By frame) {
		DriverManager.getCurrent().switchTo().frame(Element.waitForVisible(frame));
	}

	/**
	 * Switch focus back to the main window, which is the default. This method
	 * should <em>always</em> be called some time after {@link #switchToFrame(By)}.
	 */
	public void switchToMainWindow() {
		DriverManager.getCurrent().switchTo().defaultContent();
	}

	/**
	 * Close the browser.
	 */
	public void close() {
		DriverManager.close(DriverManager.getCurrent());
	}

	/**
	 * Get Title of the page.
	 * 
	 * @return
	 */
	public String getTitle() {
		return DriverManager.getCurrent().getTitle();
	}

	/**
	 * Get Title of the page.
	 * 
	 * @return
	 */
	public String getURL() {
		return DriverManager.getCurrent().getCurrentUrl();
	}

	/**
	 * Switch To Current Window.
	 * 
	 * @return
	 */
	public void switchToCurrentWindow() {
		Sleeper.sleepTightInSeconds(4);
		parentHandle = getWindowHandle();
		for (String winHandle : getWindowHandles()) {
			if (!winHandle.equals(parentHandle)) {
				DriverManager.getCurrent().switchTo().window(winHandle);
			}
		}
	}

	/**
	 * Switch To Parent Window.
	 * 
	 * @return
	 */
	public void switchToParentWindow() {
		Sleeper.sleepTightInSeconds(2);
		DriverManager.getCurrent().switchTo().window(parentHandle);
	}

	/**
	 * Close Current Window.
	 * 
	 * @return
	 */
	public void closeCurrentWindow() {
		DriverManager.getCurrent().close();
	}

	/**
	 * Accept Alert
	 * 
	 * @return
	 */
	public String acceptAlert() {

		String alertText = null;
		// Close out Alert popup if any
		try {
			Alert alert = DriverManager.getCurrent().switchTo().alert();
			alertText = alert.getText();
			alert.accept();
		} catch (Exception e) {
		}

		DriverManager.getCurrent().switchTo().defaultContent();
		return alertText;
	}

}
