package exact.sys;

import static exact.ReportLogMain.logError;
import static exact.ReportLogMain.logInfo;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

public class WebDriverFactory {

	private static final long PAGE_LOAD_TIMEOUT = 30;

	/**
	 * Instantiates new WebDriver instance for whatever browser is configured in
	 * Environment.xml
	 */
	public static final WebDriver getConfiguredWebDriver() {
		WebDriver driver = null;
		String executionType = System.getProperty("executionType");

		if (executionType == null) {
			executionType = "Normal";
		}
		String browserType = BrowserType.getBrowserTypeConfiguration();
		logInfo("browserType: " + browserType);

		try {
			if (executionType.equalsIgnoreCase("browserstack")) {
				driver = BrowserType.getBrowserType(browserType).getBrowserStackInstance();
			} else {
				driver = BrowserType.getBrowserType(browserType).getInstance();
			}
		} catch (Exception e) {
			logError("Unable to start browser instance for WebDriver");
			e.printStackTrace();
		}

		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIMEOUT));
		return driver;
	}
}
