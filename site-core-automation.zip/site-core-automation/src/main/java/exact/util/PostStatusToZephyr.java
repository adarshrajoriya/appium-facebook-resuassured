package exact.util;

import static exact.ReportLogMain.logError;
import static exact.ReportLogMain.logInfo;
import static exact.ReportLogMain.logPattern;
import static exact.ReportLogMain.logPatternWithNewline;

import java.util.HashMap;

import org.testng.ITestResult;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

/**
 * This class is used to post test case status to Zephyr scale via REST API
 * 
 * The Authorization token @auth can be modified to any user's API Access token
 * 
 * @author Sandeep Singh
 * @since 05/26/2023
 */
public class PostStatusToZephyr {

	private final static String url = "https://api.zephyrscale.smartbear.com/v2/";
	private final static String projectKey = "EPS";
	private final static String execEndpoint = "testexecutions/";

	private final static String auth = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjb250ZXh0Ijp7ImJhc2VVcmwiOiJodHRwczovL2V4YXMuYXRsYXNzaWFuLm5ldCIsInVzZXIiOnsiYWNjb3VudElkIjoiNzE"
			+ "yMDIwOjg0Y2U4M2FmLWY3MjYtNDY5Zi1iMGJmLTAzZjE2MmI3OWM2MSJ9fSwiaXNzIjoiY29tLmthbm9haC50ZXN0LW1hbmFnZXIiLCJzdWIiOiJjOTNmN"
			+ "WRlMC1mZjMxLTNiNzYtYjAwYi1lNmU1MWFmZTcxOTMiLCJleHAiOjE3MTY2MzUzNTQsImlhdCI6MTY4NTA5OTM1NH0.gqxYxSB7SN3t1RHpdAS8L9dJcMO8PguUMabMW0k8RKw";

	public static void main(String[] args) {
		updateZephyrResults("EPS-R68", "EPS-T715", null);
	}

	/**
	 * This method updates Test case status to Jira Zephyr scale via REST API
	 * 
	 * @param cycleKey    : Test Cycle Key
	 * @param testCaseKey : test Case Key
	 * @param status:     Status to post for Test case
	 */
	public static void updateZephyrResults(String cycleKey, String testCaseKey, ITestResult result) {

		String status = "";
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Pass";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Fail";
		} else if (result.getStatus() == ITestResult.SKIP) {
			status = "Blocked";
		}

		RequestSpecification execIdrequest = RestAssured.given().relaxedHTTPSValidation();
		execIdrequest.baseUri(url);
		execIdrequest.header("Content-Type", "application/json");
		execIdrequest.header("Authorization", auth);

		HashMap<String, String> requestBody = new HashMap<>();
		requestBody.put("testCaseKey", testCaseKey);
		requestBody.put("testCycleKey", cycleKey);
		requestBody.put("projectKey", projectKey);
		requestBody.put("statusName", status);
//		requestBody.put("testScriptResults", status);
		execIdrequest.body(requestBody);

		int executionStatus = execIdrequest.post(execEndpoint).getStatusCode();

		logPattern();

		if (executionStatus == 201) {
			logInfo("Posting test output results to Zephyr: SUCCESS");
			logInfo("Script Name: " + result.getTestClass().getName());
			logInfo("Test Method Name: " + result.getMethod().getMethodName());
			logInfo("Test Cycle Key: " + cycleKey);
			logInfo("Test Case Key: " + testCaseKey);
			logInfo("Status: " + status);
		} else {
			logError("Posting test output results to Zephyr: FAILURE");
			logError("Check API endpoints/logs");
		}

		logPatternWithNewline();
	}
}