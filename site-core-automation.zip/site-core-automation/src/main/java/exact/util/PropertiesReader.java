package exact.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Properties;

public class PropertiesReader extends BasicUtils {

    private static final String defaultPropertiesPath = System.getProperty("user.dir") + "\\src\\main\\resources\\pageProperties";
    private static final HashMap<String, String> propertiesMap = getAllPropertiesFiles(defaultPropertiesPath);

    private static HashMap<String, String> getAllPropertiesFiles(String directoryPath) {
        File directory = new File(directoryPath);
        File[] fileList = directory.listFiles();
        HashMap<String, String> propertiesFilePathMap = new HashMap<>();
        if (fileList != null && fileList.length > 0) {
            for (File file : fileList) {
                if (file.isDirectory()) {
                    propertiesFilePathMap.putAll(getAllPropertiesFiles(file.getAbsolutePath()));
                } else {
                    propertiesFilePathMap.put(file.getName(), file.getAbsolutePath());
                }
            }
        }
        return propertiesFilePathMap;
    }

    private static String getFilePath(String fileName) {
        return propertiesMap.get(fileName + ".properties");
    }

    public static Properties getProperties(String fileName) {
        Properties propertiesFileObject = new Properties();
        try {
            FileInputStream inputStream = new FileInputStream(getFilePath(fileName));
            propertiesFileObject.load(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));
            /*BufferedReader fileReader = new BufferedReader(new FileReader(getFilePath(fileName)));
            propertiesFileObject.load(fileReader);*/
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        return propertiesFileObject;
    }

}
