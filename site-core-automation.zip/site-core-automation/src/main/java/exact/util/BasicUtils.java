package exact.util;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.imageio.ImageIO;

import exact.sys.DriverManager;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class BasicUtils {

	/**
	 * Capture current screenshot and save to local file
	 * 
	 * @return
	 */
	public static String takeScreenshot() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy MMMM dd");
		LocalDateTime now = LocalDateTime.now();
		String jenkinsPath = System.getProperty("jenkinsFilesPath");
		if (jenkinsPath == null) {
			jenkinsPath = "\\\\fileshare\\Applications\\ATH\\Quality Engineering\\Development\\Automation\\Site Core";
		}
		String screenshotPath = jenkinsPath + "/Screenshots/" + dtf.format(now);
		File screenshotFile = new File(screenshotPath);
		screenshotFile.mkdirs();
		dtf = DateTimeFormatter.ofPattern("yyyy_MMMM_dd____hh_mm_ss_SSS_a");
		now = LocalDateTime.now();
		screenshotPath = screenshotPath + "/" + dtf.format(now) + ".jpg";
		try {
			Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
					.takeScreenshot(DriverManager.getCurrent());
			ImageIO.write(screenshot.getImage(), "JPG", new File(screenshotPath));
			return screenshotPath;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
