package exact.util.listeners;

import static exact.ReportLogMain.logError;

import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.Properties;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.FileFileFilter;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import jakarta.mail.BodyPart;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

public class EmailExecutionResults {

	/**
	 * Sends email with logs to user mentioned in config.properties file
	 */
	public static void sendMail() throws Exception {

		final String user = "exacttest2023@gmail.com";
		final String password = "515Ellis!";
		String filepath = TestListener.reportName;
		String recipientEmailAddress = System.getProperty("commaSeparatedEmailAddresses");
		if (recipientEmailAddress == null) {
			recipientEmailAddress = "sansingh@exactsciences.com";
		}
		String recipient = recipientEmailAddress;

		// InternetAddress recipientAddress = new InternetAddress(recipient.trim());

		Properties props = System.getProperties();
		props.put("mail.smtp.host", "rwccas.genomichealth.com");

		Session session = Session.getDefaultInstance(props, new jakarta.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, password);
			}
		});

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(user));
			message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient.trim()));

			String suiteToRun = System.getProperty("suiteXMLFile");
			String suite = "";
			if (suiteToRun.contains("cologuard")) {
				suite = "Cologuard Suite Execution";
			} else if (suiteToRun.contains("regressionSuite")) {
				suite = "Regression Suite Execution";
			}
			message.setSubject("Sitecore " + suite + " Results");

			BodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setContent(TestListener.stringBufferForEmail, "text/html");

			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
			File directory = new File("Logs");
			File[] files = directory.listFiles((FileFilter) FileFileFilter.FILE);
			Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);

			String filename = files[0].getName();
			String attachmentPath = "Logs/";
			// Attaching Log file
			File att = new File(new File(attachmentPath), filename);
			messageBodyPart2.attachFile(att);
			DataSource source = new FileDataSource(att);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(filename);

			// Attaching input file
			MimeBodyPart messageBodyPart3 = new MimeBodyPart();
			File att1 = new File(filepath);
			messageBodyPart3.attachFile(att1);
			DataSource source1 = new FileDataSource(att1);
			messageBodyPart3.setDataHandler(new DataHandler(source1));
			messageBodyPart3.setFileName(att1.getName());

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart1);
			multipart.addBodyPart(messageBodyPart2);
			multipart.addBodyPart(messageBodyPart3);
			message.setContent(multipart);

			// send message
			Transport.send(message);
		} catch (MessagingException | ArrayStoreException ex) {
			logError("Error occurred while sending execution report and logs via email");
		}
	}
}
