package exact.util.listeners;

import static exact.ReportLogMain.logError;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;

public class TestListener implements ITestListener {

	public static String reportName = null;
	public static String stringBufferForEmail = null;
	public static String env = null;
	public static String suite = null;

	public static int passedCount = 0;
	public static int failedCount = 0;
	private static List<String> failedTestList = new ArrayList<>();
	private static List<String> passedTestList = new ArrayList<>();

	private ExtentSparkReporter sparkReporter;
	private ExtentReports reports;
	private ExtentTest test;

	public void configReport() {
		String Timestamp = new SimpleDateFormat("yyyy.MM.dd.hh.mm.ss").format(new Date());
		reportName = "./extent-reports/ExtentReport-" + Timestamp + ".html";
		sparkReporter = new ExtentSparkReporter(reportName);

		reports = new ExtentReports();
		reports.attachReporter(sparkReporter);

		env = "Stage Environment";

		String suiteToRun = System.getProperty("suiteXMLFile");
		if (suiteToRun.contains("cologuard")) {
			suite = "Cologuard Suite Execution";
		} else if (suiteToRun.contains("regressionSuite")) {
			suite = "Regression Suite Execution";
		}

		String author = System.getProperty("executionAuthor");

		if (author == null) {
			author = "QE Offshore Automation Team";
		}
		reports.setSystemInfo("OS", System.getProperty("os.name"));
		reports.setSystemInfo("Browser", System.getProperty("browserType"));
		reports.setSystemInfo("Author", author);
		reports.setSystemInfo("Sitecore Environment", env);
		reports.setSystemInfo("Suite Details", suite);

		sparkReporter.config().setDocumentTitle("Sitecore " + suite + " Results");
		sparkReporter.config().setTheme(Theme.STANDARD);
		sparkReporter.config().setTimelineEnabled(false);
		sparkReporter.viewConfigurer().viewOrder().as(new ViewName[] { ViewName.DASHBOARD, ViewName.TEST,
				ViewName.EXCEPTION, ViewName.AUTHOR, ViewName.DEVICE, ViewName.CATEGORY, ViewName.LOG }).apply();
//		sparkReporter.viewConfigurer()

	}

	public void onStart(ITestContext Result) {
		configReport();
	}

	public void onFinish(ITestContext Result) {
		reports.flush();
		try {
			createResultsTableForEmail(env, suite, passedCount, failedCount, passedTestList, failedTestList);
		} catch (Exception e) {
			logError("Error occurred while creating table for Report Email body.");
		}
	}

	public void onTestFailure(ITestResult result) {
		test = reports.createTest(result.getName());
		failedTestList.add(result.getName());
		test.log(Status.FAIL, MarkupHelper.createLabel("Test failed: " + result.getName(), ExtentColor.RED));
		test.fail(result.getThrowable());
		String sspath = System.getProperty("user.dir") + "//screenshots//" + result.getName() + ".png";
		File screenshotFile = new File(sspath);
		if (screenshotFile.exists()) {
			test.fail("" + test.addScreenCaptureFromPath(sspath));
		}
		failedCount = failedCount + 1;
	}

	public void onTestStart(ITestResult Result) {
	}

	public void onTestSuccess(ITestResult result) {
		test = reports.createTest(result.getName());
		test.log(Status.PASS, MarkupHelper.createLabel("Test passed: " + result.getName(), ExtentColor.GREEN));
		passedCount = passedCount + 1;
		passedTestList.add(result.getName());
	}

	public static void main(String args[]) throws Exception {
		new TestListener().createResultsTableForEmail("Test", "Smoke", 2, 2, Arrays.asList("111", "222"),
				Arrays.asList("444", "333"));
	}

	public void createResultsTableForEmail(String env, String suite, int testPassed, int testFailed,
			List<String> passedTestList, List<String> failedTestList) throws Exception {

		BufferedWriter bwr = new BufferedWriter(new FileWriter("Results.html"));

		stringBufferForEmail = "Hi Team,\r\n" + "\r\n" + "<br>\r\n"
				+ "<p>We have executed Sitecore Automation code on <b>" + env
				+ "</b>. Kindly find the execution summary below.</p>\r\n" + "\r\n" + "\r\n" +

				"<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<style>\r\n" + "table, th, td {\r\n"
				+ "  border: 1px solid black;\r\n" + "  border-collapse: collapse;\r\n" + "}\r\n" + "th, td {\r\n"
				+ "  padding: 5px;\r\n" + "}\r\n" + "th {\r\n" + "  text-align: left;\r\n" + "}\r\n" + "\r\n" + "\r\n"
				+ "</style>\r\n" + "</head>\r\n" + "<body>\r\n" + "\r\n" +

				"<h3>Execution Report</h3>\r\n" + "\r\n" + "<table style=\"width:50%\">\r\n" + "  <tr>\r\n"
				+ "    <th bgcolor=\"#FFB266\" align=\"center\">Suite</th>\r\n"
				+ "    <th bgcolor=\"#FFB266\" align=\"center\">Total Tests</th> \r\n"
				+ "    <th bgcolor=\"#FFB266\" align=\"center\"># Tests Passed</th> \r\n"
				+ "    <th bgcolor=\"#FFB266\" align=\"center\"># Tests Failed</th> \r\n" + "    \r\n" + "  </tr>\r\n"
				+ "  <tr>\r\n" + "    <td>" + suite + "</td>\r\n" + "    <td>" + (testPassed + testFailed) + "</td>\r\n"
				+ "    <td>" + testPassed + "</td>\r\n" + "    <td>" + testFailed + "</td>\r\n"
				+ "  </tr>  </table><br><br>\r\n";

		if (!passedTestList.isEmpty()) {
			stringBufferForEmail = stringBufferForEmail + "<h3>Passed Test Summary</h3>\r\n" + "\r\n"
					+ "<table style=\"width:50%\">\r\n" + "  <tr>\r\n"
					+ "    <th bgcolor=\"#FFB266\" align=\"center\">S. no</th>\r\n"
					+ "    <th bgcolor=\"#FFB266\" align=\"center\">Test Name</th> \r\n" + "    \r\n" + "  </tr>\r\n";
			for (int count = 0; count < passedTestList.size(); count++) {
				stringBufferForEmail = stringBufferForEmail + "  <tr>\r\n" + "    <td>" + (count + 1) + "</td>\r\n"
						+ "    <td>" + passedTestList.get(count) + "</td>\r\n" + " " + "\r\n" + "  </tr>\r\n";
			}
			stringBufferForEmail = stringBufferForEmail + " \r\n" + "</table><br><br>\r\n";
		}

		if (!failedTestList.isEmpty()) {
			stringBufferForEmail = stringBufferForEmail + "<h3>Failed Test Summary</h3>\r\n" + "\r\n"
					+ "<table style=\"width:50%\">\r\n" + "  <tr>\r\n"
					+ "    <th bgcolor=\"#FFB266\" align=\"center\">S. no</th>\r\n"
					+ "    <th bgcolor=\"#FFB266\" align=\"center\">Test Name</th> \r\n" + "    \r\n" + "  </tr>\r\n";
			for (int count = 0; count < failedTestList.size(); count++) {
				stringBufferForEmail = stringBufferForEmail + "  <tr>\r\n" + "    <td>" + (count + 1) + "</td>\r\n"
						+ "    <td>" + failedTestList.get(count) + "</td>\r\n" + " " + "\r\n" + "  </tr>\r\n";
			}
			stringBufferForEmail = stringBufferForEmail + " \r\n" + "</table><br><br>\r\n";
		}

		stringBufferForEmail = stringBufferForEmail + "\r\n"
				+ "Kindly open the attached report in a browser to see the detailed report.<br>\r\n" + "<br/>\r\n"
				+ "Thanks" + "<br/>\r\n" + "Automation Team" + "</body>\r\n" + "</html>\r\n" + "";

		bwr.write(stringBufferForEmail);
		// flush the stream
		bwr.flush();
		// close the stream
		bwr.close();
	}
}
