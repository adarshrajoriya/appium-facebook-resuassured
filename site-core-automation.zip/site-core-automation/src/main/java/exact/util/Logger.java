package exact.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class Logger {

	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public static Log getLogger() {
		try {
			throw new Exception();
		} catch (Exception e) {
			StackTraceElement ste = e.getStackTrace()[1];
			try {
				return LogFactory.getLog(Class.forName(ste.getClassName()));
			} catch (Exception e1) {
				throw new IllegalArgumentException("Exception trying to initialize Logger", e1);
			}
		}
	}

	/**
	 * Prints out the stack.
	 *
	 * @param e1 the e1
	 * @return StringBuilder containing stack.
	 */
	public static StringBuilder printStack(Throwable e1) {
		StringBuilder stackTrace = new StringBuilder();
		StackTraceElement[] stack = e1.getStackTrace();

		for (StackTraceElement stackEntry : stack) {
			stackTrace.append(("\t" + stackEntry.getClassName() + "." + stackEntry.getMethodName() + " ["
					+ stackEntry.getLineNumber() + "]")).append("\n");
		}
		return stackTrace;
	}

	/**
	 * Instantiates a new veeva logger.
	 */
	private Logger() {
	};
}
