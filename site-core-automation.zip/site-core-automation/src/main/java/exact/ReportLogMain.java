package exact;

import org.apache.log4j.Logger;
import org.testng.Reporter;

public class ReportLogMain {
	private static final Logger logger = Logger.getLogger(ReportLogMain.class);

	private enum LogLevel {
		DEBUG, INFO, WARN, ERROR, FATAL, VERIFY
	}

	/**
	 * Logs message into TestNG result and Log4J
	 *
	 * @param sMessage : sMessage
	 * @param level    : level
	 */
	public static void logMessage(String sMessage, LogLevel level) {
		if (level == LogLevel.VERIFY) {
			Reporter.log("=====>" + sMessage);

		} else {
			Reporter.log(level.toString() + " - " + sMessage);
		}

		switch (level) {
		case DEBUG:
			logger.debug(sMessage);
			break;
		case INFO:
			logger.info(sMessage);
			break;
		case WARN:
			logger.warn(sMessage);
			break;
		case ERROR:
			logger.error(sMessage);
			break;
		case FATAL:
			logger.fatal(sMessage);
			break;
		default:
			logger.info(sMessage);
			break;
		}
	}

	/**
	 * Logging a fatal message.
	 *
	 * @param message - the message that will be logged
	 */
	public static void logFatal(String message) {
		logMessage(message, LogLevel.FATAL);
	}

	/**
	 * Logging an error message.
	 *
	 * @param message - the message that will be logged
	 */
	public static void logError(String message) {
		logMessage(message, LogLevel.ERROR);
	}

	/**
	 * Logging a warning message.
	 *
	 * @param message - the message that will be logged
	 */
	public static void logWarn(String message) {
		logMessage(message, LogLevel.WARN);
	}

	/**
	 * Logging an info message.
	 *
	 * @param message - the message that will be logged
	 */
	public static void logInfo(String message) {
		logMessage(message, LogLevel.INFO);
	}

	/**
	 * Logs the pattern
	 */
	public static void logPattern() {
		logMessage("######################################", LogLevel.INFO);
	}

	/**
	 * Logs the pattern
	 */
	public static void logPatternWithNewline() {
		logMessage("######################################\n", LogLevel.INFO);
	}

	/**
	 * Logs the pattern
	 */
	public static void logSectionHeader() {
		logMessage("######################################", LogLevel.INFO);
	}

	/**
	 * Logs the pattern
	 */
	public static void logBlockHeader() {
		logMessage("--------------------------------------", LogLevel.INFO);
	}

	/**
	 * Logging a debug message.
	 *
	 * @param message - the message that will be logged
	 */
	public static void logDebug(String message) {
		logMessage(message, LogLevel.DEBUG);
	}

	/**
	 * Logging a verify message.
	 *
	 * @param message - the message that will be logged
	 */
	public static void logVerify(String message) {
		logMessage(message, LogLevel.VERIFY);
	}
}
