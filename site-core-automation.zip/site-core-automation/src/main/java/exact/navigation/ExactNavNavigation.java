package exact.navigation;

import static exact.ReportLogMain.logInfo;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import exact.Element;
import exact.sys.Driver;
import exact.util.BasicUtils;
import exact.util.PropertiesReader;
import exact.util.Sleeper;

public class ExactNavNavigation {

	/**
	 * Used for interacting w/ a web page w/ selenium tests
	 */
	protected Driver driver = new Driver();

	protected Properties exactPagesProperties = PropertiesReader.getProperties("ExactPages");
	protected Properties cologuardPagesProperties = PropertiesReader.getProperties("cologuard");
	protected Properties corporateUkPagesProperties = PropertiesReader.getProperties("corporateUK");
	protected Properties oglPagesProperties = PropertiesReader.getProperties("ogl");
	protected Properties oiqenCHPagesProperties = PropertiesReader.getProperties("oiqenCH");
	protected Properties productsitePagesProperties = PropertiesReader.getProperties("productsite");
	protected Properties oiqdeDEPagesProperties = PropertiesReader.getProperties("oiqdeDE");

	protected final By cologuardHomepageIconBy = By
			.cssSelector(cologuardPagesProperties.getProperty("cologuardHomepageIconBy"));
	protected final By cologuardHompageNavBy = By
			.cssSelector(cologuardPagesProperties.getProperty("cologuardHompageNavBy"));

	protected final By corporateUkHomepageIconBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("corporateUkHomepageIconBy"));
	protected final By corporateUkHompageNavBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("corporateUkHompageNavBy"));

	protected final By cologuardHompageSubOptionsBy = By
			.cssSelector(cologuardPagesProperties.getProperty("cologuardHompageSubOptionsBy"));
	private final By readMoreLinkBy = By.xpath(cologuardPagesProperties.getProperty("readMoreLinkBy"));
	private final By readLessLinkBy = By.xpath(cologuardPagesProperties.getProperty("readLessLinkBy"));
	private final By readMoreContentBy = By.cssSelector(cologuardPagesProperties.getProperty("readMoreContentBy"));

	protected final By oglHomepageIconBy = By.cssSelector(oglPagesProperties.getProperty("oglHomepageIconBy"));
	protected final By oglHompageNavBy = By.cssSelector(oglPagesProperties.getProperty("oglHompageNavBy"));

	private final By hyperLinksBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("hyperLinksBy"));
	private final By hyperLinks2By = By.cssSelector(oiqdeDEPagesProperties.getProperty("hyperLinks2By"));
	private final By oiqSubMenuNavBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("oiqSubMenuNavBy"));
	private final By linksOnRightPaneBy = By.cssSelector(oiqdeDEPagesProperties.getProperty("linksOnRightPaneBy"));

	public String getReadMoreContent() {
		return Element.getText(readMoreContentBy);
	}

	public boolean isCologuardHomepageDisplayed() {
		return Element.isElementDisplayed(cologuardHomepageIconBy) && Element.isElementDisplayed(cologuardHompageNavBy);
	}

	public boolean isCorporateUkHomepageDisplayed() {
		return Element.isElementDisplayed(corporateUkHomepageIconBy)
				&& Element.isElementDisplayed(corporateUkHompageNavBy);
	}

	public void clickTopNavOption(String option) {
		List<WebElement> listElements = Element.getMultiple(cologuardHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(option)) {
				Element.loadAndClick(webElement);
				break;
			}
		}
		Element.waitForDOMToLoad();
		logInfo("Clicked on '" + option + "' Option");

	}

	public void clickHeaderOption(String optionLabel) throws Exception {
		WebElement foundElement = Element.getFromHtml(linksOnRightPaneBy, optionLabel);
		if (foundElement != null) {
			Element.loadAndClick(foundElement);
			Element.waitForDOMToLoad();
			logInfo("Clicked on '" + optionLabel + "' Option");
			return;
		}
		throw new Exception(
				"Unable to find '" + optionLabel + "' Option on the page. - " + BasicUtils.takeScreenshot());
	}

	public void selectSubOptionFromTopNavOptions(String parentOption, String optionToSelect) throws Exception {
		List<WebElement> listElements = Element.getMultiple(cologuardHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(parentOption)) {
				Element.loadAndClick(webElement);
				Element.waitForVisible(cologuardHompageSubOptionsBy);
				List<WebElement> subOptions = Element.getElementsFromWithin(webElement, cologuardHompageSubOptionsBy);
				for (WebElement subOption : subOptions) {
					if (Element.getText(subOption).equalsIgnoreCase(optionToSelect)) {
						Element.loadAndClick(subOption);
						Element.waitForDOMToLoad();
						logInfo("Clicked on '" + optionToSelect + "' option under '" + parentOption + "'");
						return;
					}
				}
			}
		}
		throw new Exception("Unable to find '" + parentOption + "/" + optionToSelect + "' option combo in top nav. - "
				+ BasicUtils.takeScreenshot());
	}

	public void selectSubOptionFromOIQSiteTopNavOptions(String parentOption, String optionToSelect) throws Exception {
		List<WebElement> listElements = Element.getMultiple(cologuardHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(parentOption)) {
				Element.loadAndClick(webElement);
				Element.waitForVisible(oiqSubMenuNavBy);
				List<WebElement> subOptions = Element.getElementsFromWithin(webElement, oiqSubMenuNavBy);
				for (WebElement subOption : subOptions) {
					if (Element.getText(subOption).equalsIgnoreCase(optionToSelect)) {
						Element.mouseHover(subOption);
						Element.loadAndClick(subOption);
						Element.waitForDOMToLoad();
						logInfo("Clicked on '" + optionToSelect + "' option under '" + parentOption + "'");
						return;
					}
				}
			}
		}
		throw new Exception("Unable to find '" + parentOption + "/" + optionToSelect + "' option combo in top nav. - "
				+ BasicUtils.takeScreenshot());
	}

	public void selectSubOptionFromOIQSiteTopNavOptions(String parentOption, String optionToSelect,
			String subOptionToSelect) throws Exception {
		List<WebElement> listElements = Element.getMultiple(cologuardHompageNavBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(parentOption)) {
				Element.loadAndClick(webElement);
				Element.waitForVisible(cologuardHompageNavBy);
				List<WebElement> subOptions = Element.getElementsFromWithin(webElement, cologuardHompageNavBy);
				for (WebElement subOption : subOptions) {
					if (Element.getText(subOption).equalsIgnoreCase(optionToSelect)) {
						Element.loadAndClick(subOption);
						Element.waitForVisible(cologuardHompageNavBy);
						List<WebElement> subOptionsSub = Element.getElementsFromWithin(webElement,
								cologuardHompageNavBy);
						for (WebElement subOptionSub : subOptionsSub) {
							if (Element.getText(subOptionSub).equalsIgnoreCase(subOptionToSelect)) {
								Element.loadAndClick(subOptionSub);
								Element.waitForDOMToLoad();
								logInfo("Clicked on '" + optionToSelect + "' option under '" + parentOption + "'");
								return;
							}
						}

					}
				}
			}
		}
		throw new Exception("Unable to find '" + parentOption + "/" + optionToSelect + "' option combo in top nav. - "
				+ BasicUtils.takeScreenshot());
	}

	public void clickOiqHyperLink(String option) throws Exception {
		List<WebElement> listElements = Element.getMultiple(hyperLinksBy);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(option)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + option + "' hyperlink");
				return;
			}
		}
		throw new Exception("Unable to find '" + option + "' hyperlink " + BasicUtils.takeScreenshot());

	}

	public void clickOiqHyperLink2(String option) throws Exception {
		List<WebElement> listElements = Element.getMultiple(hyperLinks2By);
		for (WebElement webElement : listElements) {
			if (Element.getText(webElement).equalsIgnoreCase(option)) {
				Element.loadAndClick(webElement);
				Element.waitForDOMToLoad();
				logInfo("Clicked on '" + option + "' hyperlink");
				return;
			}
		}
		throw new Exception("Unable to find '" + option + "' hyperlink " + BasicUtils.takeScreenshot());

	}

	public void clickReadMoreLink() {
		WebElement element = Element.waitForVisible(readMoreLinkBy);
		Element.loadAndClick(element);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(2);
		logInfo("Clicked on 'Read More' link");
	}

	public void clickReadLessLink() {
		WebElement element = Element.waitForVisible(readLessLinkBy);
		Element.loadAndClick(element);
		Element.waitForDOMToLoad();
		Sleeper.sleepTightInSeconds(2);
		logInfo("Clicked on 'Read Less' link");
	}

	public boolean isReadLessDisplayed() {
		return Element.isElementDisplayed(readLessLinkBy);
	}

	public boolean isReadMoreDisplayed() {
		return Element.isElementDisplayed(readMoreLinkBy);
	}

	public boolean isOglHomepageDisplayed() {
		return Element.isElementDisplayed(oglHomepageIconBy) && Element.isElementDisplayed(oglHompageNavBy);
	}

}
