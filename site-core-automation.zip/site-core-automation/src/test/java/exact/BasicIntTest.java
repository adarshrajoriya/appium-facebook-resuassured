package exact;

import static exact.ReportLogMain.logError;
import static exact.ReportLogMain.logInfo;

import org.openqa.selenium.By;
//import org.openqa.selenium.bidi.log.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;

import exact.ath.cologuard.CologuardHomepage;
import exact.ath.productsite.ProductsiteHomepage;
import exact.navigation.ExactNavNavigation;
import exact.sys.Driver;
import exact.sys.DriverManager;
import exact.util.BasicUtils;
import exact.util.listeners.EmailExecutionResults;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath:/META-INF/spring/applicationContext.xml" })
public class BasicIntTest extends ExactNavNavigation {// extends AbstractTestNGSpringContextTests {

	private static final Logger log = LoggerFactory.getLogger(BasicIntTest.class);
	protected final CologuardHomepage cologuardHomepage = new CologuardHomepage();
	protected final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();

	protected final By acceptCookiesBy = By.cssSelector(cologuardPagesProperties.getProperty("acceptCookiesBy"));

	protected final By acceptCookiesCorporateUkBy = By
			.cssSelector(corporateUkPagesProperties.getProperty("acceptCookiesCorporateUkBy"));

	protected final By acceptCookiesOglBy = By.cssSelector(oglPagesProperties.getProperty("acceptCookiesOglBy"));

	protected final String cologuardHomePageURL = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	/**
	 * Determines whether the browser is closed at the end of a testing session.
	 * Useful for when you're constructing a test and want the browser to stay open
	 * after it ends/fails so you can examine the state the browser was in.
	 */
	private boolean closeBrowser = true;

	public void acceptCookies() {
		if (Element.isElementDisplayed(acceptCookiesBy)) {
			Element.loadAndClick(acceptCookiesBy);
		}
	}

	public void acceptCookiesCorporateUk() {
		if (Element.isElementDisplayed(acceptCookiesCorporateUkBy)) {
			Element.loadAndClick(acceptCookiesCorporateUkBy);
		}
	}

	public void acceptCookiesOgl() {
		if (Element.isElementDisplayed(acceptCookiesOglBy)) {
			Element.loadAndClick(acceptCookiesOglBy);

		}
	}

	/**
	 * Url to go to for login before all tests are run. If you don't want to go to a
	 * login page, just leave this alone and it will be ignored.
	 */
	protected String loginUrl;
	/**
	 * Username to login with (at whatever {@link #loginUrl} points to)
	 */
	protected String username;
	/**
	 * Password to login with (at whatever {@link #loginUrl} points to)
	 */
	protected String password;

	protected ExactNavNavigation navigation;

	// Error flag
	private boolean errorFlag = false;

	// First assertion error
	private static AssertionError firstAssertionError = null;

	// First captured screenshot
	private static String firstScreenshot = null;

	// Detail message for AssertionError
	private StringBuffer errorLog = new StringBuffer();

	/**
	 * Creates a test which will login into
	 * <code>VaultInfo.getDefaultVault().getUrl()</code> as the username defined in
	 * the xml config as "defaultVaultAdminUsername" w/ the password
	 * "defaultVaultPassowrd". The domain of the vault you'll log into is defined in
	 * the xml config "vmc.domain.name"
	 */
	public BasicIntTest() {
	}

	/**
	 * @return returns current webpage URL
	 */
	public String getPageURL() {
		return driver.getURL();
	}

	/**
	 * @return returns current webpage URL
	 */
	public void pressBack() {
		driver.back();
	}

	public void checkForExUSSite(String url) {
		driver.open(url);
		Element.waitForDOMToLoad();
		while (driver.getURL().contains("ex-us")) {
			logInfo("Ex-US site detected, closing the browser and relaunching");
			driver.close();
			DriverManager.getCurrent();
			driver.open(url);
		}
	}

	/**
	 * Opens up a browser and loads the URL
	 */
	public void setupURL(String loginUrl) {

		// Set specified browserType if provided
		String browserType = System.getProperty("browserType");
		if (browserType != null) {
			System.setProperty("browserType", browserType);
		}

		String current = this.getClass().getName();
		System.out.println("BeforeClass Opening: " + current.toString());
		driver = new Driver();

//		this.loginUrl = exactPagesProperties.getProperty("AnnualReportURL");

		navigation = new ExactNavNavigation();
		Element.openURL(loginUrl);
	}

	/**
	 * Logs out and closes our driver's browser after all tests in a class are run
	 */
	@AfterClass(alwaysRun = true)
	public void closeTheBrowser() {
		if (closeBrowser) {
			try {
				// driver.open(this.loginUrl);
				// logout();
				driver.close();
			} catch (Exception e) {
				System.out.println("Problem logging out: " + e.getMessage() + " - " + BasicUtils.takeScreenshot());
			}

		}
		// driver.setTimeoutSeconds(20);
	}

	/**
	 * Send Execution Results Email after execution of suite
	 */
	@AfterSuite(alwaysRun = true)
	public void cleanup() {
		if (closeBrowser) {
			try {
				EmailExecutionResults.sendMail();
				driver.close();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * Verify test Results and raise AssertionError on failure. Similar to
	 * verifySafely() but will not continue on failures.
	 * 
	 * @param actualValue   - The actual test value
	 * @param expectedValue - The expected test value
	 * @param description   - The description of the test verification
	 */
	protected void verifyFatal(Object actualValue, Object expectedValue, String description) {
		verifySafely(actualValue, expectedValue, description);
		throwAssertionError();
	}

	/**
	 * Verify test result and print the report log accordingly. Screenshot is also
	 * captured for failed verification.
	 * 
	 * @param actualValue   - The actual test value
	 * @param expectedValue - The expected test value
	 * @param description   - The description of the test verification
	 */
	protected void verifySafely(Object actualValue, Object expectedValue, String description) {
		try {
			Assert.assertEquals(actualValue, expectedValue, description);
			if (expectedValue.equals(true)) {
				logInfo("SUCCESS: " + description + "");
			} else {
				logInfo("SUCCESS: " + description + ". VALUE: \"" + actualValue + "\"");
			}

		} catch (AssertionError ae) {

			logError("FAILED: " + description + ". ACTUAL: \"" + actualValue + "\", EXPECTED: \"" + expectedValue
					+ "\"");

			errorFlag = true;

			// Keep the first exception that occurred so that we re-throw it in
//			 throwAssertionErrorOnFailure();
			if (firstAssertionError == null) {
				firstAssertionError = ae;
			}

			// Capture screenshot and save to local file
			String screenshot = BasicUtils.takeScreenshot();

			// Keep the screenshot for the first exception that occurred so that
			// we add it to the message
			// in throwAssertionErrorOnFailure()
			if (firstScreenshot == null) {
				firstScreenshot = screenshot;
			}

			errorLog.append("\n" + description + ": " + ae.getMessage() + " : " + screenshot);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Throws AssertionError if errorFlag is true. This method should be called at
	 * the end of each test.
	 * 
	 * @throws AssertionError
	 */
	protected void throwAssertionErrorOnFailure() throws AssertionError {

		if (errorFlag) {
			errorFlag = false; // Reset error flag for other tests
			errorLog = new StringBuffer(); // Reset error log
			if (firstAssertionError != null) {
				AssertionError ae = new AssertionError(firstAssertionError.getMessage() + " : " + firstScreenshot);
				ae.setStackTrace(firstAssertionError.getStackTrace());
				firstAssertionError = null; // Reset firstAssertionError
				firstScreenshot = null; // Reset firstScreenshot
				log.error("Contents of errorLog: " + errorLog);
				// Throw the first assertion error instead of the whole stack
				// trace
				throw ae;
			}
			throw new AssertionError(errorLog);
		}
	}

	/**
	 * Throws AssertionError if errorFlag is true. It will not throw any error if
	 * dialog remains open.
	 * 
	 * @throws AssertionError
	 */
	protected void throwAssertionError() throws AssertionError {
		if (errorFlag) {
			errorFlag = false; // Reset error flag for other tests
			errorLog = new StringBuffer(); // Reset error log
			if (firstAssertionError != null) {
				AssertionError ae = new AssertionError(firstAssertionError.getMessage() + " : " + firstScreenshot);
				ae.setStackTrace(firstAssertionError.getStackTrace());
				firstAssertionError = null; // Reset firstAssertionError
				firstScreenshot = null; // Reset firstScreenshot
				log.error("Contents of errorLog: " + errorLog);
				// Throw the first assertion error instead of the whole stack
				// trace
				throw ae;
			}
			throw new AssertionError(errorLog);
		}
	}
}
