package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.AboutScreeningPage;
import exact.util.PostStatusToZephyr;
import exact.util.Sleeper;

/**
 * This class verifies About screening page verifications
 * 
 * @userstory #303911 Task#304658
 * @author Sandeep Singh
 * @since 05/10/2023
 */
public class AboutScreeningTest extends BasicIntTest {

	private final AboutScreeningPage aboutScreeningPage = new AboutScreeningPage();

	private final String aboutScreeningPageURL = cologuardPagesProperties.getProperty("aboutScreeningPageURL");
	private final String getCologuardURL = cologuardPagesProperties.getProperty("getCologuardURL");

	private final String whyCologuard = cologuardPagesProperties.getProperty("whyCologuard");
	private final String aboutScreening = cologuardPagesProperties.getProperty("aboutScreening");

	private final String getCologuardPageTitle = cologuardPagesProperties.getProperty("getCologuardPageTitle");
	private final String aboutScreeningPageTitle = cologuardPagesProperties.getProperty("aboutScreeningPageTitle");
	private final String textForTrueSelectedFlag = cologuardPagesProperties.getProperty("textForTrueSelectedFlag");
	private final String textForFalseSelectedFlag = cologuardPagesProperties.getProperty("textForFalseSelectedFlag");
	private final String initialTime = "0:00";
	private String finalTime;

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T719";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyAboutScreeningPageData() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");

		acceptCookies();

		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, aboutScreening);

		verifySafely(driver.getURL(), aboutScreeningPageURL, "'About Screening' page is displayed");
		verifySafely(driver.getTitle(), aboutScreeningPageTitle,
				aboutScreeningPageTitle + " is displayed as page title");

		aboutScreeningPage.clickLearnFactsForColonCancerVideo();
		logInfo("Played video next to 'Colon cancer: let's learn the facts'");
		Sleeper.sleepTightInSeconds(12);
		aboutScreeningPage.clickLearnFactsForColonCancerVideo();
		logInfo("Paused video next to 'Colon cancer: let's learn the facts'");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Learn Facts For Colon Cancer Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		aboutScreeningPage.clickWhyScreeningMattersBtn();

		aboutScreeningPage.clickWhyScreeningMattersVideo();
		logInfo("Played video next to 'Why screening matters'");
		Sleeper.sleepTightInSeconds(12);
		aboutScreeningPage.clickWhyScreeningMattersVideo();
		logInfo("Paused video next to 'Why screening matters'");
		finalTime = aboutScreeningPage.getVideoTime(1);
		verifySafely(!initialTime.equals(finalTime), true,
				"Why Screening Matters Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		aboutScreeningPage.clickWaysToGetScreenedBtn();

		aboutScreeningPage.clickWhoShouldGetScreenedBtn();

		aboutScreeningPage.selectTrueFalseFlag(1, true);
		Sleeper.sleepTightInSeconds(2);
		verifySafely(aboutScreeningPage.getFlagResultText(1).contains(textForTrueSelectedFlag), true,
				textForTrueSelectedFlag + " text is displayed when selecting true for first true/false flag");

		aboutScreeningPage.selectTrueFalseFlag(1, false);
		Sleeper.sleepTightInSeconds(2);
		verifySafely(aboutScreeningPage.getFlagResultText(1).contains(textForFalseSelectedFlag), true,
				textForFalseSelectedFlag + " text is displayed when selecting false for first true/false flag");
		logInfo("Response displays text as per selected flag");

		aboutScreeningPage.clickHowToGetCologuard();

		verifySafely(driver.getURL(), getCologuardURL, "'How to get Cologuard' page is displayed");
		verifySafely(driver.getTitle(), getCologuardPageTitle, getCologuardPageTitle + " is displayed as page title");

		driver.back();
		logInfo("Navigated back to About screening page");

		aboutScreeningPage.clickWhyScreeningMattersBtn();

		throwAssertionErrorOnFailure();
	}
}
