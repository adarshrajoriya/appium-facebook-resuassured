package exact.ath.sitecore.labs;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.LabsWebsite;
import exact.sys.Driver;

/**
 * Refer User Story #301265 ,#EPS-T394 {@summary Verify the Home page of Labs
 * Website} 
 * 
 * @author Manpreet Panesar
 *
 */
public class LabsHomePageTest extends BasicIntTest {
	private final Driver driver = new Driver();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final LabsWebsite labsWebsite = new LabsWebsite();
	private final String labsWebsiteURL = exactPagesProperties.getProperty("LabsWebsiteURL");
	private final String labsWebsiteHomeTitleValue = exactPagesProperties.getProperty("LabsWebsiteHomeTitleValue");
	private final String labClientServicesPageTitleValue = exactPagesProperties
			.getProperty("LabClientServicesPageTitleValue");
	private final String qualityAndCompliancePageTitleValue = exactPagesProperties
			.getProperty("QualityAndCompliancePageTitleValue");
	private final String aboutUsPageTitleValue = exactPagesProperties.getProperty("AboutUsPageTitleValue");
	private final String nCT01397747LinkText = exactPagesProperties.getProperty("NCT01397747LinkText");
	private final String newEnglandJournalofMedicineLinkText = exactPagesProperties
			.getProperty("NewEnglandJournalofMedicineLinkText");
	private final String clinicalTrialsSiteURL = exactPagesProperties.getProperty("ClinicalTrialsSiteURL");
	private final String cologuardhcpSiteURL = exactPagesProperties.getProperty("CologuardhcpSiteURL");
	private final String orderCologuardByFaxIconCardValue = exactPagesProperties
			.getProperty("OrderCologuardByFaxIconCardValue");
	private final String epiccareLinkProviderPortalIconCardValue = exactPagesProperties
			.getProperty("EpiccareLinkProviderPortalIconCardValue");
	private final String ordeFormPageURL = exactPagesProperties.getProperty("OrdeFormPageURL");
	private final String epiccarelinkSiteURL = exactPagesProperties.getProperty("EpiccarelinkSiteURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void labsHomePageTest() {
		logBlockHeader();
		setupURL(labsWebsiteURL);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		verifySafely(labsWebsite.isHomeMenuHeaderDisplayed(), true,
				"'Home' Menu is displayed in header section on the page");
		verifySafely(labsWebsite.isLabClientServicesMenuHeaderDisplayed(), true,
				"'Lab Client Services' Menu is displayed in header section on the page");
		verifySafely(labsWebsite.isQualityAndComplianceMenuHeaderDisplayed(), true,
				"'Quality and Compliance' Menu is displayed in header section on the page");
		verifySafely(labsWebsite.isAboutUsMenuHeaderDisplayed(), true,
				"'About Us' Menu is displayed in header section on the page");
		labsWebsite.clickLabClientServicesMenuOption();
		logInfo("Clicked on 'Lab Client Services' Menu Option");
		verifySafely(labsWebsite.getPageTitle(), labClientServicesPageTitleValue, "'Lab Client Services' Page Title");
		labsWebsite.clickQualityAndComplianceMenuOption();
		logInfo("Clicked on 'Quality and Compliance' Menu Option");
		verifySafely(labsWebsite.getPageTitle(), qualityAndCompliancePageTitleValue,
				"'Quality Assurance Policy' Page Title");
		labsWebsite.clickAboutUsMenuOption();
		logInfo("Clicked on 'About Us' Menu Option");
		verifySafely(labsWebsite.getPageTitle(), aboutUsPageTitleValue, "'About Us' Page Title ");
		labsWebsite.clickHomeMenuOption();
		logInfo("Clicked on 'Home' Menu Option");
		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "'Home' Page Title ");
		verifySafely(labsWebsite.getNCT01397747LinkDisplayed(), nCT01397747LinkText, "'NCT01397747' Link is Displayed");
		verifySafely(labsWebsite.getNewEnglandJournalofMedicineLinkDisplayed(), newEnglandJournalofMedicineLinkText,
				"'New England Journal of Medicine' Link is Displayed ");
		labsWebsite.clickNCT01397747Link();
		logInfo("Clicked on 'NCT01397747' Link");
		verifySafely(driver.getURL(), clinicalTrialsSiteURL, "After clicking on 'NCT01397747' link navigate to");
		driver.back();
		labsWebsite.clickNewEnglandJournalofMedicineLink();
		logInfo("Clicked on 'New England Journal of Medicine' Link");
		verifySafely(driver.getURL(), cologuardhcpSiteURL,
				"After clicking on 'New England Journal of Medicine' link navigate to");
		driver.back();
		verifySafely(labsWebsite.getOrderCologuardByFaxIconCardDisplayed(), orderCologuardByFaxIconCardValue,
				"'ORDER COLOGUARD BY FAX' Icon card Displayed");
		verifySafely(labsWebsite.getEpiccareLinkProviderPortalIconCardDisplayed(),
				epiccareLinkProviderPortalIconCardValue, "'EPICCARE LINK PROVIDER PORTAL' Icon card Displayed");
		labsWebsite.clickDownloadAnOrderFormButton();
		logInfo("Clicked on 'ORDER COLOGUARD BY FAX' Icon card 'Download An Order From' button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), ordeFormPageURL, "'Order Form' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		labsWebsite.clickSetUpMyEpiccareLinkProviderPortalButton();
		logInfo("Clicked on 'EPICCARE LINK PROVIDER PORTAL' Icon card 'Set Up My Epiccare Link Provider Portal' button");
		verifySafely(driver.getURL(), epiccarelinkSiteURL, "'Epiccare' Page URL matches");
		driver.back();
		verifySafely(labsWebsite.isCALL18448708870Displayed(), true, "'CALL 1-844-870-8870' Button is displayed");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}
}
