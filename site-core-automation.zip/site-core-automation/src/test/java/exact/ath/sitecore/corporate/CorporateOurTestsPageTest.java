package exact.ath.sitecore.corporate;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.sys.Driver;

public class CorporateOurTestsPageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CorporateWebsiteTitleValue");
	private final String cologaurdSiteURL = exactPagesProperties.getProperty("CologaurdWebsiteURL");
	private final String refrenceURL = exactPagesProperties.getProperty("RefrenceWebsiteURL");
	private final String oncoextrapageURL = exactPagesProperties.getProperty("PrecisionOncologyURL");
	private final String oncogaurdLiverSiteURL = exactPagesProperties.getProperty("OncogaurdLiverWebSiteURL");
	private final String ocotypeBreastSiteURL = exactPagesProperties.getProperty("OcotypeBreastWebsiteURL");
	private final String ocotypeRecurrenceSiteURL = exactPagesProperties.getProperty("OcotypeRecurrenceWebsiteURL");
	private final String ocotypeColonRecurrenceSiteURL = exactPagesProperties
			.getProperty("OcotypeColonRecurrenceWebsiteURL");
	private final String riskguardPageLearnMoreAboutPreventiongenticsSiteURL = exactPagesProperties
			.getProperty("RiskguardPageLearnMoreAboutPreventiongenticsWebsiteURL");
	private final String riskguardInsuranceCoveragSiteURL = exactPagesProperties
			.getProperty("RiskguardInsuranceCoveragWebsiteURL");
	private final String downloadAsamplePatientReportPageTitleBy = exactPagesProperties
			.getProperty("DownloadAsamplePatientReportPageTitle");
	private final String downloadRiskguardFactSheetTitleBy = exactPagesProperties
			.getProperty("DownloadRiskguardFactSheetTitle");
	private final String genomemedicalSiteURL = exactPagesProperties.getProperty("GenomemedicalWebsiteURL");
	private final String downloadRiskguardTheFactSheetTitleBy = exactPagesProperties
			.getProperty("DownloadRiskguardTheFactSheetTitle");
	private final String downloadOrderFormTitleBy = exactPagesProperties.getProperty("DownloadOrderFormTitle");
	private final String downloadaSamplePatientReportTitleBy = exactPagesProperties
			.getProperty("DownloadaSamplePatientReportTitle");
	private final String preventiongeneticsSiteURL = exactPagesProperties.getProperty("PreventiongeneticsWebsiteURL");
	private final String preventionGeneticsSiteURL = exactPagesProperties.getProperty("PreventionGeneticsWebsiteURL");
	private final String preventiongeneticsCertificationSiteURL = exactPagesProperties
			.getProperty("PreventiongeneticsCertificationWebsiteURL");
	private final String contactUSSecondCardLearnMoreForPatientsTitleBy = exactPagesProperties
			.getProperty("ContactUSSecondCardLearnMoreForPatientsTitle");
	private final String loginUrl = exactPagesProperties.getProperty("CorporateWebURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void corporateOurTestsPageTest() {

		closeTheBrowser();
		setupURL(loginUrl);
		logBlockHeader();
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		corporateWebsite.clickOurTestMenuOption();
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'Our Tests' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' header is highlighted on the page");
		verifySafely(corporateWebsite.isCologuardRxOnlyDispalyed(), true,
				"'COLOGUARD RX ONLY' Test icon card is Displayed");
		verifySafely(corporateWebsite.isoncoExtraDisplayed(), true, "'ONCOEXTRA' Test icon card is Displayed");
		verifySafely(corporateWebsite.isOncoguardLiverDisplayed(), true,
				"'Oncoguard Liver' Test icon card is Displayed");
		verifySafely(corporateWebsite.isBreastDCISscoreDisplayed(), true,
				"'OncoType DX Breast DCIS Score' Test icon card is Displayed");
		verifySafely(corporateWebsite.isBreastRecurrenceScoreDisplayed(), true,
				"'OncoType DX Breast Recurrence Score' Test icon card is Displayed");
		verifySafely(corporateWebsite.isColonRecurrenceScoreDisplayed(), true,
				"'OncoType DX Colon Recurrence Score' Test icon card is Displayed");
		verifySafely(corporateWebsite.isRiskgaurdDisplayed(), true, "'Riskgaurd' Test icon card is Displayed");
		corporateWebsite.clickColugaurdRXOnlyCardLearnMoreLink();
		verifySafely(corporateWebsite.isColugaurdRxOnlyPageDisplayed(), true, "'Colugaurd Rx Only' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		verifySafely(corporateWebsite.isCologaurdOptionHighlightedDisplayed(), true,
				"'Cologaurd' option is highlighted on the page");
		corporateWebsite.clickVisitColugaurdRXLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(cologaurdSiteURL), true,
				"'Cologaurd.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		corporateWebsite.clickExactSciencesLogo();
		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.clickCologaurdOption();
		verifySafely(corporateWebsite.isColugaurdRxOnlyPageDisplayed(), true, "'Colugaurd Rx Only' Page is displayed");
		verifySafely(corporateWebsite.isStoolDNAIsolationcardDisplayed(), true,
				"'Stool DNA Isolation' Icon card is Displayed");
		verifySafely(corporateWebsite.isDNAstabilitytechnologycardDisplayed(), true,
				"'DNA Stability Technology' Icon card is Displayed");
		verifySafely(corporateWebsite.isDNAbiomarkerdetectioncardDisplayed(), true,
				"'DNA Biomarker Detection' Icon card is Displayed");
		verifySafely(corporateWebsite.isHemoglobinbiomarkerdetectionandstabilitytechnologycardDisplayed(), true,
				"'Hemoglobin biomarker detection and stability technology' Icon card is Displayed");
		verifySafely(corporateWebsite.isPowerfulMechanicalAlgorithmcardDisplayed(), true,
				"'Powerful Mechanical Algorithm' Icon card is Displayed");
		corporateWebsite.clickStoolDNAIsolationcard();
		verifySafely(corporateWebsite.isStoolDNAIsolationSilkySliderDisplayed(), true,
				"'Stool DNA Isolation' Silky Slider is Displayed");
		corporateWebsite.clickDNAstabilitytechnologySilkySlider();
		verifySafely(corporateWebsite.isDNAstabilitytechnologySilkySliderDisplayed(), true,
				"'DNA Stability Technology' Silky Slider is Displayed");
		corporateWebsite.clickDNABiomarkerDetectionSilkySlider();
		verifySafely(corporateWebsite.isDNAbiomarkerdetectionSilkySliderDisplayed(), true,
				"'DNA Biomarker Detection' Sliky Slider is Displayed");
		corporateWebsite.clickHemoglobinbiomarkerdetectionandstabilitytechnologySilkySlider();
		verifySafely(corporateWebsite.isHemoglobinbiomarkerdetectionandstabilitytechnologySilkySliderDisplayed(), true,
				"'Hemoglobin biomarker detection and stability technology' Silky Slider is Displayed");
		corporateWebsite.clickPowerfulMechanicalAlgorithmSilkySlider();
		verifySafely(corporateWebsite.isPowerfulMechanicalAlgorithmSilkySliderDisplayed(), true,
				"'Powerful Mechanical Algorithm' Silky Slider is Displayed");
		corporateWebsite.clickReferenceLinkOnOurTest();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(refrenceURL), true,
				"'cancer.org' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		corporateWebsite.clickExactSciencesLogo();
		corporateWebsite.clickOurTestMenuOption();
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'Our Tests' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' header is highlighted on the page");
		corporateWebsite.clickOncoExtraCardLearnMoreLink();
		verifySafely(corporateWebsite.isOncoextraPageDisplayed(), true, "'OncoExtra' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		verifySafely(corporateWebsite.isOncoextraOptionHighlightedDisplayed(), true,
				"'OncoExtra' option is highlighted on the page");
		corporateWebsite.clickoncextrapageLearnMoreLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(oncoextrapageURL), true,
				"'Precision Oncology' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickExactSciencesLogo();
		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.clickOncoextraOption();
		verifySafely(corporateWebsite.isOncoextraPageDisplayed(), true, "'OncoExTra' Page is displayed");
		verifySafely(corporateWebsite.isUltraComprehensiveGenomicProfilingcardDisplayed(), true,
				"'Ultra-Comprehensive Genomic Profiling' Icon card is Displayed");
		verifySafely(corporateWebsite.isPatientMatchedTumorNormalSequencingcardDisplayed(), true,
				"'Patient Matched Tumor-Normal Sequencing' Icon card is Displayed");
		verifySafely(corporateWebsite.isClinicallyActionablecardDisplayed(), true,
				"'Clinically Actionable' Icon card is Displayed");
		corporateWebsite.clickUltraComprehensiveGenomicProfilingcard();
		verifySafely(corporateWebsite.isUltraComprehensiveGenomicProfilingSilkySliderDisplayed(), true,
				"'Ultra-Comprehensive Genomic Profiling' Silky Slider is Displayed");
		corporateWebsite.clickPatientMatchedTumorNormalSequencingcard();
		verifySafely(corporateWebsite.isPatientMatchedTumorNormalSequencingSilkySliderDisplayed(), true,
				"'Patient Matched Tumor-Normal Sequencing' Silky Slider is Displayed");
		corporateWebsite.clickClinicallyActionablecard();
		verifySafely(corporateWebsite.isClinicallyActionableSilkySliderDisplayed(), true,
				"'Clinically Actionable' Silky Slider is Displayed");

		corporateWebsite.clickOurTestMenuOption();
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'Our Tests' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' header is highlighted on the page");
		corporateWebsite.clickOncogaurdLiverCardLearnMoreLink();
		verifySafely(corporateWebsite.isOncogaurdLiverPageDisplayed(), true, "'Oncogaurd Liver' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		verifySafely(corporateWebsite.isOncogaurdLiverOptionHighlightedDisplayed(), true,
				"'Oncogaurd Liver' option is highlighted on the page");
		corporateWebsite.clickVisitOncogaurdLiverlink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(oncogaurdLiverSiteURL), true,
				"'OncogaurdLiver.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickExactSciencesLogo();
		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.clickOncogaurdLiverOption();
		verifySafely(corporateWebsite.isOncogaurdLiverPageDisplayed(), true, "'Oncogaurd Liver' Page is displayed");
		verifySafely(corporateWebsite.isAdvancedperformanceyoucanrelyoncardDisplayed(), true,
				"'Advanced performance you can rely on' Icon card is Displayed");
		verifySafely(corporateWebsite.isInnovationwithoutinconveniencecardDisplayed(), true,
				"'Innovation without inconvenience' Icon card is Displayed");
		verifySafely(corporateWebsite.isSupportthatdrivesadherencecardDisplayed(), true,
				"'Support that drives adherence' Icon card is Displayed");
		corporateWebsite.clickAdvancedperformanceyoucanrelyoncard();
		verifySafely(corporateWebsite.isAdvancedperformanceyoucanrelyonSilkySliderDisplayed(), true,
				"'Advanced performance you can rely on' Silky Slider is Displayed");
		corporateWebsite.clickInnovationwithoutinconveniencecard();
		verifySafely(corporateWebsite.isInnovationwithoutinconvenienceSilkySliderDisplayed(), true,
				"'Innovation without inconvenience' Silky Slider is Displayed");
		corporateWebsite.clickSupportthatdrivesadherencecard();
		verifySafely(corporateWebsite.isSupportthatdrivesadherenceSilkySliderDisplayed(), true,
				"'Support that drives adherence' Silky Slider is Displayed");

		corporateWebsite.clickOurTestMenuOption();
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'Our Tests' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' header is highlighted on the page");
		corporateWebsite.clickOncotypeBreastDCISScoreLearnMoreLink();
		verifySafely(corporateWebsite.isOncotypeBreastDCISScorePageDisplayed(), true,
				"'Oncotype Breast DCIS Score' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.hoverOncoTypeDXOption();
		verifySafely(corporateWebsite.isOncotypeDXBreastDCISScoreOptionHighlightedDisplayed(), true,
				"'Oncotype DX Breast DCIS Score' option is highlighted on the page");
		corporateWebsite.clickOncotypeBreastDCISScorePageLearnMoreLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(ocotypeBreastSiteURL), true,
				"'PrecisionOncology.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickExactSciencesLogo();

		corporateWebsite.clickOurTestMenuOption();
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'Our Tests' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' header is highlighted on the page");
		corporateWebsite.clickOncotypeBreastRecurrenceScoreLearnMoreLink();
		verifySafely(corporateWebsite.isOncotypeBreastRecurrenceScorePageDisplayed(), true,
				"'Oncotype Breast Recurrence Score' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.hoverOncoTypeDXOption();
		verifySafely(corporateWebsite.isOncotypeDXBreastRecurrenceScoreOptionHighlightedDisplayed(), true,
				"'Oncotype DX Breast Recurrence Score' option is highlighted on the page");
		corporateWebsite.clickOncotypeBreastRecurrenceScorePageLearnMoreLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(ocotypeRecurrenceSiteURL), true,
				"'PrecisionOncology.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickExactSciencesLogo();

		corporateWebsite.clickOurTestMenuOption();
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'Our Tests' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' header is highlighted on the page");
		corporateWebsite.clickOncotypeColonRecurrenceScoreLearnMoreLink();
		verifySafely(corporateWebsite.isOncotypeColonRecurrenceScorePageDisplayed(), true,
				"'Oncotype Colon Recurrence Score' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.hoverOncoTypeDXOption();
		verifySafely(corporateWebsite.isOncotypeDXColonRecurrenceScoreOptionHighlightedDisplayed(), true,
				"'Oncotype DX Colon Recurrence Score' option is highlighted on the page");
		corporateWebsite.clickOncotypeColonRecurrenceScorePageLearnMoreLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(ocotypeColonRecurrenceSiteURL), true,
				"'PrecisionOncology.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickExactSciencesLogo();

		corporateWebsite.clickOurTestMenuOption();
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'Our Tests' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' header is highlighted on the page");
		corporateWebsite.clickRiskguardLearnMoreLink();
		verifySafely(corporateWebsite.isRiskguardPageDisplayed(), true, "'Riskguard' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		verifySafely(corporateWebsite.isRiskguardOptionHighlightedDisplayed(), true,
				"'Riskgaurd' option is highlighted on the page");
		corporateWebsite.clickRiskguardPageLearnMoreAboutPreventiongenticsLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(riskguardPageLearnMoreAboutPreventiongenticsSiteURL), true,
				"'Preventiongenetics.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickExactSciencesLogo();

		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.clickRiskguardOption();
		verifySafely(corporateWebsite.isRiskguardPageDisplayed(), true, "'Riskguard' Page is displayed");
		corporateWebsite.hoverOurTestsMenuOption();
		verifySafely(corporateWebsite.isRiskguardOptionHighlightedDisplayed(), true,
				"'Riskgaurd' option is highlighted on the page");
		corporateWebsite.clickRiskguardInsuranceCoveragePageLearnMoreLink();
		verifySafely(driver.getURL().contains(riskguardInsuranceCoveragSiteURL), true,
				"'Insurance Coverage' Page URL matches '" + driver.getURL() + "'");
		corporateWebsite.hoverOurTestsMenuOption();
		corporateWebsite.clickRiskguardOption();
		verifySafely(corporateWebsite.isIndividualizedReportcardDisplayed(), true,
				"'INDIVIDUALIZED REPORT' Icon card is Displayed");
		verifySafely(corporateWebsite.isClinicallyActionableRiskguardcardDisplayed(), true,
				"'CLINICALLY ACTIONABLE' Icon card is Displayed");
		verifySafely(corporateWebsite.isTrustedPartnercardDisplayed(), true,
				"'TRUSTED PARTNER' Icon card is Displayed");
		corporateWebsite.clickDownloadAsamplePatientReport();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(downloadAsamplePatientReportPageTitleBy), true,
				"'Download a sample Patient Report' Page Title matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickDownloadRiskguardFactSheet();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(downloadRiskguardFactSheetTitleBy), true,
				"'Download Riskguard Fact Sheet' Page Title matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickTrustedPartnerLearnMoreLink();
		verifySafely(corporateWebsite.isTrustedPartnerDailogBoxDisplayed(), true,
				"'YOU ARE NOW LEAVING EXACTSCIENCES.COM' Text is Displayed");
		verifySafely(corporateWebsite.isTrustedPartnerContinueToGenomeDisplayed(), true,
				"'CONTINUE TO GENOME MEDICAL' Button is Displayed");
		corporateWebsite.clickCancelButton();
		verifySafely(corporateWebsite.isRiskguardPageDisplayed(), true, "'Riskguard' Page is displayed");
		corporateWebsite.clickTrustedPartnerLearnMoreLink();
		corporateWebsite.clickTrustedPartnerContinueToGenome();
		verifySafely(driver.getURL().contains(genomemedicalSiteURL), true,
				"'Genomemedical.com' Page URL matches '" + driver.getURL() + "'");
		driver.back();
		corporateWebsite.clickDownloadTheRiskguardFactSheet();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(downloadRiskguardTheFactSheetTitleBy), true,
				"'Download Riskguard The Fact Sheet' Page Title matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickDownloadOrderForm();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(downloadOrderFormTitleBy), true,
				"'Download Order Form' Page Title matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickForPatients();
		verifySafely(corporateWebsite.isPositivecardDisplayed(), true, "'Positive' Icon card is Displayed");
		verifySafely(corporateWebsite.isNegativecardDisplayed(), true, "'Negative' Icon card is Displayed");
		verifySafely(corporateWebsite.isVarientOfUncertainSignificancecardDisplayed(), true,
				"'Varient Of Uncertain Significance' Icon card is Displayed");
		corporateWebsite.clickHowTestingHelpLearnMoreLink();
		verifySafely(corporateWebsite.isHowTestingHelpLearnMoreLinkDailogBoxDisplayed(), true,
				"'YOU ARE NOW LEAVING EXACTSCIENCES.COM' Text is Displayed");
		verifySafely(corporateWebsite.isHowTestingHelpLearnMoreLinkContinueToGenomeDisplayed(), true,
				"'CONTINUE TO GENOME MEDICAL' Button is Displayed");
		corporateWebsite.clickHowTestingHelpLearnMoreLinkCancelButton();
		corporateWebsite.clickDownloadaSamplePatientReport();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(downloadaSamplePatientReportTitleBy), true,
				"'Download a Sample Patient Report' Page Title matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickForProviders();
		corporateWebsite.clickNeedAccesstothePatientReportsHub();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(preventiongeneticsSiteURL), true,
				"'preventiongenetics.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickNeedAccessToTheOpenOrClosedClientTickets();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(preventiongeneticsSiteURL), true,
				"'preventiongenetics.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickNeedNYStateProviderInformation();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(preventionGeneticsSiteURL), true,
				"'preventiongenetics.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickAreyouISO15189CAPandCLIAaccredited();
		corporateWebsite.clickPreventiongeneticsCertificationLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(preventiongeneticsCertificationSiteURL), true,
				"'preventiongenetics.com' Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickHowDoesaPatientFamilyGetTested();
		corporateWebsite.clickGenomeMedicalLink();
		verifySafely(corporateWebsite.isGenomeMedicalDailogBoxDisplayed(), true,
				"'YOU ARE NOW LEAVING EXACTSCIENCES.COM' Text is Displayed");
		verifySafely(corporateWebsite.isGenomeMedicalContinueToGenomeDisplayed(), true,
				"'CONTINUE TO GENOME MEDICAL' Button is Displayed");
		corporateWebsite.clickGenomeMedicalCancelButton();
		verifySafely(corporateWebsite.isContactUSFirstCardDisplayed(), true,
				"'First Contact US' Icon card is Displayed");
		verifySafely(corporateWebsite.isContactUSSecondCardDisplayed(), true,
				"'Second Contact US' Icon card is Displayed");
		verifySafely(corporateWebsite.isContactUSThirdCardDisplayed(), true,
				"'Third Contact US' Icon card is Displayed");
		corporateWebsite.clickContactUSSecondCardLearnMore();
		verifySafely(corporateWebsite.isSecondCardDailogBoxDisplayed(), true,
				"'YOU ARE NOW LEAVING EXACTSCIENCES.COM' Text is Displayed");
		verifySafely(corporateWebsite.isSecondCardContinueToGenomeDisplayed(), true,
				"'CONTINUE TO GENOME MEDICAL' Button is Displayed");
		corporateWebsite.clickSecondCardCancelButton();

		corporateWebsite.clickContactUSThirdCardLearnMore();
		verifySafely(driver.getURL().contains(riskguardInsuranceCoveragSiteURL), true,
				"'Insurance Coverage' Page URL matches '" + driver.getURL() + "'");
		driver.back();
		corporateWebsite.clickForPatients();
		corporateWebsite.clickContactUSSecondCardLearnMoreForPatients();
		verifySafely(driver.getURL().contains(contactUSSecondCardLearnMoreForPatientsTitleBy), true,
				"'genome-medical-riskguard-brochure.pdf' Title matches '" + driver.getURL() + "'");
		driver.back();
		corporateWebsite.clickForPatients();
		corporateWebsite.clickContactUSThirdCardLearnMoreForPatients();
		verifySafely(driver.getURL().contains(riskguardInsuranceCoveragSiteURL), true,
				"'Insurance Coverage' Page URL matches '" + driver.getURL() + "'");
		corporateWebsite.clickExactSciencesLogo();
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
