package exact.ath.sitecore.career;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CareerWebsite;
import exact.sys.Driver;

/**
 * This class verifies Career Website Benefits page verifications
 * 
 * @userstory #301264 Task#303949
 * @author qas_tgupta
 * @since 05/04/2023
 */

public class CareerBenefitsTest extends BasicIntTest {

	private final CareerWebsite careerWebsite = new CareerWebsite();
	private final Driver driver = new Driver();
	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CareerWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CareerWebURL");
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final String totalRewardsTitle = exactPagesProperties.getProperty("TotalRewardsTitle");
	private final String canadaNationLinkURL = exactPagesProperties.getProperty("CanadaNationLinkURL");
	private final String franceNationLinkURL = exactPagesProperties.getProperty("FranceNationLinkURL");
	private final String germanyNationLinkURL = exactPagesProperties.getProperty("GermanyNationLinkURL");
	private final String irelandNationLinkURL = exactPagesProperties.getProperty("IrelandNationLinkURL");
	private final String italyNationLinkURL = exactPagesProperties.getProperty("ItalyNationLinkURL");
	private final String japanNationLinkURL = exactPagesProperties.getProperty("JapanNationLinkURL");

	private final String netherlandsNationLinkURL = exactPagesProperties.getProperty("NetherlandsNationLinkURL");
	private final String swedenNationLinkURL = exactPagesProperties.getProperty("SwedenNationLinkURL");
	private final String switzerlandNationLinkURL = exactPagesProperties.getProperty("SwitzerlandNationLinkURL");
	private final String unitedStatesNationLinkURL = exactPagesProperties.getProperty("UnitedStatesNationLinkURL");
	private final String unitedKingdomNationLinkURL = exactPagesProperties.getProperty("UnitedKingdomNationLinkURL");
	private final String transparencyInCoverageHeadingTitle = exactPagesProperties
			.getProperty("TransparencyInCoverageHeadingTitle");
	private final String transparencyInCoverageRuleHeadingTitle = exactPagesProperties
			.getProperty("TransparencyInCoverageRuleHeadingTitle");
	private final String transparencyInCoverageRuleLinkURL = exactPagesProperties
			.getProperty("TransparencyInCoverageRuleLinkURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void careerBenefitsTest() {
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		logInfo("----------------Starting verification of Benefits Tab present in Header Section of Career Website------------");
		verifySafely(careerWebsite.getCareerWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Heading");
		verifySafely(careerWebsite.isHeaderSectionDisplayed(), true, "'Header Section' is displayed on the page");
		verifySafely(careerWebsite.isPageTitleDisplayed(), true,
				"'Home Page tittle - CHANGE CAREERS.CHANGE LIVES.' is displayed on the page");
		careerWebsite.clickBenefitsTab();
		logInfo("Clicked on 'Benefits' Tab from the Header section");
		verifySafely(careerWebsite.getTotalRewards(), totalRewardsTitle,
				"'TOTAL REWARDS' Title is displayed after clicking expore button from Our Benefits Icon Card");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Benefits ' Tab in the header section is highlighted in blue color");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		verifySafely(careerWebsite.isListOfNationsDisplayed(), true,
				"'Display list of nations is expanded as follows:\r\n" + "CANADA\r\n" + "FRANCE\r\n" + "GERMANY\r\n"
						+ "IRELAND\r\n" + "ITALY\r\n" + "JAPAN\r\n" + "NETHERLANDS\r\n" + "SWEDEN\r\n"
						+ "SWITZERLAND\r\n" + "UNITED STATES\r\n" + "UNITED KINGDOM");
		careerWebsite.clickCanadaNation();
		logInfo("Clicked on 'CANADA' from the expanded list");
		verifySafely(driver.getURL(), canadaNationLinkURL, "Opened 'Canada Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickFranceNation();
		logInfo("Clicked on 'FRANCE' from the expanded list");
		verifySafely(driver.getURL(), franceNationLinkURL, "Opened 'France Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickGermanyNation();
		logInfo("Clicked on 'GERMANY' from the expanded list");
		verifySafely(driver.getURL(), germanyNationLinkURL, "Opened 'Germany Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickIrelandNation();
		logInfo("Clicked on 'IRELAND' from the expanded list");
		verifySafely(driver.getURL(), irelandNationLinkURL, "Opened 'Ireland Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickItalyNation();
		logInfo("Clicked on 'ITALY' from the expanded list");
		verifySafely(driver.getURL(), italyNationLinkURL, "Opened 'Italy Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickJapanNation();
		logInfo("Clicked on 'JAPAN' from the expanded list");
		verifySafely(driver.getURL(), japanNationLinkURL, "Opened 'Japan Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickNetherlandsNation();
		logInfo("Clicked on 'NETHERLANDS' from the expanded list");
		verifySafely(driver.getURL(), netherlandsNationLinkURL,
				"Opened 'Netherlands Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickSwedenNation();
		logInfo("Clicked on 'SWEDEN' from the expanded list");
		verifySafely(driver.getURL(), swedenNationLinkURL, "Opened 'Sweden Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickSwitzerlandNation();
		logInfo("Clicked on 'SWITZERLAND' from the expanded list");
		verifySafely(driver.getURL(), switzerlandNationLinkURL,
				"Opened 'Switzerland Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickUnitedStatesNation();
		logInfo("Clicked on 'UNITED STATES' from the expanded list");
		verifySafely(driver.getURL(), unitedStatesNationLinkURL,
				"Opened 'United States Nation Link' and Page URL matches");
		careerWebsite.clickFindYourLocation();
		logInfo("Clicked on 'FIND YOUR LOCATION' button");
		careerWebsite.clickUnitedKingdomNation();
		logInfo("Clicked on 'UNITED KINGDOM' from the expanded list");
		verifySafely(driver.getURL(), unitedKingdomNationLinkURL,
				"Opened 'United Kingdom Nation Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to previous page using back browser button");
		careerWebsite.clickTransparencyInCoverageUrl();
		logInfo("Clicked on 'https://transparency-in-coverage.uhc.com' url");
		driver.switchToCurrentWindow();
		verifySafely(careerWebsite.getTransparencyInCoverageHeading(), transparencyInCoverageHeadingTitle,
				"'Transparency In Coverage' Title is displayed after clicking Transparency In Coverage URL");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		careerWebsite.clickTransparencyInCoveragePageLink();
		logInfo("Clicked on 'Transparency in Coverage' page link");
		driver.switchToCurrentWindow();
		verifySafely(careerWebsite.getTransparencyInCoverageRuleHeading(), transparencyInCoverageRuleHeadingTitle,
				"'Transparency In Coverage Rule' Title is displayed after clicking Transparency In Coverage Page Link");
		verifySafely(driver.getURL(), transparencyInCoverageRuleLinkURL,
				"Opened 'TransparencyIn Coverage Page Link URL' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifySafely(careerWebsite.isExactScienceEmailDisplayed(), true,
				"'hr@exactsciences.com' email hyperlink is displayed after text If you have any additional questions, please contact");
		logInfo("----------------Verification Done For Benefits Tab present in Header Section of Career Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}

}
