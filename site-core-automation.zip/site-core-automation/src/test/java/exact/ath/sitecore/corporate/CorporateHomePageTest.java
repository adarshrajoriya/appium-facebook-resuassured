package exact.ath.sitecore.corporate;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.sys.Driver;

public class CorporateHomePageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CorporateWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CorporateWebURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void corporateHomePageTest() {

		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		// Home Page
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Title");
		verifySafely(corporateWebsite.isOurTestsCardDisplayed(), true, "'OUR TESTS' Card is displayed on the page");
		verifySafely(corporateWebsite.isOurPipelineCardDisplayed(), true,
				"'OUR PIPELINE' Card is displayed on the page");
		verifySafely(corporateWebsite.isOurNewsroomCardDisplayed(), true, "'NEWSROOM' Card is displayed on the page");
		corporateWebsite.clickOurTestsCardLearnMoreLink();
		logInfo("Clicked on 'OUR TESTS' Card 'LEARN MORE' Link");
		verifySafely(corporateWebsite.isOurTestsPageDisplayed(), true, "'OUR TESTS' Page is displayed");
		verifySafely(corporateWebsite.isOurTestsHeaderHighlightedDisplayed(), true,
				"'Our Tests' is highlighted in header section on the page");
		corporateWebsite.clickExactSciencesLogo();
		logInfo("Clicked on 'EXACT SCIENCES' Logo");
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");

		corporateWebsite.clickOurPipelineCardLearnMoreLink();
		logInfo("Clicked on 'PIPELINE & DATA' Card 'LEARN MORE' Link");
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' is highlighted in header section on the page");
		corporateWebsite.clickExactSciencesLogo();
		logInfo("Clicked on 'EXACT SCIENCES' Logo");
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");

		corporateWebsite.clickNewsroomCardLearnMoreLink();
		logInfo("Clicked on 'NEWS & STORIES' Card 'LEARN MORE' Link");
		verifySafely(corporateWebsite.isNewsroomPageDisplayed(), true, "'NEWS & STORIES' Page is displayed");
		verifySafely(corporateWebsite.isNewsroomHeadeHighlightedDisplayed(), true,
				"'Newsroom' is highlighted in header section on the page");
		corporateWebsite.clickExactSciencesLogo();
		logInfo("Clicked on 'EXACT SCIENCES' Logo");
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");
//      Deprecated 
//		corporateWebsite.clickExploreTheTestLink();
//		verifySafely(corporateWebsite.isOncoExTraPageDisplayed(), true, "'ONCOEXTRA' Page is displayed");
//		corporateWebsite.hoverOurTestsMenuOption();
//		verifySafely(corporateWebsite.isOncoExTraHeaderOptionActiveDisplayed(), true,
//				"'ONCOEXTRA' is highlighted under the 'Our Tests' section on the page");
//		corporateWebsite.clickExactSciencesLogo();
//		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
//				"Navigated to Home Page - Title");

		corporateWebsite.clickPublicationsLink();
		logInfo("Clicked on 'PUBLICATIONS & ABSTRACTS' Link");
		verifySafely(corporateWebsite.isPublicationsPageDisplayed(), true,
				"'PUBLICATIONS & ABSTRACTS' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isPublicationsHeaderOptionActiveDisplayed(), true,
				"'Publications' is highlighted under the 'Pipeline & Data' section on the page");
		corporateWebsite.clickExactSciencesLogo();
		logInfo("Clicked on 'EXACT SCIENCES' Logo");
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
