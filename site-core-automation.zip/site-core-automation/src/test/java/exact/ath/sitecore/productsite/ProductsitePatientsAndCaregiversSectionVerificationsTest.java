package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.PSOncotypeDXBreastDcisScoreTestPage;
import exact.ath.productsite.PSOncotypeDXBreastRecurrenceScoreTestPage;
import exact.ath.productsite.PSOncotypeDXColonRecurrenceScoreTestPage;
import exact.ath.productsite.ProductsiteAdvancedSolidTumorPage;
import exact.ath.productsite.ProductsiteBreastCancerCarePage;
import exact.ath.productsite.ProductsiteColonCancerCarePage;
import exact.ath.productsite.ProductsiteCostsAndCoveragePage;
import exact.ath.productsite.ProductsiteHomepage;
import exact.ath.productsite.ProductsiteOncoextraTestPage;

/**
 * This class verifies Productsite 'Patients And Caregivers' section
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 07/07/2023
 */
public class ProductsitePatientsAndCaregiversSectionVerificationsTest extends BasicIntTest {

	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();
	private final ProductsiteCostsAndCoveragePage productsiteCostsAndCoveragePage = new ProductsiteCostsAndCoveragePage();
	private final ProductsiteBreastCancerCarePage productsiteBreastCancerCarePage = new ProductsiteBreastCancerCarePage();
	private final PSOncotypeDXBreastRecurrenceScoreTestPage pSOncotypeDXBreastRecurrenceScoreTestPage = new PSOncotypeDXBreastRecurrenceScoreTestPage();
	private final PSOncotypeDXBreastDcisScoreTestPage pSOncotypeDXBreastDcisScoreTestPage = new PSOncotypeDXBreastDcisScoreTestPage();
	private final ProductsiteColonCancerCarePage productsiteColonCancerCarePage = new ProductsiteColonCancerCarePage();
	private final PSOncotypeDXColonRecurrenceScoreTestPage pSOncotypeDXColonRecurrenceScoreTestPage = new PSOncotypeDXColonRecurrenceScoreTestPage();
	private final ProductsiteAdvancedSolidTumorPage productsiteAdvancedSolidTumorPage = new ProductsiteAdvancedSolidTumorPage();
	private final ProductsiteOncoextraTestPage productsiteOncoextraTestPage = new ProductsiteOncoextraTestPage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String TabNames = productsitePagesProperties.getProperty("TabNames");
	private final String PatientsAndCaregiversSubsectionValues = productsitePagesProperties
			.getProperty("PatientsAndCaregiversSubsectionValues");
	private final String PatientsAndCaregiversSubmenuValues = productsitePagesProperties
			.getProperty("PatientsAndCaregiversSubmenuValues");
	private final String PatientsAndCaregiversSubpartsValues = productsitePagesProperties
			.getProperty("PatientsAndCaregiversSubpartsValues");
	private final String testingAndTreatingSubsectionValue = productsitePagesProperties
			.getProperty("TestingAndTreatingSubsectionValue");
	private final String understandingYourDiagnosisSubsectionValue = productsitePagesProperties
			.getProperty("UnderstandingYourDiagnosisSubsectionValue");
	private final String testingAndTreatingHeaderValue = productsitePagesProperties
			.getProperty("TestingAndTreatingHeaderValue");
	private final String costsAndCoveragePageHeaderValue = productsitePagesProperties
			.getProperty("CostsAndCoveragePageHeaderValue");
	private final String CostsAndCoverageTabsNames = productsitePagesProperties
			.getProperty("CostsAndCoverageTabsNames");
	private final String annualIncomeValue = productsitePagesProperties.getProperty("AnnualIncomeValue");
	private final String downloadTheGapGuideForHelpNavigatingTheInsuranceProcessPageURL = productsitePagesProperties
			.getProperty("DownloadTheGapGuideForHelpNavigatingTheInsuranceProcessPageURL");
	private final String contactUsPageHeaderValue = productsitePagesProperties.getProperty("ContactUsPageHeaderValue");
	private final String CostsAndCoverageFaqValues = productsitePagesProperties
			.getProperty("CostsAndCoverageFaqValues");
	private final String costsAndCoverageBreastCancerPageHeaderValue = productsitePagesProperties
			.getProperty("CostsAndCoverageBreastCancerPageHeaderValue");
	private final String oncotypeDXBreastRecurrenceScoreTestForCostsAndCoveragesPageHeaderValue = productsitePagesProperties
			.getProperty("OncotypeDXBreastRecurrenceScoreTestForCostsAndCoveragesPageHeaderValue");
	private final String LinksNameOnCostsAndCoveragesBreadtCancerPage = productsitePagesProperties
			.getProperty("LinksNameOnCostsAndCoveragesBreadtCancerPage");
	private final String HeaderValuesOfLinksOnCostsAndCoveragesBreadtCancerPage = productsitePagesProperties
			.getProperty("HeaderValuesOfLinksOnCostsAndCoveragesBreadtCancerPage");
	private final String viewMoreBillingAndCoverageDetailsColonPageHeaderValue = productsitePagesProperties
			.getProperty("ViewMoreBillingAndCoverageDetailsColonPageHeaderValue");
	private final String OncotypeDXBreastRecurrenceScoreTestPageLinksNameForPatientAndCaregiversSection = productsitePagesProperties
			.getProperty("OncotypeDXBreastRecurrenceScoreTestPageLinksNameForPatientAndCaregiversSection");
	private final String IsTheBreastRecurrenceScoreTestRightForYouPageURL = productsitePagesProperties
			.getProperty("IsTheBreastRecurrenceScoreTestRightForYouPageURL");
	private final String oncotypeDXBreastDCISScoreTestForCostsAndCoveragesPageHeaderValue = productsitePagesProperties
			.getProperty("OncotypeDXBreastDCISScoreTestForCostsAndCoveragesPageHeaderValue");
	private final String downloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCISPageURL = productsitePagesProperties
			.getProperty("DownloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCISPageURL");
	private final String LinksNameOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection = productsitePagesProperties
			.getProperty("LinksNameOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection");
	private final String TitleValuesOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection = productsitePagesProperties
			.getProperty("TitleValuesOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection");
	private final String patientAndCaregiversColonCancerPageHeaderValue = productsitePagesProperties
			.getProperty("PatientAndCaregiversColonCancerPageHeaderValue");
	private final String oncotypeDXColonRecurrenceScorePageHeaderValue = productsitePagesProperties
			.getProperty("OncotypeDXColonRecurrenceScorePageHeaderValue");
	private final String LinksNameOnColonCancerPageLinksForPatientAndCaregiversSection = productsitePagesProperties
			.getProperty("LinksNameOnColonCancerPageLinksForPatientAndCaregiversSection");
	private final String TitleValuesOnColonCancerPageLinksForPatientAndCaregiversSection = productsitePagesProperties
			.getProperty("TitleValuesOnColonCancerPageLinksForPatientAndCaregiversSection");
	private final String patientAndCaregiversAdvancedSolidCancerPageHeaderValue = productsitePagesProperties
			.getProperty("PatientAndCaregiversAdvancedSolidCancerPageHeaderValue");
	private final String advancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversPageHeaderValue = productsitePagesProperties
			.getProperty("AdvancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversPageHeaderValue");
	private final String LinksNameOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection = productsitePagesProperties
			.getProperty("LinksNameOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection");
	private final String TitleValuesOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection = productsitePagesProperties
			.getProperty("TitleValuesOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection");
	private final String patientStateValue = productsitePagesProperties.getProperty("PatientStateValue");
	private final String householdSizeValue = productsitePagesProperties.getProperty("HouseholdSizeValue");

	private final String[] tabNames = TabNames.split(",");
	private final String[] patientsAndCaregiversSubsectionValues = PatientsAndCaregiversSubsectionValues.split(",");
	private final String[] patientsAndCaregiversSubmenuValues = PatientsAndCaregiversSubmenuValues.split(",");
	private final String[] patientsAndCaregiversSubpartsValues = PatientsAndCaregiversSubpartsValues.split(",");
	private final String[] headerValuesOfLinksOnCostsAndCoveragesBreadtCancerPage = HeaderValuesOfLinksOnCostsAndCoveragesBreadtCancerPage
			.split("\\*");
	private final String[] linksName = OncotypeDXBreastRecurrenceScoreTestPageLinksNameForPatientAndCaregiversSection
			.split("\\*");
	private final String[] isTheBreastRecurrenceScoreTestRightForYouPageURL = IsTheBreastRecurrenceScoreTestRightForYouPageURL
			.split(",");
	private final String[] titleValuesOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection = TitleValuesOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection
			.split(",");
	private final String[] titleValuesOnColonCancerPageLinksForPatientAndCaregiversSection = TitleValuesOnColonCancerPageLinksForPatientAndCaregiversSection
			.split(",");
	private final String[] titleValuesOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection = TitleValuesOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection
			.split(",");

	int counter = 0;
	int number = 0;
	int linkNumber = 0;
	int i = 0;
	int k = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsitePatientsAndCaregiversSectionVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		verifySafely(productsiteHomepage.getPatientsAndCaregiversSubsection(patientsAndCaregiversSubsectionValues[0]),
				testingAndTreatingSubsectionValue,
				"Patients And Caregivers Subsection '" + patientsAndCaregiversSubsectionValues[0] + "' is dispalyed");
		verifySafely(productsiteHomepage.getPatientsAndCaregiversSubsection(patientsAndCaregiversSubsectionValues[1]),
				understandingYourDiagnosisSubsectionValue,
				"Patients And Caregivers Subsection '" + patientsAndCaregiversSubsectionValues[1] + "' is dispalyed");
		verifyPatientsAndCaregiversSubmenuDisplayed();
		verifyPatientsAndCaregiversSubpartsDisplayed();
		productsiteHomepage.clickPatientsAndCaregiversSubmenu(patientsAndCaregiversSubmenuValues[0]);
		verifySafely(productsiteHomepage.getPageHeader(), testingAndTreatingHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteHomepage.clickLearnAboutCostsAndCoverageButton();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), costsAndCoveragePageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubmenu(patientsAndCaregiversSubmenuValues[1]);
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), costsAndCoveragePageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		verifycostsAndCoverageTabsDisplayed();
		verifycostsAndCoverageTabsOpened();
		productsiteCostsAndCoveragePage.selectPatientState(patientStateValue);
		productsiteCostsAndCoveragePage.selectHouseholdSize(householdSizeValue);
		productsiteCostsAndCoveragePage.enterAnnualIncome(annualIncomeValue);
		productsiteCostsAndCoveragePage.clickOnSubmitButton();
		verifySafely(productsiteCostsAndCoveragePage.isQualifyTextDisplayed(), true, "Qualify text is displayed ");
		productsiteCostsAndCoveragePage.clickDownloadTheGapGuideForHelpNavigatingTheInsuranceProcess();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadTheGapGuideForHelpNavigatingTheInsuranceProcessPageURL,
				"'Download the GAP guide for help navigating the insurance process' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		productsiteCostsAndCoveragePage.clickContactUsToGetStartedWithGap();
		driver.switchToCurrentWindow();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifyCostsAndCoverageFaqExpaned();

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubmenu(patientsAndCaregiversSubmenuValues[2]);
		verifySafely(productsiteHomepage.getPageHeader(), costsAndCoverageBreastCancerPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteBreastCancerCarePage.clickOncotypeDXBreastRecurrenceScoreTestLinkForCostsAndCoveragesPage();
		verifySafely(productsiteHomepage.getPageHeader(),
				oncotypeDXBreastRecurrenceScoreTestForCostsAndCoveragesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		verifyLinksOnCostsAndCoveragesBreadtCancerPage();
		productsiteBreastCancerCarePage.clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpLink();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(),
				viewMoreBillingAndCoverageDetailsColonPageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		driver.back();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubparts(patientsAndCaregiversSubpartsValues[0]);
		verifySafely(productsiteHomepage.getPageHeader(),
				oncotypeDXBreastRecurrenceScoreTestForCostsAndCoveragesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifyLinksOnOncotypeDXBreastRecurrenceScoreTestPage();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpLink();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), costsAndCoveragePageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickDownloadTheGenomicAccessProgramGuideButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadTheGapGuideForHelpNavigatingTheInsuranceProcessPageURL,
				"'Download the Genomic Access Program guide' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubparts(patientsAndCaregiversSubpartsValues[1]);
		verifySafely(productsiteHomepage.getPageHeader(),
				oncotypeDXBreastDCISScoreTestForCostsAndCoveragesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		pSOncotypeDXBreastDcisScoreTestPage.clickDownloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCIS();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadTheBrochureForBreastCancerPatientsWithStage0NonInvasiveDCISPageURL,
				"'Download the Brochure for Breast Cancer Patients with Stage 0, Non-Invasive DCIS' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastDcisScoreTestPage.clickOncotypeDXBreastRecurrenceScoreTestLink();
		verifySafely(productsiteHomepage.getPageHeader(),
				oncotypeDXBreastRecurrenceScoreTestForCostsAndCoveragesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		verifyLinksOnOncotypeDXBreastDcisScoreTestPage();
		productsiteBreastCancerCarePage.clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpLink();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(),
				viewMoreBillingAndCoverageDetailsColonPageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.back();
		productsiteCostsAndCoveragePage.clickDownloadTheGapGuideForHelpNavigatingTheInsuranceProcess();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadTheGapGuideForHelpNavigatingTheInsuranceProcessPageURL,
				"'Download the GAP guide for help navigating the insurance process' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		driver.back();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubmenu(patientsAndCaregiversSubmenuValues[3]);
		verifySafely(productsiteHomepage.getPageHeader(), patientAndCaregiversColonCancerPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteColonCancerCarePage.clickColonCancerPageIconCardExploreTestForPatientAndCaregiversSection();
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXColonRecurrenceScorePageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		verifyLinksOnColonCancerPage();
		productsiteColonCancerCarePage.clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpButton();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), costsAndCoveragePageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		driver.back();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubparts(patientsAndCaregiversSubpartsValues[2]);
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXColonRecurrenceScorePageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifyLinksOnOncotypeDXColonRecurrenceScoreTestPage();

		productsiteHomepage.clickLearnAboutCostsAndCoverageButton();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), costsAndCoveragePageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.back();
		productsiteCostsAndCoveragePage.clickDownloadTheGapGuideForHelpNavigatingTheInsuranceProcess();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadTheGapGuideForHelpNavigatingTheInsuranceProcessPageURL,
				"'Download the GAP guide for help navigating the insurance process' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubmenu(patientsAndCaregiversSubmenuValues[4]);
		verifySafely(productsiteHomepage.getPageHeader(), patientAndCaregiversAdvancedSolidCancerPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");

		productsiteAdvancedSolidTumorPage
				.clickAdvancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversSection();
		verifySafely(productsiteHomepage.getPageHeader(),
				advancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		verifyLinksOnAdvancedSolidTumorPage();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		driver.back();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubparts(patientsAndCaregiversSubpartsValues[3]);
		verifySafely(productsiteHomepage.getPageHeader(),
				advancedSolidTumorPageIconCardExploreTestForPatientAndCaregiversPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteOncoextraTestPage.clickLearnAboutCostsCoverageAndHowExactSciencesCanHelpLink();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), costsAndCoveragePageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		driver.back();

		driver.close();
		throwAssertionErrorOnFailure();
	}

	private void verifyPatientsAndCaregiversSubmenuDisplayed() {
		for (int count = 0; count <= 4; count++) {
			verifySafely(
					productsiteHomepage
							.isPatientsAndCaregiversSubmenuDisplayed(patientsAndCaregiversSubmenuValues[count]),
					true,
					"Patients And Caregivers Submenu '" + patientsAndCaregiversSubmenuValues[count] + "' is dispalyed");
		}
	}

	private void verifyPatientsAndCaregiversSubpartsDisplayed() {
		for (int count = 0; count <= 3; count++) {
			verifySafely(
					productsiteHomepage
							.isPatientsAndCaregiversSubpartsDisplayed(patientsAndCaregiversSubpartsValues[count]),
					true, "Patients And Caregivers Subparts '" + patientsAndCaregiversSubpartsValues[count]
							+ "' is dispalyed");
		}
	}

	public void verifycostsAndCoverageTabsDisplayed() {
		for (String costsAndCoverageTabsName : CostsAndCoverageTabsNames.split(",")) {
			verifySafely(productsiteCostsAndCoveragePage.isCostsAndCoverageTabsDisplayed(costsAndCoverageTabsName),
					true, "Costs And Coverage tab '" + costsAndCoverageTabsName + "' is dispalyed");
		}
	}

	public void verifycostsAndCoverageTabsOpened() {
		for (String costsAndCoverageTabsName : CostsAndCoverageTabsNames.split(",")) {
			productsiteCostsAndCoveragePage.clickCostsAndCoverageTabs(costsAndCoverageTabsName);
			verifySafely(productsiteCostsAndCoveragePage.isCostsAndCoverageTabsOpened(costsAndCoverageTabsName), true,
					"Costs And Coverage tab '" + costsAndCoverageTabsName + "' is opened");
		}
	}

	public void verifyCostsAndCoverageFaqExpaned() {
		for (String costsAndCoverageFaqValues : CostsAndCoverageFaqValues.split("\\*")) {
			productsiteCostsAndCoveragePage.clickOnfAqs(costsAndCoverageFaqValues);
			verifySafely(productsiteCostsAndCoveragePage.isFaqExpaned(costsAndCoverageFaqValues), true,
					"'" + costsAndCoverageFaqValues + "' faq accordian is expaned");
		}
	}

	public void verifyLinksOnCostsAndCoveragesBreadtCancerPage() {
		for (String linksNameOnCostsAndCoveragesBreadtCancerPage : LinksNameOnCostsAndCoveragesBreadtCancerPage
				.split(",")) {
			productsiteBreastCancerCarePage
					.clickOnLinksOnCostsAndCoveragesBreadtCancerPage(linksNameOnCostsAndCoveragesBreadtCancerPage);
			verifySafely(productsiteHomepage.getPageHeader(),
					headerValuesOfLinksOnCostsAndCoveragesBreadtCancerPage[counter],
					"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
			counter++;
			driver.back();
		}
	}

	public void verifyLinksOnOncotypeDXBreastRecurrenceScoreTestPage() {
		for (int count = 0; count <= 1; count++) {
			pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[count]);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), isTheBreastRecurrenceScoreTestRightForYouPageURL[count],
					"'" + linksName[count] + "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
		}

		for (int count = 2; count <= 5; count++) {
			pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[count]);
			verifySafely(productsiteHomepage.getPageHeader(),
					headerValuesOfLinksOnCostsAndCoveragesBreadtCancerPage[count - 2],
					"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
			driver.back();
		}
	}

	public void verifyLinksOnOncotypeDXBreastDcisScoreTestPage() {
		for (String linksNameOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection : LinksNameOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection
				.split(",")) {
			pSOncotypeDXBreastDcisScoreTestPage
					.clickOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection(
							linksNameOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection);
			verifySafely(driver.getTitle(),
					titleValuesOnOncotypeDXBreastDcisScoreTestPageLinksForPatientAndCaregiversSection[number],
					"Page title '" + driver.getTitle() + "' is matched");
			driver.back();
			number++;
		}
	}

	public void verifyLinksOnColonCancerPage() {
		for (String linksNameOnColonCancerPageLinksForPatientAndCaregiversSection : LinksNameOnColonCancerPageLinksForPatientAndCaregiversSection
				.split(",")) {
			productsiteColonCancerCarePage.clickOnLinksOnColonCancerPageForPatientAndCaregivers(
					linksNameOnColonCancerPageLinksForPatientAndCaregiversSection);
			verifySafely(driver.getTitle(), titleValuesOnColonCancerPageLinksForPatientAndCaregiversSection[linkNumber],
					"Page title '" + driver.getTitle() + "' is matched");
			driver.back();
			linkNumber++;
		}
	}

	public void verifyLinksOnOncotypeDXColonRecurrenceScoreTestPage() {
		for (String linksNameOnColonCancerPageLinksForPatientAndCaregiversSection : LinksNameOnColonCancerPageLinksForPatientAndCaregiversSection
				.split(",")) {
			pSOncotypeDXColonRecurrenceScoreTestPage
					.clickOnLinksOnOncotypeDXColonRecurrenceScoreTestPageForPatientAndCaregivers(
							linksNameOnColonCancerPageLinksForPatientAndCaregiversSection);
			verifySafely(driver.getTitle(), titleValuesOnColonCancerPageLinksForPatientAndCaregiversSection[i],
					"Page title '" + driver.getTitle() + "' is matched");
			driver.back();
			i++;
		}
	}

	public void verifyLinksOnAdvancedSolidTumorPage() {
		for (String linksNameOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection : LinksNameOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection
				.split(",")) {
			productsiteAdvancedSolidTumorPage.clickOnLinksOnAdvancedSolidTumorPageForPatientAndCaregivers(
					linksNameOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection);
			verifySafely(driver.getTitle(), titleValuesOnAdvancedSolidTumorPageLinksForPatientAndCaregiversSection[k],
					"Page title '" + driver.getTitle() + "' is matched");
			driver.back();
			k++;
		}
	}

}
