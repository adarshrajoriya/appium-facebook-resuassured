package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CGAffordablePage;
import exact.util.PostStatusToZephyr;

/**
 * This class verifies Affordable page validations
 * 
 * @userstory #303911 Task#304656
 * @author Sandeep Singh
 * @since 05/04/2023
 */
public class CGAffordablePageTest extends BasicIntTest {

	private final CGAffordablePage cgAffordablePage = new CGAffordablePage();
	// URLs
	private final String affordablePageURL = cologuardPagesProperties.getProperty("affordablePageURL");
	private final String appealsPageURL = cologuardPagesProperties.getProperty("appealsPageURL");
	private final String referencesPageURL = cologuardPagesProperties.getProperty("referencesPageURL");
	private final String getCologuardURL = cologuardPagesProperties.getProperty("getCologuardURL");
	private final String cologuardInsurancePageURL = cologuardPagesProperties.getProperty("cologuardInsurancePageURL");

	// labels
	private final String affordablePageTitle = cologuardPagesProperties.getProperty("affordablePageTitle");
	private final String appealsPageTitle = cologuardPagesProperties.getProperty("appealsPageTitle");
	private final String whyCologuard = cologuardPagesProperties.getProperty("whyCologuard");
	private final String affordable = cologuardPagesProperties.getProperty("affordable");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T722";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyAffordablePageData() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");
		acceptCookies();

		verifySafely(cgAffordablePage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cgAffordablePage.selectSubOptionFromTopNavOptions(whyCologuard, affordable);
		verifySafely(driver.getURL(), affordablePageURL, "Cologuard 'Affordable' page is displayed");
		verifySafely(driver.getTitle(), affordablePageTitle,
				"'" + affordablePageTitle + "' is displayed as page title");

		cgAffordablePage.clickReadMoreLink();
		verifySafely(cgAffordablePage.isReadLessDisplayed(), true, "'Read less' is now displayed");
		String readMoreContent = cgAffordablePage.getReadMoreContent();
		verifySafely(readMoreContent != null && !readMoreContent.equalsIgnoreCase(""), true,
				"'Read More' content is displayed");

		cgAffordablePage.clickAppealsPage();
		verifySafely(driver.getURL(), appealsPageURL, "Cologuard 'Appeals' page is displayed");
		verifySafely(driver.getTitle(), appealsPageTitle, "'" + appealsPageTitle + "' is displayed as page title");

		driver.back();

		cgAffordablePage.clickReadMoreLink();
		cgAffordablePage.clickReferencesLink();
		verifySafely(driver.getURL(), referencesPageURL, "User is redirected to 'References' page");

		driver.switchToParentWindow();

		cgAffordablePage.clickMoreAboutRequestingCG();
		verifySafely(driver.getURL(), getCologuardURL, "'how to get Cologuard' page is displayed");

		driver.back();
		cgAffordablePage.clickCologuardAndInsurance();
		verifySafely(driver.getURL(), cologuardInsurancePageURL, "'Cologuard Insurance' page is displayed");

		throwAssertionErrorOnFailure();
	}
}
