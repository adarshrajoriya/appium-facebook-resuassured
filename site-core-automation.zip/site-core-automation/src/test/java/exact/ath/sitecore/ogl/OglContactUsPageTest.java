package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglContactUsPage;
import exact.ath.ogl.OglHomepage;

/**
 * This class verifies the Contact us Page of OGL website
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 07/07/2023
 */

public class OglContactUsPageTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();
	private final OglContactUsPage oglContactUsPage = new OglContactUsPage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String contactUs = oglPagesProperties.getProperty("contactUs");
	private final String contactUsURL = oglPagesProperties.getProperty("contactUsURL");
	private final String contactUsTitle = oglPagesProperties.getProperty("contactUsTitle");
	private final String firstNameValue = oglPagesProperties.getProperty("firstNameValue");
	private final String lastNameValue = oglPagesProperties.getProperty("lastNameValue");
	private final String emailValue = oglPagesProperties.getProperty("emailValue");
	private final String phoneNumberValue = oglPagesProperties.getProperty("phoneNumberValue");
	private final String zipCodeValue = oglPagesProperties.getProperty("zipCodeValue");
	private final String institutionValue = oglPagesProperties.getProperty("institutionValue");
	private final String selectPreferrredContactMethodValue = oglPagesProperties
			.getProperty("selectPreferrredContactMethodValue");
	private final String selectWhichBestDescribesYouValue = oglPagesProperties
			.getProperty("selectWhichBestDescribesYouValue");
	private final String selectSpecialtyValue = oglPagesProperties.getProperty("selectSpecialtyValue");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglContactUsPageTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of Contact Us Page of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");
		oglHomepage.clickTopNavOption(contactUs);
		verifySafely(driver.getURL(), contactUsURL, "'Contact Us' page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), contactUsTitle,
				"'Contact Us' Title is displayed on Page");

		oglContactUsPage.clickSubmitButtonUnderContactUsProvidersOnlyTitle();
		verifySafely(oglContactUsPage.isMandatoryFieldsDisplayed(), true,
				"'Please fill out this required field' message for Mandatory Fields is displayed on the page");

		oglContactUsPage.enterFirstName(firstNameValue);
		oglContactUsPage.enterLastName(lastNameValue);
		oglContactUsPage.enterEmail(emailValue);
		oglContactUsPage.enterPhoneNumber(phoneNumberValue);
		oglContactUsPage.enterZipCode(zipCodeValue);
		oglContactUsPage.selectPreferredContactMethod(selectPreferrredContactMethodValue);
		oglContactUsPage.selectWhichBestDescribesYou(selectWhichBestDescribesYouValue);
		oglContactUsPage.clickSubmitButtonUnderContactUsProvidersOnlyTitle();
		verifySafely(oglContactUsPage.isConfirmationMessageDisplayed(), true,
				"'Thanks for submitting the form' confirmation message appears under the form.");

		driver.refresh();

		oglContactUsPage.enterFirstNameSignUp(firstNameValue);
		oglContactUsPage.enterLastNameSignUp(lastNameValue);
		oglContactUsPage.enterEmailSignUp(emailValue);
		oglContactUsPage.enterZipCodeSignUp(zipCodeValue);
		oglContactUsPage.enterPhoneNumberSignUp(phoneNumberValue);
		oglContactUsPage.selectSpecialty(selectSpecialtyValue);
		oglContactUsPage.enterInstitutionSignUp(institutionValue);
		oglContactUsPage.clickSubmitButtonUnderSignUpInformationTitle();
		verifySafely(oglContactUsPage.isConfirmationMessageDisplayed(), true,
				"'Thanks for submitting the form' confirmation message appears under the form.");

		logInfo("----------------Verification done for Contact Us Page of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();
	}

}
