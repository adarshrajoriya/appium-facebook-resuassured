package exact.ath.sitecore.oiq.enCH;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.oiq.oiqCH.OiqCHHomePage;

/**
 * This class verifies OIQ Switzerland web site French page
 * 
 * @userstory #304475 Task#307103
 * @author Pushkar Singh
 * @since 07/03/2023
 */
public class OiqCHFrenchPageTest extends BasicIntTest {

	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();

	private final String loginUrl = oiqenCHPagesProperties.getProperty("oiqCHsiteURL");
	private final String oiqenCHPageTitle = oiqenCHPagesProperties.getProperty("oiqenCHPageTitle");
	private final String popupHeadingThirdPartySitesText = oiqenCHPagesProperties
			.getProperty("popupHeadingThirdPartySitesText");
	private final String popupbutton1Text = oiqenCHPagesProperties.getProperty("popupbutton1Text");
	private final String oiqFRsiteURL = oiqenCHPagesProperties.getProperty("oiqFRsiteURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqCHFrenchPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Switzerland Homepage URL '" + loginUrl + "'");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on " + popupbutton1Text + "");

		verifySafely(oiqCHHomePage.getOiqPageTitle(), oiqenCHPageTitle, "Page Heading displayed");

		oiqCHHomePage.clickHeaderOption1();
		logInfo("Clicked on 'FRENCH WEBSITE' item from the header section");

		verifySafely(oiqCHHomePage.getpopupHeading(), popupHeadingThirdPartySitesText, "Popup Heading displayed");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		verifySafely(driver.getURL(), oiqFRsiteURL, "Page URL matches");

		throwAssertionErrorOnFailure();
	}

}
