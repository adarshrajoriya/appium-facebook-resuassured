package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglContactUsPage;
import exact.ath.ogl.OglEducationPage;
import exact.ath.ogl.OglHomepage;
import exact.ath.ogl.OglOverviewPage;
import exact.ath.ogl.OglWebinarPage;
import exact.sys.Driver;

/**
 * This class verifies the Education Page of OGL website
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 07/06/2023
 */

public class OglEducationPageTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();
	private final OglEducationPage oglEducationPage = new OglEducationPage();
	private final OglWebinarPage oglWebinarPage = new OglWebinarPage();
	private final OglOverviewPage oglOverviewPage = new OglOverviewPage();
	private final OglContactUsPage oglContactUsPage = new OglContactUsPage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String education = oglPagesProperties.getProperty("education");
	private final String educationURL = oglPagesProperties.getProperty("educationURL");
	private final String newApproachHccSurveillanceTitle = oglPagesProperties
			.getProperty("newApproachHccSurveillanceTitle");
	private final String webinarsWhitePapersMore = oglPagesProperties.getProperty("webinarsWhitePapersMore");
	private final String publications = oglPagesProperties.getProperty("publications");
	private final String blogInsights = oglPagesProperties.getProperty("blogInsights");
	private final String whitePaper = oglPagesProperties.getProperty("whitePaper");
	private final String thoughtLeadership = oglPagesProperties.getProperty("thoughtLeadership");
	private final String hepatocellularCarcinomaSurveillanceBarriersAndEducationWebinar = oglPagesProperties
			.getProperty("hepatocellularCarcinomaSurveillanceBarriersAndEducationWebinar");
	private final String webinarHepatocellularCarcinomaEducationURL = oglPagesProperties
			.getProperty("webinarHepatocellularCarcinomaEducationURL");
	private final String hepatocellularCarcinomaSurveillanceTitle = oglPagesProperties
			.getProperty("hepatocellularCarcinomaSurveillanceTitle");
	private final String webinarsURL = oglPagesProperties.getProperty("webinarsURL");
	private final String webinarsName = oglPagesProperties.getProperty("webinarsName");
	private final String webinarURL = oglPagesProperties.getProperty("webinarURL");
	private final String invalidEmail = oglPagesProperties.getProperty("invalidEmail");
	private final String validEmail = oglPagesProperties.getProperty("validEmail");
	private final String publicationNames = oglPagesProperties.getProperty("publicationNames");
	private final String publicationURL = oglPagesProperties.getProperty("publicationURL");
	private final String dnaMethylationMarkers = oglPagesProperties.getProperty("dnaMethylationMarkers");
	private final String dnaMethylationMarkersURL = oglPagesProperties.getProperty("dnaMethylationMarkersURL");
	private final String seeMoreLinkURL = oglPagesProperties.getProperty("seeMoreLinkURL");
	private final String viewBlogURL = oglPagesProperties.getProperty("viewBlogURL");
	private final String learnMorePageURL = oglPagesProperties.getProperty("learnMorePageURL");
	private final String blogNames = oglPagesProperties.getProperty("blogNames");
	private final String blogURL = oglPagesProperties.getProperty("blogURL");
	private final String hccSurveillanceCommonImpactURL = oglPagesProperties
			.getProperty("hccSurveillanceCommonImpactURL");
	private final String hepatocellularCarcinomaUnitedStatesURL = oglPagesProperties
			.getProperty("hepatocellularCarcinomaUnitedStatesURL");
	private final String simpleBloodTestDetectHccURL = oglPagesProperties.getProperty("simpleBloodTestDetectHccURL");
	private final String hccSurveillanceCommonImpact = oglPagesProperties.getProperty("hccSurveillanceCommonImpact");
	private final String hepatocellularCarcinomaUnitedStates = oglPagesProperties
			.getProperty("hepatocellularCarcinomaUnitedStates");
	private final String simpleBloodTestDetectHcc = oglPagesProperties.getProperty("simpleBloodTestDetectHcc");
	private final String ongoingClinicalTrialsURL = oglPagesProperties.getProperty("ongoingClinicalTrialsURL");
	private final String inceptionInsightsDevelopmentURL = oglPagesProperties
			.getProperty("inceptionInsightsDevelopmentURL");
	private final String signUpdatesURL = oglPagesProperties.getProperty("signUpdatesURL");
	private final String inceptionInsightsDevelopment = oglPagesProperties.getProperty("inceptionInsightsDevelopment");
	private final String textLinkNames = oglPagesProperties.getProperty("textLinkNames");
	private final String textLinkURL = oglPagesProperties.getProperty("textLinkURL");
	private final String featured = oglPagesProperties.getProperty("featured");
	private final String featuredURL = oglPagesProperties.getProperty("featuredURL");
	private final String textLinkNamesOnSecondCard = oglPagesProperties.getProperty("textLinkNamesOnSecondCard");
	private final String textLinkNamesOnSecondCardURL = oglPagesProperties.getProperty("textLinkNamesOnSecondCardURL");

	private final String strongPerformance = oglPagesProperties.getProperty("strongPerformance");
	private final String oncoguardLiverTestClinicalPerformanceURL = oglPagesProperties
			.getProperty("oncoguardLiverTestClinicalPerformanceURL");
	private final String clinicalTrialText = oglPagesProperties.getProperty("clinicalTrialText");
	private final String clinicalTrialTextURL = oglPagesProperties.getProperty("clinicalTrialTextURL");
	private final String evaluatingUltraSound = oglPagesProperties.getProperty("evaluatingUltraSound");
	private final String evaluatingUltraSoundURL = oglPagesProperties.getProperty("evaluatingUltraSoundURL");

	private final String textLinkNamesOnThirdCard = oglPagesProperties.getProperty("textLinkNamesOnThirdCard");
	private final String textLinkNamesOnThirdCardURL = oglPagesProperties.getProperty("textLinkNamesOnThirdCardURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglEducationPageTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of Education Page of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");

		oglHomepage.clickTopNavOption(education);
		verifySafely(driver.getURL(), educationURL, "'Education' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), newApproachHccSurveillanceTitle,
				"'A new approach to HCC surveillance' Title is displayed on Page");

		oglEducationPage.clickOnReadWhitePaperLink();
		verifySafely(oglEducationPage.isEnquiryFormDisplayed(), true, "Enquiry Form is displayed on Page");
		driver.refresh();
		verifySafely(!oglEducationPage.isEnquiryFormDisplayed(), true,
				"Refresh the page and Enquiry Form is not displayed on Page");

		verifySafely(oglOverviewPage.isBannerItemDisplayed(webinarsWhitePapersMore), true,
				"Icon Card '" + webinarsWhitePapersMore + "' is displayed under 'Jump to a section:' banner");
		verifySafely(oglOverviewPage.isBannerItemDisplayed(publications), true,
				"Icon Card '" + publications + "' is displayed under 'Jump to a section:' banner");
		verifySafely(oglOverviewPage.isBannerItemDisplayed(blogInsights), true,
				"Icon Card '" + blogInsights + "' is displayed under 'Jump to a section:' banner");

		oglOverviewPage.clickBannerItemOverviewPage(webinarsWhitePapersMore);
		verifySafely(oglEducationPage.getWebinarsWhitePapersMoreHeading(), webinarsWhitePapersMore,
				"'Webinars, White Papers & More' content is displayed on same page");

		oglOverviewPage.clickBannerItemOverviewPage(publications);
		verifySafely(oglEducationPage.getPublicationsHeading(), publications,
				"'Publications' content is displayed on same page");

		oglOverviewPage.clickBannerItemOverviewPage(blogInsights);
		verifySafely(oglEducationPage.getBlogInsightsHeading(), blogInsights,
				"'Blog Insights' content is displayed on same page");

		verificationsOfCardsUnderWebinarsWhitePapersAndMoreTitle();

		oglEducationPage.clickOnViewAllButton();
		verifySafely(driver.getURL(), webinarsURL, "'Webinars' Page is displayed");
		verifySafely(oglWebinarPage.isListOfCardsDisplayed(), true, "'List of cards' is displayed' on Page");
		driver.refresh();
		cardsVerificationsInWebinarPageAfterClickingOnViewAllButton();
		oglEducationPage.clickOnSignUpButton();
		verifySafely(oglContactUsPage.isMandatoryFieldsDisplayed(), true,
				"'Please fill out this required field' message is displayed on the page");

		oglEducationPage.enterEmail(invalidEmail);
		oglEducationPage.clickOnSignUpButton();
		verifySafely(oglContactUsPage.isMandatoryFieldsDisplayed(), true,
				"'Email must be formatted correctly.' message is displayed on the page");

		oglEducationPage.enterEmail(validEmail);
		oglEducationPage.clickOnSignUpButton();
		verifySafely(oglEducationPage.isSubscribingMessageDisplayed(), true,
				"'Thanks for Subscribing!' confirmation message is displayed on the page");
		driver.back();

		verificationsOfLinksUnderPublicationsTitle();

		oglEducationPage.clickOnSeeMoreLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), seeMoreLinkURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		driver.close();
		new Driver().open(oglHomePageURL);
		acceptCookiesOgl();
		oglHomepage.clickTopNavOption(education);

		oglWebinarPage.clickCardsOnPage(inceptionInsightsDevelopment);
		verifySafely(driver.getURL(), inceptionInsightsDevelopmentURL, "'Page URL matches");

		verificationsOfLinksAfterclickingTheFirstCardlinkUnderBlogInsightsTitle();
		oglEducationPage.enterEmail(validEmail);
		oglEducationPage.clickOnSignUpButton();
		verifySafely(oglEducationPage.isSubscribingMessageDisplayed(), true,
				"'Thanks for Subscribing!' confirmation message is displayed on the page");

		driver.back();

		oglWebinarPage.clickCardsOnPage(hccSurveillanceCommonImpact);
		verifySafely(driver.getURL(), hccSurveillanceCommonImpactURL, "'Page URL matches");

		verificationsOfLinksAfterclickingTheSecondCardlinkUnderBlogInsightsTitle();

		oglEducationPage.enterEmail(validEmail);
		oglEducationPage.clickOnSignUpButton();
		verifySafely(oglEducationPage.isSubscribingMessageDisplayed(), true,
				"'Thanks for Subscribing!' confirmation message is displayed on the page");

		driver.back();

		oglWebinarPage.clickCardsOnPage(evaluatingUltraSound);
		verifySafely(driver.getURL(), evaluatingUltraSoundURL, "'Page URL matches");

		verificationsOfLinksAfterclickingTheThirdCardlinkUnderBlogInsightsTitle();

		oglEducationPage.enterEmail(validEmail);
		oglEducationPage.clickOnSignUpButton();
		verifySafely(oglEducationPage.isSubscribingMessageDisplayed(), true,
				"'Thanks for Subscribing!' confirmation message is displayed on the page");

		driver.back();

		oglEducationPage.clickOnViewBlogButton();
		verifySafely(driver.getURL(), viewBlogURL, "' Page URL matches");

		oglOverviewPage.clickOnLearnMoreUnderOncoguardSolution();
		logInfo("Clicked on 'LEARN MORE' button under 'View Blog' Page");
		verifySafely(driver.getURL(), learnMorePageURL, "'Page URL matches");
		driver.back();

		verificationsOfLinksOnPageAfterClickingViewBlogButton();

		driver.back();
		oglEducationPage.clickOnLeftNavigationLearnMoreButton();
		verifySafely(driver.getURL(), ongoingClinicalTrialsURL, "' Page URL matches");
		driver.back();

		oglEducationPage.clickOnSignUpdatesCard();
		verifySafely(driver.getURL(), signUpdatesURL, "' Page URL matches");

		logInfo("----------------Verification done for Education Page of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();

	}

	private void verificationsOfCardsUnderWebinarsWhitePapersAndMoreTitle() throws Exception {

		driver.refresh();
		oglEducationPage.clickOnTheCardsUnderWebinarsWhitePapersMoreTitle(0, whitePaper);
		verifySafely(oglEducationPage.isEnquiryFormDisplayed(), true, "Enquiry Form is displayed on Page");
		driver.refresh();
		verifySafely(!oglEducationPage.isEnquiryFormDisplayed(), true,
				"Refresh the page and Enquiry Form is not displayed on Page");

		oglEducationPage.clickOnTheCardsUnderWebinarsWhitePapersMoreTitle(1, thoughtLeadership);
		verifySafely(oglEducationPage.isEnquiryFormDisplayed(), true, "Enquiry Form is displayed on Page");
		driver.refresh();
		verifySafely(!oglEducationPage.isEnquiryFormDisplayed(), true,
				"Refresh the page and Enquiry Form is not displayed on Page");

		oglEducationPage.clickOnTheCardsUnderWebinarsWhitePapersMoreTitle(2,
				hepatocellularCarcinomaSurveillanceBarriersAndEducationWebinar);
		verifySafely(driver.getURL(), webinarHepatocellularCarcinomaEducationURL,
				"'Hepatocellular Carcinoma Surveillance: Barriers and Education Webinar' Page is displayed");
		verifySafely(oglEducationPage.getHepatocellularCarcinomaSurveillanceHeading(),
				hepatocellularCarcinomaSurveillanceTitle,
				"'Hepatocellular Carcinoma Surveillance: Barriers and Education' Title is displayed on Page");

		driver.back();

	}

	private void cardsVerificationsInWebinarPageAfterClickingOnViewAllButton() throws Exception {
		oglEducationPage.clickOnTheCardsUnderWebinarsWhitePapersMoreTitle(0, whitePaper);
		verifySafely(oglEducationPage.isEnquiryFormDisplayed(), true, "Enquiry Form is displayed on Page");
		driver.refresh();
		verifySafely(!oglEducationPage.isEnquiryFormDisplayed(), true,
				"Refresh the page and Enquiry Form is not displayed on Page");

		oglEducationPage.clickOnTheCardsUnderWebinarsWhitePapersMoreTitle(1, thoughtLeadership);
		verifySafely(oglEducationPage.isEnquiryFormDisplayed(), true, "Enquiry Form is displayed on Page");
		driver.refresh();
		verifySafely(!oglEducationPage.isEnquiryFormDisplayed(), true,
				"Refresh the page and Enquiry Form is not displayed on Page");

		String[] webinarsNamesArr = webinarsName.split(",");
		String[] webinarURLArr = webinarURL.split(",");
		for (int count = 0; count < webinarsNamesArr.length; count++) {

			oglWebinarPage.clickCardsOnPage(webinarsNamesArr[count]);
			verifySafely(driver.getURL(), webinarURLArr[count], "' Page URL matches");
			driver.back();

		}

	}

	private void verificationsOfLinksUnderPublicationsTitle() throws Exception {
		String[] publicationNamesArr = publicationNames.split(",");
		String[] publicationURLArr = publicationURL.split(",");
		for (int count = 0; count < publicationNamesArr.length; count++) {

			oglEducationPage.clickPublicationsCardsOnPage(publicationNamesArr[count]);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), publicationURLArr[count], "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();

		}

		oglEducationPage.clickPublicationsCardsOnPage(dnaMethylationMarkers);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), dnaMethylationMarkersURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

	}

	private void verificationsOfLinksAfterclickingTheFirstCardlinkUnderBlogInsightsTitle() throws Exception

	{

		oglEducationPage.clickTextLinksOnPage(featured);
		verifySafely(driver.getURL(), featuredURL, "' Page URL matches");
		driver.back();

		String[] textLinkNamesArr = textLinkNames.split(",");
		String[] textLinkURLArr = textLinkURL.split(",");
		for (int count = 0; count < textLinkNamesArr.length; count++) {

			oglEducationPage.clickTextLinksOnPage(textLinkNamesArr[count]);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), textLinkURLArr[count], "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();

		}

	}

	private void verificationsOfLinksAfterclickingTheSecondCardlinkUnderBlogInsightsTitle() throws Exception

	{
		String[] textLinkNamesOnSecondCardArr = textLinkNamesOnSecondCard.split(",");
		String[] textLinkURLOnSecondCardArr = textLinkNamesOnSecondCardURL.split(",");

		for (int count = 0; count < textLinkNamesOnSecondCardArr.length; count++) {

			oglEducationPage.clickTextLinksOnPage(textLinkNamesOnSecondCardArr[count]);
			verifySafely(driver.getURL(), textLinkURLOnSecondCardArr[count], "' Page URL matches");
			driver.back();

		}

		oglEducationPage.clickTextLinksOnPage(strongPerformance);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncoguardLiverTestClinicalPerformanceURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglEducationPage.clickTextLinksOnPage(clinicalTrialText);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), clinicalTrialTextURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

	}

	private void verificationsOfLinksAfterclickingTheThirdCardlinkUnderBlogInsightsTitle() throws Exception

	{
		oglEducationPage.clickTextLinksOnPage(featured);
		verifySafely(driver.getURL(), featuredURL, "' Page URL matches");
		driver.back();

		String[] textLinkNamesOnThirdCardArr = textLinkNamesOnThirdCard.split(",");
		String[] textLinkNamesOnThirdCardURLArr = textLinkNamesOnThirdCardURL.split(",");
		for (int count = 0; count < textLinkNamesOnThirdCardArr.length; count++) {

			oglEducationPage.clickTextLinksOnPage(textLinkNamesOnThirdCardArr[count]);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), textLinkNamesOnThirdCardURLArr[count], "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();

		}
	}

	private void verificationsOfLinksOnPageAfterClickingViewBlogButton() throws Exception

	{
		String[] blogNamesArr = blogNames.split(",");
		String[] blogURLArr = blogURL.split(",");
		for (int count = 0; count < blogNamesArr.length; count++) {

			oglWebinarPage.clickCardsOnPage(blogNamesArr[count]);
			verifySafely(driver.getURL(), blogURLArr[count], "' Page URL matches");
			driver.back();

		}

		oglWebinarPage.clickCardsOnPage(hccSurveillanceCommonImpact);
		verifySafely(driver.getURL(), hccSurveillanceCommonImpactURL, "' Page URL matches");
		driver.back();

		oglWebinarPage.clickCardsOnPage(hepatocellularCarcinomaUnitedStates);
		verifySafely(driver.getURL(), hepatocellularCarcinomaUnitedStatesURL, "' Page URL matches");
		driver.back();

		oglWebinarPage.clickCardsOnPage(simpleBloodTestDetectHcc);
		verifySafely(driver.getURL(), simpleBloodTestDetectHccURL, "' Page URL matches");
		driver.back();
	}

}
