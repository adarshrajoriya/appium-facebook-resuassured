package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.AboutScreeningPage;
import exact.ath.cologuard.CGEffectiveAndEasyPage;
import exact.ath.cologuard.CollectingAndReturningYourSamplePage;
import exact.ath.cologuard.PatientStoriesPage;
import exact.ath.cologuard.ResourcesAndSupportPage;
import exact.ath.cologuard.TheCologuardDifferencePage;
import exact.ath.cologuard.UnderstandingYourResultPage;
import exact.util.PostStatusToZephyr;
import exact.util.Sleeper;

/**
 * This test checks data for videos in Cologuard Website
 * 
 * @userstory #303911 Task#304285
 * @author Tushar Gupta
 * @since 05/30/2023
 */

public class CologuardVideoTest extends BasicIntTest {

	private final AboutScreeningPage aboutScreeningPage = new AboutScreeningPage();
	private final TheCologuardDifferencePage theCologuardDifferencePage = new TheCologuardDifferencePage();
	private final PatientStoriesPage patientStoriesPage = new PatientStoriesPage();
	private final CGEffectiveAndEasyPage cgEffectiveAndEasyPage = new CGEffectiveAndEasyPage();
	private final CollectingAndReturningYourSamplePage collectingAndReturningYourSamplePage = new CollectingAndReturningYourSamplePage();
	private final UnderstandingYourResultPage understandingYourResultPage = new UnderstandingYourResultPage();
	private final ResourcesAndSupportPage resourcesAndSupportPage = new ResourcesAndSupportPage();
	private final String collectingAndReturnYourSample = cologuardPagesProperties
			.getProperty("collectingAndReturningSamples");
	private final String cologuardHomePageURL = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	private final String aboutScreeningPageURL = cologuardPagesProperties.getProperty("aboutScreeningPageURL");
	private final String patientStoriesPageURL = cologuardPagesProperties.getProperty("patientStoriesPageURL");
	private final String effectiveAndEasyURL = cologuardPagesProperties.getProperty("effectiveAndEasyURL");
	private final String useCologuard = cologuardPagesProperties.getProperty("useCologuard");
	private final String understandingYourResult = cologuardPagesProperties.getProperty("understandingYourResult");
	private final String theCologuardDifferencePageURL = cologuardPagesProperties
			.getProperty("theCologuardDifferencePageURL");
	private final String whyCologuard = cologuardPagesProperties.getProperty("whyCologuard");
	private final String effectiveAndEasyToUse = cologuardPagesProperties.getProperty("effectiveAndEasyToUse");
	private final String aboutScreening = cologuardPagesProperties.getProperty("aboutScreening");
	private final String cologuardDifference = cologuardPagesProperties.getProperty("cologuardDifference");
	private final String patientStories = cologuardPagesProperties.getProperty("patientStories");
	private final String aboutScreeningPageTitle = cologuardPagesProperties.getProperty("aboutScreeningPageTitle");
	private final String theCologuardDifferencePageTitle = cologuardPagesProperties
			.getProperty("theCologuardDifferencePageTitle");
	private final String patientStoriesPageTitle = cologuardPagesProperties.getProperty("patientStoriesPageTitle");
	private final String effectiveAndEasyToUseTitle = cologuardPagesProperties
			.getProperty("effectiveAndEasyScreeningPageTitle");
	private final String collectingAndReturningSampleURL = cologuardPagesProperties
			.getProperty("collectingAndReturningSampleURL");
	private final String collectingAndReturningSamplePageTitle = cologuardPagesProperties
			.getProperty("collectingAndReturningSamplePageTitle");
	private final String understandingYourResultURL = cologuardPagesProperties
			.getProperty("understandingYourResultURL");
	private final String understandingYourResultPageTitle = cologuardPagesProperties
			.getProperty("understandingYourResultPageTitle");
	private final String resourcesAndSupport = cologuardPagesProperties.getProperty("resourcesAndSupport");
	private final String resourcesAndSupportURL = cologuardPagesProperties.getProperty("resourcesAndSupportURL");
	private final String resourcesAndSupportPageTitle = cologuardPagesProperties
			.getProperty("resourcesAndSupportPageTitle");
	String initialTime = "0:00";
	String finalTime;

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T1082";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyCologuardVideoTest() throws Exception {

		checkForExUSSite(cologuardHomePageURL);

		acceptCookies();

		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, aboutScreening);
		logInfo("Clicked on 'About screening' under 'Why Cologuard?' dropdown");

		verifySafely(driver.getURL(), aboutScreeningPageURL, "'About Screening' page is displayed");
		verifySafely(driver.getTitle(), aboutScreeningPageTitle,
				aboutScreeningPageTitle + " is displayed as page title");

		aboutScreeningPage.clickLearnFactsForColonCancerVideo();
		logInfo("Played video next to 'Colon cancer: let's learn the facts'");
		Sleeper.sleepTightInSeconds(12);
		aboutScreeningPage.clickLearnFactsForColonCancerVideo();
		logInfo("Paused video next to 'Colon cancer: let's learn the facts'");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Learn Facts For Colon Cancer Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		aboutScreeningPage.clickWhyScreeningMattersVideo();
		logInfo("Played video next to 'Why screening matters'");
		Sleeper.sleepTightInSeconds(12);
		aboutScreeningPage.clickWhyScreeningMattersVideo();
		logInfo("Paused video next to 'Why screening matters'");
		finalTime = aboutScreeningPage.getVideoTime(1);
		verifySafely(!initialTime.equals(finalTime), true,
				"Why Screening Matters Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, cologuardDifference);
		logInfo("Clicked on 'The Cologuard difference' under 'Why Cologuard?' dropdown");

		verifySafely(driver.getURL(), theCologuardDifferencePageURL, "'The Cologuard difference' page is displayed");
		verifySafely(driver.getTitle(), theCologuardDifferencePageTitle,
				theCologuardDifferencePageTitle + " is displayed as page title");

		theCologuardDifferencePage.clickTheCologuardDifferenceVideo();
		logInfo("Played video next to 'The Cologuard difference'");
		Sleeper.sleepTightInSeconds(12);
		theCologuardDifferencePage.clickTheCologuardDifferenceVideo();
		logInfo("Paused video next to 'The Cologuard difference'");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"The Cologuard Difference Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		theCologuardDifferencePage.clickTheScienceBehindCologuardVideo();
		logInfo("Played video under the 'The science behind Cologuard'");
		Sleeper.sleepTightInSeconds(12);
		theCologuardDifferencePage.clickTheScienceBehindCologuardVideo();
		logInfo("Paused video under the 'The science behind Cologuard'");
		finalTime = aboutScreeningPage.getVideoTime(1);
		verifySafely(!initialTime.equals(finalTime), true,
				"The Science Behind Cologuard Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, effectiveAndEasyToUse);
		logInfo("Clicked on 'Effective and easy screening' under 'Why Cologuard?' dropdown");
		verifySafely(driver.getURL(), effectiveAndEasyURL, "'Effective and easy screening' page is displayed");
		verifySafely(driver.getTitle(), effectiveAndEasyToUseTitle,
				effectiveAndEasyToUseTitle + " title is displayed for the page");

		cgEffectiveAndEasyPage.clickCologuardIsConvenientVideoInCard();
		logInfo("Played video under the 'Cologuard is convenient' Card");
		Sleeper.sleepTightInSeconds(12);
		cgEffectiveAndEasyPage.clickCologuardIsConvenientVideoInCard();
		logInfo("Paused video under the 'Cologuard is convenient' Card");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Cologuard Is Convenient Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, patientStories);
		logInfo("Clicked on 'Patient stories' under 'Why Cologuard?' dropdown");

		verifySafely(driver.getURL(), patientStoriesPageURL, "'Patient Stories' page is displayed");
		verifySafely(driver.getTitle(), patientStoriesPageTitle,
				patientStoriesPageTitle + " is displayed as page title");

		patientStoriesPage.clickMeetScottPlayVideo();
		logInfo("Played video of the Patient 'Meet Scott'");
		Sleeper.sleepTightInSeconds(12);
		driver.refresh();

		cologuardHomepage.selectSubOptionFromTopNavOptions(useCologuard, collectingAndReturnYourSample);
		logInfo("Clicked on 'Collecting & returning your sample' under 'Use Cologuard' dropdown");
		verifySafely(driver.getURL(), collectingAndReturningSampleURL,
				"'Collecting and Returning your sample' page is displayed");
		verifySafely(driver.getTitle(), collectingAndReturningSamplePageTitle,
				collectingAndReturningSamplePageTitle + " is displayed as page title");

		collectingAndReturningYourSamplePage.playReadyToReturnYourKitVideo();
		logInfo("Played video under the 'Using & returning your Cologuard® kit.'");
		Sleeper.sleepTightInSeconds(12);
		collectingAndReturningYourSamplePage.playReadyToReturnYourKitVideo();
		logInfo("Paused video under the 'Using & returning your Cologuard® kit.'");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Under Using & returning your Cologuard® kit Video is played and paused successfully Initial Time = '"
						+ initialTime + "' Final Time = '" + finalTime + "'");

		cologuardHomepage.selectSubOptionFromTopNavOptions(useCologuard, understandingYourResult);
		logInfo("Clicked on 'Understanding your result' under 'Use Cologuard' dropdown");
		verifySafely(driver.getURL(), understandingYourResultURL, "'Understanding your result' page is displayed");
		verifySafely(driver.getTitle(), understandingYourResultPageTitle,
				understandingYourResultPageTitle + " is displayed as page title");

		understandingYourResultPage.clickNegativeResultAccordion();

		understandingYourResultPage.playNegativeResultVideo();
		logInfo("Played video under the 'Negative Result'");
		Sleeper.sleepTightInSeconds(12);
		understandingYourResultPage.playNegativeResultVideo();
		logInfo("Paused video under the 'Negative Result'");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Negative Result Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		understandingYourResultPage.clickPositiveResultAccordion();

		understandingYourResultPage.playNegativeResultVideo();
		logInfo("Played video under the 'Positive Result'");
		Sleeper.sleepTightInSeconds(12);
		understandingYourResultPage.playNegativeResultVideo();
		logInfo("Paused video under the 'Positive Result'");
		finalTime = aboutScreeningPage.getVideoTime(1);
		verifySafely(!initialTime.equals(finalTime), true,
				"Positive Result Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		cologuardHomepage.selectSubOptionFromTopNavOptions(useCologuard, resourcesAndSupport);
		logInfo("Clicked on 'Resources & support' under 'Use Cologuard' dropdown");
		verifySafely(driver.getURL(), resourcesAndSupportURL, "'Resources & support' page is displayed");
		verifySafely(driver.getTitle(), resourcesAndSupportPageTitle,
				resourcesAndSupportPageTitle + " is displayed as page title");

		resourcesAndSupportPage.clickPlayVideoButton();
		logInfo("Clicked on 'Play Video' Button and Video starts Playing under the 'Watch How to Use video' title");
		Sleeper.sleepTightInSeconds(12);
		understandingYourResultPage.playNegativeResultVideo();
		logInfo("Paused video under the 'Watch How to Use video' title");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Under the 'Watch How to Use video' title Video is played and paused successfully Initial Time = '"
						+ initialTime + "' Final Time = '" + finalTime + "'");

		driver.close();

		throwAssertionErrorOnFailure();

	}

}
