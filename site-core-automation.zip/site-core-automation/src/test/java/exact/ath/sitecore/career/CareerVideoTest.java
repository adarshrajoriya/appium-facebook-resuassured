package exact.ath.sitecore.career;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CareerWebsite;
import exact.sys.Driver;
import exact.util.Sleeper;

/**
 * This class verifies Career Website Videos verifications
 * 
 * @userstory #301264 Task#303952
 * @author qas_tgupta
 * @since 05/11/2023
 */

public class CareerVideoTest extends BasicIntTest {

	private final CareerWebsite careerWebsite = new CareerWebsite();
	private final Driver driver = new Driver();
	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CareerWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CareerWebURL");
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final String coreValueLinkURL = exactPagesProperties.getProperty("CoreValueLinkURL");
	private final String whyExactSciencesTitle = exactPagesProperties.getProperty("WhyExactSciencesTitle");
	private final By meetExactSciencesFrame = By.xpath(exactPagesProperties.getProperty("MeetExactSciencesFrame"));
	String initialTime;
	String finalTime;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void careerVideoTest() {
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		logInfo("----------------Starting verification of Videos of Career Website------------");
		verifySafely(careerWebsite.getCareerWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Heading");
		verifySafely(careerWebsite.isHeaderSectionDisplayed(), true, "'Header Section' is displayed on the page");
		verifySafely(careerWebsite.isPageTitleDisplayed(), true,
				"'Home Page tittle - CHANGE CAREERS.CHANGE LIVES.' is displayed on the page");
		careerWebsite.clickExploreMoreButtonDisplayedInFirstIconCard();
		logInfo("Clicked Explore More Button from 'OUR CORE VALUES GUIDE US' Icon card");
		verifySafely(careerWebsite.getTotalRewards(), whyExactSciencesTitle,
				"'WHY EXACT SCIENCES' heading is displayed after clicking Explore More Button under 'Our Core Value Guide Us' Icon Card");
		verifySafely(driver.getURL(), coreValueLinkURL, "Opened 'Core Value Guide Us Link' and Page URL matches");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Why Exact Sciences?' Tab in the header section is highlighted in blue color");
		driver.switchToFrame(meetExactSciencesFrame);
		initialTime = "0:00";
		careerWebsite.clickPlayButton(0);
		logInfo("Clicked on Play the video using 'PLAY' button above 'Olivia Finn'");
		Sleeper.sleepTightInSeconds(10);
		careerWebsite.videoHover();
		careerWebsite.clickPauseButton();
		logInfo("Clicked on Video Panel to Pause the video");
		finalTime = careerWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Olivia Finn Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		careerWebsite.clickCloseVideoButton();
		logInfo("Closed the video frame using 'X Close' button on top right");
		initialTime = "0:00";
		careerWebsite.clickPlayButton(1);
		logInfo("Clicked on Play the video using 'PLAY' button above 'Blaise Russo'");
		Sleeper.sleepTightInSeconds(8);
		careerWebsite.videoHover();
		careerWebsite.clickPauseButton();
		logInfo("Clicked on Video Panel to Pause the video");
		finalTime = careerWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Blaise Russo Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		careerWebsite.clickCloseVideoButton();
		logInfo("Closed the video frame using 'X Close' button on top right");
		initialTime = "0:00";
		careerWebsite.clickPlayButton(2);
		logInfo("Clicked on Play the video using 'PLAY' button above 'Domonique Tucker'");
		Sleeper.sleepTightInSeconds(10);
		careerWebsite.videoHover();
		careerWebsite.clickPause();
		logInfo("Clicked on Video Panel to Pause the video");
		finalTime = careerWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Domonique Tucker Video is played  and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		careerWebsite.clickCloseVideoButton();
		logInfo("Closed the video frame using 'X Close' button on top right");
		driver.refresh();
		careerWebsite.clickCareerWebsiteExactSciencesLogo();
		logInfo("Clicked on the logo 'EXACTSCIENCES' on the Header Section");
		verifySafely(careerWebsite.isPageTitleDisplayed(), true,
				"'Home Page tittle - CHANGE CAREERS.CHANGE LIVES.' is displayed on the page");
		logInfo("----------------Verification Done for Videos of Career Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
