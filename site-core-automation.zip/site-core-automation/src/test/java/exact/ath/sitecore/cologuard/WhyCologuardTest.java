package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.AboutScreeningPage;
import exact.ath.cologuard.CGAffordablePage;
import exact.ath.cologuard.CGEffectiveAndEasyPage;
import exact.ath.cologuard.CGStartScreeningAt45Page;
import exact.ath.cologuard.PatientStoriesPage;
import exact.ath.cologuard.TheCologuardDifferencePage;
import exact.ath.sitecore.CorporateWebsite;
import exact.util.PostStatusToZephyr;
import exact.util.Sleeper;

/**
 * This class verifies How to get Cologuard page verifications
 * 
 * @userstory #303911 Task#304280
 * @author Pushkar Singh
 * @since 05/03/2023
 */
public class WhyCologuardTest extends BasicIntTest {

	private final AboutScreeningPage aboutScreeningPage = new AboutScreeningPage();
	private final CGStartScreeningAt45Page cgStartScreeningAt45Page = new CGStartScreeningAt45Page();
	private final CGEffectiveAndEasyPage cgEffectiveAndEasyPage = new CGEffectiveAndEasyPage();
	private final CGAffordablePage cgAffordablePage = new CGAffordablePage();
	private final TheCologuardDifferencePage cologuardDifferencePage = new TheCologuardDifferencePage();
	private final PatientStoriesPage patientStoriesPage = new PatientStoriesPage();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();

	private final String cologuardHomePageURL = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	private final String impRiskInfoURL = cologuardPagesProperties.getProperty("impRiskInfoURL");
	private final String getCologuardURL = cologuardPagesProperties.getProperty("getCologuardURL");

	private final String whyCologuard = cologuardPagesProperties.getProperty("whyCologuard");
	private final String aboutScreening = cologuardPagesProperties.getProperty("aboutScreening");
	private final String startScreeningAt45 = cologuardPagesProperties.getProperty("startScreeningAt45");
	private final String cologuardDifference = cologuardPagesProperties.getProperty("cologuardDifference");
	private final String effectiveAndEasyToUse = cologuardPagesProperties.getProperty("effectiveAndEasyToUse");
	private final String affordable = cologuardPagesProperties.getProperty("affordable");
	private final String patientStories = cologuardPagesProperties.getProperty("patientStories");

	private final String aboutScreeningPageURL = cologuardPagesProperties.getProperty("aboutScreeningPageURL");
	private final String getCologuardPageTitle = cologuardPagesProperties.getProperty("getCologuardPageTitle");
	private final String aboutScreeningPageTitle = cologuardPagesProperties.getProperty("aboutScreeningPageTitle");
	private final String textForTrueSelectedFlag = cologuardPagesProperties.getProperty("textForTrueSelectedFlag");
	private final String textForFalseSelectedFlag = cologuardPagesProperties.getProperty("textForFalseSelectedFlag");

	private final String whyStartAt45URL = cologuardPagesProperties.getProperty("whyStartAt45URL");
	private final String effectiveAndEasyURL = cologuardPagesProperties.getProperty("effectiveAndEasyURL");
	private final String startScreeningAt45Title = cologuardPagesProperties.getProperty("startScreeningAt45Title");
	private final String impRiskInfo = cologuardPagesProperties.getProperty("impRiskInfo");

	private final String impRiskInfoPageTitle = cologuardPagesProperties.getProperty("impRiskInfoPageTitle");
	private final String effectiveAndEasyScreeningPageTitle = cologuardPagesProperties
			.getProperty("effectiveAndEasyScreeningPageTitle");
	private final String requestCologuardPageTitle = cologuardPagesProperties.getProperty("getCologuardPageTitle");

	private final String cologuardReadStoriesPageURL = cologuardPagesProperties
			.getProperty("cologuardReadStoriesPageURL");
	private final String effectiveAndEasyToUseTitle = cologuardPagesProperties
			.getProperty("effectiveAndEasyScreeningPageTitle");
	private final String cologuardScreeningStoriesTitle = cologuardPagesProperties
			.getProperty("cologuardScreeningStoriesTitle");
	private final String howDoesStoolDNATechWorkLabel = cologuardPagesProperties
			.getProperty("howDoesStoolDNATechWorkLabel");
	private final String howOftenToScreenWithCGLabel = cologuardPagesProperties
			.getProperty("howOftenToScreenWithCGLabel");

	private final String affordablePageURL = cologuardPagesProperties.getProperty("affordablePageURL");
	private final String appealsPageURL = cologuardPagesProperties.getProperty("appealsPageURL");
	private final String referencesPageURL = cologuardPagesProperties.getProperty("referencesPageURL");
	private final String cologuardInsurancePageURL = cologuardPagesProperties.getProperty("cologuardInsurancePageURL");
	private final String affordablePageTitle = cologuardPagesProperties.getProperty("affordablePageTitle");
	private final String appealsPageTitle = cologuardPagesProperties.getProperty("appealsPageTitle");

	private final String cologuardDifferencePageURL = cologuardPagesProperties
			.getProperty("cologuardDifferencePageURL");
	private final String shareYourCologuardStoryURL = cologuardPagesProperties
			.getProperty("shareYourCologuardStoryURL");
	private final String cologuardDifferencePageTitle = cologuardPagesProperties
			.getProperty("cologuardDifferencePageTitle");

	private final String whoIsCologuardForLabel = cologuardPagesProperties.getProperty("whoIsCologuardForLabel");
	private final String howEffectiveIsCologuardLabel = cologuardPagesProperties
			.getProperty("howEffectiveIsCologuardLabel");
	private final String isCologuardAFITTestLabel = cologuardPagesProperties.getProperty("isCologuardAFITTestLabel");
	private final String canCologuardDetectPolypsLabel = cologuardPagesProperties
			.getProperty("canCologuardDetectPolypsLabel");
	private final String howWillIKnowIfMyStoolSampleIsNormalLabel = cologuardPagesProperties
			.getProperty("howWillIKnowIfMyStoolSampleIsNormalLabel");

	private final String patientStoriesPageTitle = cologuardPagesProperties.getProperty("patientStoriesPageTitle");
	private final String spotlightPatientStoryName = cologuardPagesProperties.getProperty("spotlightPatientStoryName");
	private final String featuredPatientStoryName = cologuardPagesProperties.getProperty("featuredPatientStoryName");
	private final String otherPatientStoriesNames = cologuardPagesProperties.getProperty("otherPatientStoriesNames");
	private final String otherPatientMoreStoriesNames = cologuardPagesProperties
			.getProperty("otherPatientMoreStoriesNames");

	private final String firstName = exactPagesProperties.getProperty("FirstNameValue");
	private final String lastName = exactPagesProperties.getProperty("LastNameValue");
	private final String email = exactPagesProperties.getProperty("EmailValue");
	private final String phoneNumberValue = cologuardPagesProperties.getProperty("phoneNumberValue");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T1079";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyWhyCologuardPageTest() throws Exception {

		checkForExUSSite(cologuardHomePageURL);

		acceptCookies();

		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cologuardHomepage.clickTopNavOption(whyCologuard);
		verifySafely(cologuardHomepage.isSubItemDisplayed(aboutScreening), true,
				"Sub item '" + aboutScreening + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(startScreeningAt45), true,
				"Sub item '" + startScreeningAt45 + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(cologuardDifference), true,
				"Sub item '" + cologuardDifference + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(effectiveAndEasyToUse), true,
				"Sub item '" + effectiveAndEasyToUse + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(affordable), true,
				"Sub item '" + affordable + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(patientStories), true,
				"Sub item '" + patientStories + "' is displayed under 'Why Cologuard?' item");

		driver.refresh();
		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, aboutScreening);
		logInfo("Clicked on 'About screening' under 'Why Cologuard?' dropdown");

		verifySafely(driver.getURL(), aboutScreeningPageURL, "'About Screening' page is displayed");
		verifySafely(driver.getTitle(), aboutScreeningPageTitle,
				aboutScreeningPageTitle + " is displayed as page title");

		aboutScreeningPage.clickWhyScreeningMattersBtn();
		logInfo("Clicked on 'Why screening matters' button and it navigates to section");

		aboutScreeningPage.clickWaysToGetScreenedBtn();
		logInfo("Clicked on 'Ways to get screened' button and it navigates to section");

		aboutScreeningPage.clickWhoShouldGetScreenedBtn();
		logInfo("Clicked on 'Who should get screened' button and it navigates to section");

		aboutScreeningPage.selectTrueFalseFlag(1, true);
		Sleeper.sleepTightInSeconds(2);
		logInfo("Clicked on 'true' for first true/flag option");
		verifySafely(aboutScreeningPage.getFlagResultText(1).contains(textForTrueSelectedFlag), true,
				textForTrueSelectedFlag + " text is displayed when selecting true for first true/false flag");

		aboutScreeningPage.selectTrueFalseFlag(1, false);
		Sleeper.sleepTightInSeconds(2);
		logInfo("Clicked on 'true' for first true/flag option");
		verifySafely(aboutScreeningPage.getFlagResultText(1).contains(textForFalseSelectedFlag), true,
				textForFalseSelectedFlag + " text is displayed when selecting false for first true/false flag");
		logInfo("Response displays text as per selected flag");

		aboutScreeningPage.clickHowToGetCologuard();
		logInfo("Clicked on 'How to get Cologuard'");

		verifySafely(driver.getURL(), getCologuardURL, "'How to get Cologuard' page is displayed");
		verifySafely(driver.getTitle(), getCologuardPageTitle, getCologuardPageTitle + " is displayed as page title");

		driver.back();
		logInfo("Navigated back to About screening page");

		aboutScreeningPage.clickWhyScreeningMattersBtn();
		logInfo("Clicked on 'Why screening matters' button and it navigates to section");

		verifySafely(cgStartScreeningAt45Page.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cgStartScreeningAt45Page.selectSubOptionFromTopNavOptions(whyCologuard, startScreeningAt45);
		verifySafely(driver.getURL(), whyStartAt45URL, "'Why Start at 45?' page is displayed");
		verifySafely(driver.getTitle(), startScreeningAt45Title,
				"'" + startScreeningAt45Title + "' is displayed as page title");

		cologuardHomepage.clickLinkOnPage(impRiskInfo);
		verifySafely(driver.getURL(), impRiskInfoURL, "'Important Risk Information' page is displayed");
		verifySafely(driver.getTitle(), impRiskInfoPageTitle,
				"'" + impRiskInfoPageTitle + "' is displayed as page title");

		driver.back();

		cgStartScreeningAt45Page.clickLearnMoreLink();
		verifySafely(driver.getURL(), effectiveAndEasyURL, "'Effective and easy screening' page is displayed");
		verifySafely(driver.getTitle(), effectiveAndEasyScreeningPageTitle,
				"'" + effectiveAndEasyScreeningPageTitle + "' is displayed as page title");

		driver.back();

		cgStartScreeningAt45Page.clickGetTheConversationStartedLink();
		verifySafely(driver.getURL(), getCologuardURL, "'Request Cologuard' page is displayed");
		verifySafely(driver.getTitle(), requestCologuardPageTitle,
				"'" + requestCologuardPageTitle + "' is displayed as page title");

		cologuardDifferencePage.selectSubOptionFromTopNavOptions(whyCologuard, cologuardDifference);
		verifySafely(driver.getURL(), cologuardDifferencePageURL, "'The Cologuard difference' page is displayed");
		verifySafely(driver.getTitle(), cologuardDifferencePageTitle,
				"'" + cologuardDifferencePageTitle + "' is displayed as page title");

		cologuardDifferencePage.clickReadOurPatientStoriesBtn();
		logInfo("Clicked on 'Read our Patient Stories' button");
		verifySafely(driver.getURL(), cologuardReadStoriesPageURL, "'Patient Stories' page is displayed");

		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(whoIsCologuardForLabel);
		logInfo("Expanded 'Who is Cologuard for?' accordion");
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(whoIsCologuardForLabel), true,
				whoIsCologuardForLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(howEffectiveIsCologuardLabel);
		logInfo("Expanded 'How effective is Cologuard?' accordion");
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(howEffectiveIsCologuardLabel), true,
				howEffectiveIsCologuardLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(isCologuardAFITTestLabel);
		logInfo("Expanded 'Is Cologuard a FIT* test?' accordion");
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(isCologuardAFITTestLabel), true,
				isCologuardAFITTestLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(canCologuardDetectPolypsLabel);
		logInfo("Expanded 'Can Cologuard detect polyps?' accordion");
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(canCologuardDetectPolypsLabel), true,
				canCologuardDetectPolypsLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(howWillIKnowIfMyStoolSampleIsNormalLabel);
		logInfo("Expanded 'How will I know if my stool sample is ‘normal’?' accordion");
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(howWillIKnowIfMyStoolSampleIsNormalLabel), true,
				howWillIKnowIfMyStoolSampleIsNormalLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(whoIsCologuardForLabel);
		logInfo("Collapsed 'Who is Cologuard for?' accordion");
		verifySafely(!cgEffectiveAndEasyPage.isAccordionExpandedFor(whoIsCologuardForLabel), true,
				whoIsCologuardForLabel + " accordion is collapsed");

		cgEffectiveAndEasyPage.clickAccordion(howEffectiveIsCologuardLabel);
		logInfo("Collapsed 'How effective is Cologuard?' accordion");
		verifySafely(!cgEffectiveAndEasyPage.isAccordionExpandedFor(howEffectiveIsCologuardLabel), true,
				howEffectiveIsCologuardLabel + " accordion is collapsed");

		cgEffectiveAndEasyPage.clickAccordion(isCologuardAFITTestLabel);
		logInfo("Collapsed 'Is Cologuard a FIT* test?' accordion");
		verifySafely(!cgEffectiveAndEasyPage.isAccordionExpandedFor(isCologuardAFITTestLabel), true,
				isCologuardAFITTestLabel + " accordion is collapsed");

		cgEffectiveAndEasyPage.clickAccordion(canCologuardDetectPolypsLabel);
		logInfo("Collapsed 'Can Cologuard detect polyps?' accordion");
		verifySafely(!cgEffectiveAndEasyPage.isAccordionExpandedFor(canCologuardDetectPolypsLabel), true,
				canCologuardDetectPolypsLabel + " accordion is collapsed");

		cgEffectiveAndEasyPage.clickAccordion(howWillIKnowIfMyStoolSampleIsNormalLabel);
		logInfo("Collapsed 'How will I know if my stool sample is ‘normal’?' accordion");
		verifySafely(!cgEffectiveAndEasyPage.isAccordionExpandedFor(howWillIKnowIfMyStoolSampleIsNormalLabel), true,
				howWillIKnowIfMyStoolSampleIsNormalLabel + " accordion is collapsed");

		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, effectiveAndEasyToUse);
		logInfo("Clicked on 'Effective and easy screening' under 'Why Cologuard?' dropdown");
		verifySafely(driver.getURL(), effectiveAndEasyURL, "'Effective and easy screening' page is displayed");
		verifySafely(driver.getTitle(), effectiveAndEasyToUseTitle,
				effectiveAndEasyToUseTitle + " title is displayed for the page");

		cgEffectiveAndEasyPage.clickAccordion(howDoesStoolDNATechWorkLabel);
		logInfo("Expanded 'How does Stool DNA Technology Work?' accordion");
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(howDoesStoolDNATechWorkLabel), true,
				howDoesStoolDNATechWorkLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(howOftenToScreenWithCGLabel);
		logInfo("Expanded 'How often to screen with Cologuard' accordion");
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(howOftenToScreenWithCGLabel), true,
				howOftenToScreenWithCGLabel + " accordion is expanded");

		cologuardHomepage.clickLinkOnPage(impRiskInfo);
		logInfo("Clicked on 'Important Risk Information' link");
		verifySafely(driver.getURL(), impRiskInfoURL, "'Important Risk Information' page is displayed");
		verifySafely(driver.getTitle(), impRiskInfoPageTitle,
				impRiskInfoPageTitle + " title is displayed for the page");

		driver.back();
		cgEffectiveAndEasyPage.clickReadStories();
		logInfo("Clicked on 'Read Stories' button");
		verifySafely(driver.getURL(), cologuardReadStoriesPageURL, "'Patient Stories' page is displayed");
		verifySafely(driver.getTitle(), cologuardScreeningStoriesTitle,
				"'" + cologuardScreeningStoriesTitle + "' is displayed as page title");

		driver.back();
		logInfo("Navigated back to the page");

		cgEffectiveAndEasyPage.clickMoreAboutRequestingCGBtn();
		logInfo("Clicked on 'More about requesting Cologuard' button");
		verifySafely(driver.getURL(), getCologuardURL, "'Get Cologuard' page is displayed");
		verifySafely(driver.getTitle(), getCologuardPageTitle,
				getCologuardPageTitle + " title is displayed for the page");

		cgAffordablePage.selectSubOptionFromTopNavOptions(whyCologuard, affordable);
		verifySafely(driver.getURL(), affordablePageURL, "Cologuard 'Affordable' page is displayed");
		verifySafely(driver.getTitle(), affordablePageTitle,
				"'" + affordablePageTitle + "' is displayed as page title");

		cgAffordablePage.clickReadMoreLink();
		verifySafely(cgAffordablePage.isReadLessDisplayed(), true, "'Read less' is now displayed");
		String readMoreContent = cgAffordablePage.getReadMoreContent();
		verifySafely(readMoreContent != null && !readMoreContent.equalsIgnoreCase(""), true,
				"'Read More' content is displayed");

		cgAffordablePage.clickAppealsPage();
		verifySafely(driver.getURL(), appealsPageURL, "Cologuard 'Appeals' page is displayed");
		verifySafely(driver.getTitle(), appealsPageTitle, "'" + appealsPageTitle + "' is displayed as page title");

		driver.back();

		cgAffordablePage.clickReadMoreLink();
		cgAffordablePage.clickReferencesLink();
		verifySafely(driver.getURL(), referencesPageURL, "User is redirected to 'References' page");

		driver.switchToParentWindow();

		cgAffordablePage.clickMoreAboutRequestingCG();
		verifySafely(driver.getURL(), getCologuardURL, "'how to get Cologuard' page is displayed");

		driver.back();
		cgAffordablePage.clickCologuardAndInsurance();
		verifySafely(driver.getURL(), cologuardInsurancePageURL, "'Cologuard Insurance' page is displayed");

		patientStoriesPage.selectSubOptionFromTopNavOptions(whyCologuard, patientStories);
		verifySafely(driver.getURL(), cologuardReadStoriesPageURL, "'Patient stories' page is displayed");
		verifySafely(driver.getTitle(), patientStoriesPageTitle,
				"'" + patientStoriesPageTitle + "' is displayed as page title");

		patientStoriesPage.clickReadMoreSpotlightPatientStoriesLink();
		logInfo("Clicked on Patient Story '" + spotlightPatientStoryName + "' Read More link");
		verifySafely(patientStoriesPage.getPatientNamePageTitle().contains(spotlightPatientStoryName), true,
				"Opened Page - Title VALUE: '" + patientStoriesPage.getPatientNamePageTitle() + "'");
		driver.back();

		patientStoriesPage.clickReadMoreFeaturedPatientStoriesLink();
		logInfo("Clicked on Patient Story '" + featuredPatientStoryName + "' Read More link");
		verifySafely(patientStoriesPage.getPatientNamePageTitle().contains(featuredPatientStoryName), true,
				"Opened Page - Title VALUE: '" + patientStoriesPage.getPatientNamePageTitle() + "'");
		driver.back();

		for (String otherPatientStoriesName : otherPatientStoriesNames.split(",")) {
			patientStoriesPage.clickReadMoreOtherPatientStoriesLink(otherPatientStoriesName);
			logInfo("Clicked on Patient Story '" + otherPatientStoriesName + "' Read More link");
			verifySafely(patientStoriesPage.getPatientNamePageTitle().contains(otherPatientStoriesName), true,
					"Opened Page - Title VALUE: '" + patientStoriesPage.getPatientNamePageTitle() + "'");
			driver.back();

		}

		patientStoriesPage.clickSubmitStoryBtn();
		logInfo("Clicked on Submit Story Button");
		verifySafely(driver.getURL(), shareYourCologuardStoryURL, "'Share your Cologuard® story' page is displayed");

		corporateWebsite.clickSubmitButton();
		verifySafely(corporateWebsite.isMandatoryFieldsDisplayed(), true,
				"'Please fill out this required field' message for Mandatory Fields is displayed on the page");

		corporateWebsite.enterFirstName(firstName);
		logInfo("Entered First Name '" + firstName + "'");
		corporateWebsite.enterLastName(lastName);
		logInfo("Entered Last Name '" + lastName + "'");
		corporateWebsite.enterEmail(email);
		logInfo("Entered Email '" + email + "'");
		patientStoriesPage.enterPhoneNumber(phoneNumberValue);
		logInfo("Entered Comments '" + phoneNumberValue + "'");
		patientStoriesPage.selectYourExperience();
		logInfo("Selected 'How would you describe your experience with Cologuard?* 'Satisfied'");

		corporateWebsite.clickSubmitButton();
		verifySafely(patientStoriesPage.isThankYouPageDisplayed(), true,
				"'Thank you' message is displayed on the page");

		patientStoriesPage.selectSubOptionFromTopNavOptions(whyCologuard, patientStories);
		verifySafely(driver.getURL(), cologuardReadStoriesPageURL, "'Patient stories' page is displayed");
		verifySafely(driver.getTitle(), patientStoriesPageTitle,
				"'" + patientStoriesPageTitle + "' is displayed as page title");

		for (String otherPatientStoriesName : otherPatientMoreStoriesNames.split(",")) {
			patientStoriesPage.clickMoreStoriesBtn();
			logInfo("Clicked on 'More Stories' Button");
			patientStoriesPage.clickReadMoreOtherPatientStoriesLink(otherPatientStoriesName);
			logInfo("Clicked on Patient Story '" + otherPatientStoriesName + "' Read More link");
			verifySafely(patientStoriesPage.getPatientNamePageTitle().contains(otherPatientStoriesName), true,
					"Opened Page - Title VALUE: '" + patientStoriesPage.getPatientNamePageTitle() + "'");
			driver.back();

		}

		throwAssertionErrorOnFailure();
	}

}
