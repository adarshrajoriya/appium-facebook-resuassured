package exact.ath.sitecore.career;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CareerWebsite;
import exact.sys.Driver;

/**
 * This class verifies Career Website home page verifications
 * 
 * @userstory #301264 Task#303945
 * @author qas_tgupta
 * @since 04/20/2023
 */

public class CareerHomePageTest extends BasicIntTest {

	private final CareerWebsite careerWebsite = new CareerWebsite();
	private final Driver driver = new Driver();
	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CareerWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CareerWebURL");
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final String coreValuesTitle = exactPagesProperties.getProperty("CoreValuesTitle");
	private final String inclusiveCultureTitle = exactPagesProperties.getProperty("InclusiveCultureTitle");
	private final String ourBenefitsTitle = exactPagesProperties.getProperty("OurBenefitsTitle");
	private final String fiveCoreValuesTitle = exactPagesProperties.getProperty("FiveCoreValuesTitle");
	private final String coreValueLinkURL = exactPagesProperties.getProperty("CoreValueLinkURL");
	private final String lifeAtExactSciencesTitle = exactPagesProperties.getProperty("LifeAtExactSciencesTitle");
	private final String inclusiveCultureLinkURL = exactPagesProperties.getProperty("InclusiveCultureLinkURL");
	private final String totalRewardsTitle = exactPagesProperties.getProperty("TotalRewardsTitle");
	private final String ourBenefitsLinkURL = exactPagesProperties.getProperty("OurBenefitsLinkURL");
	private final String viewOpeningsLinkURL = exactPagesProperties.getProperty("ViewOpeningsLinkURL");
	private final String lifeInMadisonTitle = exactPagesProperties.getProperty("LifeInMadisonTitle");
	private final String discoverLifeLinkURL = exactPagesProperties.getProperty("DiscoverLifeLinkURL");
	private final String exactScienceGroupPrivacyTitle = exactPagesProperties
			.getProperty("ExactScienceGroupPrivacyTitle");
//	private final String hereLinkURL = exactPagesProperties.getProperty("HereLinkURL");

	private final String equalOpportunityEmploymentLawLinkURL = exactPagesProperties
			.getProperty("EqualOpportunityEmploymentLawLinkURL");
	private final String posterSupplementLinkURL = exactPagesProperties.getProperty("PosterSupplementLinkURL");
	private final String rightWorkLinkURL = exactPagesProperties.getProperty("RightWorkLinkURL");
	private final String participationNoticeLinkURL = exactPagesProperties.getProperty("ParticipationNoticeLinkURL");
	private final String payTransparencyNondiscriminationProvisionLinkURL = exactPagesProperties
			.getProperty("PayTransparencyNondiscriminationProvisionLinkURL");
	private final String espOneLinkURL = exactPagesProperties.getProperty("EspOneLinkURL");
	private final String espTwoLinkURL = exactPagesProperties.getProperty("EspTwoLinkURL");
	private final String espThreeLinkURL = exactPagesProperties.getProperty("EspThreeLinkURL");
	private final String chineseOneLinkURL = exactPagesProperties.getProperty("ChineseOneLinkURL");
	private final String chineseTwoLinkURL = exactPagesProperties.getProperty("ChineseTwoLinkURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void careerHomePageTest() {
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		logInfo("----------------Starting verification of Home page of Career Website------------");
		verifySafely(careerWebsite.getCareerWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Heading");
		verifySafely(careerWebsite.isHeaderSectionDisplayed(), true, "'Header Section' is displayed on the page");
		verifySafely(careerWebsite.isPageTitleDisplayed(), true,
				"'Home Page tittle - CHANGE CAREERS.CHANGE LIVES.' is displayed on the page");
		verifySafely(careerWebsite.isOurCoreValuesCardDisplayed(), true,
				"'OUR CORE VALUES GUIDE US' card is displayed on the page");
		verifySafely(careerWebsite.isInclusiveCultureCardDisplayed(), true,
				"'INCLUSIVE CULTURE' card is displayed on the page");
		verifySafely(careerWebsite.isOurBenefitsCardDisplayed(), true, "'OUR BENEFITS' card is displayed on the page");
		verifySafely(careerWebsite.isDiverseTeamsSingularMissionCardDisplayed(), true,
				"'DIVERSE TEAMS ON A SINGULAR MISSION' card is displayed on the page");
		verifySafely(careerWebsite.isDiscoverLifeInMadisonButtonDisplayed(), true,
				"'DISCOVER LIFE IN MADISON' Button is displayed on the page");
		verifySafely(careerWebsite.isSeeOpenPositionsButtonDisplayed(), true,
				"'SEE OPEN POSITIONS' Button is displayed on the page");
		verifySafely(careerWebsite.isLegalDisclaimerLinksDisplayed(), true,
				"'LEGAL DISCLAIMER' Links is displayed on the page");
		verifySafely(careerWebsite.isCareerWebsiteFooterDisplayed(), true, "'Footer Section' is displayed on the page");
		logInfo("----------------Starting verification of Header Section------------");
		verifySafely(careerWebsite.isCareerWebsiteExactSciencesLogoDisplayed(), true,
				"'EXACT SCIENCES' logo is displayed under header section of Home Page");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayed(), true,
				"'Why Exactsciences?' Tab is displayed under header section of Home Page");
		verifySafely(careerWebsite.isLifeAtExactTabDisplayed(), true,
				"'Life At Exact' Tab is displayed under header section of Home Page");
		verifySafely(careerWebsite.isLocationsTabDisplayed(), true,
				"'Locations' Tab is displayed under header section of Home Page");
		verifySafely(careerWebsite.isBenefitsTabDisplayed(), true,
				"'Benefits' Tab is displayed under header section of Home Page");
		verifySafely(careerWebsite.isCurrentOpeningsTabDisplayed(), true,
				"'Current Openings' Tab is displayed under header section of Home Page");
		logInfo("----------------Verification Done for Header Section------------");
		logInfo("----------------Starting verification of Icon Cards------------");
		verifySafely(careerWebsite.getCoreValuesTitleDisplayedInFirstIconCard(), coreValuesTitle,
				"'OUR CORE VALUES GUIDE US' Title is displayed in First Icon Card");
		verifySafely(careerWebsite.isExploreMoreButtonDisplayedInFirstIconCard(), true,
				"'EXPLORE MORE' button is displayed is displayed in First Icon Card");
		verifySafely(careerWebsite.getInclusiveCultureTitleDisplayedInSecondIconCard(), inclusiveCultureTitle,
				"'INCLUSIVE CULTURE' Title is displayed in Second Icon Card");
		verifySafely(careerWebsite.isExploreMoreButtonDisplayedInSecondIconCard(), true,
				"'EXPLORE MORE' button is displayed is displayed in Second Icon Card");
		verifySafely(careerWebsite.getOurBenefitsTitleDisplayedInThirdIconCard(), ourBenefitsTitle,
				"'OUR BENEFITS' Title is displayed in Third Icon Card");
		verifySafely(careerWebsite.isExploreMoreButtonDisplayedInThirdIconCard(), true,
				"'EXPLORE MORE' button is displayed is displayed in Third Icon Card");
		logInfo("----------------Verification Done for Icon Cards------------");
		careerWebsite.clickExploreMoreButtonDisplayedInFirstIconCard();
		logInfo("Clicked Explore More Button from 'OUR CORE VALUES GUIDE US' Icon card");
		verifySafely(careerWebsite.getFiveCoreValues(), fiveCoreValuesTitle,
				"'FIVE CORE VALUES' Title is displayed after clicking expore button from Our Core Value Guide Us Icon Card");
		verifySafely(driver.getURL(), coreValueLinkURL, "Opened 'Core Value Guide Us Link' and Page URL matches");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Why Exact Sciences?' Tab in the header section is highlighted in blue color");
		driver.back();
		careerWebsite.clickExploreMoreButtonDisplayedInSecondIconCard();
		logInfo("Clicked Explore More Button  from ' INCLUSIVE CULTURE ' Icon card");
		verifySafely(careerWebsite.getLifeAtExactSciences(), lifeAtExactSciencesTitle,
				"'LIFE AT EXACT SCIENCES' Title is displayed after clicking expore button from Inclusive Culture Icon Card");
		verifySafely(driver.getURL(), inclusiveCultureLinkURL, "Opened 'Inclusive Culture Link' and Page URL matches");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Life At Exact ' Tab in the header section is highlighted in blue color");
		driver.back();
		careerWebsite.clickExploreMoreButtonDisplayedInThirdIconCard();
		logInfo("Clicked Explore More Button  from 'OUR BENEFITS' Icon card");
		verifySafely(careerWebsite.getTotalRewards(), totalRewardsTitle,
				"'TOTAL REWARDS' Title is displayed after clicking expore button from Our Benefits Icon Card");
		verifySafely(driver.getURL(), ourBenefitsLinkURL, "Opened 'Our Benefits Link' and Page URL matches");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Benefits ' Tab in the header section is highlighted in blue color");
		driver.back();
		careerWebsite.clickViewOpenings();
		logInfo("Clicked on 'VIEW OPENINGS' button from 'DIVERSE TEAMS ON A SINGULAR MISSION' card");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), viewOpeningsLinkURL, "Opened 'View Opening Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		careerWebsite.clickDiscoverLifeInMadisonButton();
		logInfo("Clicked on 'DISCOVER LIFE IN MADISON' below the 'HEADQUARTERED IN MADISON, WISCONSIN;FIGHTING CANCER GLOBALLY' title.");
		verifySafely(careerWebsite.getTotalRewards(), lifeInMadisonTitle,
				"'LIFE IN MADISON' Title is displayed after clicking Discover Life In Madison Button");
		verifySafely(driver.getURL(), discoverLifeLinkURL,
				"Opened 'Discover Life In Madison Link' and Page URL matches");
		driver.back();
		careerWebsite.clickSeeOpenPositionsButton();
		logInfo("Clicked on 'SEE OPEN POSITIONS' button below the 'We have a diverse variety of rapidly growing teams' text");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), viewOpeningsLinkURL, "Opened 'See Open Positions Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifySafely(careerWebsite.isPopupPhoneNumber(), true,
				"'608-535-8726' phone number hyperlink is displayed under LEGAL DISCLAIMER text");
		verifySafely(careerWebsite.isPopupEmail(), true,
				"'hr@exactsciences.com' email hyperlink is displayed under LEGAL DISCLAIMER text");
		careerWebsite.clickHereLinkInLegal();
		logInfo("Clicked on 'here'link from the 'LEGAL DISCLAIMER' text");
		verifySafely(careerWebsite.getExactScienceGroupPrivacy(), exactScienceGroupPrivacyTitle,
				"'EXACT SCIENCES GROUP PRIVACY NOTICE (FOR APPLICANTS IN CALIFORNIA)' Title is displayed after clicking Here Link from LEGAL DISCLAIMER text");
//		verifySafely(driver.getURL(), hereLinkURL,
//				"Opened 'Here Link from LEGAL DISCLAIMER text' and Page URL matches");
		driver.back();
		careerWebsite.clickEqualOpportunityEmployment();
		logInfo("Clicked on 'Equal Opportunity Employment Law' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), equalOpportunityEmploymentLawLinkURL,
				"Opened 'Equal Opportunity Employment is the Law Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickPosterSupplement();
		logInfo("Clicked on 'EEO is the Law Poster Supplement' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), posterSupplementLinkURL,
				"Opened '“EEO is the Law” Poster Supplement Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickRightToWork();
		logInfo("Clicked on 'Right to Work' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), rightWorkLinkURL, "Opened 'Right to Work Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickParticipationNotice();
		logInfo("Clicked on 'Participation Notice' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), participationNoticeLinkURL,
				"Opened 'Participation Notice Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickPayTransparency();
		logInfo("Clicked on 'Pay Transparency Nondiscrimination Provision' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), payTransparencyNondiscriminationProvisionLinkURL,
				"Opened 'Pay Transparency Nondiscrimination Provision Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickEspanolOne();
		logInfo("Clicked on 'Español Link 1'");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), espOneLinkURL, "Opened 'Español Link 1' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickEspanolTwo();
		logInfo("Clicked on 'Español Link 2'");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), espTwoLinkURL, "Opened 'Español Link 2' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickEspanolThree();
		logInfo("Clicked on 'Español Link 3'");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), espThreeLinkURL, "Opened 'Español Link 3' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickChineseOne();
		logInfo("Clicked on 'Chinese Link 1'");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), chineseOneLinkURL, "Opened Chinese Link 1' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickChineseTwo();
		logInfo("Clicked on 'Chinese Link 2'");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), chineseTwoLinkURL, "Opened Chinese Link 2' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Verification Done for Home page of Career Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}

}
