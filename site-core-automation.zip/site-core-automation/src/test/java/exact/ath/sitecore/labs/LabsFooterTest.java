package exact.ath.sitecore.labs;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.LabsWebsite;
import exact.sys.Driver;

/**
 * Refer User Story #301265 ,#EPS-T428 {@summary Verify the Footer of Labs
 * Website}
 * 
 * @author Manpreet Panesar
 *
 */

public class LabsFooterTest extends BasicIntTest {
	private final Driver driver = new Driver();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final LabsWebsite labsWebsite = new LabsWebsite();
	private final String labsWebsiteURL = exactPagesProperties.getProperty("LabsWebsiteURL");
	private final String labsWebsiteHomeTitleValue = exactPagesProperties.getProperty("LabsWebsiteHomeTitleValue");
	private final String aboutURL = exactPagesProperties.getProperty("AboutURL");
	private final String termsofUseURL = exactPagesProperties.getProperty("TermsofUseURL");
	private final String sMSTermsURL = exactPagesProperties.getProperty("SMSTermsURL");
	private final String purchasingTermsURL = exactPagesProperties.getProperty("PurchasingTermsURL");
	private final String patentsTrademarksURL = exactPagesProperties.getProperty("PatentsTrademarksURL");
	private final String privacyPolicyURL = exactPagesProperties.getProperty("PrivacyPolicyURL");
	private final String hIPAANoticeURL = exactPagesProperties.getProperty("HIPAANoticeURL");
	private final String doNotSellMyInfoURL = exactPagesProperties.getProperty("DoNotSellMyInfoURL");
	private final String epicCareLinkProviderPortalURL = exactPagesProperties
			.getProperty("EpicCareLinkProviderPortalURL");
	private final String cologuardcomURL = exactPagesProperties.getProperty("CologuardURL");
	private final String facebookURL = exactPagesProperties.getProperty("FacebookIconURL");
	private final String twitterURL = exactPagesProperties.getProperty("TwitterIconURL");
	private final String linkedinURL = exactPagesProperties.getProperty("LinkedInIconURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void labsFooterTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(labsWebsiteURL);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		verifySafely(labsWebsite.isFooterDisplayed(), true, "'Footer' is Displayed on the page");
		for (int count = 1; count <= 13; count++) {
			String counter = Integer.toString(count);
			String[] links = { aboutURL, termsofUseURL, sMSTermsURL, purchasingTermsURL, patentsTrademarksURL,
					privacyPolicyURL, hIPAANoticeURL, doNotSellMyInfoURL, epicCareLinkProviderPortalURL,
					cologuardcomURL, facebookURL, twitterURL, linkedinURL };
			String UrlText = labsWebsite.getFooterLinksText(counter);
			labsWebsite.clickFooterLinks(counter);
			logInfo("Clicked on '" + UrlText + "' footer link");
			if (count > 10 || count == 9) {
				driver.switchToCurrentWindow();
			}
			if (count == 10) {
				labsWebsite.checkForExUSSiteOnFooter(counter, labsWebsiteURL);
			}
			if (count == 13) {
				verifySafely(driver.getURL().contains(linkedinURL), true,
						"'" + UrlText + "' Page URL Contains. VALUE:" + linkedinURL);
			} else {
				verifySafely(driver.getURL(), links[count - 1], "'" + UrlText + "' Page URL matches");
			}
			if (count > 10 || count == 9) {
				driver.closeCurrentWindow();
				driver.switchToParentWindow();
			} else {
				driver.back();
			}
		}

		labsWebsite.clickExactSciencesLogolab();
		logInfo("Clicked on 'ExactSciences' Logo ");
		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		logBlockHeader();
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
