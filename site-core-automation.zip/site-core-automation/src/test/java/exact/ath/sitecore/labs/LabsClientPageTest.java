package exact.ath.sitecore.labs;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.LabsWebsite;
import exact.sys.Driver;

/**
 * Refer User Story #301265 ,#EPS-T396 {@summary Verify the Lab Client Services
 * page and its subpages of Labs Website} 
 * 
 * @author Manpreet Panesar
 *
 */
public class LabsClientPageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final LabsWebsite labsWebsite = new LabsWebsite();
	private final String labsWebsiteURL = exactPagesProperties.getProperty("LabsWebsiteURL");
	private final String labsWebsiteHomeTitleValue = exactPagesProperties.getProperty("LabsWebsiteHomeTitleValue");
	private final String labClientServicesPageTitleValue = exactPagesProperties
			.getProperty("LabClientServicesPageTitleValue");
	private final String becomingAClientPageTitleValue = exactPagesProperties
			.getProperty("BecomingAClientPageTitleValue");
	private final String becomingAClientPageURL = exactPagesProperties.getProperty("BecomingAClientPageURL");
	private final String orderRequisitionFormURL = exactPagesProperties.getProperty("OrderRequisitionFormURL");
	private final String epiccarelinkSiteURL = exactPagesProperties.getProperty("EpiccarelinkSiteURL");
	private final String sampleReportPageTitleValue = exactPagesProperties.getProperty("SampleReportPageTitleValue");
	private final String sampleReportPageURL = exactPagesProperties.getProperty("SampleReportPageURL");
	private final String patientBillingPageTitleValue = exactPagesProperties
			.getProperty("PatientBillingPageTitleValue");
	private final String patientBillingPageURL = exactPagesProperties.getProperty("PatientBillingPageURL");
	private final String cologuardSiteURL = exactPagesProperties.getProperty("CologuardSiteURL");
	private final String visualMapOfTestingProcessPageTitleValue = exactPagesProperties
			.getProperty("VisualMapOfTestingProcessPageTitleValue");
	private final String visualMapOfTestingProcessPageURL = exactPagesProperties
			.getProperty("VisualMapOfTestingProcessPageURL");
	private final String covid19TestingPageTitleValue = exactPagesProperties
			.getProperty("Covid19TestingPageTitleValue");
	private final String covid19TestingPageURL = exactPagesProperties.getProperty("Covid19TestingPageURL");
	private final String atHomeCollectionforCOVID19TestingPageTitleValue = exactPagesProperties
			.getProperty("AtHomeCollectionforCOVID19TestingPageTitleValue");
	private final String atHomeCollectionforCOVID19TestingPageURL = exactPagesProperties
			.getProperty("AtHomeCollectionforCOVID19TestingPageURL");
	private final String requestCOVID19TestingPageTitleValue = exactPagesProperties
			.getProperty("RequestCOVID19TestingPageTitleValue");
	private final String requestCOVID19TestingPageURL = exactPagesProperties
			.getProperty("RequestCOVID19TestingPageURL");
	private final String companyName = exactPagesProperties.getProperty("CompanyName");
	private final String companyAddress = exactPagesProperties.getProperty("CompanyAddress");
	private final String cityName = exactPagesProperties.getProperty("CityName");
	private final String stateName = exactPagesProperties.getProperty("StateName");
	private final String postelNumber = exactPagesProperties.getProperty("PostelNumber");
	private final String firstName = exactPagesProperties.getProperty("FirstName");
	private final String lastName = exactPagesProperties.getProperty("LastName");
	private final String email = exactPagesProperties.getProperty("Email");
	private final String phoneNumber = exactPagesProperties.getProperty("PhoneNumber");
	private final String bestTimeToContact = exactPagesProperties.getProperty("BestTimeToContact");
	private final String estimatedNumber = exactPagesProperties.getProperty("EstimatedNumber");
	private final String additionalComments = exactPagesProperties.getProperty("AdditionalComments");
	private final String covid19TestingDonationProgramPageTitleValue = exactPagesProperties
			.getProperty("COVID19TestingDonationProgramPageTitleValue");
	private final String covid19TestingDonationProgramPageURL = exactPagesProperties
			.getProperty("COVID19TestingDonationProgramPageURL");
	private final String covid19TestDonationRequestFormURL = exactPagesProperties
			.getProperty("COVID19TestDonationRequestFormURL");
	private final String covid19TestingIconCardValue = exactPagesProperties.getProperty("Covid19TestingIconCardValue");
	private final String covid19FluPanelTestingIconCardValue = exactPagesProperties
			.getProperty("Covid19FluPanelTestingIconCardValue");
	private final String covid19TestinginformationPageURL = exactPagesProperties
			.getProperty("Covid19TestinginformationPageURL");
	private final String covid19FluPanelTestingPageTitleValue = exactPagesProperties
			.getProperty("Covid19FluPanelTestingPageTitleValue");
	private final String covid19FluPanelTestinginformationPageURL = exactPagesProperties
			.getProperty("Covid19FluPanelTestinginformationPageURL");
	private final String cdcSiteURL = exactPagesProperties.getProperty("CdcSiteURL");
	private final String specimenCollectionSubsectionValue = exactPagesProperties
			.getProperty("SpecimenCollectionSubsectionValue");
	private final String specimenHandlingAndShippingToExactSciencesLaboratoriesSubsectionValue = exactPagesProperties
			.getProperty("SpecimenHandlingAndShippingToExactSciencesLaboratoriesSubsectionValue");
	private final String resultsDeliverySubsectionValue = exactPagesProperties
			.getProperty("ResultsDeliverySubsectionValue");
	private final String faqsTestingSarsCov2URL = exactPagesProperties.getProperty("FaqsTestingSarsCov2URL");
	private final String guidelinesClinicalSpecimensURL = exactPagesProperties
			.getProperty("GuidelinesClinicalSpecimensURL");
	private final String nasalCollectionInstructionsURL = exactPagesProperties
			.getProperty("NasalCollectionInstructionsURL");
	private final String nasalHealthcareProviderFactSheetURL = exactPagesProperties
			.getProperty("NasalHealthcareProviderFactSheetURL");
	private final String patientFactSheetURL = exactPagesProperties.getProperty("PatientFactSheetURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void labsClientPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(labsWebsiteURL);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		labsWebsite.hoverLabClientServicesMenu();
		verifySafely(labsWebsite.isBecomingAClientSubmenuDisplayed(), true,
				"'Becoming a Client' Submenu is displayed under 'Lab Client Services' header");
		verifySafely(labsWebsite.isSampleReportSubmenuDisplayed(), true,
				"'Sample Report' Submenu is displayed under 'Lab Client Services' header");
		verifySafely(labsWebsite.isPatientBillingSubmenuDisplayed(), true,
				"'Patient Billing' Submenu is displayed under 'Lab Client Services' header");
		verifySafely(labsWebsite.isVisualMapOfTestingProcessSubmenuDisplayed(), true,
				"'Visual Map of Testing Process' Submenu is displayed under 'Lab Client Services' header");
		verifySafely(labsWebsite.isCovid19TestingSubmenuDisplayed(), true,
				"'Covid-19 Testing' Submenu is displayed under 'Lab Client Services' header");
		labsWebsite.clickLabClientServicesMenuOption();
		logInfo("Clicked on 'Lab Client Services' Menu Option");
		verifySafely(labsWebsite.getPageTitle(), labClientServicesPageTitleValue, "'Lab Client Services' Page Title");
		verifySafely(labsWebsite.isCALL18448708870Displayed(), true, "'CALL 1-844-870-8870' Button is displayed");
		labsWebsite.hoverLabClientServicesMenu();
		labsWebsite.clickBecomingAClientSubmenuOption();
		logInfo("Clicked on 'Becoming a Client' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), becomingAClientPageTitleValue, "'Becoming a Client' Page Title");
		verifySafely(driver.getURL(), becomingAClientPageURL, "'Becoming a Client' Page URL matches");
		labsWebsite.clickDownloadAnOrderFormLink();
		logInfo("Clicked on 'Download An Order Form' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), orderRequisitionFormURL, "'ORDER REQUISITION FORM' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		labsWebsite.clickDownloadAnOrderFormButton();
		logInfo("Clicked on 'Download An Order Form' Button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), orderRequisitionFormURL, "'ORDER REQUISITION FORM' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		labsWebsite.clickHereLink();
		logInfo("Clicked on 'Here' Link");
		verifySafely(driver.getURL(), epiccarelinkSiteURL, "'Epiccare' Page URL matches");
		driver.back();
		labsWebsite.hoverLabClientServicesMenu();
		labsWebsite.clickSampleReportSubmenuOption();
		logInfo("Clicked on 'Sample Report' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), sampleReportPageTitleValue, "'Sample Report' Page Title");
		verifySafely(driver.getURL(), sampleReportPageURL, "'Sample Report' Page URL matches");
		labsWebsite.hoverLabClientServicesMenu();
		labsWebsite.clickPatientBillingSubmenuOption();
		logInfo("Clicked on 'Patient Billing' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), patientBillingPageTitleValue, "'Patient Billing' Page Title");
		verifySafely(driver.getURL(), patientBillingPageURL, "'Patient Billing' Page URL matches");
		labsWebsite.clickCologuardLink();
		logInfo("Clicked on 'Cologuard' Link");
		verifySafely(driver.getURL(), cologuardSiteURL, "'cologuard.com' Page URL matches");
		driver.back();
		labsWebsite.hoverLabClientServicesMenu();
		labsWebsite.clickVisualMapOfTestingProcessSubmenuOption();
		logInfo("Clicked on 'Visual Map Of Testing Process' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), visualMapOfTestingProcessPageTitleValue,
				"'Visual Map Of Testing Process' Page Title");
		verifySafely(driver.getURL(), visualMapOfTestingProcessPageURL,
				"'Visual Map Of Testing Process' Page URL matches");

		labsWebsite.hoverLabClientServicesMenu();
		labsWebsite.clickCovid19TestingSubmenuOption();
		logInfo("Clicked on 'Covid 19 Testing' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), covid19TestingPageTitleValue, "'Covid-19 Testing' Page Title");
		verifySafely(driver.getURL(), covid19TestingPageURL, "'Covid-19 Testing' Page URL matches");
		labsWebsite.clickClickHereLink();
		logInfo("Clicked on 'Click Here' Link");
		verifySafely(labsWebsite.getPageTitle(), atHomeCollectionforCOVID19TestingPageTitleValue,
				"'At-Home Collection for COVID-19 Testing' Page Title");
		verifySafely(driver.getURL(), atHomeCollectionforCOVID19TestingPageURL,
				"'At-Home Collection for COVID-19 Testing' Page URL matches");
		driver.back();
		labsWebsite.clickRequestAdditionalDetailsButton();
		logInfo("Clicked on 'Request Additional Details' Button");
		verifySafely(labsWebsite.getPageTitle(), requestCOVID19TestingPageTitleValue,
				"'Request COVID-19 Testing' Page Title");
		verifySafely(driver.getURL(), requestCOVID19TestingPageURL, "'Request COVID-19 Testing' Page URL matches");
		labsWebsite.enterComapanyName(companyName);
		logInfo("Entered 'Company Name': " + companyName);
		labsWebsite.enterComapanyAddress(companyAddress);
		logInfo("Entered 'Company Address': " + companyAddress);
		labsWebsite.enterCityName(cityName);
		logInfo("Entered 'City Name': " + cityName);
		labsWebsite.enterStateName(stateName);
		logInfo("Entered 'State Name': " + stateName);
		labsWebsite.enterPostelNumber(postelNumber);
		logInfo("Entered 'Postal Number': " + postelNumber);
		labsWebsite.enterFirstName(firstName);
		logInfo("Entered 'First Name': " + firstName);
		labsWebsite.enterLastName(lastName);
		logInfo("Entered 'Last Name': " + lastName);
		labsWebsite.enterEmail(email);
		logInfo("Entered 'Email': " + email);
		labsWebsite.enterPhoneNumber(phoneNumber);
		logInfo("Entered 'Phone Number': " + phoneNumber);
		labsWebsite.enterBestTimeToContact(bestTimeToContact);
		logInfo("Entered 'Best time to contact': " + bestTimeToContact);
		labsWebsite.enterEstimatedNumber(estimatedNumber);
		logInfo("Entered 'Estimated number of employees/members that will need testing': " + estimatedNumber);
		labsWebsite.selectDropdownListEmploy();
		logInfo("Entered 'Do you employ or contract a Healthcare Provider at your company/organization (e.g. Chief Medical Officer, onsite clinic, etc.)'");
		labsWebsite.enterAdditionalComments(additionalComments);
		logInfo("Entered 'Additional Comments': " + additionalComments);
		labsWebsite.clickSubmitButton();
		logInfo("Clicked on 'Submit' Button");
		verifySafely(labsWebsite.isFormSubmittingTextDisplayed(), true, "Thank you for submitting your request.");
		driver.back();
		labsWebsite.clickDonationProgramLink();
		logInfo("Clicked on 'Donation Program' Link");
		verifySafely(labsWebsite.getPageTitle(), covid19TestingDonationProgramPageTitleValue,
				"'COVID-19 Test Donation Program' Page Title");
		verifySafely(driver.getURL(), covid19TestingDonationProgramPageURL,
				"'COVID-19 Test Donation Program' Page URL matches");
		labsWebsite.clickPDFRequestFormLink();
		logInfo("Clicked on 'PDF Request Form' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), covid19TestDonationRequestFormURL,
				"'COVID-19 TEST DONATION REQUEST FORM' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.back();
		verifySafely(labsWebsite.getCovid19TestingIconCardDisplayed(), covid19TestingIconCardValue,
				"'COVID-19 TESTING' Icon card Displayed");
		verifySafely(labsWebsite.getCovid19FluPanelTestingIconCardDisplayed(), covid19FluPanelTestingIconCardValue,
				"'COVID-19/FLU PANEL TESTING' Icon card Displayed");
		labsWebsite.clickCovid19TestingIconCardExploreMoreLink();
		logInfo("Clicked on 'Covid 19 Testing'Icon Card 'Explore More' Link");
		verifySafely(labsWebsite.getPageTitle(), covid19TestingPageTitleValue, "'COVID-19 Testing' Page Title");
		verifySafely(driver.getURL(), covid19TestinginformationPageURL, "'COVID-19 Testing' Page URL matches");
		labsWebsite.clickPleaseGohereLink();
		logInfo("Clicked on 'Please Go here' Link");
		verifySafely(labsWebsite.getPageTitle(), covid19FluPanelTestingPageTitleValue,
				"'COVID-19/Flu Panel Testing' Page Title");
		verifySafely(driver.getURL(), covid19FluPanelTestinginformationPageURL,
				"'COVID-19/Flu Panel Testing' Page URL matches");
		driver.back();
		labsWebsite.clickCdcLink();
		logInfo("Clicked on 'CDC' Link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), cdcSiteURL, "'CDC' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		labsWebsite.clickRequestAdditionalDetailsButton();
		logInfo("Clicked on 'Request Additional Details' Button");
		driver.switchToCurrentWindow();
		verifySafely(labsWebsite.getPageTitle(), requestCOVID19TestingPageTitleValue,
				"'Request COVID-19 Testing' Page Title");
		verifySafely(driver.getURL(), requestCOVID19TestingPageURL, "'Request COVID-19 Testing' Page URL matches");
		labsWebsite.enterComapanyName(companyName);
		logInfo("Entered 'Company Name': " + companyName);
		labsWebsite.enterComapanyAddress(companyAddress);
		logInfo("Entered 'Company Address': " + companyAddress);
		labsWebsite.enterCityName(cityName);
		logInfo("Entered 'City Name': " + cityName);
		labsWebsite.enterStateName(stateName);
		logInfo("Entered 'State Name': " + stateName);
		labsWebsite.enterPostelNumber(postelNumber);
		logInfo("Entered 'Postal Number': " + postelNumber);
		labsWebsite.enterFirstName(firstName);
		logInfo("Entered 'First Name': " + firstName);
		labsWebsite.enterLastName(lastName);
		logInfo("Entered 'Last Name': " + lastName);
		labsWebsite.enterEmail(email);
		logInfo("Entered 'Email': " + email);
		labsWebsite.enterPhoneNumber(phoneNumber);
		logInfo("Entered 'Phone Number': " + phoneNumber);
		labsWebsite.enterBestTimeToContact(bestTimeToContact);
		logInfo("Entered 'Best time to contact': " + bestTimeToContact);
		labsWebsite.enterEstimatedNumber(estimatedNumber);
		logInfo("Entered 'Estimated number of employees/members that will need testing': " + estimatedNumber);
		labsWebsite.selectDropdownListEmploy();
		logInfo("Entered 'Do you employ or contract a Healthcare Provider at your company/organization (e.g. Chief Medical Officer, onsite clinic, etc.)'");
		labsWebsite.enterAdditionalComments(additionalComments);
		logInfo("Entered 'Additional Comments': " + additionalComments);
		labsWebsite.clickSubmitButton();
		logInfo("Clicked on 'Submit' Button");
		verifySafely(labsWebsite.isFormSubmittingTextDisplayed(), true, "Thank you for submitting your request.");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifySafely(labsWebsite.getSpecimenCollectionSubsectionText(), specimenCollectionSubsectionValue,
				"'Specimen Collection' Subsection");
		verifySafely(labsWebsite.getSpecimenHandlingAndShippingToExactSciencesLaboratoriesSubsectionText(),
				specimenHandlingAndShippingToExactSciencesLaboratoriesSubsectionValue,
				"'Specimen Handling and Shipping to Exact Sciences Laboratories' Subsection");
		verifySafely(labsWebsite.getResultsDeliverySubsectionText(), resultsDeliverySubsectionValue,
				"'Results Delivery' Subsection");
		for (int count = 1; count <= 3; count++) {
			String counter = Integer.toString(count);
			labsWebsite.clickHeadingToExpandCollapseSection(counter);
			logInfo("Clicked on '" + labsWebsite.getSectionHeadingText(counter) + "' + button");
			verifySafely(labsWebsite.isSubsectionExpand(), true,
					"'" + labsWebsite.getSectionHeadingText(counter) + "'" + "Subsection Expand");
			if (count == 1) {
				labsWebsite.clickFaqsTestingSarsCov2Link();
				logInfo("Clicked on 'FAQs on Testing for SARS-CoV-2' Link ");
				driver.switchToCurrentWindow();
				verifySafely(driver.getURL(), faqsTestingSarsCov2URL,
						"'FAQs on Testing for SARS-CoV-2' Page URL matches");
				driver.closeCurrentWindow();
				driver.switchToParentWindow();
				labsWebsite.clickGuidelinesClinicalSpecimensLink();
				logInfo("Clicked on 'Interim Guidelines for Collecting and Handling of Clinical Specimens for COVID-19 Testing' Link ");
				driver.switchToCurrentWindow();
				verifySafely(driver.getURL(), guidelinesClinicalSpecimensURL,
						"'Interim Guidelines for Collecting and Handling of Clinical Specimens for COVID-19 Testing' Page URL matches");
				driver.closeCurrentWindow();
				driver.switchToParentWindow();
			}
			labsWebsite.clickHeadingToExpandCollapseSection(counter);
			logInfo("Clicked on '" + labsWebsite.getSectionHeadingText(counter) + "' - button");
			verifySafely(labsWebsite.isSubsectionCollapse(counter), true,
					"'" + labsWebsite.getSectionHeadingText(counter) + "'" + " Subsection Collapsed");
		}

		labsWebsite.clickNasalCollectionInstructionsIconCard();
		logInfo("Clicked on 'Nasal Collection Instructions' Icon Card ");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), nasalCollectionInstructionsURL,
				"'2021-nasal-swab-instructions-web-final.pdf' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		labsWebsite.clickNasalHealthcareProviderFactSheetIconCard();
		logInfo("Clicked on 'Nasal Healthcare Provider Fact Sheet' Icon Card ");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), nasalHealthcareProviderFactSheetURL,
				"'FACT SHEET FOR HEALTHCARE PROVIDERS' Page URL matches ");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		labsWebsite.clickPatientFactSheetIconCard();
		logInfo("Clicked on 'Patient Fact Sheet' Icon Card ");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), patientFactSheetURL, "'FACT SHEET FOR PATIENTS' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		for (int count = 4; count <= 18; count++) {
			String counter = Integer.toString(count);
			labsWebsite.clickHeadingToExpandCollapseSection(counter);
			logInfo("Clicked on '" + labsWebsite.getSectionHeadingText(counter) + "' + button");
			verifySafely(labsWebsite.isSubsectionExpand(), true,
					"'" + labsWebsite.getSectionHeadingText(counter) + "'" + "FAQ section Expand");
			labsWebsite.clickHeadingToExpandCollapseSection(counter);
			logInfo("Clicked on '" + labsWebsite.getSectionHeadingText(counter) + "' - button");
			verifySafely(labsWebsite.isSubsectionCollapse(counter), true,
					"'" + labsWebsite.getSectionHeadingText(counter) + "'" + " FAQ section Collapsed");

		}
		driver.back();
		labsWebsite.clickCovid19FluPanelTestingIconCardExploreMoreLink();
		logInfo("Clicked on 'Covid 19/Flu Panel Testing' Icon Card 'Explore More' Link ");
		verifySafely(labsWebsite.getPageTitle(), covid19FluPanelTestingPageTitleValue,
				"'COVID-19/Flu Panel Testing' Page Title");
		verifySafely(driver.getURL(), covid19FluPanelTestinginformationPageURL,
				"'COVID-19/Flu Panel Testing' Page URL matches");
		labsWebsite.clickPleaseGohereLink();
		logInfo("Clicked on 'Please Go here' Link ");
		verifySafely(labsWebsite.getPageTitle(), covid19TestingPageTitleValue, "'COVID-19 Testing' Page Title");
		verifySafely(driver.getURL(), covid19TestinginformationPageURL, "'COVID-19 Testing' Page URL matches");
		labsWebsite.clickExactSciencesLogolab();
		logInfo("Clicked on 'ExactSciences' Logo ");
		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}
}
