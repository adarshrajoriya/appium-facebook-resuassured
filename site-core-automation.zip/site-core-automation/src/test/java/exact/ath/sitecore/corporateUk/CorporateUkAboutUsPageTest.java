package exact.ath.sitecore.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.corporateUk.CorporateUkAboutUsPage;
import exact.ath.corporateUk.CorporateUkHomePage;

/**
 * This class verifies Corporate Uk About us page verifications
 * 
 * @userstory #304475 Task#307942
 * @author Tushar Gupta
 * @since 07/19/2023
 */
public class CorporateUkAboutUsPageTest extends BasicIntTest {

	private final CorporateUkHomePage corporateUkHomePage = new CorporateUkHomePage();
	private final CorporateUkAboutUsPage corporateUkAboutUsPage = new CorporateUkAboutUsPage();
	private final String corporateUkHomePageURL = corporateUkPagesProperties.getProperty("corporateUkHomePageURL");
	private final String about = corporateUkPagesProperties.getProperty("about");
	private final String leadership = corporateUkPagesProperties.getProperty("leadership");
	private final String contactUs = corporateUkPagesProperties.getProperty("contactUs");
	private final String aboutUsURL = corporateUkPagesProperties.getProperty("aboutUsURL");
	private final String ourPurpose = corporateUkPagesProperties.getProperty("ourPurpose");
	private final String ourPromise = corporateUkPagesProperties.getProperty("ourPromise");
	private final String ourPrinciples = corporateUkPagesProperties.getProperty("ourPrinciples");
	private final String youAreNowLeaving = corporateUkPagesProperties.getProperty("youAreNowLeaving");
	private final String leadershipTeamURL = corporateUkPagesProperties.getProperty("leadershipTeamURL");
	private final String contactUsURL = corporateUkPagesProperties.getProperty("contactUsURL");
	private final String pageHeadingDisplayedCorporateUkHomePage = corporateUkPagesProperties
			.getProperty("pageHeadingDisplayedCorporateUkHomePage");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyCorporateUkAboutUsPageTest() throws Exception {
		setupURL(corporateUkHomePageURL);
		logInfo("Page URL : " + corporateUkHomePageURL + "");

		acceptCookiesCorporateUk();
		logInfo("----------------Starting verification of About Us Page of Corpoarte UK Website------------");
		verifySafely(corporateUkHomePage.isCorporateUkHomepageDisplayed(), true, "Corporate Uk Homepage is displayed");
		verifySafely(corporateUkHomePage.getPageHeadingDisplayedHomePage(), pageHeadingDisplayedCorporateUkHomePage,
				"'PURSUING EARLIER DETECTION AND LIFE-CHANGING ANSWERS' Title is displayed on Home Page Of Corporate Uk website");

		corporateUkHomePage.hoverTopNavOption(about);
		verifySafely(corporateUkHomePage.isSubItemDisplayed(leadership), true,
				"Sub Menu Option '" + leadership + "' is displayed under '" + about + "' Menu Option");
		verifySafely(corporateUkHomePage.isSubItemDisplayed(contactUs), true,
				"Sub Menu Option '" + contactUs + "' is displayed under '" + about + "' Menu Option");

		corporateUkHomePage.clickHeaderOption(about);
		verifySafely(driver.getURL(), aboutUsURL, "'Page URL matches'");

		verifySafely(corporateUkAboutUsPage.isCardItemDisplayed(ourPurpose), true,
				"Card Item '" + ourPurpose + "' is displayed under the bottom of the page");
		verifySafely(corporateUkAboutUsPage.isCardItemDisplayed(ourPromise), true,
				"Card Item '" + ourPromise + "' is displayed under the bottom of the page");
		verifySafely(corporateUkAboutUsPage.isCardItemDisplayed(ourPrinciples), true,
				"Card Item '" + ourPrinciples + "' is displayed under the bottom of the page");

		corporateUkHomePage.hoverTopNavOption(about);
		corporateUkHomePage.clickHeaderOption(leadership);
		verifySafely(corporateUkHomePage.getPopUpText(), youAreNowLeaving,
				"'YOU ARE NOW LEAVING THIS SITE.' popup is displayed");
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), leadershipTeamURL, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

		corporateUkHomePage.hoverTopNavOption(about);
		corporateUkHomePage.clickHeaderOption(contactUs);
		verifySafely(driver.getURL(), contactUsURL, "'Page URL matches'");
		logInfo("----------------Verification done for About Us Page of Corpoarte UK Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
