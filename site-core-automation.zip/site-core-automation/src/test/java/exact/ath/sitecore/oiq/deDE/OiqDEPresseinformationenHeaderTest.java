package exact.ath.sitecore.oiq.deDE;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CGEffectiveAndEasyPage;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqDE.OiqDEHomePage;
import exact.ath.oiq.oiqDE.OiqDEKlinischeEvidenzPage;
import exact.ath.oiq.oiqDE.OiqDEUberDenTestPage;

/**
 * This class verifies OIQ Germany web site PRESSEINFORMATIONEN header
 * components
 * 
 * @userstory #304475 Task#307772 Test Case #EPS-T1065
 * @author Pushkar Singh
 * @since 07/25/2023
 */
public class OiqDEPresseinformationenHeaderTest extends BasicIntTest {

	private final OiqDEHomePage oiqDEHomePage = new OiqDEHomePage();
	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final CGEffectiveAndEasyPage cgEffectiveAndEasyPage = new CGEffectiveAndEasyPage();
	private final OiqDEKlinischeEvidenzPage oiqDEKlinischeEvidenzPage = new OiqDEKlinischeEvidenzPage();
	private final OiqDEUberDenTestPage oiqDEUberDenTestPage = new OiqDEUberDenTestPage();

	private final String loginUrl = oiqdeDEPagesProperties.getProperty("oiqDEsiteURL");
	private final String presseinformationen = oiqdeDEPagesProperties.getProperty("presseinformationen");
	private final String presseinformationenPageTitle = oiqdeDEPagesProperties
			.getProperty("presseinformationenPageTitle");
	private final String presseinformationenHyperLink1Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink1Text");
	private final String presseinformationenHyperLink2Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink2Text");
	private final String presseinformationenHyperLink3Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink3Text");
	private final String accordion2021 = oiqdeDEPagesProperties.getProperty("accordion2021");
	private final String presseinformationenHyperLink4Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink4Text");
	private final String presseinformationenHyperLink5Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink5Text");
	private final String presseinformationenHyperLink4PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink4PageURL");
	private final String presseinformationenHyperLink5PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink5PageURL");
	private final String presseinformationenHyperLink12Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink12Text");
	private final String presseinformationenHyperLink12PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink12PageURL");
	private final String presseinformationenHyperLink14Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink14Text");
	private final String presseinformationenHyperLink14PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink14PageURL");
	private final String presseinformationenHyperLink19Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink19Text");
	private final String presseinformationenHyperLink19PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink19PageURL");
	private final String presseinformationenHyperLink21Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink21Text");
	private final String presseinformationenHyperLink21PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink21PageURL");
	private final String presseinformationenHyperLink30Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink30Text");
	private final String presseinformationenHyperLink30PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink30PageURL");
	private final String presseinformationenHyperLink26Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink26Text");
	private final String presseinformationenHyperLink26PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink26PageURL");
	private final String presseinformationenHyperLink40Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink40Text");
	private final String presseinformationenHyperLink40PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink40PageURL");
	private final String presseinformationenHyperLink43Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink43Text");
	private final String presseinformationenHyperLink43PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink43PageURL");
	private final String presseinformationenHyperLink49Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink49Text");
	private final String presseinformationenHyperLink49PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink49PageURL");
	private final String presseinformationenHyperLink33Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink33Text");
	private final String presseinformationenHyperLink33PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink33PageURL");
	private final String presseinformationenHyperLink39Text = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink39Text");
	private final String presseinformationenHyperLink39PageURL = oiqdeDEPagesProperties
			.getProperty("presseinformationenHyperLink39PageURL");

	private final String accordion2020 = oiqdeDEPagesProperties.getProperty("accordion2020");
	private final String accordion2019 = oiqdeDEPagesProperties.getProperty("accordion2019");
	private final String accordion2018 = oiqdeDEPagesProperties.getProperty("accordion2018");
	private final String accordion2017 = oiqdeDEPagesProperties.getProperty("accordion2017");
	private final String accordion2016 = oiqdeDEPagesProperties.getProperty("accordion2016");
	private final String accordion2015 = oiqdeDEPagesProperties.getProperty("accordion2015");
	private final String klickenPageURL = oiqdeDEPagesProperties.getProperty("klickenPageURL");
	private final String konSieUnsPageURL = oiqdeDEPagesProperties.getProperty("konSieUnsPageURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqDEPresseinformationenHeaderTest() throws Exception {

		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Deutschland Homepage URL '" + loginUrl + "'");

		oiqDEHomePage.clickTopNavOption(presseinformationen);

		verifySafely(oiqCHHomePage.getPageTitle(), presseinformationenPageTitle, "Page Heading displayed");

		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink1Text);
		logInfo("Pdf file downloaded");

		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink2Text);
		logInfo("Pdf file downloaded");

		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink3Text);
		logInfo("Pdf file downloaded");

		cgEffectiveAndEasyPage.clickAccordion(accordion2021);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2021), true,
				accordion2021 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink4Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink4PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2021);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2021), true,
				accordion2021 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink5Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink5PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2020);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2020), true,
				accordion2020 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink12Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink12PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2020);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2020), true,
				accordion2020 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink14Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink14PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2019);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2019), true,
				accordion2019 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink19Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink19PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2019);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2019), true,
				accordion2019 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink21Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink21PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2018);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2018), true,
				accordion2018 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink30Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink30PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2018);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2018), true,
				accordion2018 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink26Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink26PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2017);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2017), true,
				accordion2017 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink33Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink33PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2017);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2017), true,
				accordion2017 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink(presseinformationenHyperLink39Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink39PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2016);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2016), true,
				accordion2016 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink2(presseinformationenHyperLink40Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink40PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2016);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2016), true,
				accordion2016 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink2(presseinformationenHyperLink43Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink43PageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(accordion2015);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(accordion2015), true,
				accordion2015 + " accordion is expanded");
		oiqCHHomePage.clickOiqHyperLink2(presseinformationenHyperLink49Text);
		verifySafely(driver.getURL(), presseinformationenHyperLink49PageURL, "Page URL Matches");
		driver.back();

		oiqDEUberDenTestPage.clickKlickenBtn();
		logInfo("Clicked on 'KLICKEN SIE HIER ' button from 'Brustkrebs-Früherkennung' card");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), klickenPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsPREHdrBtn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
