package exact.ath.sitecore.career;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CareerWebsite;
import exact.sys.Driver;

/**
 * This class verifies Career Website Current Openings page verifications
 * 
 * @userstory #301264 Task#303950
 * @author qas_tgupta
 * @since 05/05/2023
 */

public class CareerCurrentOpeningsTest extends BasicIntTest {

	private final CareerWebsite careerWebsite = new CareerWebsite();
	private final Driver driver = new Driver();
	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CareerWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CareerWebURL");
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final String viewOpeningsLinkURL = exactPagesProperties.getProperty("ViewOpeningsLinkURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void careerCurrentOpeningsTest() {
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		logInfo("----------------Starting verification of Current Openings Tab present in Header Section of Career Website------------");
		verifySafely(careerWebsite.getCareerWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Heading");
		verifySafely(careerWebsite.isHeaderSectionDisplayed(), true, "'Header Section' is displayed on the page");
		verifySafely(careerWebsite.isPageTitleDisplayed(), true,
				"'Home Page tittle - CHANGE CAREERS.CHANGE LIVES.' is displayed on the page");
		careerWebsite.clickCurrentOpeningsTab();
		logInfo("Clicked on 'Current Openings' Tab from the Header section");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), viewOpeningsLinkURL, "Opened 'Current Openings Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Verification Done for Current Openings Tab present in Header Section of Career Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}

}
