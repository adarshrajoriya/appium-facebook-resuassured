package exact.ath.sitecore.csr;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CsrWebsite;

/**
 * @author pusingh
 *
 */
public class CsrSustainabilityPageTest extends BasicIntTest {

	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final CsrWebsite csrWebsite = new CsrWebsite();

	private final String pPERecyclingInitiativeLinkURL = exactPagesProperties
			.getProperty("PPERecyclingInitiativeLinkURL");

	private final String loginUrl = exactPagesProperties.getProperty("CsrWebURL");

	private final String csrSustainabilityCardTittles = exactPagesProperties
			.getProperty("CsrSustainabilityCardTittles");
	private final String csrSustainabilityFullCardTittles = exactPagesProperties
			.getProperty("CsrSustainabilityFullCardTittles");
	private final String csrRecyclingExactSciencesClinicalLabPageCardTittles = exactPagesProperties
			.getProperty("CsrRecyclingExactSciencesClinicalLabPageCardTittles");
	private final String csrPPERecyclingInitiativePageCardTittles = exactPagesProperties
			.getProperty("CsrPPERecyclingInitiativePageCardTittles");
	private final String recyclingExactSciencesClinicalLabPageURL = exactPagesProperties
			.getProperty("RecyclingExactSciencesClinicalLabPageURL");
	private final String seeMoreEntriesURL = exactPagesProperties.getProperty("SeeMoreEntriesURL");
	private int viewCount = 0;

	@Test
	public void csrSustainabilityPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");
		csrWebsite.clickCsrSustainabilityHeader();
		logInfo("Clicked on 'Sustainability' Header Option");
		verifySafely(csrWebsite.isCsrSustainabilityHeaderHighlightedDisplayed(), true,
				"'Sustainability' item is displayed Highlighted in header section on the page");
		csrWebsite.clickReadMore();
		logInfo("Clicked on 'READ MORE' button");
		verifySafely(driver.getURL(), recyclingExactSciencesClinicalLabPageURL,
				"'Recycling at Exact Sciences: Clinical Lab' Page URL matches");

		csrWebsite.clickPPERecyclingInitiativeLink();
		logInfo("Clicked on 'PPE Recycling Initiative' Link");
		verifySafely(driver.getURL(), pPERecyclingInitiativeLinkURL,
				"'PPE Recycling Initiative Link' Navigates to Page URL matches");
		logInfo("Verification of 'PPE Recycling Initiative Link' page Icon cards");
		viewCount = 0;
		for (String csrPPERecyclingInitiativePageCardTittle : csrPPERecyclingInitiativePageCardTittles.split(",")) {
			viewCount++;
			verifySafely(
					csrWebsite.getCsrCiAndCrIconCardTittle(viewCount).contains(csrPPERecyclingInitiativePageCardTittle),
					true, "Displayed Publication Card - Tittle VALUE: '"
							+ csrWebsite.getCsrCiAndCrIconCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCiAndCrIconCardTittle(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrPPERecyclingInitiativePageCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		driver.back();
		logInfo("Navigated back to page 'Recycling at Exact Sciences: Clinical Lab'");
		logInfo("Verification of 'Recycling at Exact Sciences: Clinical Lab' page Icon cards");
		viewCount = 0;
		for (String csrRESCLCardTittle : csrRecyclingExactSciencesClinicalLabPageCardTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCiAndCrIconCardTittle(viewCount).contains(csrRESCLCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCiAndCrIconCardTittle(viewCount)
							+ "'");
			csrWebsite.clickCsrCiAndCrIconCardTittle(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrRESCLCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		driver.back();
		verifySafely(csrWebsite.isCsrSustainabilityHeaderHighlightedDisplayed(), true,
				"Navigated back to 'Sustainability' Page and is displayed Highlighted in header section on the page");

		viewCount = 1;
		logInfo("Verification of 'Sustainability' page Icon cards");
		for (String csrSustainabilityCardTittle : csrSustainabilityCardTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrSustainabilityCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrSustainabilityCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		String recentURL = getPageURL();
		closeTheBrowser();
		setupURL(recentURL);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		csrWebsite.clickSeeMoreEntries();
		logInfo("Clicked on 'SEE MORE ENTRIES' button");
		verifySafely(driver.getURL(), seeMoreEntriesURL, "'See More Entries' button Navigates to Page URL matches");

		viewCount = 0;
		logInfo("Verification of 'Sustainability' page all Icon cards");
		for (String csrSustainabilityFullCardTittle : csrSustainabilityFullCardTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrSustainabilityFullCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrSustainabilityFullCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();
			if (viewCount == 6) {
				recentURL = getPageURL();
				closeTheBrowser();
				setupURL(recentURL);
				logInfo("Page URL : " + getPageURL() + "");
				if (annualReportsPage.acceptCookiesDisplayed()) {
					annualReportsPage.acceptCookies();
				}
			}

		}

		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
