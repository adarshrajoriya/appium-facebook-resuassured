package exact.ath.sitecore.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.corporateUk.CorporateUkHomePage;
import exact.ath.corporateUk.CorporateUkOncoTypeDxTestPage;
import exact.ath.corporateUk.CorporateUkProductPage;

/**
 * This class verifies Corporate Uk Our Product page verifications
 * 
 * @userstory #304475 Task#307942
 * @author Tushar Gupta
 * @since 07/20/2023
 */
public class CorporateUkOurProductPageTest extends BasicIntTest {

	private final CorporateUkHomePage corporateUkHomePage = new CorporateUkHomePage();
	private final CorporateUkOncoTypeDxTestPage corporateUkOncoTypeDxTestPage = new CorporateUkOncoTypeDxTestPage();
	private final CorporateUkProductPage corporateUkProductPage = new CorporateUkProductPage();
	private final String corporateUkHomePageURL = corporateUkPagesProperties.getProperty("corporateUkHomePageURL");
	private final String ourProducts = corporateUkPagesProperties.getProperty("ourProducts");
	private final String oncotypeTests = corporateUkPagesProperties.getProperty("oncotypeTests");
	private final String productURL = corporateUkPagesProperties.getProperty("productURL");
	private final String youAreNowLeaving = corporateUkPagesProperties.getProperty("youAreNowLeaving");
	private final String cologuardURL = corporateUkPagesProperties.getProperty("cologuardURL");
	private final String oncotypeTestsURL = corporateUkPagesProperties.getProperty("oncotypeTestsURL");
	private final String oncotypeIqUkURL = corporateUkPagesProperties.getProperty("oncotypeIqUkURL");
	private final String genomicURL = corporateUkPagesProperties.getProperty("genomicURL");
	private final String oncotypeIqUkBreastCancerURL = corporateUkPagesProperties
			.getProperty("oncotypeIqUkBreastCancerURL");
	private final String ourProductsPipelineURL = corporateUkPagesProperties.getProperty("ourProductsPipelineURL");
	private final String pageHeadingDisplayedCorporateUkHomePage = corporateUkPagesProperties
			.getProperty("pageHeadingDisplayedCorporateUkHomePage");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyCorporateUkOurProductPageTest() throws Exception {
		setupURL(corporateUkHomePageURL);
		logInfo("Page URL : " + corporateUkHomePageURL + "");

		acceptCookiesCorporateUk();
		logInfo("----------------Starting verification of Our Product Page of Corpoarte UK Website------------");
		verifySafely(corporateUkHomePage.isCorporateUkHomepageDisplayed(), true, "Corporate Uk Homepage is displayed");
		verifySafely(corporateUkHomePage.getPageHeadingDisplayedHomePage(), pageHeadingDisplayedCorporateUkHomePage,
				"'PURSUING EARLIER DETECTION AND LIFE-CHANGING ANSWERS' Title is displayed on Home Page Of Corporate Uk website");

		corporateUkHomePage.hoverTopNavOption(ourProducts);
		verifySafely(corporateUkHomePage.isSubItemDisplayed(oncotypeTests), true,
				"Sub Menu Option '" + oncotypeTests + "' is displayed under '" + ourProducts + "' Menu Option");

		corporateUkHomePage.clickHeaderOption(ourProducts);
		verifySafely(driver.getURL(), productURL, "'Page URL matches'");

		corporateUkProductPage.clickPrecisionOncology();
		verifySafely(driver.getURL(), oncotypeTestsURL, "'Page URL matches'");
		driver.back();

		corporateUkProductPage.clickScreening();
		verifySafely(corporateUkHomePage.getPopUpText(), youAreNowLeaving,
				"'YOU ARE NOW LEAVING THIS SITE.' popup is displayed");
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), cologuardURL, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

		corporateUkProductPage.clickpipeline();
		verifySafely(corporateUkHomePage.getPopUpText(), youAreNowLeaving,
				"'YOU ARE NOW LEAVING THIS SITE.' popup is displayed");
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(ourProductsPipelineURL), true, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

		corporateUkHomePage.hoverTopNavOption(ourProducts);
		corporateUkHomePage.clickHeaderOption(oncotypeTests);
		verifySafely(driver.getURL(), oncotypeTestsURL, "'Page URL matches'");

		corporateUkOncoTypeDxTestPage.clickPortalButton(0);
		logInfo("Clicked on 'VISIT ONCOTYPEDX.COM' button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncotypeIqUkURL, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		corporateUkOncoTypeDxTestPage.clickPortalButton(1);
		logInfo("Clicked on 'UK ORDERING PORTAL' button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(genomicURL), true, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		corporateUkOncoTypeDxTestPage.clickOncotypeDxTest();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncotypeIqUkBreastCancerURL, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Verification done for Our Product Page of Corpoarte UK Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
