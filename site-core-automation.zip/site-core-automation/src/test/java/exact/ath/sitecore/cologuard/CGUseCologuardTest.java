package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CancelPickupPage;
import exact.ath.cologuard.CollectingAndReturningYourSamplePage;
import exact.ath.cologuard.ResourcesAndSupportPage;
import exact.ath.cologuard.SchedulePickupPage;
import exact.ath.cologuard.StoreLocatorPage;
import exact.ath.cologuard.UnderstandingYourResultPage;
import exact.util.PostStatusToZephyr;

/**
 * This test verifies CG Use Cologuard Page verifications
 * 
 * @userstory #303911 Task#304282
 * @author Tushar Gupta
 * @since 06/05/2023
 */

public class CGUseCologuardTest extends BasicIntTest {

	private final CollectingAndReturningYourSamplePage collectingAndReturningYourSamplePage = new CollectingAndReturningYourSamplePage();
	private final SchedulePickupPage schedulePickupPage = new SchedulePickupPage();
	private final StoreLocatorPage storeLocatorPage = new StoreLocatorPage();
	private final CancelPickupPage cancelPickupPage = new CancelPickupPage();
	private final UnderstandingYourResultPage understandingYourResultPage = new UnderstandingYourResultPage();
	private final ResourcesAndSupportPage resourcesAndSupportPage = new ResourcesAndSupportPage();
	private final String useCologuard = cologuardPagesProperties.getProperty("useCologuard");
	private final String collectingAndReturningSamples = cologuardPagesProperties
			.getProperty("collectingAndReturningSamples");
	private final String understandingYourResult = cologuardPagesProperties.getProperty("understandingYourResult");
	private final String resourcesAndSupport = cologuardPagesProperties.getProperty("resourcesAndSupport");
	private final String collectingAndReturnYourSample = cologuardPagesProperties
			.getProperty("collectingAndReturningSamples");
	private final String collectingAndReturningSamplePageTitle = cologuardPagesProperties
			.getProperty("collectingAndReturningSamplePageTitle");
	private final String collectingAndReturningSampleURL = cologuardPagesProperties
			.getProperty("collectingAndReturningSampleURL");
	private final String schedulePickupURL = cologuardPagesProperties.getProperty("schedulePickupURL");
	private final String schedulePickupPageTitle = cologuardPagesProperties.getProperty("schedulePickupPageTitle");
	private final String trackingNumber = cologuardPagesProperties.getProperty("trackingNumber");
	private final String contactName = cologuardPagesProperties.getProperty("contactName");
	private final String streetAddress = cologuardPagesProperties.getProperty("streetAddress");
	private final String city = cologuardPagesProperties.getProperty("city");
	private final String state = cologuardPagesProperties.getProperty("state");
	private final String zipCode = cologuardPagesProperties.getProperty("zip");
	private final String phoneNumber = cologuardPagesProperties.getProperty("phone");
	private final String storeLocatorURL = cologuardPagesProperties.getProperty("storeLocatorURL");
	private final String englishShippingInstructionsURL = cologuardPagesProperties
			.getProperty("englishShippingInstructionsURL");
	private final String english = cologuardPagesProperties.getProperty("english");
	private final String shippingFAQ = cologuardPagesProperties.getProperty("shippingFAQ");
	private final String cancelUPSPickupURL = cologuardPagesProperties.getProperty("cancelUPSPickupURL");
	private final String screeningAndMobilityIssues = cologuardPagesProperties
			.getProperty("screeningAndMobilityIssues");
	private final String doNotUseCologuardIfYouSeeBloodInYourStool = cologuardPagesProperties
			.getProperty("doNotUseCologuardIfYouSeeBloodInYourStool");
	private final String urineInTheCollectionContainer = cologuardPagesProperties
			.getProperty("urineInTheCollectionContainer");
	private final String understandingYourResultURL = cologuardPagesProperties
			.getProperty("understandingYourResultURL");
	private final String understandingYourResultPageTitle = cologuardPagesProperties
			.getProperty("understandingYourResultPageTitle");
	private final String loginButtonURL = cologuardPagesProperties.getProperty("loginButtonURL");
	private final String resourcesAndSupportURL = cologuardPagesProperties.getProperty("resourcesAndSupportURL");
	private final String resourcesAndSupportPageTitle = cologuardPagesProperties
			.getProperty("resourcesAndSupportPageTitle");
	private final String downloadPatientBrochureURL = cologuardPagesProperties
			.getProperty("downloadPatientBrochureURL");
	private final String downloadDoctorDiscussionGuideBrochureURL = cologuardPagesProperties
			.getProperty("downloadDoctorDiscussionGuideBrochureURL");
	private final String downloadPatientGuideBrochureURL = cologuardPagesProperties
			.getProperty("downloadPatientGuideBrochureURL");
	private final String downloadKitReturnInstructionsBrochureURL = cologuardPagesProperties
			.getProperty("downloadKitReturnInstructionsBrochureURL");
	private final String downloadCologuardBrochureURL = cologuardPagesProperties
			.getProperty("downloadCologuardBrochureURL");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T1080";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyCGUseCologuardTest() throws Exception {

		checkForExUSSite(cologuardHomePageURL);

		acceptCookies();

		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(useCologuard), true,
				"Header option '" + useCologuard + "' is displayed on home page");

		cologuardHomepage.clickTopNavOption(useCologuard);
		verifySafely(cologuardHomepage.isSubItemDisplayed(collectingAndReturningSamples), true,
				"Sub item '" + collectingAndReturningSamples + "' is displayed under 'Use Cologuard' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(understandingYourResult), true,
				"Sub item '" + understandingYourResult + "' is displayed under 'Use Cologuard' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(resourcesAndSupport), true,
				"Sub item '" + resourcesAndSupport + "' is displayed under 'Use Cologuard' item");

		driver.refresh();
		cologuardHomepage.selectSubOptionFromTopNavOptions(useCologuard, collectingAndReturnYourSample);

		verifySafely(driver.getURL(), collectingAndReturningSampleURL,
				"'Collecting and Returning your sample' page is displayed");
		verifySafely(driver.getTitle(), collectingAndReturningSamplePageTitle,
				collectingAndReturningSamplePageTitle + " is displayed as page title");

		collectingAndReturningYourSamplePage.clickSchedulePickup();
		verifySafely(driver.getURL(), schedulePickupURL, "'Schedule pickup' page is displayed");
		verifySafely(driver.getTitle(), schedulePickupPageTitle,
				schedulePickupPageTitle + " is displayed as page title");

		schedulePickupPage.enterPickupDate();
		schedulePickupPage.enterTrackingNumber(trackingNumber);
		schedulePickupPage.enterContactName(contactName);
		schedulePickupPage.enterStreetAddress(streetAddress);
		schedulePickupPage.enterCity(city);
		schedulePickupPage.selectState(state);
		schedulePickupPage.enterZIPCode(zipCode);
		schedulePickupPage.enterPhoneNumber(phoneNumber);
		schedulePickupPage.clickSubmitBtn();

		verifySafely(schedulePickupPage.isPickupConfirmationMessageDisplayed(), true,
				"Confirmation message is displayed after clicking 'Schedule pickup'");

		String upsPickupRequestNumber = schedulePickupPage.getUPSPickupRequestNumber();

		driver.back();

		collectingAndReturningYourSamplePage.clickDropOffAtUPSBtn();

		verifySafely(driver.getURL(), storeLocatorURL, "'Store Locator' page is displayed");

		storeLocatorPage.enterZipcode(zipCode);
		storeLocatorPage.clickSubmitBtn();

		verifySafely(storeLocatorPage.isNearestStoreDisplayed(), true,
				"Nearest store is displayed under 'UPS Store Locator' after searching with Zipcode");

		driver.back();

		collectingAndReturningYourSamplePage.clickDownloadShippingInstructions(english);

		verifySafely(driver.getURL(), englishShippingInstructionsURL,
				"English shipping instructions are displayed in a new tab");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		collectingAndReturningYourSamplePage.expandAccordion(shippingFAQ);
		verifySafely(collectingAndReturningYourSamplePage.isAccordionExpanded(shippingFAQ), true,
				"Shipping FAQ accordion is expanded");

		collectingAndReturningYourSamplePage.clickCancelUPSPickup();
		verifySafely(driver.getURL(), cancelUPSPickupURL, "'Cancel UPS pickup' page is displayed");

		cancelPickupPage.enterRequestNumber(upsPickupRequestNumber);
		cancelPickupPage.clickSubmitBtn();
		verifySafely(cancelPickupPage.isCancellationSuccessfulMsgDisplayed(), true,
				"'UPS Pickup was successfully cancelled' confirmation message is displayed");

		driver.back();

		collectingAndReturningYourSamplePage.expandAccordion(screeningAndMobilityIssues);
		verifySafely(collectingAndReturningYourSamplePage.isAccordionExpanded(screeningAndMobilityIssues), true,
				screeningAndMobilityIssues + " accordion is expanded for 'Addittional Important Topics'");

		collectingAndReturningYourSamplePage.expandAccordion(doNotUseCologuardIfYouSeeBloodInYourStool);
		verifySafely(
				collectingAndReturningYourSamplePage.isAccordionExpanded(doNotUseCologuardIfYouSeeBloodInYourStool),
				true, doNotUseCologuardIfYouSeeBloodInYourStool
						+ " accordion is expanded for 'Addittional Important Topics'");

		collectingAndReturningYourSamplePage.expandAccordion(urineInTheCollectionContainer);
		verifySafely(collectingAndReturningYourSamplePage.isAccordionExpanded(urineInTheCollectionContainer), true,
				urineInTheCollectionContainer + " accordion is expanded for 'Addittional Important Topics'");

		cologuardHomepage.selectSubOptionFromTopNavOptions(useCologuard, understandingYourResult);
		verifySafely(driver.getURL(), understandingYourResultURL, "'Understanding your result' page is displayed");
		verifySafely(driver.getTitle(), understandingYourResultPageTitle,
				understandingYourResultPageTitle + " is displayed as page title");

		understandingYourResultPage.clickLoginButtonBy();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), loginButtonURL, "'Patient Hub Login' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		understandingYourResultPage.clickNegativeResultAccordion();

		cologuardHomepage.selectSubOptionFromTopNavOptions(useCologuard, resourcesAndSupport);
		verifySafely(driver.getURL(), resourcesAndSupportURL, "'Resources & support' page is displayed");
		verifySafely(driver.getTitle(), resourcesAndSupportPageTitle,
				resourcesAndSupportPageTitle + " is displayed as page title");

		resourcesAndSupportPage.clickLoginInToAccountLinkBy();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), loginButtonURL, "'Patient Hub Login' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		understandingYourResultPage.clickLoginButtonBy();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), loginButtonURL, "'Patient Hub Login' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		resourcesAndSupportPage.clickDownloadPatientBrochure();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadPatientBrochureURL,
				"Download Patient Brochure is displayed in a new tab");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		resourcesAndSupportPage.clickSelectAnotherLanguage(0);
		verifySafely(resourcesAndSupportPage.isDropdownExpandsAndMultipleLanguageLinksDisplayed(0), true,
				"Select Another Language dropdown expands and multiple language links is available to download");

		resourcesAndSupportPage.clickDownloadDoctorDiscussionGuideBrochure();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadDoctorDiscussionGuideBrochureURL,
				"Download Doctor Discussion Guide Brochure is displayed in a new tab");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		resourcesAndSupportPage.clickDownloadPatientGuideBrochure();

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadPatientGuideBrochureURL,
				"Download Patient Guide Brochure is displayed in a new tab");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		resourcesAndSupportPage.clickDownloadKitReturnInstructionsBrochure();

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadKitReturnInstructionsBrochureURL,
				"Download Kit Return Instructions Brochure is displayed in a new tab");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		resourcesAndSupportPage.clickDownloadCologuardBrochure();

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadCologuardBrochureURL,
				"Download Cologuard Brochure is displayed in a new tab");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		driver.close();

		throwAssertionErrorOnFailure();

	}

}
