package exact.ath.sitecore.oiq.deDE;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CGEffectiveAndEasyPage;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqDE.OiqDEGestelltePage;
import exact.ath.oiq.oiqDE.OiqDEHomePage;
import exact.ath.oiq.oiqDE.OiqDEKlinischeEvidenzPage;
import exact.ath.oiq.oiqDE.OiqDEKlinischenPraxisPage;
import exact.ath.oiq.oiqDE.OiqDEPatientengeschichtenPage;
import exact.ath.oiq.oiqDE.OiqDETestFurMichGeeignetPage;
import exact.ath.oiq.oiqDE.OiqDETestergebnissePage;
import exact.ath.oiq.oiqDE.OiqDEUberDenTestPage;

/**
 * This class verifies OIQ Germany web site PATIENTEN header components
 * 
 * @userstory #304475 Task#307772
 * @author Pushkar Singh
 * @since 07/25/2023
 */
public class OiqDEPatientenHeaderTest extends BasicIntTest {

	private final OiqDEHomePage oiqDEHomePage = new OiqDEHomePage();
	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final CGEffectiveAndEasyPage cgEffectiveAndEasyPage = new CGEffectiveAndEasyPage();
	private final OiqDEKlinischenPraxisPage oiqDEKlinischenPraxisPage = new OiqDEKlinischenPraxisPage();
	private final OiqDEKlinischeEvidenzPage oiqDEKlinischeEvidenzPage = new OiqDEKlinischeEvidenzPage();
	private final OiqDEUberDenTestPage oiqDEUberDenTestPage = new OiqDEUberDenTestPage();
	private final OiqDETestFurMichGeeignetPage oiqDETestFurMichGeeignetPage = new OiqDETestFurMichGeeignetPage();
	private final OiqDETestergebnissePage oiqDETestergebnissePage = new OiqDETestergebnissePage();
	private final OiqDEPatientengeschichtenPage oiqDEPatientengeschichtenPage = new OiqDEPatientengeschichtenPage();
	private final OiqDEGestelltePage oiqDEGestelltePage = new OiqDEGestelltePage();

	private final String loginUrl = oiqdeDEPagesProperties.getProperty("oiqDEsiteURL");
	private final String patienten = oiqdeDEPagesProperties.getProperty("patienten");
	private final String uberDenTest = oiqdeDEPagesProperties.getProperty("uberDenTest");
	private final String testFurMichGeeignet = oiqdeDEPagesProperties.getProperty("testFurMichGeeignet");
	private final String testergebnisse = oiqdeDEPagesProperties.getProperty("testergebnisse");
	private final String patientengeschichten = oiqdeDEPagesProperties.getProperty("patientengeschichten");
	private final String tragtDieKosten = oiqdeDEPagesProperties.getProperty("tragtDieKosten");
	private final String gestellte = oiqdeDEPagesProperties.getProperty("gestellte");
	private final String glossar = oiqdeDEPagesProperties.getProperty("glossar");

	private final String fiSiHeTestGeeignetPageURL = oiqdeDEPagesProperties.getProperty("fiSiHeTestGeeignetPageURL");
	private final String uberDenTestPageTitle = oiqdeDEPagesProperties.getProperty("uberDenTestPageTitle");
	private final String erSiMeUBTestergebnissePageURL = oiqdeDEPagesProperties
			.getProperty("erSiMeUBTestergebnissePageURL");
	private final String mehrInfoFindenPageURL = oiqdeDEPagesProperties.getProperty("mehrInfoFindenPageURL");
	private final String fürPatientenPageURL = oiqdeDEPagesProperties.getProperty("fürPatientenPageURL");
	private final String rEFERENZENLabel = oiqdeDEPagesProperties.getProperty("rEFERENZENLabel");
	private final String klickenPageURL = oiqdeDEPagesProperties.getProperty("klickenPageURL");
	private final String patientengeschichtenPageTitle = oiqdeDEPagesProperties
			.getProperty("patientengeschichtenPageTitle");
	private final String oncoDxRecScrTstPageTitle = oiqdeDEPagesProperties.getProperty("oncoDxRecScrTstPageTitle");
	private final String testberichtPageURL = oiqdeDEPagesProperties.getProperty("testberichtPageURL");
	private final String erSiMeDarWiSiZuZuTeBePageURL = oiqdeDEPagesProperties
			.getProperty("erSiMeDarWiSiZuZuTeBePageURL");
	private final String horenPodcasPageURL = oiqdeDEPagesProperties.getProperty("horenPodcasPageURL");
	private final String wanSolOncoBrestLabel = oiqdeDEPagesProperties.getProperty("wanSolOncoBrestLabel");
	private final String welEinOncoBrestLabel = oiqdeDEPagesProperties.getProperty("welEinOncoBrestLabel");
	private final String wasUntZwiGenTesLabel = oiqdeDEPagesProperties.getProperty("wasUntZwiGenTesLabel");
	private final String wasUntZwiGenPradLabel = oiqdeDEPagesProperties.getProperty("wasUntZwiGenPradLabel");
	private final String erSiMeUbEiUnTePageURL = oiqdeDEPagesProperties.getProperty("erSiMeUbEiUnTePageURL");
	private final String wieWerAnaBrusUntrsLabel = oiqdeDEPagesProperties.getProperty("wieWerAnaBrusUntrsLabel");
	private final String storyTitles = oiqdeDEPagesProperties.getProperty("storyTitles");
	private final String bEDEUTETLabel = oiqdeDEPagesProperties.getProperty("bEDEUTETLabel");
	private final String gestelltePageTitle = oiqdeDEPagesProperties.getProperty("gestelltePageTitle");
	private final String testergebnissePageTitle = oiqdeDEPagesProperties.getProperty("testergebnissePageTitle");
	private final String konSieUnsPageURL = oiqdeDEPagesProperties.getProperty("konSieUnsPageURL");
	private final String erfBehBruFruOncTstPageURL = oiqdeDEPagesProperties.getProperty("erfBehBruFruOncTstPageURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqDEPatientenHeaderTest() throws Exception {

		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Deutschland Homepage URL '" + loginUrl + "'");

		oiqDEHomePage.clickTopNavOption(patienten);
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(uberDenTest), true,
				"Header option '" + uberDenTest + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(testFurMichGeeignet), true,
				"Header option '" + testFurMichGeeignet + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(testergebnisse), true,
				"Header option '" + testergebnisse + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(patientengeschichten), true,
				"Header option '" + patientengeschichten + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(tragtDieKosten), true,
				"Header option '" + tragtDieKosten + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(gestellte), true,
				"Header option '" + gestellte + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(glossar), true,
				"Header option '" + glossar + "' is displayed on home page");

		driver.refresh();

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, uberDenTest);
		oiqDEHomePage.clickHeaderOption(uberDenTest);

		verifySafely(oiqCHHomePage.getPageTitle().contains(uberDenTestPageTitle), true,
				"Page Heading displayed VALUE: '" + uberDenTestPageTitle + "'");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(uberDenTest), true,
				"'Über den Test' underlined displayed on the right panel");

		oiqDEUberDenTestPage.clickFiSiHeTestGeeignetBtn();
		logInfo("Clicked on 'FINDEN SIE HERAUS, OB DER TEST FÜR SIE GEEIGNET IST' button");
		verifySafely(driver.getURL(), fiSiHeTestGeeignetPageURL, "Page Heading displayed");
		driver.back();

		oiqDEUberDenTestPage.clickErSiMeUBTestergebnisseBtn();
		logInfo("Clicked on 'ERFAHREN SIE MEHR ÜBER DIE TESTERGEBNISSE' button");
		verifySafely(driver.getURL(), erSiMeUBTestergebnissePageURL, "Page Heading displayed");
		driver.back();

		oiqDEUberDenTestPage.clickMehrInfoFindenBtn();
		logInfo("Clicked on 'MEHR INFORMATIONEN FINDEN SIE HIER' button");
		verifySafely(driver.getURL(), mehrInfoFindenPageURL, "Page Heading displayed");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEUberDenTestPage.clickKlickenBtn();
		logInfo("Clicked on 'KLICKEN SIE HIER ' button from 'Brustkrebs-Früherkennung' card");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), klickenPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Ist der Test für mich geeignet? option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, testFurMichGeeignet);

		verifySafely(oiqCHHomePage.getPageTitle(), testFurMichGeeignet, "Page Heading displayed");

		oiqDETestFurMichGeeignetPage.clickOncoDxRecScrTstBtn();
		logInfo("Clicked on 'Oncotype DX Breast Recurrence Score® Test' link");
		verifySafely(oiqCHHomePage.getPageTitle().contains(oncoDxRecScrTstPageTitle), true,
				"Page Heading displayed VALUE: '" + oiqCHHomePage.getPageTitle() + "'");
		driver.back();

		oiqDETestFurMichGeeignetPage.clickTestberichtLink();
		logInfo("Clicked on 'Testbericht' link");
		verifySafely(driver.getURL(), testberichtPageURL, "Page URL Matches");
		driver.back();

		oiqDETestFurMichGeeignetPage.clickErSiMeDarWiSiZuZuTeBeBtn();
		logInfo("Clicked on 'ERFAHREN SIE MEHR DARÜBER, WIE SIE ZUGANG ZUM TEST BEKOMMEN' button");
		verifySafely(driver.getURL(), erSiMeDarWiSiZuZuTeBePageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

//		Deprecated
//		oiqDETestFurMichGeeignetPage.clickBroschureDownload();
//		logInfo("Clicked on 'BROSCHÜRE ZUM DOWNLOAD' button from 'Die Oncotype DX Patienten Broschüre' card");
//		logInfo("Pdf file downloaded");

		// Die Oncotype DX Testergebnisse header option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, testergebnisse);

		verifySafely(oiqCHHomePage.getPageTitle(), testergebnissePageTitle, "Page Heading displayed");

		oiqDETestergebnissePage.clickPatientinnenLink();
		logInfo("Clicked on 'Patientinnen' link");
		logInfo("Pdf file downloaded");

		oiqDETestergebnissePage.clickErSiMeUbEiUnTeBtn();
		logInfo("Clicked on 'ERFAHREN SIE MEHR ÜBER EIGNUNG UND TESTVERFAHREN' button");
		verifySafely(driver.getURL(), erSiMeUbEiUnTePageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEUberDenTestPage.clickKlickenBtn();
		logInfo("Clicked on 'KLICKEN SIE HIER ' button from 'Infografik' card");
		logInfo("Pdf file downloaded");

		// Patientengeschichten NEU header option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, patientengeschichten);

		verifySafely(oiqCHHomePage.getPageTitle(), patientengeschichtenPageTitle, "Page Heading displayed");

		for (String storyTitle : storyTitles.split(",")) {

			oiqDEPatientengeschichtenPage.clickStoryNameLink(storyTitle);

		}

		oiqDEPatientengeschichtenPage.clickHorenPodcastBtn();
		logInfo("Clicked on 'HÖREN SIE DEN PODCAST' button from 'Muss es immer Chemo sein?' card");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), horenPodcasPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// option Wer trägt die Kosten für den Test?

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, tragtDieKosten);

		verifySafely(oiqCHHomePage.getPageTitle(), tragtDieKosten, "Page Heading displayed");

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Häufig gestellte Fragen option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, gestellte);

		verifySafely(oiqCHHomePage.getPageTitle(), gestelltePageTitle, "Page Heading displayed");

		cgEffectiveAndEasyPage.clickAccordion(wanSolOncoBrestLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wanSolOncoBrestLabel), true,
				wanSolOncoBrestLabel + " accordion is expanded");

		oiqDEGestelltePage.clickFunktioniertLink();
		logInfo("Clicked on 'wie der Oncotype DX Test funktioniert' link");
		verifySafely(driver.getURL(), fürPatientenPageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(welEinOncoBrestLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(welEinOncoBrestLabel), true,
				welEinOncoBrestLabel + " accordion is expanded");

		oiqDEGestelltePage.clickTestergebnisseBtn();
		logInfo("Clicked on 'Testergebnis' link");
		verifySafely(driver.getURL(), erSiMeUBTestergebnissePageURL, "Page Heading displayed");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(wasUntZwiGenTesLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wasUntZwiGenTesLabel), true,
				wasUntZwiGenTesLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(wasUntZwiGenPradLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wasUntZwiGenPradLabel), true,
				wasUntZwiGenPradLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(wieWerAnaBrusUntrsLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wieWerAnaBrusUntrsLabel), true,
				wieWerAnaBrusUntrsLabel + " accordion is expanded");

		oiqDEGestelltePage.clickGeeignetLink();
		logInfo("Clicked on 'geeignet' link");
		verifySafely(driver.getURL(), fiSiHeTestGeeignetPageURL, "Page Heading displayed");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(bEDEUTETLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(bEDEUTETLabel), true,
				bEDEUTETLabel + " accordion is expanded");

		oiqDEGestelltePage.clickGeeignetLink();
		logInfo("Clicked on 'geeignet' link");
		verifySafely(driver.getURL(), fiSiHeTestGeeignetPageURL, "Page Heading displayed");
		driver.back();

		oiqDEGestelltePage.clickErfBehBruFruOncTstLink();
		logInfo("Clicked on 'Erfahren Sie mehr über die Behandlung von Brustkrebs im Frühstadium und den Oncotype DX Test' link.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");
		verifySafely(driver.getURL(), erfBehBruFruOncTstPageURL, "Page URL Matches");

		oiqDEGestelltePage.clickPatientenbroschüreLink();
		logInfo("Clicked on 'Unsere Patientenbroschüre anfordern' link.");
		logInfo("Pdf file downloaded");

		oiqDEGestelltePage.clickErgebnisseTAILORxLink();
		logInfo("Clicked on 'Erfahren Sie mehr über die Ergebnisse der TAILORx-Studie' link.");
		logInfo("Pdf file downloaded");

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Glossar option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, glossar);
		oiqDEHomePage.clickHeaderOption(glossar);
		verifySafely(oiqCHHomePage.getPageTitle(), glossar, "Page Heading displayed");

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
