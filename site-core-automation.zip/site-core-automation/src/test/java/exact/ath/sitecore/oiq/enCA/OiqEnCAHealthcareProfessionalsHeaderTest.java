package exact.ath.sitecore.oiq.enCA;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CGEffectiveAndEasyPage;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqDE.OiqDEGestelltePage;
import exact.ath.oiq.oiqDE.OiqDEHomePage;
import exact.ath.oiq.oiqDE.OiqDEKlinischeEvidenzPage;
import exact.ath.oiq.oiqDE.OiqDEKlinischenPraxisPage;
import exact.ath.oiq.oiqDE.OiqDEOncotypeDXTestPage;
import exact.ath.oiq.oiqDE.OiqDEPatientengeschichtenPage;
import exact.ath.oiq.oiqDE.OiqDETestFurMichGeeignetPage;
import exact.ath.oiq.oiqDE.OiqDETestergebnissePage;
import exact.ath.oiq.oiqDE.OiqDEUberDenTestPage;

/**
 * This class verifies OIQ en Canada web site Healthcare Professionals header
 * components
 * 
 * @userstory #304475 Task#307981
 * @author Pushkar Singh
 * @since 10/6/2023
 */
public class OiqEnCAHealthcareProfessionalsHeaderTest extends BasicIntTest {

	private final OiqDEHomePage oiqDEHomePage = new OiqDEHomePage();
	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final CGEffectiveAndEasyPage cgEffectiveAndEasyPage = new CGEffectiveAndEasyPage();
	private final OiqDEOncotypeDXTestPage oiqDEOncotypeDXTestPage = new OiqDEOncotypeDXTestPage();
	private final OiqDEKlinischenPraxisPage oiqDEKlinischenPraxisPage = new OiqDEKlinischenPraxisPage();
	private final OiqDEKlinischeEvidenzPage oiqDEKlinischeEvidenzPage = new OiqDEKlinischeEvidenzPage();
	private final OiqDEUberDenTestPage oiqDEUberDenTestPage = new OiqDEUberDenTestPage();
	private final OiqDETestFurMichGeeignetPage oiqDETestFurMichGeeignetPage = new OiqDETestFurMichGeeignetPage();
	private final OiqDETestergebnissePage oiqDETestergebnissePage = new OiqDETestergebnissePage();
	private final OiqDEPatientengeschichtenPage oiqDEPatientengeschichtenPage = new OiqDEPatientengeschichtenPage();
	private final OiqDEGestelltePage oiqDEGestelltePage = new OiqDEGestelltePage();

	private final String loginUrl = oiqenCAPagesProperties.getProperty("oiqCAsiteURL");
	private final String oiqenCHPageTitle = oiqenCHPagesProperties.getProperty("oiqenCHPageTitle");
	private final String healthcareProfessionals = oiqenCAPagesProperties.getProperty("healthcareProfessionals");
	private final String aboutTheTest = oiqenCAPagesProperties.getProperty("aboutTheTest");
	private final String valueClinicalPractice = oiqenCAPagesProperties.getProperty("valueClinicalPractice");
	private final String clinicalEvidence = oiqenCAPagesProperties.getProperty("clinicalEvidence");
	private final String inclusionGuidelines = oiqenCAPagesProperties.getProperty("inclusionGuidelines");
	private final String prognosticPredictive = oiqenCAPagesProperties.getProperty("prognosticPredictive");
	private final String interpretingResults = oiqenCAPagesProperties.getProperty("interpretingResults");
	private final String howOrderTest = oiqenCAPagesProperties.getProperty("howOrderTest");
	private final String patientProfileNavigator = oiqenCAPagesProperties.getProperty("patientProfileNavigator");
	private final String videosWebcasts = oiqenCAPagesProperties.getProperty("videosWebcasts");
	private final String nodeNegative = oiqenCAPagesProperties.getProperty("nodeNegative");
	private final String nodePositive = oiqenCAPagesProperties.getProperty("nodePositive");

	private final String fiSiHeTestGeeignetPageURL = oiqdeDEPagesProperties.getProperty("fiSiHeTestGeeignetPageURL");
	private final String uberDenTestPageTitle = oiqdeDEPagesProperties.getProperty("uberDenTestPageTitle");
	private final String erSiMeUBTestergebnissePageURL = oiqdeDEPagesProperties
			.getProperty("erSiMeUBTestergebnissePageURL");
	private final String mehrInfoFindenPageURL = oiqdeDEPagesProperties.getProperty("mehrInfoFindenPageURL");
	private final String fürPatientenPageURL = oiqdeDEPagesProperties.getProperty("fürPatientenPageURL");
	private final String rEFERENZENLabel = oiqdeDEPagesProperties.getProperty("rEFERENZENLabel");
	private final String klickenPageURL = oiqdeDEPagesProperties.getProperty("klickenPageURL");
	private final String patientengeschichtenPageTitle = oiqdeDEPagesProperties
			.getProperty("patientengeschichtenPageTitle");
	private final String oncoDxRecScrTstPageTitle = oiqdeDEPagesProperties.getProperty("oncoDxRecScrTstPageTitle");
	private final String testberichtPageURL = oiqdeDEPagesProperties.getProperty("testberichtPageURL");
	private final String erSiMeDarWiSiZuZuTeBePageURL = oiqdeDEPagesProperties
			.getProperty("erSiMeDarWiSiZuZuTeBePageURL");
	private final String horenPodcasPageURL = oiqdeDEPagesProperties.getProperty("horenPodcasPageURL");
	private final String wanSolOncoBrestLabel = oiqdeDEPagesProperties.getProperty("wanSolOncoBrestLabel");
	private final String welEinOncoBrestLabel = oiqdeDEPagesProperties.getProperty("welEinOncoBrestLabel");
	private final String wasUntZwiGenTesLabel = oiqdeDEPagesProperties.getProperty("wasUntZwiGenTesLabel");
	private final String wasUntZwiGenPradLabel = oiqdeDEPagesProperties.getProperty("wasUntZwiGenPradLabel");
	private final String erSiMeUbEiUnTePageURL = oiqdeDEPagesProperties.getProperty("erSiMeUbEiUnTePageURL");
	private final String wieWerAnaBrusUntrsLabel = oiqdeDEPagesProperties.getProperty("wieWerAnaBrusUntrsLabel");
	private final String storyTitles = oiqdeDEPagesProperties.getProperty("storyTitles");
	private final String bEDEUTETLabel = oiqdeDEPagesProperties.getProperty("bEDEUTETLabel");
	private final String gestelltePageTitle = oiqdeDEPagesProperties.getProperty("gestelltePageTitle");
	private final String testergebnissePageTitle = oiqdeDEPagesProperties.getProperty("testergebnissePageTitle");
	private final String besSieDenTesPageURL = oiqdeDEPagesProperties.getProperty("besSieDenTesPageURL");
	private final String konSieUnsPageURL = oiqdeDEPagesProperties.getProperty("konSieUnsPageURL");
	private final String swogLabel = oiqdeDEPagesProperties.getProperty("swogLabel");
	private final String erfBehBruFruOncTstPageURL = oiqdeDEPagesProperties.getProperty("erfBehBruFruOncTstPageURL");
	private final String klinischeValidierungARTIKELPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeValidierungARTIKELPageURL");
	private final String oncotypeDXTitle = oiqdeDEPagesProperties.getProperty("oncotypeDXTitle");
	private final String sieNccLeiPageURL = oiqdeDEPagesProperties.getProperty("sieNccLeiPageURL");
	private final String iqwPReLesPageURL = oiqdeDEPagesProperties.getProperty("iqwPReLesPageURL");
	private final String nicEmpAufURL = oiqdeDEPagesProperties.getProperty("nicEmpAufURL");
	private final String klinischeEvidenzNodNegPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeEvidenzNodNegPageURL");
	private final String klinischeEvidenzNodPosPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeEvidenzNodPosPageURL");
	private final String prognostischPageTitle = oiqdeDEPagesProperties.getProperty("prognostischPageTitle");
	private final String klinischeValidierungNegARTIKELPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeValidierungNegARTIKELPageURL");
	private final String testenSolltePageTitle = oiqdeDEPagesProperties.getProperty("testenSolltePageTitle");
	private final String pognVsPradPageURL = oiqdeDEPagesProperties.getProperty("pognVsPradPageURL");
	private final String aBKÜRZUNGENLabel = oiqdeDEPagesProperties.getProperty("aBKÜRZUNGENLabel");
	private final String qUELLENANGABENLabel = oiqdeDEPagesProperties.getProperty("qUELLENANGABENLabel");
	private final String nCCNGuidInsBrCanPageURL = oiqdeDEPagesProperties.getProperty("nCCNGuidInsBrCanPageURL");
	private final String nicDiaGuiDGPageURL = oiqdeDEPagesProperties.getProperty("nicDiaGuiDGPageURL");
	private final String erstattungPageTitle = oiqdeDEPagesProperties.getProperty("erstattungPageTitle");
	private final String oncotypeDxBrustPageURL = oiqdeDEPagesProperties.getProperty("oncotypeDxBrustPageURL");
	private final String nodalNegPatLabel = oiqdeDEPagesProperties.getProperty("nodalNegPatLabel");
	private final String nodalPosPatLabel = oiqdeDEPagesProperties.getProperty("nodalPosPatLabel");
	private final String einFalEinPageURL = oiqdeDEPagesProperties.getProperty("einFalEinPageURL");
	private final String fallstudienPageTitle = oiqdeDEPagesProperties.getProperty("fallstudienPageTitle");
	private final String patientenprofil = oiqdeDEPagesProperties.getProperty("patientenprofil");
	private final String patientenprofilPageTitle = oiqdeDEPagesProperties.getProperty("patientenprofilPageTitle");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqEnCAHealthcareProfessionalsHeaderTest() throws Exception {

		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Switzerland Homepage URL '" + loginUrl + "'");
		verifySafely(oiqCHHomePage.getOiqPageTitle(), oiqenCHPageTitle, "Page Heading displayed");

		oiqDEHomePage.clickTopNavOption(healthcareProfessionals);
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(aboutTheTest), true,
				"Header option '" + aboutTheTest + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(valueClinicalPractice), true,
				"Header option '" + valueClinicalPractice + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(clinicalEvidence), true,
				"Header option '" + clinicalEvidence + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(inclusionGuidelines), true,
				"Header option '" + inclusionGuidelines + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(prognosticPredictive), true,
				"Header option '" + prognosticPredictive + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(interpretingResults), true,
				"Header option '" + interpretingResults + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(howOrderTest), true,
				"Header option '" + howOrderTest + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(patientProfileNavigator), true,
				"Header option '" + patientProfileNavigator + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(videosWebcasts), true,
				"Header option '" + videosWebcasts + "' is displayed on home page");

		driver.refresh();

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(healthcareProfessionals, aboutTheTest);
		oiqDEHomePage.clickHeaderOption(aboutTheTest);

		verifySafely(oiqCHHomePage.getPageTitle().contains(uberDenTestPageTitle), true,
				"Page Heading displayed VALUE: '" + uberDenTestPageTitle + "'");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(uberDenTest), true,
				"'Über den Test' underlined displayed on the right panel");

		oiqDEUberDenTestPage.clickFiSiHeTestGeeignetBtn();
		logInfo("Clicked on 'FINDEN SIE HERAUS, OB DER TEST FÜR SIE GEEIGNET IST' button");
		verifySafely(driver.getURL(), fiSiHeTestGeeignetPageURL, "Page Heading displayed");
		driver.back();

		oiqDEUberDenTestPage.clickErSiMeUBTestergebnisseBtn();
		logInfo("Clicked on 'ERFAHREN SIE MEHR ÜBER DIE TESTERGEBNISSE' button");
		verifySafely(driver.getURL(), erSiMeUBTestergebnissePageURL, "Page Heading displayed");
		driver.back();

		oiqDEUberDenTestPage.clickMehrInfoFindenBtn();
		logInfo("Clicked on 'MEHR INFORMATIONEN FINDEN SIE HIER' button");
		verifySafely(driver.getURL(), mehrInfoFindenPageURL, "Page Heading displayed");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEUberDenTestPage.clickKlickenBtn();
		logInfo("Clicked on 'KLICKEN SIE HIER ' button from 'Brustkrebs-Früherkennung' card");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on 'Ich stimme zu' option");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), klickenPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Ist der Test für mich geeignet? option

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, testFurMichGeeignet);

		verifySafely(oiqCHHomePage.getPageTitle(), testFurMichGeeignet, "Page Heading displayed");

		oiqDETestFurMichGeeignetPage.clickOncoDxRecScrTstBtn();
		logInfo("Clicked on 'Oncotype DX Breast Recurrence Score® Test' link");
		verifySafely(oiqCHHomePage.getPageTitle().contains(oncoDxRecScrTstPageTitle), true,
				"Page Heading displayed VALUE: '" + oiqCHHomePage.getPageTitle() + "'");
		driver.back();

		oiqDETestFurMichGeeignetPage.clickTestberichtLink();
		logInfo("Clicked on 'Testbericht' link");
		verifySafely(driver.getURL(), testberichtPageURL, "Page URL Matches");
		driver.back();

		oiqDETestFurMichGeeignetPage.clickErSiMeDarWiSiZuZuTeBeBtn();
		logInfo("Clicked on 'ERFAHREN SIE MEHR DARÜBER, WIE SIE ZUGANG ZUM TEST BEKOMMEN' button");
		verifySafely(driver.getURL(), erSiMeDarWiSiZuZuTeBePageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

//		Deprecated
//		oiqDETestFurMichGeeignetPage.clickBroschureDownload();
//		logInfo("Clicked on 'BROSCHÜRE ZUM DOWNLOAD' button from 'Die Oncotype DX Patienten Broschüre' card");
//		logInfo("Pdf file downloaded");

		// Die Oncotype DX Testergebnisse header option

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, testergebnisse);

		verifySafely(oiqCHHomePage.getPageTitle(), testergebnissePageTitle, "Page Heading displayed");

		oiqDETestergebnissePage.clickPatientinnenLink();
		logInfo("Clicked on 'Patientinnen' link");
		logInfo("Pdf file downloaded");

		oiqDETestergebnissePage.clickErSiMeUbEiUnTeBtn();
		logInfo("Clicked on 'ERFAHREN SIE MEHR ÜBER EIGNUNG UND TESTVERFAHREN' button");
		verifySafely(driver.getURL(), erSiMeUbEiUnTePageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEUberDenTestPage.clickKlickenBtn();
		logInfo("Clicked on 'KLICKEN SIE HIER ' button from 'Infografik' card");
		logInfo("Pdf file downloaded");

		// Patientengeschichten NEU header option

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, patientengeschichten);

		verifySafely(oiqCHHomePage.getPageTitle(), patientengeschichtenPageTitle, "Page Heading displayed");

		for (String storyTitle : storyTitles.split(",")) {

			oiqDEPatientengeschichtenPage.clickStoryNameLink(storyTitle);

		}

		oiqDEPatientengeschichtenPage.clickHorenPodcastBtn();
		logInfo("Clicked on 'HÖREN SIE DEN PODCAST' button from 'Muss es immer Chemo sein?' card");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on 'Ich stimme zu' option");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), horenPodcasPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// option Wer trägt die Kosten für den Test?

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, tragtDieKosten);

		verifySafely(oiqCHHomePage.getPageTitle(), tragtDieKosten, "Page Heading displayed");

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Häufig gestellte Fragen option

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, gestellte);

		verifySafely(oiqCHHomePage.getPageTitle(), gestelltePageTitle, "Page Heading displayed");

		cgEffectiveAndEasyPage.clickAccordion(wanSolOncoBrestLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wanSolOncoBrestLabel), true,
				wanSolOncoBrestLabel + " accordion is expanded");

		oiqDEGestelltePage.clickFunktioniertLink();
		logInfo("Clicked on 'wie der Oncotype DX Test funktioniert' link");
		verifySafely(driver.getURL(), fürPatientenPageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(welEinOncoBrestLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(welEinOncoBrestLabel), true,
				welEinOncoBrestLabel + " accordion is expanded");

		oiqDEGestelltePage.clickTestergebnisseBtn();
		logInfo("Clicked on 'Testergebnis' link");
		verifySafely(driver.getURL(), erSiMeUBTestergebnissePageURL, "Page Heading displayed");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(wasUntZwiGenTesLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wasUntZwiGenTesLabel), true,
				wasUntZwiGenTesLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(wasUntZwiGenPradLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wasUntZwiGenPradLabel), true,
				wasUntZwiGenPradLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(wieWerAnaBrusUntrsLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wieWerAnaBrusUntrsLabel), true,
				wieWerAnaBrusUntrsLabel + " accordion is expanded");

		oiqDEGestelltePage.clickGeeignetLink();
		logInfo("Clicked on 'geeignet' link");
		verifySafely(driver.getURL(), fiSiHeTestGeeignetPageURL, "Page Heading displayed");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(bEDEUTETLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(bEDEUTETLabel), true,
				bEDEUTETLabel + " accordion is expanded");

		oiqDEGestelltePage.clickGeeignetLink();
		logInfo("Clicked on 'geeignet' link");
		verifySafely(driver.getURL(), fiSiHeTestGeeignetPageURL, "Page Heading displayed");
		driver.back();

		oiqDEGestelltePage.clickErfBehBruFruOncTstLink();
		logInfo("Clicked on 'Erfahren Sie mehr über die Behandlung von Brustkrebs im Frühstadium und den Oncotype DX Test' link.");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on 'Ich stimme zu' option");
		verifySafely(driver.getURL(), erfBehBruFruOncTstPageURL, "Page URL Matches");

		oiqDEGestelltePage.clickPatientenbroschüreLink();
		logInfo("Clicked on 'Unsere Patientenbroschüre anfordern' link.");
		logInfo("Pdf file downloaded");

		oiqDEGestelltePage.clickErgebnisseTAILORxLink();
		logInfo("Clicked on 'Erfahren Sie mehr über die Ergebnisse der TAILORx-Studie' link.");
		logInfo("Pdf file downloaded");

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Glossar option

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(patienten, glossar);

		verifySafely(oiqCHHomePage.getPageTitle(), gestelltePageTitle, "Page Heading displayed");

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
