package exact.ath.sitecore.oiq.deDE;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CGEffectiveAndEasyPage;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqDE.OiqDEErstattungPage;
import exact.ath.oiq.oiqDE.OiqDEFallstudienPage;
import exact.ath.oiq.oiqDE.OiqDEHomePage;
import exact.ath.oiq.oiqDE.OiqDEInterpretierenPage;
import exact.ath.oiq.oiqDE.OiqDEKlinischeEvidenzPage;
import exact.ath.oiq.oiqDE.OiqDEKlinischenPraxisPage;
import exact.ath.oiq.oiqDE.OiqDEOncotypeDXPage;
import exact.ath.oiq.oiqDE.OiqDEOncotypeDXTestPage;
import exact.ath.oiq.oiqDE.OiqDEPatientenprofilPage;
import exact.ath.oiq.oiqDE.OiqDETestenSolltePage;
import exact.ath.oiq.oiqDE.OiqDEWebcastsPage;

/**
 * This class verifies OIQ Germany web site FACHKREISE header components
 * 
 * @userstory #304475 Task#307772
 * @author Pushkar Singh
 * @since 07/12/2023
 */
public class OiqDEFachkreiseHeaderTest extends BasicIntTest {

	private final OiqDEHomePage oiqDEHomePage = new OiqDEHomePage();
	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final CGEffectiveAndEasyPage cgEffectiveAndEasyPage = new CGEffectiveAndEasyPage();
	private final OiqDEOncotypeDXTestPage oiqDEOncotypeDXTestPage = new OiqDEOncotypeDXTestPage();
	private final OiqDEKlinischenPraxisPage oiqDEKlinischenPraxisPage = new OiqDEKlinischenPraxisPage();
	private final OiqDEKlinischeEvidenzPage oiqDEKlinischeEvidenzPage = new OiqDEKlinischeEvidenzPage();
	private final OiqDEOncotypeDXPage oiqDEOncotypeDXPage = new OiqDEOncotypeDXPage();
	private final OiqDETestenSolltePage oiqDETestenSolltePage = new OiqDETestenSolltePage();
	private final OiqDEErstattungPage oiqDEErstattungPage = new OiqDEErstattungPage();
	private final OiqDEInterpretierenPage oiqDEInterpretierenPage = new OiqDEInterpretierenPage();
	private final OiqDEFallstudienPage oiqDEFallstudienPage = new OiqDEFallstudienPage();
	private final OiqDEWebcastsPage oiqDEWebcastsPage = new OiqDEWebcastsPage();
	private final OiqDEPatientenprofilPage oiqDEPatientenprofilPage = new OiqDEPatientenprofilPage();

	private final String loginUrl = oiqdeDEPagesProperties.getProperty("oiqDEsiteURL");
	private final String fachkreise = oiqdeDEPagesProperties.getProperty("fachkreise");
	private final String oncotypeDXTest = oiqdeDEPagesProperties.getProperty("oncotypeDXTest");
	private final String klinischenPraxis = oiqdeDEPagesProperties.getProperty("klinischenPraxis");
	private final String klinischeEvidenz = oiqdeDEPagesProperties.getProperty("klinischeEvidenz");
	private final String oncotypeDX = oiqdeDEPagesProperties.getProperty("oncotypeDX");
	private final String prognostisch = oiqdeDEPagesProperties.getProperty("prognostisch");
	private final String testenSollte = oiqdeDEPagesProperties.getProperty("testenSollte");
	private final String testenSollteOption = oiqdeDEPagesProperties.getProperty("testenSollteOption");
	private final String erstattung = oiqdeDEPagesProperties.getProperty("erstattung");
	private final String interpretieren = oiqdeDEPagesProperties.getProperty("interpretieren");
	private final String fallstudien = oiqdeDEPagesProperties.getProperty("fallstudien");
	private final String webcasts = oiqdeDEPagesProperties.getProperty("webcasts");
	private final String oncotypeDXTestTitle = oiqdeDEPagesProperties.getProperty("oncotypeDXTestTitle");
	private final String denUntVerPageTitle = oiqdeDEPagesProperties.getProperty("denUntVerPageTitle");
	private final String weInZuInPageTitle = oiqdeDEPagesProperties.getProperty("weInZuInPageTitle");
	private final String nodalNegativenPatientinnenLabel = oiqdeDEPagesProperties
			.getProperty("nodalNegativenPatientinnenLabel");
	private final String nodalPositivenPatientinnenLabel = oiqdeDEPagesProperties
			.getProperty("nodalPositivenPatientinnenLabel");
	private final String canCologuardDetectPolypsLabel = oiqdeDEPagesProperties
			.getProperty("canCologuardDetectPolypsLabel");
	private final String fürPatientenPageURL = oiqdeDEPagesProperties.getProperty("fürPatientenPageURL");
	private final String rEFERENZENLabel = oiqdeDEPagesProperties.getProperty("rEFERENZENLabel");
	private final String leSiHiWePageURL = oiqdeDEPagesProperties.getProperty("leSiHiWePageURL");
	private final String tAILORxARTIKELPageURL = oiqdeDEPagesProperties.getProperty("tAILORxARTIKELPageURL");
	private final String tAILORxARTIKELPageURL2 = oiqdeDEPagesProperties.getProperty("tAILORxARTIKELPageURL2");
	private final String planBARTIKELPageURL = oiqdeDEPagesProperties.getProperty("planBARTIKELPageURL");
	private final String brustkrebsARTIKELPageURL = oiqdeDEPagesProperties.getProperty("brustkrebsARTIKELPageURL");
	private final String wertDerklinischenPraxis = oiqdeDEPagesProperties.getProperty("wertDerklinischenPraxis");
	private final String nodalNegativ = oiqdeDEPagesProperties.getProperty("nodalNegativ");
	private final String nodalPositiv = oiqdeDEPagesProperties.getProperty("nodalPositiv");
	private final String derklinischenPraxisTitle = oiqdeDEPagesProperties.getProperty("derklinischenPraxisTitle");
	private final String derklinischenPraxisNodalPositivTitle = oiqdeDEPagesProperties
			.getProperty("derklinischenPraxisNodalPositivTitle");
	private final String oriBehBasRecScoErgUndAltLabel = oiqdeDEPagesProperties
			.getProperty("oriBehBasRecScoErgUndAltLabel");
	private final String leSiMeZuklEvBePageURL = oiqdeDEPagesProperties.getProperty("leSiMeZuklEvBePageURL");
	private final String mEHRPageURL = oiqdeDEPagesProperties.getProperty("mEHRPageURL");
	private final String mEHRPageURLIE = oiqdeDEPagesProperties.getProperty("mEHRPageURLIE");
	private final String wiTrDeOnDXTeUnThBeLabel = oiqdeDEPagesProperties.getProperty("wiTrDeOnDXTeUnThBeLabel");
	private final String klinischeEvidenzPageTitle = oiqdeDEPagesProperties.getProperty("klinischeEvidenzPageTitle");
	private final String klinischeEvidenzPosPageTitle = oiqdeDEPagesProperties
			.getProperty("klinischeEvidenzPosPageTitle");
	private final String weiInfTaiXLabel = oiqdeDEPagesProperties.getProperty("weiInfTaiXLabel");
	private final String erSiMeUbUnZwPrPrPageURL = oiqdeDEPagesProperties.getProperty("erSiMeUbUnZwPrPrPageURL");
	private final String viWiInLePageURL = oiqdeDEPagesProperties.getProperty("viWiInLePageURL");
	private final String besSieDenTesPageURL = oiqdeDEPagesProperties.getProperty("besSieDenTesPageURL");
	private final String konSieUnsPageURL = oiqdeDEPagesProperties.getProperty("konSieUnsPageURL");
	private final String swogLabel = oiqdeDEPagesProperties.getProperty("swogLabel");
	private final String rxPonderLabel = oiqdeDEPagesProperties.getProperty("rxPonderLabel");
	private final String klinischeValidierungARTIKELPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeValidierungARTIKELPageURL");
	private final String oncotypeDXTitle = oiqdeDEPagesProperties.getProperty("oncotypeDXTitle");
	private final String sieNccLeiPageURL = oiqdeDEPagesProperties.getProperty("sieNccLeiPageURL");
	private final String iqwPReLesPageURL = oiqdeDEPagesProperties.getProperty("iqwPReLesPageURL");
	private final String nicEmpAufURL = oiqdeDEPagesProperties.getProperty("nicEmpAufURL");
	private final String klinischeEvidenzNodNegPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeEvidenzNodNegPageURL");
	private final String klinischeEvidenzNodPosPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeEvidenzNodPosPageURL");
	private final String prognostischPageTitle = oiqdeDEPagesProperties.getProperty("prognostischPageTitle");
	private final String klinischeValidierungNegARTIKELPageURL = oiqdeDEPagesProperties
			.getProperty("klinischeValidierungNegARTIKELPageURL");
	private final String testenSolltePageTitle = oiqdeDEPagesProperties.getProperty("testenSolltePageTitle");
	private final String pognVsPradPageURL = oiqdeDEPagesProperties.getProperty("pognVsPradPageURL");
	private final String aBKÜRZUNGENLabel = oiqdeDEPagesProperties.getProperty("aBKÜRZUNGENLabel");
	private final String qUELLENANGABENLabel = oiqdeDEPagesProperties.getProperty("qUELLENANGABENLabel");
	private final String nCCNGuidInsBrCanPageURL = oiqdeDEPagesProperties.getProperty("nCCNGuidInsBrCanPageURL");
	private final String nicDiaGuiDGPageURL = oiqdeDEPagesProperties.getProperty("nicDiaGuiDGPageURL");
	private final String erstattungPageTitle = oiqdeDEPagesProperties.getProperty("erstattungPageTitle");
	private final String oncotypeDxBrustPageURL = oiqdeDEPagesProperties.getProperty("oncotypeDxBrustPageURL");
	private final String nodalNegPatLabel = oiqdeDEPagesProperties.getProperty("nodalNegPatLabel");
	private final String nodalPosPatLabel = oiqdeDEPagesProperties.getProperty("nodalPosPatLabel");
	private final String einFalEinPageURL = oiqdeDEPagesProperties.getProperty("einFalEinPageURL");
	private final String pdfPageURL = oiqdeDEPagesProperties.getProperty("pdfPageURL");
	private final String fallstudienPageTitle = oiqdeDEPagesProperties.getProperty("fallstudienPageTitle");
	private final String patientenprofil = oiqdeDEPagesProperties.getProperty("patientenprofil");
	private final String patientenprofilPageTitle = oiqdeDEPagesProperties.getProperty("patientenprofilPageTitle");
	private final String getInTouchPageURL = oiqdeDEPagesProperties.getProperty("getInTouchPageURL");
	private final String webcastsPageTitle = oiqdeDEPagesProperties.getProperty("webcastsPageTitle");
	private final String abSofortOnDemandPageURL = oiqdeDEPagesProperties.getProperty("abSofortOnDemandPageURL");
	private final String weInZuSeUbVoNegPatPageTitle = oiqdeDEPagesProperties
			.getProperty("weInZuSeUbVoNegPatPageTitle");
	private final String weInZuSeUbVoPosPatPageTitle = oiqdeDEPagesProperties
			.getProperty("weInZuSeUbVoPosPatPageTitle");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqDEFachkreiseHeaderTest() throws Exception {

		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Deutschland Homepage URL '" + loginUrl + "'");

		oiqDEHomePage.clickTopNavOption(fachkreise);
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(oncotypeDXTest), true,
				"Header option '" + oncotypeDXTest + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(klinischenPraxis), true,
				"Header option '" + klinischenPraxis + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(klinischeEvidenz), true,
				"Header option '" + klinischeEvidenz + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(oncotypeDX), true,
				"Header option '" + oncotypeDX + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(prognostisch), true,
				"Header option '" + prognostisch + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(testenSollte), true,
				"Header option '" + testenSollte + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(erstattung), true,
				"Header option '" + erstattung + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(interpretieren), true,
				"Header option '" + interpretieren + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(fallstudien), true,
				"Header option '" + fallstudien + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(patientenprofil), true,
				"Header option '" + patientenprofil + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(webcasts), true,
				"Header option '" + webcasts + "' is displayed on home page");

		driver.refresh();

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, oncotypeDXTest);

		oiqCHHomePage.clickpopupFürPatientenOption();
		verifySafely(driver.getURL(), fürPatientenPageURL, "Page URL Matches");
		driver.back();

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), oncotypeDXTestTitle, "Page Heading displayed");

		oiqDEOncotypeDXTestPage.clickDenUntVerBtn();
		logInfo("Clicked on 'DEN UNTERSCHIED VERSTEHEN' button");
		verifySafely(oiqCHHomePage.getPageTitle(), denUntVerPageTitle, "Page Heading displayed");
		driver.back();

		oiqDEOncotypeDXTestPage.clickWeInZuInrBtn();
		logInfo("Clicked on 'WEITERE INFORMATIONEN ZUR INTERPRETATION DER ERGEBNISSE DES ONCOTYPE DX  TESTS BEI NODAL-NEGATIVEN UND NODAL-POSITIVEN PATIENTINNEN' button");
		verifySafely(oiqCHHomePage.getPageTitle(), weInZuInPageTitle, "Page Heading displayed");
		driver.back();

		oiqDEOncotypeDXTestPage.clickDEAccordian(nodalNegativenPatientinnenLabel);
		verifySafely(oiqDEOncotypeDXTestPage.isAccordionExpanded(), true,
				nodalNegativenPatientinnenLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickWeInZuSeUbVoNegPatPageBtn();
		logInfo("Clicked on 'WEITERE INFORMATIONEN ZUR SENKUNG DES RISIKOS EINER UNTER- BZW. ÜBERBEHANDLUNG VON NODAL-NEGATIVEN PATIENTINNEN' button");
		verifySafely(oiqCHHomePage.getPageTitle(), weInZuSeUbVoNegPatPageTitle, "Page Heading displayed");
		driver.back();

		oiqDEOncotypeDXTestPage.clickDEAccordian(nodalPositivenPatientinnenLabel);
		verifySafely(oiqDEOncotypeDXTestPage.isAccordionExpanded(), true,
				nodalPositivenPatientinnenLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickWeInZuSeUbVoNegPatPageBtn();
		logInfo("Clicked on 'WEITERE INFORMATIONEN ZUR SENKUNG DES RISIKOS EINER UNTER- BZW. ÜBERBEHANDLUNG VON NODAL-POSITIVEN PATIENTINNEN' button");
		verifySafely(oiqCHHomePage.getPageTitle(), weInZuSeUbVoPosPatPageTitle, "Page Heading displayed");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickLeSiHiWeBtn();
		logInfo("Clicked on 'LESEN SIE HIER WEITER' button from 'Wegweisende Ergebnisse der RxPONDER-Studie' card");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), leSiHiWePageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXTestPage.clickTAILORxARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten TAILORx' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), tAILORxARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXTestPage.clickPlanBARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten WSG Plan B' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), planBARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXTestPage.clickBrustkrebsARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Gesundheits- ökonomische Untersuchung Invasiver früher Brustkrebs' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), brustkrebsARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		// Wert in der klinischen Praxis option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, wertDerklinischenPraxis, nodalNegativ);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), derklinischenPraxisTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(nodalNegativ), true,
				"'Nodal-Negativ' underlined displayed under 'Wert in der klinischen Praxis' on the right panel");

		cgEffectiveAndEasyPage.clickAccordion(oriBehBasRecScoErgUndAltLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(oriBehBasRecScoErgUndAltLabel), true,
				oriBehBasRecScoErgUndAltLabel + " accordion is expanded");

		oiqDEKlinischenPraxisPage.clickLeSiMeZuklEvBeBtn();
		logInfo("Clicked on 'LESEN SIE MEHR ZUR KLINISCHEN EVIDENZ BEI NODAL-NEGATIVEN PATIENTINNEN' option");
		verifySafely(driver.getURL(), leSiMeZuklEvBePageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickTAILORxARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten TAILORx' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), tAILORxARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischenPraxisPage.clickMEHRBtn();
		logInfo("Clicked on 'MEHR' button from 'Ergebnisse der TAILORx-Studie' card");
		verifySafely(driver.getURL(), mEHRPageURL, "Page URL Matches");
		driver.back();

		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, wertDerklinischenPraxis, nodalPositiv);

		verifySafely(oiqCHHomePage.getPageTitle(), derklinischenPraxisNodalPositivTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(nodalPositiv), true,
				"'Nodal-Positiv' underlined displayed under 'Wert in der klinischen Praxis' on the right panel");

		cgEffectiveAndEasyPage.clickAccordion(wiTrDeOnDXTeUnThBeLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(wiTrDeOnDXTeUnThBeLabel), true,
				wiTrDeOnDXTeUnThBeLabel + " accordion is expanded");

//		oiqDEKlinischenPraxisPage.clickLeSiMeZuklEvBeBtn();
//		logInfo("Clicked on 'LESEN SIE MEHR ZUR KLINISCHEN EVIDENZ BEI NODAL-POSITIVEN PATIENTINNEN' option");
//		verifySafely(driver.getURL(), leSiMeZuklEvBePageURL, "Page URL Matches");
//		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickLeSiHiBtn();
		logInfo("Clicked on 'LESEN SIE HIER' button from 'Neue NCCN Brustkrebs Leitlinien' card");
		logInfo("Pdf file downloaded");

		oiqDEOncotypeDXTestPage.clickPlanBARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten WSG Plan B' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), planBARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXTestPage.clickBrustkrebsARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Gesundheits- ökonomische Untersuchung Invasiver früher Brustkrebs' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), brustkrebsARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		// Klinische Evidenz header option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, klinischeEvidenz, nodalNegativ);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), klinischeEvidenzPageTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(nodalNegativ), true,
				"'Nodal-Negativ' underlined displayed under 'Klinische Evidenz' on the right panel");

		cgEffectiveAndEasyPage.clickAccordion(weiInfTaiXLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(weiInfTaiXLabel), true,
				weiInfTaiXLabel + " accordion is expanded");

		oiqDEKlinischeEvidenzPage.clickErSiMeUbUnZwPrPrLink();
		logInfo("Clicked on 'Erfahren Sie mehr über den Unterschied zwischen prognostisch und prädiktiv' Hyperlink");
		verifySafely(driver.getURL(), erSiMeUbUnZwPrPrPageURL, "Page URL Matches");
		driver.back();

		oiqDEKlinischeEvidenzPage.clickViWiInLeLink();
		logInfo("Clicked on 'vier wichtigsten internationalen Leitlinien' Hyperlink");
		verifySafely(driver.getURL(), viWiInLePageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEKlinischenPraxisPage.clickMEHRBtn();
		logInfo("Clicked on 'MEHR' button from 'Ergebnisse der TAILORx-Studie' card");
		verifySafely(driver.getURL(), mEHRPageURL, "Page URL Matches");
		driver.back();

//		oiqDEOncotypeDXTestPage.clickBrustkrebsARTIKELBtn();
//		logInfo("Clicked on 'ARTIKEL' button from 'Gesundheits- ökonomische Untersuchung Invasiver früher Brustkrebs' card.");
//		oiqCHHomePage.clickpopupbutton1();
//		logInfo("Clicked on 'Ich stimme zu' option");
//
//		driver.switchToCurrentWindow();
//		verifySafely(driver.getURL(), brustkrebsARTIKELPageURL, "Page URL Matches");
//		driver.closeCurrentWindow();
//		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickBesSieDenTesBtn();
		logInfo("Clicked on 'BESTELLEN SIE DEN TEST' button");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), besSieDenTesPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsBtn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Positiv

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, klinischeEvidenz, nodalPositiv);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), klinischeEvidenzPosPageTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(nodalPositiv), true,
				"'Nodal-Positiv' underlined displayed under 'Klinische Evidenz' on the right panel");

		cgEffectiveAndEasyPage.clickAccordion(swogLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(swogLabel), true,
				swogLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(rxPonderLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rxPonderLabel), true,
				rxPonderLabel + " accordion is expanded");

		oiqDEKlinischeEvidenzPage.clickErSiMeUbUnZwPrPrLink();
		logInfo("Clicked on 'Erfahren Sie mehr zum Unterschied zwischen prognostisch und prädiktiv' Hyperlink");
		verifySafely(driver.getURL(), erSiMeUbUnZwPrPrPageURL, "Page URL Matches");
		driver.back();

		oiqDEKlinischeEvidenzPage.clickViWiInLeLinkA();
		logInfo("Clicked on 'vier wichtigsten internationalen Leitlinien' Hyperlink");
		verifySafely(driver.getURL(), viWiInLePageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEKlinischeEvidenzPage.clickKlinischeValidierungPosARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Klinische Validierung Clalit Nodal-Positiv' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), klinischeValidierungARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXTestPage.clickPlanBARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten WSG Plan B' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), planBARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsBtn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Oncotype DX in Leitlinien option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, oncotypeDX);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), oncotypeDXTitle, "Page Heading displayed");

		oiqDEOncotypeDXPage.clickSieNccLeiBtn();
		logInfo("Clicked on 'SIEHE NCCN-LEITLINIEN' button.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), sieNccLeiPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXPage.clickIqwPReLesBtn();
		logInfo("Clicked on 'IQWIG-PRESSEMITTEILUNG LESEN' button.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), iqwPReLesPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXPage.clickNicEmpAufBtn();
		logInfo("Clicked on 'NICE-EMPFEHLUNG AUFRUFEN' button.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), nicEmpAufURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEOncotypeDXPage.clickKlinischeEvidenzNodNegBtn();
		logInfo("Clicked on 'KLINISCHE EVIDENZ FÜR NODAL-NEGATIV' Hyperlink");
		verifySafely(driver.getURL(), klinischeEvidenzNodNegPageURL, "Page URL Matches");
		driver.back();

		oiqDEOncotypeDXPage.clickKlinischeEvidenzNodPosBtn();
		logInfo("Clicked on 'KLINISCHE EVIDENZ FÜR NODAL-POSITIV' Hyperlink");
		verifySafely(driver.getURL(), klinischeEvidenzNodPosPageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickTAILORxARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten TAILORx' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), tAILORxARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		// Prädiktiv versus prognostisch option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, prognostisch);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), prognostischPageTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(prognostisch), true,
				"'Prädiktiv versus prognostisch' underlined displayed under the right panel");

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickTAILORxARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten TAILORx' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), tAILORxARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKlinischeValidierungNegARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Klinische Validierung Clalit Nodal-Negativ' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), klinischeValidierungNegARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKlinischeValidierungPosARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Klinische Validierung Clalit Nodal-Positiv' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), klinischeValidierungARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsBtn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Wen man testen sollte

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, testenSollte);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), testenSolltePageTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(testenSollteOption), true,
				"'Wen man testen sollte NEW' underlined displayed under the right panel");

		oiqDETestenSolltePage.clickPognVsPradBtn();
		logInfo("Clicked on 'MEHR ÜBER PROGNOSTISCHE VS. PRÄDIKTIVE TESTS ERFAHREN' button");
		verifySafely(driver.getURL(), pognVsPradPageURL, "Page URL Matches");
		driver.back();

		cgEffectiveAndEasyPage.clickAccordion(aBKÜRZUNGENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(aBKÜRZUNGENLabel), true,
				aBKÜRZUNGENLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(qUELLENANGABENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(qUELLENANGABENLabel), true,
				qUELLENANGABENLabel + " accordion is expanded");

		oiqDETestenSolltePage.clickNCCNGuidInsBrCanLink();
		logInfo("Clicked on 'NCCN Guidelines Insights: Breast Cancer, Version 3.2021.' link");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), nCCNGuidInsBrCanPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDETestenSolltePage.clickNicDiaGuiDGLink();
		logInfo("Clicked on 'NICE Diagnostics Guidance DG34 December 2018.' link");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), nicDiaGuiDGPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.back();
		driver.refresh();

		// Erstattung header option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, erstattung);
		oiqDEHomePage.clickHeaderOption(erstattung);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), erstattungPageTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(erstattung), true,
				"'Erstattung' underlined displayed under the right panel");

		oiqDEErstattungPage.clickOncotypeDxLoginLink();
		logInfo("Clicked on 'https://online.oncotypedx.de/#/login' link");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), besSieDenTesPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEErstattungPage.clickOncotypeDxBrustLink();
		logInfo("Clicked on 'Oncotype DX® Brustkrebstest' link");
		verifySafely(driver.getURL(), oncotypeDxBrustPageURL, "Page URL Matches");
		driver.back();

		oiqDEKlinischenPraxisPage.clickMEHRBtn();
		logInfo("Clicked on 'MEHR' button from 'Ergebnisse der TAILORx-Studie' card");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");
		verifySafely(driver.getURL(), mEHRPageURLIE, "Page URL Matches");
		driver.back();

//		oiqDEKlinischeEvidenzPage.clickKonSieUnsBtn();
//		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
//		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
//		driver.back();

		// Die Ergebnisse interpretieren header option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, interpretieren);

		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), weInZuInPageTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(interpretieren), true,
				"'Die Ergebnisse interpretieren' underlined displayed under the right panel");

		oiqDEInterpretierenPage.clickOriZumBerStaBtn();
		logInfo("Clicked on 'Orientierungshilfe zum Bericht starten' button");
		verifySafely(oiqDEInterpretierenPage.isOriZumBerStaImageDisplayed(), true,
				"'Orientierungshilfe zum Bericht starten' Image is displayed");
		oiqDEInterpretierenPage.clickCloseImage();

		driver.refresh();
		cgEffectiveAndEasyPage.clickAccordion(nodalNegPatLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(nodalNegPatLabel), true,
				nodalNegPatLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(nodalPosPatLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(nodalPosPatLabel), true,
				nodalPosPatLabel + " accordion is expanded");

		oiqDEInterpretierenPage.clickNodalNegBtn();
		logInfo("Clicked on 'NODAL-NEGATIV' button.");
		logInfo("Pdf file downloaded");

		oiqDEInterpretierenPage.clickNodalPosBtn();
		logInfo("Clicked on 'NODAL-POSITIV' button.");
		logInfo("Pdf file downloaded");

		cgEffectiveAndEasyPage.clickAccordion(rEFERENZENLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(rEFERENZENLabel), true,
				rEFERENZENLabel + " accordion is expanded");

		oiqDEOncotypeDXTestPage.clickTAILORxARTIKELBtn();
		logInfo("Clicked on 'ARTIKEL' button from 'Prospektive Outcome Daten TAILORx' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), tAILORxARTIKELPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		// Fallstudien NEW Header option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, fallstudien);

		oiqDEHomePage.clickHeaderOption(fallstudien);
		oiqCHHomePage.clickpopupWeiAngMedFacOption();
		verifySafely(oiqCHHomePage.getPageTitle(), fallstudienPageTitle, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(fallstudienPageTitle), true,
				"'Fallstudien NEW' underlined displayed under the right panel");

		oiqDEFallstudienPage.selectFilterOption("RecurrenceScoreResult0_25", "0-25");
		oiqDEFallstudienPage.selectFilterOption("AGE", "50 and under (0-50)");
		oiqDEFallstudienPage.selectFilterOption("MENOPAUSAL STATUS", "Premenopausal");
		oiqDEFallstudienPage.selectFilterOption("TUMOR TYPE", "Ductal");
		oiqDEFallstudienPage.selectFilterOptionDropDown("LYMPH NODE STATUS", "Node negative");
		oiqDEFallstudienPage.selectFilterOptionDropDown("TUMOR SIZE (CM)", "≤ 1.0");
		oiqDEFallstudienPage.selectFilterOption("HISTOLOGIC GRADE", "2");
		oiqDEFallstudienPage.selectFilterOption("ER STATUS", "10-50%");
		oiqDEFallstudienPage.selectFilterOption("PR STATUS", "10-50%");
		oiqDEFallstudienPage.selectFilterOptionDropDown("HER2/NEU", "IHC 2+ & ISH- (negative)");
		oiqDEFallstudienPage.selectFilterOptionDropDown("KI-67", "10-25%");

		oiqDEFallstudienPage.clickViewNowBtn();
		logInfo("Clicked on 'VIEW NOW' button.");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), pdfPageURL, "Pdf Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEFallstudienPage.clickEinFalEinBtn();
		logInfo("Clicked on 'EINEN FALL EINREICHEN' button under 'Reichen Sie Ihren Fall von invasivem Brustkrebs hier ein' card");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), einFalEinPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		// Patientenprofil-Navigator NEW Header

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, patientenprofil);

		verifySafely(oiqCHHomePage.getProfileHeaderTitle(), patientenprofilPageTitle, "Page Heading displayed");

		oiqDEPatientenprofilPage.clickStartBtnBy();

		oiqDEPatientenprofilPage.selectFilterOption("Alter", "Less than equal to 50");
		oiqDEPatientenprofilPage.selectFilterOption("Tumorgröße", "Less than 1");
		oiqDEPatientenprofilPage.selectFilterOption("Tumorgrad", "1");
		oiqDEPatientenprofilPage.selectFilterOption("Ki-67", "Less than 10");

		oiqDEPatientenprofilPage.clickCreateProfileBtn();
		logInfo("Clicked on 'ERSTELLEN SIE IHR AUSGEWÄHLTES PATIENTENPROFIL ' button");

		oiqDEPatientenprofilPage.click2ndSlideBtn();
		logInfo("Clicked on the second tab");

		verifySafely(oiqDEPatientenprofilPage.is2ndSlideDisplayed(), true, "Next slide gets displayed.");

		oiqDEPatientenprofilPage.clickGetInTouchBtn();
		logInfo("Clicked on 'GET IN TOUCH WITH US' button.");
		verifySafely(driver.getURL(), getInTouchPageURL, "Page URL Matches");
		driver.back();

		verifySafely(oiqCHHomePage.getProfileHeaderTitle(), patientenprofilPageTitle, "Page Heading displayed");

		oiqDEPatientenprofilPage.clickStartBtnBy();

		oiqDEPatientenprofilPage.selectFilterOption("Alter", "Less than equal to 50");
		oiqDEPatientenprofilPage.selectFilterOption("Tumorgröße", "Less than 1");
		oiqDEPatientenprofilPage.selectFilterOption("Tumorgrad", "1");
		oiqDEPatientenprofilPage.selectFilterOption("Ki-67", "Less than 10");

		oiqDEPatientenprofilPage.clickCreateProfileBtn();
		logInfo("Clicked on 'ERSTELLEN SIE IHR AUSGEWÄHLTES PATIENTENPROFIL ' button");

		oiqDEPatientenprofilPage.clickResetProfilesBtn();
		logInfo("Clicked on 'RESET PROFILES' button.");

		verifySafely(oiqCHHomePage.getProfileHeaderTitle(), patientenprofilPageTitle, "Page Heading displayed");

		// Webcasts und Videos Header option

		driver.close();
		setupURL(loginUrl);
		oiqDEHomePage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, webcasts);

		verifySafely(oiqCHHomePage.getPageTitle(), webcastsPageTitle, "Page Heading displayed");

		oiqDEWebcastsPage.clickAbSofortOnDemandBtn();
		logInfo("Clicked on 'AB SOFORT ON DEMAND' button under 'Frühinvasiver, HR+ HER2neu negativer Brustkrebs' card.");
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), abSofortOnDemandPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEKlinischeEvidenzPage.clickKonSieUnsH2Btn();
		logInfo("Clicked on 'KONTAKTIEREN SIE UNS' button under 'Haben Sie Fragen?' card");
		verifySafely(driver.getURL(), konSieUnsPageURL, "Page URL Matches");
		driver.back();

		oiqDEWebcastsPage.click2ndPageLink();
		logInfo("Clicked on '2' from bottom jump link.");
		verifySafely(oiqDEWebcastsPage.is2ndPageDisplayed(), true, "Page Heading displayed");

		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
