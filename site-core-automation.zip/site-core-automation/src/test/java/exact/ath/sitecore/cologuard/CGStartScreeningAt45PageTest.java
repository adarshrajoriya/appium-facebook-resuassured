package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CGStartScreeningAt45Page;
import exact.ath.cologuard.CologuardHomepage;
import exact.util.PostStatusToZephyr;

/**
 * This class verifies Start screening at 45 page validations
 * 
 * @userstory #303911 Task#304657
 * @author Sandeep Singh
 * @since 05/04/2023
 */
public class CGStartScreeningAt45PageTest extends BasicIntTest {

	private final CologuardHomepage cologuardHomepage = new CologuardHomepage();
	private final CGStartScreeningAt45Page cgStartScreeningAt45Page = new CGStartScreeningAt45Page();

	private final String cologuardHomePageURL = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	private final String whyStartAt45URL = cologuardPagesProperties.getProperty("whyStartAt45URL");
	private final String impRiskInfoURL = cologuardPagesProperties.getProperty("impRiskInfoURL");
	private final String effectiveAndEasyURL = cologuardPagesProperties.getProperty("effectiveAndEasyURL");
	private final String getCologuardURL = cologuardPagesProperties.getProperty("getCologuardURL");

	private final String whyCologuard = cologuardPagesProperties.getProperty("whyCologuard");
	private final String startScreeningAt45 = cologuardPagesProperties.getProperty("startScreeningAt45");
	private final String startScreeningAt45Title = cologuardPagesProperties.getProperty("startScreeningAt45Title");
	private final String impRiskInfo = cologuardPagesProperties.getProperty("impRiskInfo");

	private final String impRiskInfoPageTitle = cologuardPagesProperties.getProperty("impRiskInfoPageTitle");
	private final String effectiveAndEasyScreeningPageTitle = cologuardPagesProperties
			.getProperty("effectiveAndEasyScreeningPageTitle");
	private final String requestCologuardPageTitle = cologuardPagesProperties.getProperty("getCologuardPageTitle");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T721";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyStartScreeningAT45PageData() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");
		acceptCookies();

		verifySafely(cgStartScreeningAt45Page.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cgStartScreeningAt45Page.selectSubOptionFromTopNavOptions(whyCologuard, startScreeningAt45);
		verifySafely(driver.getURL(), whyStartAt45URL, "'Why Start at 45?' page is displayed");
		verifySafely(driver.getTitle(), startScreeningAt45Title,
				"'" + startScreeningAt45Title + "' is displayed as page title");

		cologuardHomepage.clickLinkOnPage(impRiskInfo);
		verifySafely(driver.getURL(), impRiskInfoURL, "'Important Risk Information' page is displayed");
		verifySafely(driver.getTitle(), impRiskInfoPageTitle,
				"'" + impRiskInfoPageTitle + "' is displayed as page title");

		driver.back();

		cgStartScreeningAt45Page.clickLearnMoreLink();
		verifySafely(driver.getURL(), effectiveAndEasyURL, "'Effective and easy screening' page is displayed");
		verifySafely(driver.getTitle(), effectiveAndEasyScreeningPageTitle,
				"'" + effectiveAndEasyScreeningPageTitle + "' is displayed as page title");

		driver.back();

		cgStartScreeningAt45Page.clickGetTheConversationStartedLink();
		verifySafely(driver.getURL(), getCologuardURL, "'Request Cologuard' page is displayed");
		verifySafely(driver.getTitle(), requestCologuardPageTitle,
				"'" + requestCologuardPageTitle + "' is displayed as page title");

		throwAssertionErrorOnFailure();
	}
}
