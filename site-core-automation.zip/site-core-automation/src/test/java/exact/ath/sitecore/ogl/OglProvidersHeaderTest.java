package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglAddingToWorkflowPage;
import exact.ath.ogl.OglClinicalPerformancePage;
import exact.ath.ogl.OglContactUsPage;
import exact.ath.ogl.OglFAQsPage;
import exact.ath.ogl.OglHomepage;
import exact.ath.ogl.OglOrdersAndResultsPage;
import exact.ath.ogl.OglOverviewPage;
import exact.ath.ogl.OglScientificRigorPage;

/**
 * This class verifies the Providers header components of OGL website
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 06/27/2023
 */

public class OglProvidersHeaderTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();
	private final OglOverviewPage oglOverviewPage = new OglOverviewPage();
	private final OglClinicalPerformancePage oglClinicalPerformancePage = new OglClinicalPerformancePage();

	private final OglContactUsPage oglContactUsPage = new OglContactUsPage();
	private final OglScientificRigorPage oglScientificRigorPage = new OglScientificRigorPage();
	private final OglAddingToWorkflowPage oglAddingToWorkflowPage = new OglAddingToWorkflowPage();
	private final OglOrdersAndResultsPage oglOrdersAndResultsPage = new OglOrdersAndResultsPage();

	private final OglFAQsPage oglFAQsPage = new OglFAQsPage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String providers = oglPagesProperties.getProperty("providers");
	private final String overview = oglPagesProperties.getProperty("overview");
	private final String theOncoguardLiverTest = oglPagesProperties.getProperty("theOncoguardLiverTest");
	private final String clinicalPerformance = oglPagesProperties.getProperty("clinicalPerformance");
	private final String scientificRigor = oglPagesProperties.getProperty("scientificRigor");
	private final String addingToTheWorkflow = oglPagesProperties.getProperty("addingToTheWorkflow");
	private final String ordersAndResults = oglPagesProperties.getProperty("ordersAndResults");
	private final String insuranceAndBilling = oglPagesProperties.getProperty("insuranceAndBilling");

	private final String patientEngagementProgram = oglPagesProperties.getProperty("patientEngagementProgram");
	private final String advocacy = oglPagesProperties.getProperty("advocacy");
	private final String aboutUs = oglPagesProperties.getProperty("aboutUs");
	private final String faqs = oglPagesProperties.getProperty("faqs");
	private final String overviewURL = oglPagesProperties.getProperty("overviewURL");
	private final String advancedPerformanceYouCanRelyOn = oglPagesProperties
			.getProperty("advancedPerformanceYouCanRelyOn");
	private final String innovationWithoutInconvenience = oglPagesProperties
			.getProperty("innovationWithoutInconvenience");
	private final String supportDrivesAdherence = oglPagesProperties.getProperty("supportDrivesAdherence");
	private final String oncoguardLiverTestURL = oglPagesProperties.getProperty("oncoguardLiverTestURL");
	private final String hccTestingPatientsTitle = oglPagesProperties.getProperty("hccTestingPatientsTitle");
	private final String oncoguardLiverTestClinicalPerformanceURL = oglPagesProperties
			.getProperty("oncoguardLiverTestClinicalPerformanceURL");
	private final String deliveringHighDegreeHCCDetectionTitle = oglPagesProperties
			.getProperty("deliveringHighDegreeHCCDetectionTitle");
	private final String contactUs = oglPagesProperties.getProperty("contactUs");
	private final String contactUsProvidersOnlyTitle = oglPagesProperties.getProperty("contactUsProvidersOnlyTitle");
	private final String oncoguardLiverTestScientificRigorURL = oglPagesProperties
			.getProperty("oncoguardLiverTestScientificRigorURL");
	private final String targetingUnmetNeedTitle = oglPagesProperties.getProperty("targetingUnmetNeedTitle");
	private final String oncoguardLiverTestAddingWorkflowURL = oglPagesProperties
			.getProperty("oncoguardLiverTestAddingWorkflowURL");
	private final String streamliningApproachHCCTestingTitle = oglPagesProperties
			.getProperty("streamliningApproachHCCTestingTitle");
	private final String contactUsURL = oglPagesProperties.getProperty("contactUsURL");
	private final String contactUsTitle = oglPagesProperties.getProperty("contactUsTitle");
	private final String oncoguardLiverTestOrdersAndResultsURL = oglPagesProperties
			.getProperty("oncoguardLiverTestOrdersAndResultsURL");
	private final String orderingResultsReportingEasyTitle = oglPagesProperties
			.getProperty("orderingResultsReportingEasyTitle");
	private final String convenientOrderingProcessesWorkflowTitle = oglPagesProperties
			.getProperty("convenientOrderingProcessesWorkflowTitle");
	private final String oncoguardLiverTestResultsTitle = oglPagesProperties
			.getProperty("oncoguardLiverTestResultsTitle");
	private final String epicCareLinkURL = oglPagesProperties.getProperty("epicCareLinkURL");
	private final String theResoucePageLinkURL = oglPagesProperties.getProperty("theResoucePageLinkURL");
	private final String seeOrderSuppliesSectionLinkURL = oglPagesProperties
			.getProperty("seeOrderSuppliesSectionLinkURL");
	private final String oncoguardLiverTestInsuranceAndBillingURL = oglPagesProperties
			.getProperty("oncoguardLiverTestInsuranceAndBillingURL");
	private final String expandingCoverageFinancialSupportTitle = oglPagesProperties
			.getProperty("expandingCoverageFinancialSupportTitle");
	private final String patientEngagementProgramURL = oglPagesProperties.getProperty("patientEngagementProgramURL");
	private final String promotingSurveillanceAdherenceTitle = oglPagesProperties
			.getProperty("promotingSurveillanceAdherenceTitle");
	private final String advocacyURL = oglPagesProperties.getProperty("advocacyURL");
	private final String resources = oglPagesProperties.getProperty("resources");
	private final String aboutUsURL = oglPagesProperties.getProperty("aboutUsURL");
	private final String pursuingHccDetectionTitle = oglPagesProperties.getProperty("pursuingHccDetectionTitle");
	private final String faqURL = oglPagesProperties.getProperty("faqURL");
	private final String answeringFrequentlyQuestionsTitle = oglPagesProperties
			.getProperty("answeringFrequentlyQuestionsTitle");
	private final String searchString = oglPagesProperties.getProperty("searchString");
	private final String specificSearchResultString = oglPagesProperties.getProperty("specificSearchResultString");
	private final String convenientOrderingProcesses = oglPagesProperties.getProperty("convenientOrderingProcesses");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglProvidersHeaderTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of Provider Header Components of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");

		oglHomepage.hoverTopNavOption(providers);
		verifySafely(oglHomepage.isSubItemDisplayed(overview), true,
				"Sub item '" + overview + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(theOncoguardLiverTest), true,
				"Sub item '" + theOncoguardLiverTest + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(clinicalPerformance), true,
				"Sub item '" + clinicalPerformance + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(scientificRigor), true,
				"Sub item '" + scientificRigor + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(addingToTheWorkflow), true,
				"Sub item '" + addingToTheWorkflow + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(ordersAndResults), true,
				"Sub item '" + ordersAndResults + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(insuranceAndBilling), true,
				"Sub item '" + insuranceAndBilling + "' is displayed under '" + providers + "' header");

		verifySafely(oglHomepage.isSubItemDisplayed(patientEngagementProgram), true,
				"Sub item '" + patientEngagementProgram + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(advocacy), true,
				"Sub item '" + advocacy + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(aboutUs), true,
				"Sub item '" + aboutUs + "' is displayed under '" + providers + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(faqs), true,
				"Sub item '" + faqs + "' is displayed under '" + providers + "' header");

		oglHomepage.clickTopNavOption(overview);
		verifySafely(driver.getURL(), overviewURL, "'Healthcare Provider Overview' Page is displayed");
		verifySafely(oglHomepage.isHeaderOptionDisplayed(overview), true, "Sub Menu option '" + overview
				+ "' is highlighted and underlined in the header section and left navigation list present on page");

		verifySafely(oglOverviewPage.isBannerItemDisplayed(advancedPerformanceYouCanRelyOn), true,
				"Icon Card '" + advancedPerformanceYouCanRelyOn + "' is displayed under 'Jump to a section:' banner");
		verifySafely(oglOverviewPage.isBannerItemDisplayed(innovationWithoutInconvenience), true,
				"Icon Card '" + innovationWithoutInconvenience + "' is displayed under 'Jump to a section:' banner");
		verifySafely(oglOverviewPage.isBannerItemDisplayed(supportDrivesAdherence), true,
				"Icon Card '" + supportDrivesAdherence + "' is displayed under 'Jump to a section:' banner");

		driver.refresh();
		oglOverviewPage.clickBannerItemOverviewPage(advancedPerformanceYouCanRelyOn);
		verifySafely(oglOverviewPage.getAdvancedPerformanceYouCanRelyOnHeading(), advancedPerformanceYouCanRelyOn,
				"'Advanced performance you can rely on' Title is displayed on same page.");

		oglOverviewPage.clickBannerItemOverviewPage(innovationWithoutInconvenience);

		verifySafely(oglOverviewPage.getInnovationWithoutInconvenienceHeading(), innovationWithoutInconvenience,
				"'Innovation Without Inconvenience' Title is displayed on same page.");

		oglOverviewPage.clickBannerItemOverviewPage(supportDrivesAdherence);

		verifySafely(oglOverviewPage.getSupportDrivesAdherenceHeading(), supportDrivesAdherence,
				"'Support that drives adherence' Title is displayed on same page.");

		driver.refresh();
		oglOverviewPage.clickOnLearnMoreUnderOncoguardSolution();
		verifySafely(driver.getURL(), oncoguardLiverTestURL, "'Oncoguard Liver Test' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), hccTestingPatientsTitle,
				"'HCC testing that works for more patients' Title is displayed on Page");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(theOncoguardLiverTest);

		verifySafely(driver.getURL(), oncoguardLiverTestURL, "'Oncoguard Liver Test' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), hccTestingPatientsTitle,
				"'HCC testing that works for more patients' Title is displayed on Page");

		driver.refresh();
		oglOverviewPage.clickOnLearnMoreUnderOncoguardSolution();
		verifySafely(driver.getURL(), oncoguardLiverTestClinicalPerformanceURL,
				"'Clinical Performance' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), deliveringHighDegreeHCCDetectionTitle,
				"'Delivering a high degree of sensitivity for HCC detection' Title is displayed on Page");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(clinicalPerformance);

		verifySafely(driver.getURL(), oncoguardLiverTestClinicalPerformanceURL,
				"'Clinical Performance' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), deliveringHighDegreeHCCDetectionTitle,
				"'Delivering a high degree of sensitivity for HCC detection' Title is displayed on Page");

		oglClinicalPerformancePage.clickLearnMoreAboutClinicalTrialsButton();
		logInfo("Clicked on 'LEARN MORE' button under 'Ongoing clinical trials' title.'");
		verifySafely(oglHomepage.isHeaderOptionDisplayed(contactUs), true,
				"Header option '" + contactUs + "' is underlined in the header section of the page");
		verifySafely(oglContactUsPage.getContactUsProvidersOnly(), contactUsProvidersOnlyTitle,
				"'Contact Us (providers only)' Title is present under 'CONTACT US' page");
		verifySafely(oglContactUsPage.isContactUsProvidersOnlyCardDisplayed(), true,
				"'Contact Us (providers only)' card is present under 'CONTACT US' page");
		driver.back();

		oglOverviewPage.clickOnLearnMoreUnderOncoguardSolution();
		verifySafely(driver.getURL(), oncoguardLiverTestScientificRigorURL, "'Scientific Rigor' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), targetingUnmetNeedTitle,
				"'Targeting an unmet need' Title is displayed on Page");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(scientificRigor);
		verifySafely(driver.getURL(), oncoguardLiverTestScientificRigorURL, "'Scientific Rigor' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), targetingUnmetNeedTitle,
				"'Targeting an unmet need' Title is displayed on Page");

		oglClinicalPerformancePage.clickLearnMoreAboutClinicalTrialsButton();
		logInfo("Clicked on 'LEARN MORE' link under this page.'");
		verifySafely(driver.getURL(), oncoguardLiverTestClinicalPerformanceURL,
				"'Clinical Performance' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), deliveringHighDegreeHCCDetectionTitle,
				"'Delivering a high degree of sensitivity for HCC detection' Title is displayed on Page");
		driver.back();

		oglScientificRigorPage.clickOnLearnMoreUnderOncoguardSolution();
		verifySafely(driver.getURL(), oncoguardLiverTestAddingWorkflowURL,
				"'Adding to the Workflow' Page is displayed");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(addingToTheWorkflow);
		verifySafely(driver.getURL(), oncoguardLiverTestAddingWorkflowURL,
				"'Adding to the Workflow' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), streamliningApproachHCCTestingTitle,
				"'Streamlining your approach to HCC testing' Title is displayed on Page");

		verifySafely(oglAddingToWorkflowPage.isPhoneLinkUnderLetUsHelpTitleDisplayed(), true,
				"'The Phone number '1-844-870-8870' link under 'Let us help you get started' title is displayed on Page");

		oglAddingToWorkflowPage.clickOnFillFormLink();
		verifySafely(driver.getURL(), contactUsURL, "'Contact Us' page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), contactUsTitle,
				"'Contact Us' Title is displayed on Page");
		driver.back();
		oglOverviewPage.clickOnLearnMoreUnderOncoguardSolution();
		verifySafely(driver.getURL(), oncoguardLiverTestOrdersAndResultsURL, "'Orders & Results' Page is displayed");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(ordersAndResults);
		verifySafely(driver.getURL(), oncoguardLiverTestOrdersAndResultsURL, "'Orders & Results' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), orderingResultsReportingEasyTitle,
				"'Ordering and results reporting made easy' Title is displayed on Page");

		driver.refresh();
		oglOverviewPage.clickBannerItemOverviewPage(convenientOrderingProcesses);
		verifySafely(oglOrdersAndResultsPage.getConvenientOrderingProcessesWorkflowHeading(),
				convenientOrderingProcessesWorkflowTitle,
				"'Convenient ordering processes that work with your workflow' content is displayed on same page");
		driver.refresh();
		oglOrdersAndResultsPage.clickOnOncoguarLiverTestResultsIconCard();
		verifySafely(oglOrdersAndResultsPage.getOncoguardLiverTestResultsHeading(), oncoguardLiverTestResultsTitle,
				"'Oncoguard® Liver test results' content is displayed on same page.");

		driver.refresh();
		oglOrdersAndResultsPage.clickOnOrderingWithRequisitionFormLink();
		verifySafely(oglOrdersAndResultsPage.isAccordionContentExpanded(0), true,
				"Content is displayed as expanded and (-) sign is replaced with (+) sign.");

		oglOrdersAndResultsPage.clickOnOrderingThroughEpicCareLink();
		verifySafely(oglOrdersAndResultsPage.isAccordionContentExpanded(1), true,
				"Content is displayed as expanded and (-) sign is replaced with (+) sign.");

		oglOrdersAndResultsPage.clickOnEpicCareLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), epicCareLinkURL, "'Epic Care Link' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglOrdersAndResultsPage.clickOnTheResoucePageLink();
		verifySafely(driver.getURL(), theResoucePageLinkURL, "'The Resouce Page' Link is displayed");
		driver.back();

		oglOrdersAndResultsPage.clickOnSeeOrderSuppliesSectionLink();
		verifySafely(driver.getURL(), seeOrderSuppliesSectionLinkURL,
				"'See the Order Supplies section for more details'Link is displayed");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(insuranceAndBilling);
		verifySafely(driver.getURL(), oncoguardLiverTestInsuranceAndBillingURL,
				"'Insurance & Billing' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), expandingCoverageFinancialSupportTitle,
				"'Expanding coverage and financial support' Title is displayed on Page");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(patientEngagementProgram);
		verifySafely(driver.getURL(), patientEngagementProgramURL, "'Patient Engagement Program' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), promotingSurveillanceAdherenceTitle,
				"'Promoting surveillance adherence' Title is displayed on Page");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(advocacy);
		verifySafely(driver.getURL(), advocacyURL, "'Advocacy' Page is displayed");
		verifySafely(oglHomepage.isHeaderOptionDisplayed(resources), true,
				"Header option '" + resources + "' is underlined in the header section of the page");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(aboutUs);
		verifySafely(driver.getURL(), aboutUsURL, "'About Us' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pursuingHccDetectionTitle,
				"'Pursuing earlier HCC detection' Title is displayed on Page");

		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(faqs);
		verifySafely(driver.getURL(), faqURL, "'FAQs' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), answeringFrequentlyQuestionsTitle,
				"'Answering your frequently asked questions' Title is displayed on Page");

		oglFAQsPage.enterInputInSearchBox(searchString);
		verifySafely(oglFAQsPage.getFirstSearchResult().contains(specificSearchResultString), true,
				"Search results are displayed according to the searched text");

		oglFAQsPage.clickOpenAllQuestions();
		verifySafely(oglFAQsPage.areAllQuestionsExpanded(), true,
				"All questions are now expanded and (+) sign gets replaced with (-) sign.");

		oglFAQsPage.clickCloseAllQuestions();
		verifySafely(oglFAQsPage.areAllQuestionsCollapsed(), true,
				"All questions are now collapsed and (-) sign gets replaced with (+) sign.");

		oglFAQsPage.expandAllAccordionsOneByOne();
		logInfo("Clicked on + sign next to field headings");
		verifySafely(oglFAQsPage.areAllQuestionsExpanded(), true,
				"All questions are now expanded one by one  and (+) sign gets replaced with (-) sign");

		oglFAQsPage.collapseAllAccordionsOneByOne();
		logInfo("Clicked on - sign next to field headings");
		verifySafely(oglFAQsPage.areAllQuestionsCollapsed(), true,
				"All questions are now collapsed one by one  and (-) sign gets replaced with (+) sign");
		logInfo("----------------Verification done for Provider Header Components of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();

	}

}
