package exact.ath.sitecore.csr;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.ath.sitecore.CsrWebsite;

/**
 * @author pusingh
 *
 */
public class CsrCiAndCrPageTest extends BasicIntTest {

	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final CorporateWebsite corporateWebsite = new CorporateWebsite();

	private final CsrWebsite csrWebsite = new CsrWebsite();

	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CorporateWebsiteTitleValue");

	private final String loginUrl = exactPagesProperties.getProperty("CsrWebURL");
	private final String forGrantSubmissionURL = exactPagesProperties.getProperty("ForGrantSubmissionURL");
	private final String forEventSponsorshipURL = exactPagesProperties.getProperty("ForEventSponsorshipURL");
	private final String pageESGURL = exactPagesProperties.getProperty("PageESGURL");
	private final String csrCiAndCrIconTittles = exactPagesProperties.getProperty("CsrCiAndCrIconCardTittles");
	private final String communityRelationsPageURL = exactPagesProperties.getProperty("CommunityRelationsPageURL");
	private final String levelingCancerCarePlayingFieldArizonaPageURL = exactPagesProperties
			.getProperty("LevelingCancerCarePlayingFieldArizonaPageURL");
	private final String csrLtCCPFiACardTittles = exactPagesProperties.getProperty("CsrLtCCPFiACardTittles");
	private final String csrLtCCPFiACardFullTittles = exactPagesProperties.getProperty("CsrLtCCPFiACardFullTittles");
	private int viewCount = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void csrCiAndCrPageTest() {

		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");
		verifySafely(corporateWebsite.isExactSciencesLogoDisplayed(), true,
				"'EXACT SCIENCES' logo is displayed on the page");
		verifySafely(csrWebsite.isCsrCtoECHeaderDisplayed(), true,
				"'Commitment to Eradicate Cancer' item is displayed in header section on the page");
		verifySafely(csrWebsite.isCsrCommunityEngagementHeaderDisplayed(), true,
				"'Community Engagement' item is displayed in header section on the page");
		verifySafely(csrWebsite.isCsrSustainabilityHeaderDisplayed(), true,
				"'Sustainability' item is displayed in header section on the page");

		corporateWebsite.clickExactSciencesLogo();
		logInfo("Clicked on 'EXACT SCIENCES' Logo");
		logInfo("Page URL : " + getPageURL() + "");
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - title");
		driver.back();
		logInfo("Navigated back to Page URL : " + getPageURL() + "");
		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");

		verifySafely(csrWebsite.isUSRequestsClickHereButtonDisplayed(), true,
				"'U.S. REQUESTS CLICK HERE' button is displayed on the page");
		verifySafely(csrWebsite.isOutsideUSRequestsClickHereButtonDisplayed(), true,
				"'OUTSIDE U.S. REQUESTS CLICK HERE' button is displayed on the page");
		csrWebsite.clickUSRequestsClickHereButton();
		logInfo("Clicked on 'U.S. REQUESTS CLICK HERE' button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), forGrantSubmissionURL, "'US REQUESTS CLICK HERE' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		csrWebsite.clickOutsideUSRequestsClickHereButton();
		logInfo("Clicked on 'OUTSIDE U.S. REQUESTS CLICK HERE' button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), forEventSponsorshipURL, "'OUTSIDE US REQUESTS CLICK HERE' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		csrWebsite.clickInvestorRelationsCorporateGovernanceSustainabilityLink();
		logInfo("Clicked on 'Exact Sciences Investor Relations - Corporate Governance and Sustainability' link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(pageESGURL), true,
				"'Exact Sciences Investor Relations - Corporate Governance and Sustainability Link' Page URL contains VALUE: '"
						+ pageESGURL + "'");

		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		logInfo("Verification of 'Corporate Impact and Community Relations' page Icon cards");
		for (String csrCiAndCrIconCardTittle : csrCiAndCrIconTittles.split(",")) {
			viewCount++;
			for (int i = 3; i < viewCount; i++) {
				corporateWebsite.clickNextArrowSign();
			}
			verifySafely(csrWebsite.getCsrCiAndCrIconCardTittle(viewCount).contains(csrCiAndCrIconCardTittle), true,
					"Icon Card under 'RECENT POSTS'- Tittle VALUE: '"
							+ csrWebsite.getCsrCiAndCrIconCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCiAndCrIconCardTittle(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrCiAndCrIconCardTittle), true,
					"Opened Icon Card Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		csrWebsite.clickCsrViewAllPostsLink();
		logInfo("Clicked on 'VIEW ALL POSTS' button");
		verifySafely(driver.getURL(), communityRelationsPageURL, "'VIEW ALL POSTS' Navigates to Page URL matches");

		csrWebsite.clickReadMore();
		logInfo("Clicked on 'READ MORE' button");
		verifySafely(driver.getURL(), levelingCancerCarePlayingFieldArizonaPageURL,
				"'Leveling the Cancer Care Playing Field in Arizona' Page URL matches");
		driver.back();
		verifySafely(driver.getURL(), communityRelationsPageURL, "Navigated back to Page URL matches");

		closeTheBrowser();
		setupURL(communityRelationsPageURL);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		logInfo("Verification of 'VIEW ALL POSTS' page Icon cards");
		viewCount = 1;
		for (String csrLtCCPFiACardTittle : csrLtCCPFiACardTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrLtCCPFiACardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrLtCCPFiACardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		csrWebsite.clickSeeMoreEntries();
		logInfo("Clicked on 'SEE MORE ENTRIES' button");
		verifySafely(csrWebsite.isJumpLink1Highlighted(), true, "'Jump Link 1' is displayed highlighted on the page");

		logInfo("Verification of Icon cards");
		viewCount = 0;
		for (String csrLtCCPFiACardFullTittle : csrLtCCPFiACardFullTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrLtCCPFiACardFullTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrLtCCPFiACardFullTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();
			if (viewCount == 4) {
				String recentURL = getPageURL();
				closeTheBrowser();
				setupURL(recentURL);
				logInfo("Page URL : " + getPageURL() + "");
				if (annualReportsPage.acceptCookiesDisplayed()) {
					annualReportsPage.acceptCookies();
				}
			}

		}

		csrWebsite.clickJumpLink2();
		logInfo("Clicked on 'Jump Link 2'");
		verifySafely(csrWebsite.isJumpLink2Highlighted(), true, "'Jump Link 2' is displayed highlighted on the page");

		csrWebsite.clickJumpLink3();
		logInfo("Clicked on 'Jump Link 3'");
		verifySafely(csrWebsite.isJumpLink3Highlighted(), true, "'Jump Link 3' is displayed highlighted on the page");

		csrWebsite.clickJumpLink4();
		logInfo("Clicked on 'Jump Link 4'");
		verifySafely(csrWebsite.isJumpLink4Highlighted(), true, "'Jump Link 4' is displayed highlighted on the page");

		csrWebsite.clickJumpLink5();
		logInfo("Clicked on 'Jump Link 5'");
		verifySafely(csrWebsite.isJumpLink5Highlighted(), true, "'Jump Link 5' is displayed highlighted on the page");

		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
