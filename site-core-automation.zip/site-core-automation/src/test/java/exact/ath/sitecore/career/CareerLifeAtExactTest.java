package exact.ath.sitecore.career;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CareerWebsite;
import exact.sys.Driver;

/**
 * This class verifies Career Website Life At Exact page verifications
 * 
 * @userstory #301264 Task#303947
 * @author qas_tgupta
 * @since 04/28/2023
 */

public class CareerLifeAtExactTest extends BasicIntTest {

	private final CareerWebsite careerWebsite = new CareerWebsite();
	private final Driver driver = new Driver();
	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CareerWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CareerWebURL");
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final String lifeAtExactSciencesTitle = exactPagesProperties.getProperty("LifeAtExactSciencesTitle");
	private final String sharingRespectTitle = exactPagesProperties.getProperty("SharingRespectTitle");
	private final String fosteringTogethernessTitle = exactPagesProperties.getProperty("FosteringTogethernessTitle");
	private final String developingPeopleTitle = exactPagesProperties.getProperty("DevelopingPeopleTitle");
	private final String employeeRecognitionTitle = exactPagesProperties.getProperty("EmployeeRecognitionTitle");
	private final String exactSciencesWorkplacesTitle = exactPagesProperties
			.getProperty("ExactSciencesWorkplacesTitle");
	private final String viewOurProfileLinkURL = exactPagesProperties.getProperty("ViewOurProfileLinkURL");

	private final String volunteerTimeOffTitle = exactPagesProperties.getProperty("VolunteerTimeOffTitle");
	private final String unitedWayCampaignTitle = exactPagesProperties.getProperty("UnitedWayCampaignTitle");
	private final String communityCommitteeTitle = exactPagesProperties.getProperty("CommunityCommitteeTitle");

	private final String fitnessClassesTitle = exactPagesProperties.getProperty("FitnessClassesTitle");
	private final String ourFoodPhilosophyTitle = exactPagesProperties.getProperty("OurFoodPhilosophyTitle");
	private final String wellnessPointsProgramTitle = exactPagesProperties.getProperty("WellnessPointsProgramTitle");
	private final String careComTitle = exactPagesProperties.getProperty("CareComTitle");
	private final String fitnessReimbursementTitle = exactPagesProperties.getProperty("FitnessReimbursementTitle");
	private final String hydroponicFarmTitle = exactPagesProperties.getProperty("HydroponicFarmTitle");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void careerLifeAtExactTest() {
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		logInfo("----------------Starting verification of Life At Exact Tab present in Header Section of Career Website------------");
		verifySafely(careerWebsite.getCareerWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Heading");
		verifySafely(careerWebsite.isHeaderSectionDisplayed(), true, "'Header Section' is displayed on the page");
		verifySafely(careerWebsite.isPageTitleDisplayed(), true,
				"'Home Page tittle - CHANGE CAREERS.CHANGE LIVES.' is displayed on the page");
		careerWebsite.clickLifeAtExactTab();
		logInfo("Clicked on 'Life At Exact' Tab from the Header section");
		verifySafely(careerWebsite.getLifeAtExactSciences(), lifeAtExactSciencesTitle,
				"'LIFE AT EXACT SCIENCES' Title is displayed after clicking Life At Exact  tab from the header section");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Life At Exact' Tab in the header section is highlighted in blue color");
		logInfo("----------------Starting verification of Cards present under 'COMMITMENT TO PEOPLE' title------------");
		verifySafely(careerWebsite.getSharingRespect(), sharingRespectTitle,
				"'SHARING RESPECT' Title icon card is visible under 'COMMITMENT TO PEOPLE' title");
		verifySafely(careerWebsite.getFosteringTogetherness(), fosteringTogethernessTitle,
				"'FOSTERING TOGETHERNESS' Title icon card is visible under 'COMMITMENT TO PEOPLE' title");
		verifySafely(careerWebsite.getDevelopingPeople(), developingPeopleTitle,
				"'DEVELOPING PEOPLE' Title icon card is visible under 'COMMITMENT TO PEOPLE' title");
		careerWebsite.clickForwardSlickArrow(0);
		logInfo("Clicked on Forward Slick Arrow Next to 'DEVELOPING PEOPLE' card");
		verifySafely(careerWebsite.getEmployeeRecognition(), employeeRecognitionTitle,
				"'EMPLOYEE RECOGNITION' Title icon card is visible under 'COMMITMENT TO PEOPLE' title");
		logInfo("----------------Verification Done For Cards present under 'COMMITMENT TO PEOPLE' title------------");
		careerWebsite.clickGreatPlaceToWork();
		logInfo("Clicked on 'Great Place To Work' link from 'EMPLOYEE RECOGNITION' card");
		driver.switchToCurrentWindow();
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		verifySafely(careerWebsite.getExactSciencesWorkplaces(), exactSciencesWorkplacesTitle,
				"'Exact Sciences Named One of the 2021 Best Workplaces in Health Care & Biopharma™' Title is displayed after clicking on Great Place To Work link from EMPLOYEE RECOGNITION card.");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		careerWebsite.clickViewOurProfile();
		logInfo("Clicked on 'TheMuse.com' link or 'VIEW OUR PROFILE' button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), viewOurProfileLinkURL, "Opened Profile Link' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Starting verification of Cards present  under 'COMMUNITY INVOLVEMENT' title------------");
		verifySafely(careerWebsite.getVolunteerTimeOff(), volunteerTimeOffTitle,
				"'VOLUNTEER TIME OFF' Title icon card is visible under 'COMMUNITY INVOLVEMENT' title");
		verifySafely(careerWebsite.getUnitedWayCampaign(), unitedWayCampaignTitle,
				"'UNITED WAY CAMPAIGN' Title icon card is visible under 'COMMUNITY INVOLVEMENT' title");
		verifySafely(careerWebsite.getCommunityCommittee(), communityCommitteeTitle,
				"'COMMUNITY COMMITTEE' Title icon card is visible under 'COMMUNITY INVOLVEMENT' title");
		logInfo("----------------Verification Done For Cards present under 'COMMUNITY INVOLVEMENT' title------------");
		careerWebsite.clickCorporateSocialResponsibility();
		logInfo("Clicked on 'Corporate Social Responsibility page' link below Icon cards");
		driver.switchToCurrentWindow();
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Corporate Impact and Community Relations' Tab in the header section is highlighted in blue color");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Starting verification of Cards present  under 'WELLNESS' title------------");
		verifySafely(careerWebsite.getFitnessClasses(), fitnessClassesTitle,
				"'FITNESS CLASSES' Title icon card is visible under 'WELLNESS' title");
		verifySafely(careerWebsite.getOurFoodPhilosophy(), ourFoodPhilosophyTitle,
				"'OUR FOOD PHILOSOPHY' Title icon card is visible under 'WELLNESS' title");
		verifySafely(careerWebsite.getWellnessPointsProgram(), wellnessPointsProgramTitle,
				"'WELLNESS POINTS PROGRAM' Title icon card is visible under 'WELLNESS' title");
		careerWebsite.clickForwardSlickArrow(1);
		logInfo("Clicked on Slick Next Arrow");
		verifySafely(careerWebsite.getCareCom(), careComTitle,
				"'CARE.COM' Title icon card is visible under 'WELLNESS' title");
		careerWebsite.clickForwardSlickArrow(1);
		logInfo("Clicked on Slick Next Arrow");
		verifySafely(careerWebsite.getFitnessReimbursement(), fitnessReimbursementTitle,
				"'FITNESS REIMBURSEMENT' Title icon card is visible under 'WELLNESS' title");
		careerWebsite.clickForwardSlickArrow(1);
		logInfo("Clicked on Slick Next Arrow");
		verifySafely(careerWebsite.getHydroponicFarm(), hydroponicFarmTitle,
				"'HYDROPONIC FARM' Title icon card is visible under 'WELLNESS' title");

		logInfo("----------------Verification Done For Cards present under 'WELLNESS' title------------");
		logInfo("----------------Verification Done For Life At Exact Tab present in Header Section of Career Website------------");

		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}

}
