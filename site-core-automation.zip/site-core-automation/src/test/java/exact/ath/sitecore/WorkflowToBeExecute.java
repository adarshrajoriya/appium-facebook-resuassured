package exact.ath.sitecore;

import static exact.ReportLogMain.logError;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import exact.ath.sitecore.annualReport.AnnualReportsPageTest;
import exact.ath.sitecore.career.CareerBenefitsTest;
import exact.ath.sitecore.career.CareerCurrentOpeningsTest;
import exact.ath.sitecore.career.CareerFooterTest;
import exact.ath.sitecore.career.CareerHomePageTest;
import exact.ath.sitecore.career.CareerLifeAtExactTest;
import exact.ath.sitecore.career.CareerLocationsTest;
import exact.ath.sitecore.career.CareerVideoTest;
import exact.ath.sitecore.career.CareerWhyExactSciencesTest;
import exact.ath.sitecore.cologuard.AboutScreeningTest;
import exact.ath.sitecore.cologuard.CGAffordablePageTest;
import exact.ath.sitecore.cologuard.CGEffectiveAndEasyPageTest;
import exact.ath.sitecore.cologuard.CGFAQsPageTest;
import exact.ath.sitecore.cologuard.CGStartScreeningAt45PageTest;
import exact.ath.sitecore.cologuard.CGUseCologuardTest;
import exact.ath.sitecore.cologuard.CollectingAndReturningYourSamplesTest;
import exact.ath.sitecore.cologuard.CologuardHomepageVerificationsTest;
import exact.ath.sitecore.cologuard.CologuardInsuranceAndBillingTest;
import exact.ath.sitecore.cologuard.CologuardVideoTest;
import exact.ath.sitecore.cologuard.HowToGetCologuardTest;
import exact.ath.sitecore.cologuard.WhyCologuardTest;
import exact.ath.sitecore.corporate.CorporateAboutPageTest;
import exact.ath.sitecore.corporate.CorporateFooterTest;
import exact.ath.sitecore.corporate.CorporateHomePageTest;
import exact.ath.sitecore.corporate.CorporateNewsroomPageTest;
import exact.ath.sitecore.corporate.CorporateOurTestsPageTest;
import exact.ath.sitecore.corporate.CorporatePipelineDataPageTest;
import exact.ath.sitecore.corporate.CorporateVideoTest;
import exact.ath.sitecore.corporateUk.CorporateUkAboutUsPageTest;
import exact.ath.sitecore.corporateUk.CorporateUkFooterTest;
import exact.ath.sitecore.corporateUk.CorporateUkHomePageVerificationsTest;
import exact.ath.sitecore.corporateUk.CorporateUkOurProductPageTest;
import exact.ath.sitecore.corporateUk.CorporateUkPressRoomPageTest;
import exact.ath.sitecore.csr.CsrCiAndCrPageTest;
import exact.ath.sitecore.csr.CsrCmnEngPageTest;
import exact.ath.sitecore.csr.CsrCtoECPageTest;
import exact.ath.sitecore.csr.CsrFooterTest;
import exact.ath.sitecore.csr.CsrSustainabilityPageTest;
import exact.ath.sitecore.csr.CsrVideoTest;
import exact.ath.sitecore.labs.LabsAboutPageTest;
import exact.ath.sitecore.labs.LabsClientPageTest;
import exact.ath.sitecore.labs.LabsFooterTest;
import exact.ath.sitecore.labs.LabsHomePageTest;
import exact.ath.sitecore.labs.LabsQualityPageTest;
import exact.ath.sitecore.ogl.OglContactUsPageTest;
import exact.ath.sitecore.ogl.OglEducationPageTest;
import exact.ath.sitecore.ogl.OglFooterTest;
import exact.ath.sitecore.ogl.OglHomePageVerificationsTest;
import exact.ath.sitecore.ogl.OglPatientsHeaderTest;
import exact.ath.sitecore.ogl.OglProvidersHeaderTest;
import exact.ath.sitecore.ogl.OglResourcePageTest;
import exact.ath.sitecore.ogl.OglVideoTest;
import exact.ath.sitecore.oiq.deDE.OiqDEFachkreiseHeaderTest;
import exact.ath.sitecore.oiq.deDE.OiqDEFooterTest;
import exact.ath.sitecore.oiq.deDE.OiqDEKontaktHeaderTest;
import exact.ath.sitecore.oiq.deDE.OiqDEPatientenHeaderTest;
import exact.ath.sitecore.oiq.deDE.OiqDEPresseinformationenHeaderTest;
import exact.ath.sitecore.oiq.deDE.OiqDEVideoTest;
import exact.ath.sitecore.oiq.enCH.OiqCHContactUsPageTest;
import exact.ath.sitecore.oiq.enCH.OiqCHFrenchPageTest;
import exact.ath.sitecore.oiq.enCH.OiqCHGermanPageTest;
import exact.ath.sitecore.oiq.enCH.OiqCHHomePageTest;
import exact.ath.sitecore.oiq.enCH.OiqCHReimbursementPageTest;
import exact.ath.sitecore.productsite.ProductsiteAboutUsVerificationsTest;
import exact.ath.sitecore.productsite.ProductsiteBillingAndCoverageVerificationsTest;
import exact.ath.sitecore.productsite.ProductsiteContactUsVerificationsTest;
import exact.ath.sitecore.productsite.ProductsiteFooterVerificationsTest;
import exact.ath.sitecore.productsite.ProductsiteHealthcareProvidersSectionVerificationsTest;
import exact.ath.sitecore.productsite.ProductsiteHomepageVerificationsTest;
import exact.ath.sitecore.productsite.ProductsitePatientsAndCaregiversSectionVerificationsTest;
import exact.ath.sitecore.productsite.ProductsiteVideoVerificationsTest;

/**
 * @author pusingh
 * 
 *         Depends on parameters it execute the cases.
 *
 */
public class WorkflowToBeExecute {

	// String testCasesNumber = System.getProperty("testCasesValue");
	private final AnnualReportsPageTest annualReportsPageTest = new AnnualReportsPageTest();
	private final CorporateHomePageTest corporateHomePageTest = new CorporateHomePageTest();
	private final CorporateAboutPageTest corporateAboutPageTest = new CorporateAboutPageTest();
	private final CorporateNewsroomPageTest corporateNewsroomPageTest = new CorporateNewsroomPageTest();
	private final CorporatePipelineDataPageTest corporatePipelineDataPageTest = new CorporatePipelineDataPageTest();
	private final CorporateFooterTest corporateFooterTest = new CorporateFooterTest();
	private final CorporateOurTestsPageTest corporateOurTestsPageTest = new CorporateOurTestsPageTest();
	private final CorporateVideoTest corporateVideoTest = new CorporateVideoTest();
	private final CsrCtoECPageTest csrCtoECPageTest = new CsrCtoECPageTest();
	private final CsrCiAndCrPageTest csrCiAndCrPageTest = new CsrCiAndCrPageTest();
	private final CsrCmnEngPageTest csrCmnEngPageTest = new CsrCmnEngPageTest();
	private final CsrSustainabilityPageTest csrSustainabilityPageTest = new CsrSustainabilityPageTest();
	private final CsrFooterTest csrFooterTest = new CsrFooterTest();
	private final CsrVideoTest csrVideoTest = new CsrVideoTest();

	private final CareerHomePageTest careerHomePageTest = new CareerHomePageTest();
	private final CareerWhyExactSciencesTest careerWhyExactSciencesTest = new CareerWhyExactSciencesTest();
	private final CareerLifeAtExactTest careerLifeAtExactTest = new CareerLifeAtExactTest();
	private final CareerLocationsTest careerLocationsTest = new CareerLocationsTest();
	private final CareerBenefitsTest careerBenefitsTest = new CareerBenefitsTest();
	private final CareerCurrentOpeningsTest careerCurrentOpeningsTest = new CareerCurrentOpeningsTest();
	private final CareerFooterTest careerFooterTest = new CareerFooterTest();
	private final CareerVideoTest careerVideoTest = new CareerVideoTest();

	private final CologuardHomepageVerificationsTest cologuardHomepageVerificationsTest = new CologuardHomepageVerificationsTest();
	private final CologuardInsuranceAndBillingTest cologuardInsuranceAndBillingTest = new CologuardInsuranceAndBillingTest();
	private final HowToGetCologuardTest howToGetCologuardTest = new HowToGetCologuardTest();
	private final CGAffordablePageTest cgAffordablePageTest = new CGAffordablePageTest();
	private final CGStartScreeningAt45PageTest cgStartScreeningAt45PageTest = new CGStartScreeningAt45PageTest();
	private final LabsHomePageTest labsHomePageTest = new LabsHomePageTest();
	private final LabsClientPageTest labsClientPageTest = new LabsClientPageTest();
	private final LabsQualityPageTest labsQualityPageTest = new LabsQualityPageTest();
	private final LabsAboutPageTest labsAboutPageTest = new LabsAboutPageTest();
	private final LabsFooterTest labsFooterTest = new LabsFooterTest();
	private final AboutScreeningTest aboutScreeningTest = new AboutScreeningTest();
	private final CGFAQsPageTest cgFAQsPageTest = new CGFAQsPageTest();
	private final CGEffectiveAndEasyPageTest cgEffectiveAndEasyPageTest = new CGEffectiveAndEasyPageTest();
	private final CollectingAndReturningYourSamplesTest collectingAndReturningYourSamplesTest = new CollectingAndReturningYourSamplesTest();
	private final WhyCologuardTest whyCologuardTest = new WhyCologuardTest();
	private final CologuardVideoTest cologuardVideoTest = new CologuardVideoTest();
	private final CGUseCologuardTest cgUseCologuardTest = new CGUseCologuardTest();
	private final OiqCHHomePageTest oiqCHHomePageTest = new OiqCHHomePageTest();
	private final OiqCHFrenchPageTest oiqCHFrenchPageTest = new OiqCHFrenchPageTest();
	private final OiqCHGermanPageTest oiqCHGermanPageTest = new OiqCHGermanPageTest();
	private final OiqCHReimbursementPageTest oiqCHReimbursementPageTest = new OiqCHReimbursementPageTest();
	private final OiqCHContactUsPageTest oiqCHContactUsPageTest = new OiqCHContactUsPageTest();
	private final OiqDEFachkreiseHeaderTest oiqDEFachkreiseHeaderTest = new OiqDEFachkreiseHeaderTest();
	private final OiqDEPatientenHeaderTest oiqDEPatientenHeaderTest = new OiqDEPatientenHeaderTest();
	private final OiqDEPresseinformationenHeaderTest oiqDEPresseinformationenHeaderTest = new OiqDEPresseinformationenHeaderTest();
	private final OiqDEKontaktHeaderTest oiqDEKontaktHeaderTest = new OiqDEKontaktHeaderTest();
	private final OiqDEFooterTest oiqDEFooterTest = new OiqDEFooterTest();
	private final OiqDEVideoTest oiqDEVideoTest = new OiqDEVideoTest();

	private final CorporateUkHomePageVerificationsTest corporateUkHomePageVerificationsTest = new CorporateUkHomePageVerificationsTest();
	private final CorporateUkAboutUsPageTest corporateUkAboutUsPageTest = new CorporateUkAboutUsPageTest();
	private final CorporateUkOurProductPageTest corporateUkOurProductPageTest = new CorporateUkOurProductPageTest();
	private final CorporateUkPressRoomPageTest corporateUkPressRoomPageTest = new CorporateUkPressRoomPageTest();
	private final CorporateUkFooterTest corporateUkFooterTest = new CorporateUkFooterTest();
	private final ProductsiteHomepageVerificationsTest productsiteHomepageVerificationsTest = new ProductsiteHomepageVerificationsTest();
	private final ProductsiteHealthcareProvidersSectionVerificationsTest productsiteHealthcareProvidersSectionVerificationsTest = new ProductsiteHealthcareProvidersSectionVerificationsTest();
	private final ProductsitePatientsAndCaregiversSectionVerificationsTest productsitePatientsAndCaregiversSectionVerificationsTest = new ProductsitePatientsAndCaregiversSectionVerificationsTest();
	private final ProductsiteBillingAndCoverageVerificationsTest productsiteBillingAndCoverageVerificationsTest = new ProductsiteBillingAndCoverageVerificationsTest();
	private final ProductsiteAboutUsVerificationsTest productsiteAboutUsVerificationsTest = new ProductsiteAboutUsVerificationsTest();
	private final ProductsiteContactUsVerificationsTest productsiteContactUsVerificationsTest = new ProductsiteContactUsVerificationsTest();
	private final ProductsiteFooterVerificationsTest productsiteFooterVerificationsTest = new ProductsiteFooterVerificationsTest();
	private final ProductsiteVideoVerificationsTest productsiteVideoVerificationsTest = new ProductsiteVideoVerificationsTest();

	private final OglHomePageVerificationsTest oglHomePageVerificationsTest = new OglHomePageVerificationsTest();
	private final OglProvidersHeaderTest oglProvidersHeaderTest = new OglProvidersHeaderTest();
	private final OglPatientsHeaderTest oglPatientsHeaderTest = new OglPatientsHeaderTest();
	private final OglEducationPageTest oglEducationPageTest = new OglEducationPageTest();
	private final OglResourcePageTest oglResourcePageTest = new OglResourcePageTest();
	private final OglContactUsPageTest oglContactUsPageTest = new OglContactUsPageTest();
	private final OglFooterTest oglFooterTest = new OglFooterTest();
	private final OglVideoTest oglVideoTest = new OglVideoTest();

	@DataProvider(name = "testCases")
	public Object[] testCases() throws Exception {
		String testCasesNumber = System.getProperty("testCasesValue");
		if (testCasesNumber.contains("CorporateWebsiteTest")) {
			testCasesNumber = testCasesNumber.replace("CorporateWebsiteTest",
					"corporateHomePageTest,corporateAboutPageTest,corporateNewsroomPageTest,corporateOurTestsPageTest,corporatePipelineDataPageTest,corporateVideoTest,corporateFooterTest");
		}
		if (testCasesNumber.contains("CsrWebsiteTest")) {
			testCasesNumber = testCasesNumber.replace("CsrWebsiteTest",
					"CsrCiAndCrPageTest,CsrCtoECPageTest,CsrCmnEngPageTest,CsrSustainabilityPageTest,CsrFooterTest,CsrVideoTest");
		}

		if (testCasesNumber.contains("CareerWebsiteTest")) {
			testCasesNumber = testCasesNumber.replace("CareerWebsiteTest",
					"careerHomePageTest,careerWhyExactSciencesTest,careerLifeAtExactTest,careerLocationsTest,careerBenefitsTest,careerCurrentOpeningsTest,careerFooterTest,careerVideoTest");
		}

		if (testCasesNumber.contains("LabsWebsiteTest")) {
			testCasesNumber = testCasesNumber.replace("LabsWebsiteTest",
					"labsHomePageTest,labsClientPageTest,labsQualityPageTest,labsAboutPageTest,labsFooterTest");
		}

		if (testCasesNumber.contains("OiqSwitzerland")) {
			testCasesNumber = testCasesNumber.replace("OiqSwitzerland",
					"OiqCHHomePageTest,OiqCHFrenchPageTest,OiqCHGermanPageTest,OiqCHReimbursementPageTest,OiqCHContactUsPageTest");
		}

		if (testCasesNumber.contains("CorporateUkWebsiteTest")) {
			testCasesNumber = "CorporateUkHomePageVerificationsTest,CorporateUkAboutUsPageTest,CorporateUkOurProductPageTest,CorporateUkPressRoomPageTest,CorporateUkFooterTest";
			testCasesNumber.replace("CorporateUkWebsiteTest",
					"CorporateUkHomePageVerificationsTest,CorporateUkAboutUsPageTest,CorporateUkOurProductPageTest,CorporateUkPressRoomPageTest,CorporateUkFooterTest");
		}

		if (testCasesNumber.contains("ProductsiteTest")) {
			testCasesNumber = testCasesNumber.replace("ProductsiteTest",
					"ProductsiteHomepageVerificationsTest,ProductsiteHealthcareProvidersSectionVerificationsTest,ProductsitePatientsAndCaregiversSectionVerificationsTest,ProductsiteBillingAndCoverageVerificationsTest,ProductsiteAboutUsVerificationsTest,ProductsiteContactUsVerificationsTest,ProductsiteFooterVerificationsTest,ProductsiteVideoVerificationsTest");
		}
		if (testCasesNumber.contains("OglWebsiteTest")) {
			testCasesNumber = "OglVideoTest,OglHomePageVerificationsTest,OglPatientsHeaderTest,OglEducationPageTest,OglContactUsPageTest,OglProvidersHeaderTest,OglFooterTest,OglResourcePageTest";
			testCasesNumber.replace("OglWebsiteTest",
					"OglVideoTest,OglHomePageVerificationsTest,OglPatientsHeaderTest,OglEducationPageTest,OglContactUsPageTest,OglProvidersHeaderTest,OglFooterTest,OglResourcePageTest");

		}

		String[] useCases = testCasesNumber.split("\\s*,\\s*");
		return useCases;
	}

	@Parameters({ "testCasesValue" })
	@Test(dataProvider = "testCases")
	public void tests(String testCaseNumber) throws Exception {

		// @SuppressWarnings("rawtypes")
		// List<Class> listnerClasses = new ArrayList<Class>();
		//// TestListenerAdapter tla = new
		// TestListenerAdapter();listnerClasses.add(org.uncommons.reportng.HTMLReporter.class);listnerClasses.add(org.uncommons.reportng.JUnitXMLReporter.class);
		// TestNG testng = new TestNG();
		//
		// @SuppressWarnings("rawtypes")
		// Class[] classToExecute = null;

		switch (testCaseNumber) {
		case "All":
			// classToExecute = new Class[] { CorporateWebsiteTest.class };
			// classToExecute = new Class[] { AnnualReportsPageTest.class };
			break;
		case "AnnualReportsPageTest":
			annualReportsPageTest.annualReportsPageTest();
			// classToExecute = new Class[] { AnnualReportsPageTest.class };
			break;
		case "corporateHomePageTest":
			// classToExecute = new Class[] { CorporateWebsiteTest.class };
			corporateHomePageTest.corporateHomePageTest();
			// corporateAboutPageTest.corporateAboutPageTest();
			// corporateNewsroomPageTest.corporateNewsroomPageTest();
			// corporateOurTestsPageTest.corporateOurTestsPageTest();
			// corporatePipelineDataPageTest.corporatePipelineDataPageTest();
			// corporateFooterTest.corporateFooterTest();
			// corporateVideoTest.corporateVideoTest();
			// classToExecute = new Class[] { CorporateVideoTest.class };
			// classToExecute = new Class[] { CorporateFooterTest.class };
			// classToExecute = new Class[] { CorporatePipelineDataPageTest.class };
			// classToExecute = new Class[] { CorporateOurTestsPageTest.class };
			// classToExecute = new Class[] { CorporateNewsroomPageTest.class };
			// classToExecute = new Class[] { CorporateAboutPageTest.class };
			// classToExecute = new Class[] { CorporateHomePageTest.class };
			break;
		case "corporateAboutPageTest":
			corporateAboutPageTest.corporateAboutPageTest();
			break;
		case "corporateNewsroomPageTest":
			corporateNewsroomPageTest.corporateNewsroomPageTest();
			break;
		case "corporateOurTestsPageTest":
			corporateOurTestsPageTest.corporateOurTestsPageTest();
			break;
		case "corporatePipelineDataPageTest":
			corporatePipelineDataPageTest.corporatePipelineDataPageTest();
			break;
		case "corporateVideoTest":
			corporateVideoTest.corporateVideoTest();
			break;
		case "corporateFooterTest":
			corporateFooterTest.corporateFooterTest();
			break;
		case "Cologuard Homepage Test":
			cologuardHomepageVerificationsTest.verifyCologuardHomepageLinksTest();
			break;
		case "CsrCiAndCrPageTest":
			csrCiAndCrPageTest.csrCiAndCrPageTest();
			break;
		case "CsrCtoECPageTest":
			csrCtoECPageTest.csrCtoECPageTest();
			break;
		case "CsrCmnEngPageTest":
			csrCmnEngPageTest.csrCmnEngPageTest();
			break;
		case "CsrSustainabilityPageTest":
			csrSustainabilityPageTest.csrSustainabilityPageTest();
			break;
		case "CsrFooterTest":
			csrFooterTest.csrFooterTest();
			break;
		case "CsrVideoTest":
			csrVideoTest.csrVideoTest();
			break;
		case "Cologuard Insurance & Billing Test":
			cologuardInsuranceAndBillingTest.verifyInsuranceAndBillingPageData();
			break;
		case "How to get cologuard Test":
			howToGetCologuardTest.verifyGetCologuardPageTest();
			break;
		case "Cologuard Affordable Page Test":
			cgAffordablePageTest.verifyAffordablePageData();
			break;
		case "Start screening at 45 Test":
			cgStartScreeningAt45PageTest.verifyStartScreeningAT45PageData();
			break;
		case "careerHomePageTest":
			careerHomePageTest.careerHomePageTest();
			break;
		case "careerWhyExactSciencesTest":
			careerWhyExactSciencesTest.careerWhyExactSciencesTest();
			break;
		case "careerLifeAtExactTest":
			careerLifeAtExactTest.careerLifeAtExactTest();
			break;
		case "careerLocationsTest":
			careerLocationsTest.careerLocationsTest();
			break;
		case "careerBenefitsTest":
			careerBenefitsTest.careerBenefitsTest();
			break;
		case "careerCurrentOpeningsTest":
			careerCurrentOpeningsTest.careerCurrentOpeningsTest();
			break;
		case "careerFooterTest":
			careerFooterTest.careerFooterTest();
			break;
		case "careerVideoTest":
			careerVideoTest.careerVideoTest();
			break;
		case "labsHomePageTest":
			labsHomePageTest.labsHomePageTest();
			break;
		case "labsClientPageTest":
			labsClientPageTest.labsClientPageTest();
			break;
		case "labsQualityPageTest":
			labsQualityPageTest.labsQualityPageTest();
			break;
		case "labsAboutPageTest":
			labsAboutPageTest.labsAboutPageTest();
			break;
		case "labsFooterTest":
			labsFooterTest.labsFooterTest();
			break;
		case "Learn about colon cancer & screening":
			aboutScreeningTest.verifyAboutScreeningPageData();
			break;
		case "Cologuard FAQs page":
			cgFAQsPageTest.verifyFAQsPageData();
			break;
		case "Cologuard Effective and easy to use test":
			cgEffectiveAndEasyPageTest.verifyCologuardHomepageLinksTest();
			break;
		case "Collecting and returning your samples test":
			collectingAndReturningYourSamplesTest.verifyCollectingAndReturningYourSamplesTest();
			break;
		case "WhyCologuardTest":
			whyCologuardTest.verifyWhyCologuardPageTest();
			break;
		case "CologuardVideoTest":
			cologuardVideoTest.verifyCologuardVideoTest();
			break;
		case "CGUseCologuardTest":
			cgUseCologuardTest.verifyCGUseCologuardTest();
			break;

		case "CorporateUkHomePageVerificationsTest":
			corporateUkHomePageVerificationsTest.verifyCorporateUkHomeLinksTest();
			break;
		case "CorporateUkAboutUsPageTest":
			corporateUkAboutUsPageTest.verifyCorporateUkAboutUsPageTest();
			break;
		case "CorporateUkOurProductPageTest":
			corporateUkOurProductPageTest.verifyCorporateUkOurProductPageTest();
			break;
		case "CorporateUkPressRoomPageTest":
			corporateUkPressRoomPageTest.verifyCorporateUkPressRoomPageTest();
			break;
		case "CorporateUkFooterTest":
			corporateUkFooterTest.verifyCorporateUkFooterTest();
			break;
		case "OglHomePageVerificationsTest":
			oglHomePageVerificationsTest.verifyOglHomepageLinksTest();
			break;
		case "OglProvidersHeaderTest":
			oglProvidersHeaderTest.verifyOglProvidersHeaderTest();
			break;
		case "OglPatientsHeaderTest":
			oglPatientsHeaderTest.verifyOglPatientsHeaderTest();
			break;
		case "OglEducationPageTest":
			oglEducationPageTest.verifyOglEducationPageTest();
			break;
		case "OglResourcePageTest":
			oglResourcePageTest.verifyOglResourcePageTest();
			break;
		case "OglContactUsPageTest":
			oglContactUsPageTest.verifyOglContactUsPageTest();
			break;
		case "OglFooterTest":
			oglFooterTest.verifyOglFooterTest();
			break;
		case "OglVideoTest":
			oglVideoTest.verifyOglVideoTest();
			break;
		case "OiqCHHomePageTest":
			oiqCHHomePageTest.verifyOiqCHHomePageTest();
			break;
		case "OiqCHFrenchPageTest":
			oiqCHFrenchPageTest.verifyOiqCHFrenchPageTest();
			break;
		case "OiqCHGermanPageTest":
			oiqCHGermanPageTest.verifyOiqCHGermanPageTest();
			break;
		case "OiqCHReimbursementPageTest":
			oiqCHReimbursementPageTest.verifyOiqCHReimbursementPageTest();
			break;
		case "OiqCHContactUsPageTest":
			oiqCHContactUsPageTest.verifyOiqCHContactUsPageTest();
			break;
		case "ProductsiteHomepageVerificationsTest":
			productsiteHomepageVerificationsTest.productsiteHomepageVerificationsTest();
			break;
		case "ProductsiteHealthcareProvidersSectionVerificationsTest":
			productsiteHealthcareProvidersSectionVerificationsTest
					.productsiteHealthcareProvidersSectionVerificationsTest();
			break;
		case "ProductsitePatientsAndCaregiversSectionVerificationsTest":
			productsitePatientsAndCaregiversSectionVerificationsTest
					.productsitePatientsAndCaregiversSectionVerificationsTest();
			break;
		case "ProductsiteBillingAndCoverageVerificationsTest":
			productsiteBillingAndCoverageVerificationsTest.productsiteBillingAndCoverageVerificationsTest();
			break;
		case "ProductsiteAboutUsVerificationsTest":
			productsiteAboutUsVerificationsTest.productsiteAboutUsVerificationsTest();
			break;
		case "ProductsiteContactUsVerificationsTest":
			productsiteContactUsVerificationsTest.productsiteContactUsVerificationsTest();
			break;
		case "ProductsiteFooterVerificationsTest":
			productsiteFooterVerificationsTest.productsiteFooterVerificationsTest();
			break;
		case "ProductsiteVideoVerificationsTest":
			productsiteVideoVerificationsTest.productsiteVideoVerificationsTest();
			break;
		case "OiqDEFachkreiseHeaderTest":
			oiqDEFachkreiseHeaderTest.verifyOiqDEFachkreiseHeaderTest();
			break;
		case "OiqDEPatientenHeaderTest":
			oiqDEPatientenHeaderTest.verifyOiqDEPatientenHeaderTest();
			break;
		case "OiqDEPresseinformationenHeaderTest":
			oiqDEPresseinformationenHeaderTest.verifyOiqDEPresseinformationenHeaderTest();
			break;
		case "OiqDEKontaktHeaderTest":
			oiqDEKontaktHeaderTest.verifyOiqDEKontaktHeaderTest();
			break;
		case "OiqDEFooterTest":
			oiqDEFooterTest.verifyOiqDEFooterTest();
			break;
		case "OiqDEVideoTest":
			oiqDEVideoTest.verifyOiqDEVideoTest();
			break;
		default:
			logError("Wrong choice for test case: " + testCaseNumber
					+ ", it does not exist in list of existing test cases.");
			throw new NoSuchElementException("Error");

		}

		// testng.setTestClasses(classToExecute);
		//// testng.setListenerClasses(listnerClasses);
		//// testng.addListener(tla);testng.run();
		// testng.run();

	}
}
