package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.CologuardInsuranceAndBillingPage;
import exact.util.PostStatusToZephyr;

/**
 * This class verifies Cologuard Insurance page verifications
 * 
 * @userstory #303911 Task#304283
 * @author Sandeep Singh
 * @since 05/03/2023
 */
public class CologuardInsuranceAndBillingTest extends BasicIntTest {

	private final CologuardInsuranceAndBillingPage cologuardInsuranceAndBillingPage = new CologuardInsuranceAndBillingPage();

	private final String cologuardHomePageURL = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	private final String cologuardInsurancePageURL = cologuardPagesProperties.getProperty("cologuardInsurancePageURL");
	private final String cologuardReadStoriesPageURL = cologuardPagesProperties
			.getProperty("cologuardReadStoriesPageURL");
	private final String cologuardSeeResourcesAndSupportPageURL = cologuardPagesProperties
			.getProperty("cologuardSeeResourcesAndSupportPageURL");

	private final String insuranceAndBilling = cologuardPagesProperties.getProperty("insuranceAndBilling");
	private final String insurance = cologuardPagesProperties.getProperty("insurance");
	private final String insurancePageTitle = cologuardPagesProperties.getProperty("insurancePageTitle");
	private final String cologuardScreeningStoriesTitle = cologuardPagesProperties
			.getProperty("cologuardScreeningStoriesTitle");
	private final String cologuardSeeResourcesAndSupportTitle = cologuardPagesProperties
			.getProperty("cologuardSeeResourcesAndSupportTitle");

	private final String medicareAndMedicareAdvantage = cologuardPagesProperties
			.getProperty("medicareAndMedicareAdvantage");
	private final String medicaid = cologuardPagesProperties.getProperty("medicaid");
	private final String commercialInsuranceInNetwork = cologuardPagesProperties
			.getProperty("commercialInsuranceInNetwork");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T717";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyInsuranceAndBillingPageData() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");
		acceptCookies();

		verifySafely(cologuardInsuranceAndBillingPage.isCologuardHomepageDisplayed(), true,
				"Cologuard homepage is displayed");

		cologuardInsuranceAndBillingPage.selectSubOptionFromTopNavOptions(insuranceAndBilling, insurance);
		verifySafely(driver.getURL(), cologuardInsurancePageURL, "'Cologuard Insurance' page is displayed");
		verifySafely(driver.getTitle(), insurancePageTitle, "'" + insurancePageTitle + "' is displayed as page title");

		cologuardInsuranceAndBillingPage.clickReadMoreLink();
		verifySafely(cologuardInsuranceAndBillingPage.isReadLessDisplayed(), true, "'Read less' is now displayed");

		String readMoreContent = cologuardInsuranceAndBillingPage.getReadMoreContent();
		verifySafely(readMoreContent != null && !readMoreContent.equalsIgnoreCase(""), true,
				"'Read More' content is displayed");

		cologuardInsuranceAndBillingPage.clickReadLessLink();
		verifySafely(cologuardInsuranceAndBillingPage.isReadMoreDisplayed(), true, "'Read more' is now displayed");

		cologuardInsuranceAndBillingPage.clickAccordionWithLabel(medicareAndMedicareAdvantage);
		verifySafely(cologuardInsuranceAndBillingPage.isAccordionSectionExpanded(medicareAndMedicareAdvantage), true,
				medicareAndMedicareAdvantage + " accordion is expanded");

		cologuardInsuranceAndBillingPage.clickAccordionWithLabel(medicaid);
		verifySafely(cologuardInsuranceAndBillingPage.isAccordionSectionExpanded(medicaid), true,
				medicaid + " accordion is expanded");

		cologuardInsuranceAndBillingPage.clickAccordionWithLabel(commercialInsuranceInNetwork);
		verifySafely(cologuardInsuranceAndBillingPage.isAccordionSectionExpanded(commercialInsuranceInNetwork), true,
				commercialInsuranceInNetwork + " accordion is expanded");

		cologuardInsuranceAndBillingPage.closeAllAccordion();
		verifySafely(cologuardInsuranceAndBillingPage.areAccordionsClosed(), true, "All accordions are now closed");

		cologuardInsuranceAndBillingPage.openAllAccordion();
		verifySafely(cologuardInsuranceAndBillingPage.areAccordionsOpen(), true, "All accordions are now open");

		cologuardInsuranceAndBillingPage.clickReadStories();
		verifySafely(driver.getURL(), cologuardReadStoriesPageURL, "'Patient Stories' page is displayed");
		verifySafely(driver.getTitle(), cologuardScreeningStoriesTitle,
				"'" + cologuardScreeningStoriesTitle + "' is displayed as page title");

		driver.back();
		cologuardInsuranceAndBillingPage.clickSeeResourcesAndSupport();
		verifySafely(driver.getURL(), cologuardSeeResourcesAndSupportPageURL,
				"'See resources & support' page is displayed");
		verifySafely(driver.getTitle(), cologuardSeeResourcesAndSupportTitle,
				"'" + cologuardSeeResourcesAndSupportTitle + "' is displayed as page title");

		throwAssertionErrorOnFailure();
	}
}
