package exact.ath.sitecore.labs;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;

public class LabsWebsiteTest extends BasicIntTest {
	private final LabsHomePageTest labsHomePageTest = new LabsHomePageTest();
	private final LabsClientPageTest labsClientPageTest = new LabsClientPageTest();

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test(priority = 1)
	public void labsHomePageTest() {
		labsHomePageTest.labsHomePageTest();
	}

	@Test(priority = 2)
	public void labsClientPageTest() {
		labsClientPageTest.labsClientPageTest();
	}
}
