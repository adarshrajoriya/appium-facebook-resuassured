package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.AboutScreeningPage;
import exact.ath.cologuard.CGEffectiveAndEasyPage;
import exact.util.PostStatusToZephyr;
import exact.util.Sleeper;

/**
 * This class tests page functionality for Effective and easy screening for
 * Cologuard page
 * 
 * @userstory #303911 Task#304660
 * @author Sandeep Singh
 * @since 05/16/2023
 */
public class CGEffectiveAndEasyPageTest extends BasicIntTest {

	private final CGEffectiveAndEasyPage cgEffectiveAndEasyPage = new CGEffectiveAndEasyPage();
	private final AboutScreeningPage aboutScreeningPage = new AboutScreeningPage();
	private final String effectiveAndEasyURL = cologuardPagesProperties.getProperty("effectiveAndEasyURL");
	private final String impRiskInfoURL = cologuardPagesProperties.getProperty("impRiskInfoURL");
	private final String cologuardReadStoriesPageURL = cologuardPagesProperties
			.getProperty("cologuardReadStoriesPageURL");
	private final String getCologuardURL = cologuardPagesProperties.getProperty("getCologuardURL");

	private final String impRiskInfoPageTitle = cologuardPagesProperties.getProperty("impRiskInfoPageTitle");
	private final String effectiveAndEasyToUseTitle = cologuardPagesProperties
			.getProperty("effectiveAndEasyScreeningPageTitle");
	private final String whyCologuard = cologuardPagesProperties.getProperty("whyCologuard");
	private final String effectiveAndEasyToUse = cologuardPagesProperties.getProperty("effectiveAndEasyToUse");
	private final String impRiskInfo = cologuardPagesProperties.getProperty("impRiskInfo");
	private final String cologuardScreeningStoriesTitle = cologuardPagesProperties
			.getProperty("cologuardScreeningStoriesTitle");
	private final String getCologuardPageTitle = cologuardPagesProperties.getProperty("getCologuardPageTitle");
	private final String howDoesStoolDNATechWorkLabel = cologuardPagesProperties
			.getProperty("howDoesStoolDNATechWorkLabel");
	private final String howOftenToScreenWithCGLabel = cologuardPagesProperties
			.getProperty("howOftenToScreenWithCGLabel");
	private final String initialTime = "0:00";
	private String finalTime;

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T716";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyCologuardHomepageLinksTest() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");
		acceptCookies();

		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cologuardHomepage.selectSubOptionFromTopNavOptions(whyCologuard, effectiveAndEasyToUse);
		verifySafely(driver.getURL(), effectiveAndEasyURL, "'Effective and easy screening' page is displayed");
		verifySafely(driver.getTitle(), effectiveAndEasyToUseTitle,
				effectiveAndEasyToUseTitle + " title is displayed for the page");

		cgEffectiveAndEasyPage.clickAccordion(howDoesStoolDNATechWorkLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(howDoesStoolDNATechWorkLabel), true,
				howDoesStoolDNATechWorkLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.clickAccordion(howOftenToScreenWithCGLabel);
		verifySafely(cgEffectiveAndEasyPage.isAccordionExpandedFor(howOftenToScreenWithCGLabel), true,
				howOftenToScreenWithCGLabel + " accordion is expanded");

		cgEffectiveAndEasyPage.playCologuardIsConvenientVideo();
		Sleeper.sleepTightInSeconds(12);
		cgEffectiveAndEasyPage.clickCologuardIsConvenientVideoInCard();
		logInfo("Paused video under the 'Cologuard is convenient' Card");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Cologuard Is Convenient Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		cologuardHomepage.clickLinkOnPage(impRiskInfo);
		verifySafely(driver.getURL(), impRiskInfoURL, "'Important Risk Information' page is displayed");
		verifySafely(driver.getTitle(), impRiskInfoPageTitle,
				impRiskInfoPageTitle + " title is displayed for the page");

		driver.back();
		cgEffectiveAndEasyPage.clickReadStories();
		verifySafely(driver.getURL(), cologuardReadStoriesPageURL, "'Patient Stories' page is displayed");
		verifySafely(driver.getTitle(), cologuardScreeningStoriesTitle,
				"'" + cologuardScreeningStoriesTitle + "' is displayed as page title");

		driver.back();
		logInfo("Navigated back to the page");

		cgEffectiveAndEasyPage.clickMoreAboutRequestingCGBtn();
		verifySafely(driver.getURL(), getCologuardURL, "'Get Cologuard' page is displayed");
		verifySafely(driver.getTitle(), getCologuardPageTitle,
				getCologuardPageTitle + " title is displayed for the page");

		throwAssertionErrorOnFailure();
	}
}
