package exact.ath.sitecore.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.corporateUk.CorporateUkHomePage;
import exact.ath.corporateUk.CorporateUkPressRoomPage;

/**
 * This class verifies Corporate Uk Press Room page verifications
 * 
 * @userstory #304475 Task#307942
 * @author Tushar Gupta
 * @since 07/24/2023
 */
public class CorporateUkPressRoomPageTest extends BasicIntTest {

	private final CorporateUkHomePage corporateUkHomePage = new CorporateUkHomePage();
	private final String pageHeadingDisplayedCorporateUkHomePage = corporateUkPagesProperties
			.getProperty("pageHeadingDisplayedCorporateUkHomePage");
	private final CorporateUkPressRoomPage corporateUkPressRoomPage = new CorporateUkPressRoomPage();
	private final String corporateUkHomePageURL = corporateUkPagesProperties.getProperty("corporateUkHomePageURL");
	private final String pressRoom = corporateUkPagesProperties.getProperty("pressRoom");
	private final String pressRoomURL = corporateUkPagesProperties.getProperty("pressRoomURL");
	private final String pressReleasesNames = corporateUkPagesProperties.getProperty("pressReleasesNames");
	private final String pressReleasesURL = corporateUkPagesProperties.getProperty("pressReleasesURL");
	private final String publicationNewEnglandURL = corporateUkPagesProperties.getProperty("publicationNewEnglandURL");
	private final String publicationNewEngland = corporateUkPagesProperties.getProperty("publicationNewEngland");
	private final String newTailorPublishedURL = corporateUkPagesProperties.getProperty("newTailorPublishedURL");
	private final String newTailorPublished = corporateUkPagesProperties.getProperty("newTailorPublished");
	private final String newRealWorld = corporateUkPagesProperties.getProperty("newRealWorld");
	private final String newRealWorldURL = corporateUkPagesProperties.getProperty("newRealWorldURL");
	private final String breastCancerTest = corporateUkPagesProperties.getProperty("breastCancerTest");
	private final String breastCancerTestURL = corporateUkPagesProperties.getProperty("breastCancerTestURL");
	private final String newResultsLarge = corporateUkPagesProperties.getProperty("newResultsLarge");
	private final String newResultsLargeURL = corporateUkPagesProperties.getProperty("newResultsLargeURL");
	private final String decidingChemotherapyURL = corporateUkPagesProperties.getProperty("decidingChemotherapyURL");
	private final String decidingChemotherapy = corporateUkPagesProperties.getProperty("decidingChemotherapy");
	private final String oncotypePresentationsURL = corporateUkPagesProperties.getProperty("oncotypePresentationsURL");
	private final String oncotypePresentations = corporateUkPagesProperties.getProperty("oncotypePresentations");
	private final String womenDiagnosedURL = corporateUkPagesProperties.getProperty("womenDiagnosedURL");
	private final String womenDiagnosed = corporateUkPagesProperties.getProperty("womenDiagnosed");
	private final String majorNewStudy = corporateUkPagesProperties.getProperty("majorNewStudy");
	private final String majorNewStudyURL = corporateUkPagesProperties.getProperty("majorNewStudyURL");
	private final String doNeedURL = corporateUkPagesProperties.getProperty("doNeedURL");
	private final String doNeed = corporateUkPagesProperties.getProperty("doNeed");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyCorporateUkPressRoomPageTest() throws Exception {
		setupURL(corporateUkHomePageURL);
		logInfo("Page URL : " + corporateUkHomePageURL + "");

		acceptCookiesCorporateUk();
		logInfo("----------------Starting verification of Press Room Page of Corpoarte UK Website------------");
		verifySafely(corporateUkHomePage.isCorporateUkHomepageDisplayed(), true, "Corporate Uk Homepage is displayed");
		verifySafely(corporateUkHomePage.getPageHeadingDisplayedHomePage(), pageHeadingDisplayedCorporateUkHomePage,
				"'PURSUING EARLIER DETECTION AND LIFE-CHANGING ANSWERS' Title is displayed on Home Page Of Corporate Uk website");

		corporateUkHomePage.clickHeaderOption(pressRoom);
		verifySafely(driver.getURL(), pressRoomURL, "'Page URL matches'");

		verificationOfPressReleasesOfPresentYear();

		corporateUkPressRoomPage.clickPlusIconButton(0);
		logInfo("Clicked on '+' icon for year 2019");
		verifySafely(corporateUkPressRoomPage.isYearExpanded(), true, "'2019 Year is Expanded'");

		verificationOfPressReleasesAndMediaCoverageOf2019Year();

		corporateUkPressRoomPage.clickPlusIconButton(1);
		logInfo("Clicked on '+' icon for year 2018");
		verifySafely(corporateUkPressRoomPage.isYearExpanded(), true, "'2018 Year is Expanded'");

		verificationOfPressReleasesAndMediaCoverageOf2018Year();

		corporateUkPressRoomPage.clickPlusIconButton(2);
		logInfo("Clicked on '+' icon for year 2017");
		verifySafely(corporateUkPressRoomPage.isYearExpanded(), true, "'2017 Year is Expanded'");

		verificationOfPressReleasesAndMediaCoverageOf2017Year();

		corporateUkPressRoomPage.clickPlusIconButton(3);
		logInfo("Clicked on '+' icon for year 2016");
		verifySafely(corporateUkPressRoomPage.isYearExpanded(), true, "'2016 Year is Expanded'");

		verificationOfPressReleasesAndMediaCoverageOf2016Year();

		corporateUkPressRoomPage.clickPlusIconButton(4);
		logInfo("Clicked on '+' icon for year 2015");
		verifySafely(corporateUkPressRoomPage.isYearExpanded(), true, "'2015 Year is Expanded'");

		verificationOfPressReleasesAndMediaCoverageOf2015Year();
		logInfo("----------------Verification done for Press Room Page of Corpoarte UK Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

	private void verificationOfPressReleasesOfPresentYear() throws Exception {

		String[] pressReleasesNamesArr = pressReleasesNames.split(",");
		String[] pressReleasesURLArr = pressReleasesURL.split(",");

		for (int count = 0; count < pressReleasesNamesArr.length; count++) {

			corporateUkPressRoomPage.clickPressReleasesOption(pressReleasesNamesArr[count]);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), pressReleasesURLArr[count], "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();

		}

		corporateUkPressRoomPage.clickPressReleasesOption(publicationNewEngland);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), publicationNewEnglandURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

	}

	private void verificationOfPressReleasesAndMediaCoverageOf2019Year() throws Exception {

		logInfo("For PRESS RELEASES of 2 October 2019");
		corporateUkPressRoomPage.clickPressReleasesOption(newTailorPublished);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), newTailorPublishedURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		logInfo("For MEDIA COVERAGE of 16 October 2019");
		corporateUkPressRoomPage.clickPressReleasesOption(doNeed);
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), doNeedURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

	}

	private void verificationOfPressReleasesAndMediaCoverageOf2018Year() throws Exception {

		logInfo("For MEDIA COVERAGE of 3 June 2018");
		corporateUkPressRoomPage.clickPressReleasesOption(breastCancerTest);
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), breastCancerTestURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

		logInfo("For PRESS RELEASES of 22 October, 2018");
		corporateUkPressRoomPage.clickPressReleasesOption(newRealWorld);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), newRealWorldURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

	}

	private void verificationOfPressReleasesAndMediaCoverageOf2017Year() throws Exception {

		logInfo("For PRESS RELEASE of 11 December, 2017");
		corporateUkPressRoomPage.clickPressReleasesOption(newResultsLarge);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), newResultsLargeURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		logInfo("For MEDIA COVERAGE of 6 December 2017");
		corporateUkPressRoomPage.clickPressReleasesOption(decidingChemotherapy);
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), decidingChemotherapyURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

	}

	private void verificationOfPressReleasesAndMediaCoverageOf2016Year() throws Exception {

		logInfo("For PRESS RELEASE of 6 June 2016");
		corporateUkPressRoomPage.clickPressReleasesOption(oncotypePresentations);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncotypePresentationsURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		logInfo("For MEDIA COVERAGE of 9 October 2016");
		corporateUkPressRoomPage.clickPressReleasesOption(womenDiagnosed);
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), womenDiagnosedURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

	}

	private void verificationOfPressReleasesAndMediaCoverageOf2015Year() throws Exception {

		logInfo("For PRESS RELEASE of 14 December 2015");
		corporateUkPressRoomPage.clickPressReleasesOption(majorNewStudy);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), majorNewStudyURL, "' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

	}

}
