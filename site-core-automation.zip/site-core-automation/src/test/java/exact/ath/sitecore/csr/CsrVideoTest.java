package exact.ath.sitecore.csr;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.ath.sitecore.CsrWebsite;
import exact.sys.Driver;
import exact.util.Sleeper;

public class CsrVideoTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final CsrWebsite csrWebsite = new CsrWebsite();

	private final String loginUrl = exactPagesProperties.getProperty("CsrWebURL");

	String initialTime;
	String finalTime;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void csrVideoTest() {

		closeTheBrowser();
		setupURL(loginUrl);
		logBlockHeader();
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");
		initialTime = corporateWebsite.getVideoTime();
		corporateWebsite.clickPlayButton();
		logInfo("Clicked on 'Play' button");
		Sleeper.sleepTightInSeconds(7);
		corporateWebsite.videoHover();
		corporateWebsite.clickPauseButton();
		logInfo("Clicked on 'Pause' button");
		finalTime = corporateWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"'Exact Sciences stands with all those working to build a better tomorrow' Video is played  successfully Initial Time = '"
						+ initialTime + "' Final Time = '" + finalTime + "'");
		initialTime = corporateWebsite.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true,
				"'Exact Sciences stands with all those working to build a better tomorrow' Video is paused  successfully Initial Time = '"
						+ finalTime + "' Final Time = '" + initialTime + "'");

		csrWebsite.clickCsrCtoECHeader();
		logInfo("Clicked on 'Commitment to Eradicate Cancer' Header Option");
		verifySafely(csrWebsite.isCsrCtoECHeaderHighlightedDisplayed(), true,
				"'Commitment to Eradicate Cancer' item is displayed Highlighted in header section on the page");
		corporateWebsite.clickPlayButton();
		logInfo("Clicked on 'Play' button");
		initialTime = corporateWebsite.getVideoTime();
		Sleeper.sleepTightInSeconds(7);
		corporateWebsite.videoHover();
		corporateWebsite.clickPauseButton();
		logInfo("Clicked on 'Pause' button");
		finalTime = corporateWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"'COMMITMENT TO ERADICATE CANCER' Video is played  successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		initialTime = corporateWebsite.getVideoTime();

		verifySafely(initialTime.equals(finalTime), true,
				"'COMMITMENT TO ERADICATE CANCER' Video is paused  successfully Initial Time = '" + finalTime
						+ "' Final Time = '" + initialTime + "'");

		csrWebsite.clickCsrCmnEngHeader();
		logInfo("Clicked on 'Community Engagement' Header Option");
		verifySafely(csrWebsite.isCsrCmnEngHeaderHighlightedDisplayed(), true,
				"'Community Engagement' item is displayed Highlighted in header section on the page");
		corporateWebsite.clickPlayButton();
		logInfo("Clicked on 'Play' button");
		initialTime = corporateWebsite.getVideoTime();
		Sleeper.sleepTightInSeconds(7);
		corporateWebsite.videoHover();
		corporateWebsite.clickPauseButton();
		logInfo("Clicked on 'Pause' button");
		finalTime = corporateWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"GIVING BACK TO LOCAL COMMUNITIES' Video is played  successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		initialTime = corporateWebsite.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true,
				"GIVING BACK TO LOCAL COMMUNITIES' Video is paused  successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");

		csrWebsite.clickCsrSustainabilityHeader();
		logInfo("Clicked on 'Sustainability' Header Option");
		verifySafely(csrWebsite.isCsrSustainabilityHeaderHighlightedDisplayed(), true,
				"'Sustainability' item is displayed Highlighted in header section on the page");
		corporateWebsite.clickPlayButton();
		logInfo("Clicked on 'Play' button");
		initialTime = corporateWebsite.getVideoTime();
		initialTime = "0:00";
		Sleeper.sleepTightInSeconds(4);
		corporateWebsite.videoHover();
		corporateWebsite.videoHover();
		corporateWebsite.clickPauseButton();
		logInfo("Clicked on 'Pause' button");
		finalTime = corporateWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"PURSUING ENVIRONMENTALLY-CONSCIOUS OPERATIONS' Video is played  successfully Initial Time = '"
						+ initialTime + "' Final Time = '" + finalTime + "'");
		initialTime = corporateWebsite.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true,
				"PURSUING ENVIRONMENTALLY-CONSCIOUS OPERATIONS' Video is paused  successfully Initial Time = '"
						+ initialTime + "' Final Time = '" + finalTime + "'");

		logBlockHeader();
		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
