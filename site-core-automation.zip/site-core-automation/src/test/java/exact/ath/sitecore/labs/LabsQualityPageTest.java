package exact.ath.sitecore.labs;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.LabsWebsite;
import exact.sys.Driver;

/**
 * Refer User Story #301265 ,#EPS-T397   {@summary Verify the Quality and
 * compliance page and its subpages of Labs Website}
 * 
 * @author Manpreet Panesar
 *
 */
public class LabsQualityPageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final LabsWebsite labsWebsite = new LabsWebsite();
	private final String labsWebsiteURL = exactPagesProperties.getProperty("LabsWebsiteURL");
	private final String labsWebsiteHomeTitleValue = exactPagesProperties.getProperty("LabsWebsiteHomeTitleValue");
	private final String qualityAndCompliancePageTitleValue = exactPagesProperties
			.getProperty("QualityAndCompliancePageTitleValue");
	private final String patientPrivacyPolicyPageTitleValue = exactPagesProperties
			.getProperty("PatientPrivacyPolicyPageTitleValue");
	private final String patientPrivacyPolicyPageURL = exactPagesProperties.getProperty("PatientPrivacyPolicyPageURL");
	private final String licensingAndAccreditaionPageTitleValue = exactPagesProperties
			.getProperty("LicensingAndAccreditaionPageTitleValue");
	private final String licensingAndAccreditaionPageURL = exactPagesProperties
			.getProperty("LicensingAndAccreditaionPageURL");
	private final String cLIAnumber52D2072838URL = exactPagesProperties.getProperty("CLIAnumber52D2072838URL");
	private final String cLIAnumber52D2162828URL = exactPagesProperties.getProperty("CLIAnumber52D2162828URL");
	private final String cAPnumber8968743URL = exactPagesProperties.getProperty("CAPnumber8968743URL");
	private final String cAPnumber8527475URL = exactPagesProperties.getProperty("CAPnumber8527475URL");
	private final String californiaCDS00800491URL = exactPagesProperties.getProperty("CaliforniaCDS00800491URL");
	private final String californiaCDS90000987URL = exactPagesProperties.getProperty("CaliforniaCDS90000987URL");
	private final String pFINumber8852URL = exactPagesProperties.getProperty("PFINumber8852URL");
	private final String pFINumber9596URL = exactPagesProperties.getProperty("PFINumber9596URL");
	private final String pennsylvaniaClinicalPermit1URL = exactPagesProperties
			.getProperty("PennsylvaniaClinicalPermit1URL");
	private final String pennsylvaniaClinicalPermit2URL = exactPagesProperties
			.getProperty("PennsylvaniaClinicalPermit2URL");
	private final String rhodeIslandLicense1URL = exactPagesProperties.getProperty("RhodeIslandLicense1URL");
	private final String rhodeIslandLicense2URL = exactPagesProperties.getProperty("RhodeIslandLicense2URL");
	private final String marylandPermit1URL = exactPagesProperties.getProperty("MarylandPermit1URL");
	private final String marylandPermit2URL = exactPagesProperties.getProperty("MarylandPermit2URL");
	private final String informationSecurityPageTitleValue = exactPagesProperties
			.getProperty("InformationSecurityPageTitleValue");
	private final String informationSecurityPageURL = exactPagesProperties.getProperty("InformationSecurityPageURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void labsQualityPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(labsWebsiteURL);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		labsWebsite.hoverQualityAndComplianceMenu();
		verifySafely(labsWebsite.isPatientPrivacyPolicySubmenuDisplayed(), true,
				"'Patient Privacy Policy' Submenu is displayed under 'Quality And Compliance' header");
		verifySafely(labsWebsite.isLicensingAndAccreditaionSubmenuDisplayed(), true,
				"'Licensing and Accreditation' Submenu is displayed under 'Quality And Compliance' header");
		verifySafely(labsWebsite.isInformationSecuritySubmenuDisplayed(), true,
				"'Information Security' Submenu is displayed under 'Quality And Compliance' header");
		labsWebsite.clickQualityAndComplianceMenuOption();
		logInfo("Clicked on 'Quality And Compliance' Menu Option");
		verifySafely(labsWebsite.getPageTitle(), qualityAndCompliancePageTitleValue,
				"'Quality Assurance Policy' Page Title");
		labsWebsite.hoverQualityAndComplianceMenu();
		labsWebsite.clickPatientPrivacyPolicySubmenuOption();
		logInfo("Clicked on 'Patient Privacy Policy' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), patientPrivacyPolicyPageTitleValue,
				"'Patient Privacy Policy' Page Title");
		verifySafely(driver.getURL(), patientPrivacyPolicyPageURL, "'Patient Privacy Policy' Page URL matches");
		labsWebsite.hoverQualityAndComplianceMenu();
		labsWebsite.clickLicensingAndAccreditaionSubmenuOption();
		logInfo("Clicked on 'Licensing And Accreditaion' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), licensingAndAccreditaionPageTitleValue,
				"'Licensing And Accreditaion' Page Title");
		verifySafely(driver.getURL(), licensingAndAccreditaionPageURL, "'Licensing And Accreditaion' Page URL matches");
		for (int count = 1; count <= 14; count++) {
			String counter = Integer.toString(count);
			String[] links = { cLIAnumber52D2072838URL, cLIAnumber52D2162828URL, cAPnumber8968743URL,
					cAPnumber8527475URL, californiaCDS00800491URL, californiaCDS90000987URL, pFINumber8852URL,
					pFINumber9596URL, pennsylvaniaClinicalPermit1URL, pennsylvaniaClinicalPermit2URL,
					rhodeIslandLicense1URL, rhodeIslandLicense2URL, marylandPermit1URL, marylandPermit2URL };
			String[] UrlText = { "CLIA number 52D2072838", "CLIA number 52D2162828", "CAP number 8968743",
					"CAP number 8527475", "California CDS00800491", "California CDS90000987",
					"New York PFI Number: 8852", "New York PFI Number: 9596", "Pennsylvania Clinical Permit 1",
					"Pennsylvania Clinical Permit 2", "Rhode Island License 1", "Rhode Island License 2",
					"Maryland Permit 1", "Maryland Permit 2" };
			labsWebsite.clickViewCertificateLicensePermitLink(counter);
			logInfo("Clicked on '" + UrlText[count - 1] + "' Link");
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), links[count - 1], "'" + UrlText[count - 1] + "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
		}
		labsWebsite.hoverQualityAndComplianceMenu();
		labsWebsite.clickInformationSecuritySubmenuOption();
		logInfo("Clicked on 'Information Security' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), informationSecurityPageTitleValue,
				"'Information Security' Page Title");
		verifySafely(driver.getURL(), informationSecurityPageURL, "'Information Security' Page URL matches '");
		labsWebsite.clickExactSciencesLogolab();
		logInfo("Clicked on 'ExactSciences' Logo ");
		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
