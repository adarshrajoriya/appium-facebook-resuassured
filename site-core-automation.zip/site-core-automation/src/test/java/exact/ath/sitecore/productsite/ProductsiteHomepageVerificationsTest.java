package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.PSOncotypeDXBreastRecurrenceScoreTestPage;
import exact.ath.productsite.ProductsiteBreastCancerCarePage;
import exact.ath.productsite.ProductsiteHomepage;

/**
 * This class verifies Productsite 'Homepage'
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 07/14/2023
 */

public class ProductsiteHomepageVerificationsTest extends BasicIntTest {
	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();
	private final ProductsiteBreastCancerCarePage productsiteBreastCancerCarePage = new ProductsiteBreastCancerCarePage();
	private final PSOncotypeDXBreastRecurrenceScoreTestPage pSOncotypeDXBreastRecurrenceScoreTestPage = new PSOncotypeDXBreastRecurrenceScoreTestPage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String getTheWhitePaperPageHeaderValue = productsitePagesProperties
			.getProperty("GetTheWhitePaperPageHeaderValue");
	private final String searchText = productsitePagesProperties.getProperty("SearchText");
	private final String searchReasultsTitle = productsitePagesProperties.getProperty("SearchReasultsTitle");
	private final String createAnAccountPageUrl = productsitePagesProperties.getProperty("CreateAnAccountPageUrl");
	private final String signUpForPhysicianPortalPageHeaderValue = productsitePagesProperties
			.getProperty("SignUpForPhysicianPortalPageHeaderValue");
	private final String physicianPortalPageUrl = productsitePagesProperties.getProperty("PhysicianPortalPageUrl");
	private final String TabNames = productsitePagesProperties.getProperty("TabNames");
	private final String aboutUsTitle = productsitePagesProperties.getProperty("AboutUsTitle");
	private final String breastCancerPageHeaderValue = productsitePagesProperties
			.getProperty("BreastCancerPageHeaderValue");
	private final String breastCancerPageUrl = productsitePagesProperties.getProperty("BreastCancerPageUrl");
	private final String colonCancerPageHeaderValue = productsitePagesProperties
			.getProperty("ColonCancerPageHeaderValue");
	private final String colonCancerPageUrl = productsitePagesProperties.getProperty("ColonCancerPageUrl");
	private final String advancedSolidTumorsCancerPageTitle = productsitePagesProperties
			.getProperty("AdvancedSolidTumorsCancerPageTitle");
	private final String advancedSolidTumorsCancerPageUrl = productsitePagesProperties
			.getProperty("AdvancedSolidTumorsCancerPageUrl");
	private final String downloadWhitePaperLinkUrl = productsitePagesProperties
			.getProperty("DownloadWhitePaperLinkUrl");
	private final String getRecapOfTheAnnualMeetingUrl = productsitePagesProperties
			.getProperty("GetRecapOfTheAnnualMeetingUrl");
	private final String testingAndTreatingHeaderValue = productsitePagesProperties
			.getProperty("TestingAndTreatingHeaderValue");
	private final String learnMoreAboutGenomicTestingPageUrl = productsitePagesProperties
			.getProperty("LearnMoreAboutGenomicTestingPageUrl");
	private final String billingAndCoverageDetailsColonPageHeaderValue = productsitePagesProperties
			.getProperty("ViewMoreBillingAndCoverageDetailsColonPageHeaderValue");
	private final String billingAndCoveragePageUrl = productsitePagesProperties
			.getProperty("ExploreBillingCoverageoptionsPageUrl");
	private final String firstName = productsitePagesProperties.getProperty("FirstName");
	private final String lastName = productsitePagesProperties.getProperty("LastName");
	private final String email = productsitePagesProperties.getProperty("Email");
	private final String registerforUpdatesPageHeaderValue = productsitePagesProperties
			.getProperty("RegisterforUpdatesPageHeaderValue");
	private final String registerforUpdatesPageUrl = productsitePagesProperties
			.getProperty("RegisterforUpdatesPageUrl");
	private final String contactUsPageHeaderValue = productsitePagesProperties.getProperty("ContactUsPageHeaderValue");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsiteHomepageVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		productsiteHomepage.clickDownloadWhitePaperLink();
		verifySafely(productsiteHomepage.getPageHeader(), getTheWhitePaperPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "User back to Productsite homepage");
		productsiteHomepage.clickPrecisionOncologyLogo();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "User remains on Productsite homepage");
		productsiteHomepage.enterTextInSearchField(searchText);
		productsiteHomepage.clickOnSearchButton();
		verifySafely(driver.getTitle(), searchReasultsTitle, "Search results page title matched");
		driver.back();
		productsiteHomepage.clickCreateAnAccount();
		verifySafely(productsiteHomepage.getPageHeader(), signUpForPhysicianPortalPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), createAnAccountPageUrl, "'Create an account' Page Url matched");
		verifySafely(productsiteHomepage.isContactUsTabHighlighted(), true, "Contact Us tab is highlighted ");
		driver.back();
		productsiteHomepage.clickPhysicianLogin();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), physicianPortalPageUrl, "'Physician Login' Page Url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifyHeaderTabsDisplayed();
		verifySafely(productsiteHomepage.isRegionTabDisplayed(), true, "'Region' dropdown is displayed");
		productsiteHomepage.clickLearnMoreLink();
		verifySafely(driver.getTitle(), aboutUsTitle, "About Us page title matched");
		driver.back();
		productsiteHomepage.clickBreastCancerTestsLink();
		verifySafely(productsiteHomepage.getPageHeader(), breastCancerPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), breastCancerPageUrl, "Breast cancer page url matched");
		verifySafely(productsiteHomepage.isHealthcareProvidersHighlighted(), true,
				"Healthcare providers tab is highlighted ");
		driver.back();
		productsiteHomepage.clickColonCancerTestsLink();
		verifySafely(productsiteHomepage.getPageHeader(), colonCancerPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), colonCancerPageUrl, "Colon cancer page url matched");
		verifySafely(productsiteHomepage.isHealthcareProvidersHighlighted(), true,
				"Healthcare providers tab is highlighted ");
		driver.back();
		productsiteHomepage.clickAdvancedSolidTumorsCancerTestsLink();
		verifySafely(productsiteHomepage.getPageHeader(), advancedSolidTumorsCancerPageTitle,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), advancedSolidTumorsCancerPageUrl, "Advanced Solid Tumor page url matched");
		verifySafely(productsiteHomepage.isHealthcareProvidersHighlighted(), true,
				"Healthcare providers tab is highlighted ");
		driver.back();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickBeckersHealthcareWhitePaper();
		verifySafely(driver.getURL(), downloadWhitePaperLinkUrl, "Beckers Healthcare White Paper page url matched");
		driver.back();
		productsiteHomepage.clickGetRecapOfTheAnnualMeeting();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), getRecapOfTheAnnualMeetingUrl,
				"Get Recap Of The Annual Meeting page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteHomepage.clickLearnMoreAboutGenomicTestingLink();
		verifySafely(productsiteHomepage.getPageHeader(), testingAndTreatingHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), learnMoreAboutGenomicTestingPageUrl,
				"Learn More About Genomic Testing page url matched");
		verifySafely(productsiteHomepage.isPatientsCaregiversHighlighted(), true,
				"Patient & Caregivers tab is highlighted ");
		driver.back();
		productsiteHomepage.clickExploreBillingCoverageoptionsLink();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), billingAndCoverageDetailsColonPageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), billingAndCoveragePageUrl, "'Billing And Coverage' page URL matches");
		verifySafely(productsiteHomepage.isBillingCoverageHighlighted(), true, "Billing Coverage tab is highlighted ");
		driver.back();
		productsiteHomepage.enterFirstNameOfSignUpforOurHealthcareProfessionalUpdatesFields(firstName);
		productsiteHomepage.enterLastNameOfSignUpforOurHealthcareProfessionalUpdatesFields(lastName);
		productsiteHomepage.clickEmailsOfSignUpforOurHealthcareProfessionalUpdatesFields(email);
		productsiteHomepage.clickSubmitButton();
		verifySafely(productsiteHomepage.getPageHeader(), registerforUpdatesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), registerforUpdatesPageUrl, "'Register for Updates' page URL matches");
		verifySafely(productsiteHomepage.isContactUsTabHighlighted(), true, "Contact Us tab is highlighted ");
		driver.back();
		verifySafely(productsiteBreastCancerCarePage.isCallButtonDispalyed(), true,
				"'+1 866-662-6897' button is dispalyed");
		verifySafely(productsiteHomepage.isEmailCustomerServiceButtonDispalyed(), true,
				"'Email Customer Service' button is dispalyed");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		verifySafely(productsiteHomepage.isContactUsTabAfterClickedOnContactUsButtonHighlighted(), true,
				"Contact Us tab is highlighted ");
		driver.back();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		throwAssertionErrorOnFailure();

	}

	public void verifyHeaderTabsDisplayed() {
		for (String tabNames : TabNames.split(",")) {
			verifySafely(productsiteHomepage.isHeaderTabDisplayed(tabNames), true,
					"'" + tabNames + "' tab is displayed");
		}
	}
}
