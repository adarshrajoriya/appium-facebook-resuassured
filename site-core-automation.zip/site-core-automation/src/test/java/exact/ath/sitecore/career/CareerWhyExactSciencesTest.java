package exact.ath.sitecore.career;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CareerWebsite;
import exact.sys.Driver;

/**
 * This class verifies Career Website Why ExactSciences page verifications
 * 
 * @userstory #301264 Task#303946
 * @author qas_tgupta
 * @since 04/25/2023
 */

public class CareerWhyExactSciencesTest extends BasicIntTest {

	private final CareerWebsite careerWebsite = new CareerWebsite();
	private final Driver driver = new Driver();
	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CareerWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CareerWebURL");
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final String whyExactSciencesTitle = exactPagesProperties.getProperty("WhyExactSciencesTitle");
	private final By meetExactSciencesFrame = By.xpath(exactPagesProperties.getProperty("MeetExactSciencesFrame"));

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void careerWhyExactSciencesTest() {
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		logInfo("----------------Starting verification of Why Exact Sciences Tab present in Header Section of Career Website------------");
		verifySafely(careerWebsite.getCareerWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Heading");
		verifySafely(careerWebsite.isHeaderSectionDisplayed(), true, "'Header Section' is displayed on the page");
		verifySafely(careerWebsite.isPageTitleDisplayed(), true,
				"'Home Page tittle - CHANGE CAREERS.CHANGE LIVES.' is displayed on the page");
		careerWebsite.clickWhyExactSciencesTab();
		logInfo("Clicked on 'Why Exact Sciences?' Tab from the Header section");
		verifySafely(careerWebsite.getTotalRewards(), whyExactSciencesTitle,
				"'WHY EXACT SCIENCES' Title is displayed after clicking Why Exact Science Tab in Header Section");
		verifySafely(careerWebsite.isWhyExactSciencesTabDisplayedHighlighted(), true,
				"'Why Exact Sciences' Tab in the header section is highlighted in blue color");
		logInfo("----------------Starting verification of element present under FIVE CORE VALUES title------------");
		verifySafely(careerWebsite.isIntegrityIconLogoDisplayed(), true,
				"'Integrity' Icon Card is displayed under FIVE CORE VALUES title ");
		verifySafely(careerWebsite.isInnovationIconLogoDisplayed(), true,
				"'Innovation ' Icon Card is displayed under FIVE CORE VALUES title");
		verifySafely(careerWebsite.isTeamworkIconLogoDisplayed(), true,
				"'Team Work' Icon Card is displayed under FIVE CORE VALUES title");
		verifySafely(careerWebsite.isAccountabilityIconLogoDisplayed(), true,
				"'Accountability' Icon Card is displayed under FIVE CORE VALUES title");
		verifySafely(careerWebsite.isQualityIconLogoDisplayed(), true,
				"'Quality' Icon Card is displayed under FIVE CORE VALUES title");
		logInfo("----------------Verification Done for element present under FIVE CORE VALUES title------------");
		careerWebsite.clickInnovationIconLogo();
		logInfo("Clicked on 'INNOVATION' Icon logo");
		verifySafely(careerWebsite.isInnovationCardDisplayed(), true,
				"'Innovation'Card is displayed after click on Innovation Icon Logo");
		verifySafely(careerWebsite.isInnovationIconLogoHighlightedInBlue(), true,
				"' INNOVATION' icon logo is highlighted in blue");
		verifySafely(careerWebsite.isSlickDotInBottomHighlighted(), true,
				"'2nd' slick dot in  bottom is highlighted in black color");

		careerWebsite.clickTeamworkIconLogo();
		logInfo("Clicked on 'TEAMWORK' Icon logo");
		verifySafely(careerWebsite.isTeamworkCardDisplayed(), true,
				"'Teamwork'Card is displayed after click on Teamwork Icon Logo");
		verifySafely(careerWebsite.isInnovationIconLogoHighlightedInBlue(), true,
				"' TEAMWORK' icon logo is highlighted in blue");
		verifySafely(careerWebsite.isSlickDotInBottomHighlighted(), true,
				"'3rd' slick dot in  bottom is highlighted in black color");

		careerWebsite.clickAccountabilityIconLogo();
		logInfo("Clicked on 'ACCOUNTABILITY' Icon logo");
		verifySafely(careerWebsite.isAccountabilityCardDisplayed(), true,
				"'Accountability'Card is displayed after click on Accountability Icon Logo");
		verifySafely(careerWebsite.isInnovationIconLogoHighlightedInBlue(), true,
				"' ACCOUNTABILITY' icon logo is highlighted in blue");
		verifySafely(careerWebsite.isSlickDotInBottomHighlighted(), true,
				"'4th' slick dot in  bottom is highlighted in black color");

		careerWebsite.clickQualityIconLogo();
		logInfo("Clicked on 'QUALITY' Icon logo");
		verifySafely(careerWebsite.isQualityCardDisplayed(), true,
				"'Quality'Card is displayed after click on Quality Icon Logo");
		verifySafely(careerWebsite.isInnovationIconLogoHighlightedInBlue(), true,
				"'QUALITY' icon logo is highlighted in blue");
		verifySafely(careerWebsite.isSlickDotInBottomHighlighted(), true,
				"'5th' slick dot in  bottom is highlighted in black color");

		careerWebsite.clickBackwardSlickArrow();
		logInfo("Clicked on Backward Slick Arrow");
		verifySafely(careerWebsite.isAccountabilityCardDisplayed(), true,
				"'Previous'Card that is Accountability Card is displayed");
		driver.refresh();
		driver.switchToFrame(meetExactSciencesFrame);
		logInfo("----------------Starting verification of list present under 'Meet Exact Sciences Employees' heading------------");
		verifySafely(careerWebsite.isOliviaFinnDisplayed(), true,
				"'Olivia Finn' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isBlaiseRussoDisplayed(), true,
				"'Blaise Russo' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isDomoniqueTuckerDisplayed(), true,
				"'Domonique Tucker' person is displayed under 'Meet Exact Sciences Employees' heading");
		logInfo("----------------Verification Done for list present under 'Meet Exact Sciences Employees' heading------------");

		careerWebsite.clickShowMore();
		logInfo("Clicked on  'SHOW MORE' pull-down");
		logInfo("----------------Starting verification of list present under 'Meet Exact Sciences Employees' heading after clicking on 'SHOW MORE' pull-down.------------");
		verifySafely(careerWebsite.isOliviaFinnDisplayed(), true,
				"'Olivia Finn' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isBlaiseRussoDisplayed(), true,
				"'Blaise Russo' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isDomoniqueTuckerDisplayed(), true,
				"'Domonique Tucker' person is displayed under 'Meet Exact Sciences Employees' heading");

		verifySafely(careerWebsite.isLakshmiSampathDisplayed(), true,
				"'Lakshmi Sampath' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isKongXiongDisplayed(), true,
				"'Kong Xiong' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isUzomaIwuagwuDisplayed(), true,
				"'Uzoma Iwuagwu' person is displayed under 'Meet Exact Sciences Employees' heading");

		verifySafely(careerWebsite.isKyleStaceyDisplayed(), true,
				"'Kyle Stacey' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isEmmaTumiltyDisplayed(), true,
				"'Emma Tumilty' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isAndreaAdkinsDisplayed(), true,
				"'Andrea Adkins' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isJamiePuckettDisplayed(), true,
				"'Jamie Puckett' person is displayed under 'Meet Exact Sciences Employees' heading");

		logInfo("----------------Verification Done for list present under 'Meet Exact Sciences Employees' heading after clicking on 'SHOW MORE' pull-down.------------");
		careerWebsite.clickShowLess();
		logInfo("Clicked on 'SHOW LESS' upward menu");

		logInfo("----------------Starting verification of list present under 'Meet Exact Sciences Employees' heading after clicking on 'SHOW LESS' upward menu.------------");
		verifySafely(careerWebsite.isOliviaFinnDisplayed(), true,
				"'Olivia Finn' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isBlaiseRussoDisplayed(), true,
				"'Blaise Russo' person is displayed under 'Meet Exact Sciences Employees' heading");
		verifySafely(careerWebsite.isDomoniqueTuckerDisplayed(), true,
				"'Domonique Tucker' person is displayed under 'Meet Exact Sciences Employees' heading");
		logInfo("----------------Verification Done for list present under 'Meet Exact Sciences Employees' heading after clicking on 'SHOW LESS' upward menu.-----------");
		logInfo("----------------Verification Done for Why Exact Sciences Tab present in Header Section of Career Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}

}
