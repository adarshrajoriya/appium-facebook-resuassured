package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.FAQsPage;
import exact.util.PostStatusToZephyr;

/**
 * This test checks data on FAQs page
 * 
 * @userstory #303911 Task#304659
 * @author Sandeep Singh
 * @since 05/12/2023
 */
public class CGFAQsPageTest extends BasicIntTest {

	private final FAQsPage faQsPage = new FAQsPage();

	private final String faqsURL = cologuardPagesProperties.getProperty("faqsURL");
	private final String resourcesAndSupportURL = cologuardPagesProperties.getProperty("resourcesAndSupportURL");
	private final String signUpNowURL = cologuardPagesProperties.getProperty("signUpForInfoURL");

	private final String FAQs = cologuardPagesProperties.getProperty("FAQs");
	private final String FAQsPageTitle = cologuardPagesProperties.getProperty("FAQsPageTitle");
	private final String searchString = cologuardPagesProperties.getProperty("searchString");
	private final String specificSearchResultString = cologuardPagesProperties
			.getProperty("specificSearchResultString");
	private final String resourcesAndSupportPageTitle = cologuardPagesProperties
			.getProperty("resourcesAndSupportPageTitle");
	private final String signUpNowPageTitle = cologuardPagesProperties.getProperty("signUpForCologuardTitle");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T718";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyFAQsPageData() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");

		acceptCookies();

		verifySafely(isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cologuardHomepage.clickLinkOnPage(FAQs);
		verifySafely(driver.getURL(), faqsURL, "'FAQs' page is displayed");
		verifySafely(driver.getTitle(), FAQsPageTitle, FAQsPageTitle + " title is displayed for the page");

		faQsPage.search(searchString);

		verifySafely(faQsPage.getFirstSearchResult().contains(specificSearchResultString), true,
				"Search results are displayed according to the searched text");

		faQsPage.clickOpenAllQuestions();
		verifySafely(faQsPage.areAllQuestionsExpanded(), true, "All questions are now expanded");

		faQsPage.clickCloseAllQuestions();
		verifySafely(faQsPage.areAllQuestionsCollapsed(), true, "All questions are now collapsed");

		faQsPage.expandAllAccordionsOneByOne();
		verifySafely(faQsPage.areAllQuestionsExpanded(), true, "All questions are now expanded");

		faQsPage.clickSeeResourcesAndSupportBtn();
		verifySafely(driver.getURL(), resourcesAndSupportURL, "'Resources & Support' page is displayed");
		verifySafely(driver.getTitle(), resourcesAndSupportPageTitle,
				resourcesAndSupportPageTitle + " title is displayed for the page");

		driver.back();
		logInfo("Navigated back to FAQs page");

		faQsPage.clickSignUpNowBtn();
		verifySafely(driver.getURL(), signUpNowURL, "'Sign up now' page is displayed");
		verifySafely(driver.getTitle(), signUpNowPageTitle, signUpNowPageTitle + " title is displayed for the page");

		throwAssertionErrorOnFailure();
	}
}