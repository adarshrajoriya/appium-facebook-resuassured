package exact.ath.sitecore.csr;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.corporate.CorporateAboutPageTest;
import exact.ath.sitecore.corporate.CorporateFooterTest;
import exact.ath.sitecore.corporate.CorporateNewsroomPageTest;
import exact.ath.sitecore.corporate.CorporateOurTestsPageTest;
import exact.ath.sitecore.corporate.CorporatePipelineDataPageTest;
import exact.ath.sitecore.corporate.CorporateVideoTest;


public class CsrWebsiteTest extends BasicIntTest {
	
	private final CsrCiAndCrPageTest csrCiAndCrPageTest = new CsrCiAndCrPageTest();
	private final CorporateAboutPageTest corporateAboutPageTest = new CorporateAboutPageTest();
	private final CorporatePipelineDataPageTest corporatePipelineDataPageTest = new CorporatePipelineDataPageTest();
	private final CorporateOurTestsPageTest corporateOurTestsPageTest = new CorporateOurTestsPageTest();
	private final CorporateNewsroomPageTest corporateNewsroomPageTest = new CorporateNewsroomPageTest();
	private final CorporateVideoTest corporateVideoTest = new CorporateVideoTest();
	private final CorporateFooterTest corporateFooterTest = new CorporateFooterTest();
	
	
	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test(priority = 1)
	public void csrCiAndCrPageTest() {

		csrCiAndCrPageTest.csrCiAndCrPageTest();
			
	}
	
	@Test(priority = 2)
	public void corporateAboutPageTest() {

		corporateAboutPageTest.corporateAboutPageTest();
			
	}
	
	@Test(priority = 3)
	public void corporatePipelineDataPageTest() {

		corporatePipelineDataPageTest.corporatePipelineDataPageTest();
			
	}
	
	@Test(priority = 4)
	public void corporateOurTestsPageTest() {

		corporateOurTestsPageTest.corporateOurTestsPageTest();
			
	}
	
	@Test(priority = 5)
	public void corporateNewsroomPageTest() {

		corporateNewsroomPageTest.corporateNewsroomPageTest();
			
	}
	
	@Test(priority = 6)
	public void corporateVideoTest() {

		corporateVideoTest.corporateVideoTest();
			
	}
	
	@Test(priority = 7)
	public void corporateFooterTest() {

		corporateFooterTest.corporateFooterTest();
			
	}
}
