package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglHomepage;

/**
 * This class verifies OGL home page verifications
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 06/07/2023
 */

public class OglHomePageVerificationsTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String providerPageHeadingTitle = oglPagesProperties.getProperty("providerPageHeadingTitle");
	private final String providers = oglPagesProperties.getProperty("providers");
	private final String forProviders = oglPagesProperties.getProperty("forProviders");
	private final String forPatients = oglPagesProperties.getProperty("forPatients");
	private final String signUpForHelpfulInfo = oglPagesProperties.getProperty("signUpForHelpfulInfo");
	private final String patientPageHeadingTitle = oglPagesProperties.getProperty("patientPageHeadingTitle");
	private final String patients = oglPagesProperties.getProperty("patients");
	private final String contactUs = oglPagesProperties.getProperty("contactUs");
	private final String forHealthcareProviders = oglPagesProperties.getProperty("forHealthcareProviders");
	private final String patientPageHeadingTitleTwo = oglPagesProperties.getProperty("patientPageHeadingTitleTwo");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglHomepageLinksTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of Home page of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");

		oglHomepage.clickExactlyWhatsNeededTodayButton();

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), providerPageHeadingTitle,
				"'An HCC test with 82% early-stage sensitivity? Exactly.' Title is displayed on the PROVIDERS page");

		verifySafely(oglHomepage.isHeaderOptionDisplayed(providers), true,
				"Header option '" + providers + "' is underlined in the header section of the page");
		driver.back();

		verifySafely(oglHomepage.isBannerItemDisplayed(forProviders), true,
				"Icon Card '" + forProviders + "' is displayed under 'Jump to a section:' banner");
		verifySafely(oglHomepage.isBannerItemDisplayed(forPatients), true,
				"Icon Card '" + forPatients + "' is displayed under 'Jump to a section:' banner");
		verifySafely(oglHomepage.isBannerItemDisplayed(signUpForHelpfulInfo), true,
				"Icon Card '" + signUpForHelpfulInfo + "' is displayed under 'Jump to a section:' banner");

		oglHomepage.clickBannerItemHomePage(forProviders);
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), providerPageHeadingTitle,
				"'An HCC test with 82% early-stage sensitivity? Exactly.' Title is displayed on the PROVIDERS page");

		verifySafely(oglHomepage.isHeaderOptionDisplayed(providers), true,
				"Header option '" + providers + "' is underlined in the header section of the page");
		driver.back();
		oglHomepage.clickBannerItemHomePage(forPatients);

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), patientPageHeadingTitle,
				"'A better way to stay on top of risk? Exactly.' Title is displayed on the PROVIDERS page");

		verifySafely(oglHomepage.isHeaderOptionDisplayed(patients), true,
				"Header option '" + patients + "' is underlined in the header section of the page");
		driver.back();

		oglHomepage.clickBannerItemHomePage(signUpForHelpfulInfo);
		verifySafely(oglHomepage.isSignUpForInformationCardDisplayed(), true,
				"'Sign up for Information' card is displayed under 'CONTACT US' page.");

		verifySafely(oglHomepage.isHeaderOptionDisplayed(contactUs), true,
				"Header option '" + contactUs + "' is underlined in the header section of the page");
		driver.back();

		oglHomepage.clickLearnMoreButtonUnderTitles(0, forHealthcareProviders);
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), providerPageHeadingTitle,
				"'An HCC test with 82% early-stage sensitivity? Exactly.' Title is displayed on the PROVIDERS page");

		verifySafely(oglHomepage.isHeaderOptionDisplayed(providers), true,
				"Header option '" + providers + "' is underlined in the header section of the page");
		driver.back();

		oglHomepage.clickLearnMoreButtonUnderTitles(1, forPatients);
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), patientPageHeadingTitleTwo,
				"'Delivering important answers about liver cancer' Title is displayed on the PROVIDERS page");

		verifySafely(oglHomepage.isHeaderOptionDisplayed(patients), true,
				"Header option '" + patients + "' is underlined in the header section of the page");
		driver.back();
		logInfo("----------------Verification Done for Home page of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();

	}

}
