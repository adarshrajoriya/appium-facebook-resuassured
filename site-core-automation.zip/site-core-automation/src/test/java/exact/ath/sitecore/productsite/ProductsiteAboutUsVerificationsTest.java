package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.PSOncotypeDXBreastRecurrenceScoreTestPage;
import exact.ath.productsite.ProductsiteAboutUsPage;
import exact.ath.productsite.ProductsiteAdvancedSolidTumorPage;
import exact.ath.productsite.ProductsiteHomepage;

/**
 * This class verifies Productsite 'About Us' page
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 07/12/2023
 */
public class ProductsiteAboutUsVerificationsTest extends BasicIntTest {

	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();
	private final ProductsiteAboutUsPage productsiteAboutUsPage = new ProductsiteAboutUsPage();
	private final ProductsiteAdvancedSolidTumorPage productsiteAdvancedSolidTumorPage = new ProductsiteAdvancedSolidTumorPage();
	private final PSOncotypeDXBreastRecurrenceScoreTestPage pSOncotypeDXBreastRecurrenceScoreTestPage = new PSOncotypeDXBreastRecurrenceScoreTestPage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String TabNames = productsitePagesProperties.getProperty("TabNames");
	private final String aboutUsPageHeaderValue = productsitePagesProperties.getProperty("AboutUsPageHeaderValue");
	private final String aboutUsPageUrl = productsitePagesProperties.getProperty("AboutUsPageUrl");
	private final String ProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksNames = productsitePagesProperties
			.getProperty("ProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksNames");
	private final String productsiteAboutUsTitle = productsitePagesProperties.getProperty("ProductsiteAboutUsTitle");
	private final String downloadBrochurePageUrl = productsitePagesProperties.getProperty("DownloadBrochurePageUrl");
	private final String IconCardNameAboutUsPage = productsitePagesProperties.getProperty("IconCardNameAboutUsPage");
	private final String riskguardPageUrl = productsitePagesProperties.getProperty("RiskguardPageUrl");
	private final String UrlLinksUnderScreeningSurveillance = productsitePagesProperties
			.getProperty("UrlLinksUnderScreeningSurveillance");
	private final String LinksNameUnderPrognosisTreatmentGuidance = productsitePagesProperties
			.getProperty("LinksNameUnderPrognosisTreatmentGuidance");
	private final String TitlelinksUnderPrognosisTreatmentGuidance = productsitePagesProperties
			.getProperty("TitlelinksUnderPrognosisTreatmentGuidance");
	private final String molecularResidualDiseasePageUrl = productsitePagesProperties
			.getProperty("MolecularResidualDiseasePageUrl");
	private final String oncoExTraTestPageHeaderValue = productsitePagesProperties
			.getProperty("OncoExTraTestPageHeaderValue");
	private final String contactUsPageHeaderValue = productsitePagesProperties.getProperty("ContactUsPageHeaderValue");

	private final String[] tabNames = TabNames.split(",");
	private final String[] titlelinksUnderPrognosisTreatmentGuidance = TitlelinksUnderPrognosisTreatmentGuidance
			.split(",");

	private int cnumber = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsiteAboutUsVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		productsiteHomepage.clickHeaderTab(tabNames[3]);
		verifySafely(productsiteHomepage.getPageHeader(), aboutUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), aboutUsPageUrl, "'About Us' page URL matches");
		verifyProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinks();
		productsiteAboutUsPage.clickDownloadBrochureButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadBrochurePageUrl, "'Download Brochure' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifyIconCardAboutUsPageDisplayed();
		productsiteAboutUsPage.clickOnRiskguardLinkUnderHereditaryTest();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), riskguardPageUrl, "'Riskguard' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifyLinksUnderScreeningSurveillance();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[3]);
		verifyLinksUnderPrognosisTreatmentGuidance();
		productsiteAboutUsPage.clickOnRiskguardLinkUnderPrognosisTreatmentGuidance();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), riskguardPageUrl, "'Riskguard' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		productsiteAboutUsPage.clickOnLearnMoreLinkUnderMolecularResidualDisease();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), molecularResidualDiseasePageUrl, "'Riskguard' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		productsiteAboutUsPage.clickOnOncoExTraLinkUnderTherapySelection();
		verifySafely(productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage(), oncoExTraTestPageHeaderValue,
				"Page header '" + productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage()
						+ "' is dispalyed");
		driver.back();
		productsiteAboutUsPage.clickOnRiskguardLinkUnderTherapySelection();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), riskguardPageUrl, "'Riskguard' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		driver.back();

		driver.close();

		throwAssertionErrorOnFailure();
	}

	public void verifyProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinks() {
		for (String progressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksNames : ProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksNames
				.split(",")) {
			productsiteAboutUsPage.clickProgressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinks(
					progressAgainstCancerIntelligentTestsPersonalizedDecisionMakingLinksNames);
			verifySafely(driver.getTitle(), productsiteAboutUsTitle,
					"User redriects to respective content on same page");

		}
	}

	public void verifyIconCardAboutUsPageDisplayed() {
		for (String iconCardNameAboutUsPage : IconCardNameAboutUsPage.split(",")) {
			verifySafely(productsiteAboutUsPage.isIconCardDisplayed(iconCardNameAboutUsPage), true,
					"'" + iconCardNameAboutUsPage + "' tile is displayed");
		}
	}

	public void verifyLinksUnderScreeningSurveillance() {
		for (String urlLinksUnderScreeningSurveillance : UrlLinksUnderScreeningSurveillance.split(",")) {
			productsiteAboutUsPage.clickOnLinksUnderScreeningSurveillance(urlLinksUnderScreeningSurveillance);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), urlLinksUnderScreeningSurveillance, "page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();

		}
	}

	public void verifyLinksUnderPrognosisTreatmentGuidance() {
		for (String linksNameUnderPrognosisTreatmentGuidance : LinksNameUnderPrognosisTreatmentGuidance.split(",")) {
			productsiteAboutUsPage
					.clickOnLinksUnderPrognosisTreatmentGuidance(linksNameUnderPrognosisTreatmentGuidance);
			verifySafely(driver.getTitle(), titlelinksUnderPrognosisTreatmentGuidance[cnumber], "page title matched");
			driver.back();
			cnumber++;
		}
	}

}
