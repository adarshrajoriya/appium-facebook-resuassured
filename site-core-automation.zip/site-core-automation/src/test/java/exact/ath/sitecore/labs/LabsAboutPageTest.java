package exact.ath.sitecore.labs;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.LabsWebsite;
import exact.sys.Driver;

/**
 * Refer User Story #301265 ,#EPS-T398 {@summary Verify the About Us page and
 * its subpages of Labs Website}
 * 
 * @author Manpreet Panesar
 *
 */
public class LabsAboutPageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final LabsWebsite labsWebsite = new LabsWebsite();
	private final String labsWebsiteURL = exactPagesProperties.getProperty("LabsWebsiteURL");
	private final String labsWebsiteHomeTitleValue = exactPagesProperties.getProperty("LabsWebsiteHomeTitleValue");
	private final String aboutUsPageTitleValue = exactPagesProperties.getProperty("AboutUsPageTitleValue");
	private final String frequentlyAskedQuestionsPageTitleValue = exactPagesProperties
			.getProperty("FrequentlyAskedQuestionsPageTitleValue");
	private final String frequentlyAskedQuestionsPageURL = exactPagesProperties
			.getProperty("FrequentlyAskedQuestionsPageURL");
	private final String frequentlyaskedquestionsPageTitleValue = exactPagesProperties
			.getProperty("FrequentlyaskedquestionsPageTitleValue");
	private final String frequentlyaskedquestionsPageURL = exactPagesProperties
			.getProperty("FrequentlyaskedquestionsPageURL");
	private final String patientBrochurePageURL = exactPagesProperties.getProperty("PatientBrochurePageURL");
	private final String cologuardpatientwebsitePageURL = exactPagesProperties
			.getProperty("CologuardpatientwebsitePageURL");
	private final String labLeadershipBiosPageTitleValue = exactPagesProperties
			.getProperty("LabLeadershipBiosPageTitleValue");
	private final String labLeadershipBiosPageURL = exactPagesProperties.getProperty("LabLeadershipBiosPageURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void labsAboutPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(labsWebsiteURL);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		labsWebsite.hoverAboutUsMenu();
		verifySafely(labsWebsite.isFrequentlyAskedQuestionsSubmenuDisplayed(), true,
				"'Frequently Asked Questions' Submenu is displayed under 'About Us' header");
		verifySafely(labsWebsite.isLabLeadershipBiosSubmenuDisplayed(), true,
				"'Lab Leadership Bios' Submenu is displayed under 'About Us' header");
		labsWebsite.clickAboutUsMenuOption();
		logInfo("Clicked on 'About Us' Menu Option");
		verifySafely(labsWebsite.getPageTitle(), aboutUsPageTitleValue, "'About Us' Page Title ");
		labsWebsite.hoverAboutUsMenu();
		labsWebsite.clickFrequentlyAskedQuestionsSubmenu();
		logInfo("Clicked on 'Frequently Asked Questions' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), frequentlyAskedQuestionsPageTitleValue,
				"'Frequently Asked Questions' Page Title");
		verifySafely(driver.getURL(), frequentlyAskedQuestionsPageURL, "'Frequently Asked Questions' Page URL matches");
		labsWebsite.clickClickHereLink();
		logInfo("Clicked on 'click here' Link ");
		verifySafely(labsWebsite.getFrequentlyaskedquestionsPageTitle(), frequentlyaskedquestionsPageTitleValue,
				"'Frequently asked questions' Page Title");
		verifySafely(driver.getURL(), frequentlyaskedquestionsPageURL, "'Frequently asked questions' Page URL matches");
		driver.back();
		labsWebsite.clickPatientBrochureLink();
		logInfo("Clicked on 'Patient Brochure' Link ");
		verifySafely(driver.getURL(), patientBrochurePageURL, "'Patient Brochure'' Page URL matches");
		driver.back();
		String url = driver.getURL();
		labsWebsite.clickCologuardpatientwebsiteLink();
		logInfo("Clicked on 'cologuard patient website' Link ");
		labsWebsite.checkForExUSSiteForAboutPage(url);
		verifySafely(driver.getURL(), cologuardpatientwebsitePageURL, "'Cologuard patient website' Page URL matches");
		driver.back();
		labsWebsite.hoverAboutUsMenu();
		labsWebsite.clickLabLeadershipBiosSubmenu();
		logInfo("Clicked on 'Lab Leadership Bios' Submenu Option");
		verifySafely(labsWebsite.getPageTitle(), labLeadershipBiosPageTitleValue, "'Lab Leadership Bios' Page Title");
		verifySafely(driver.getURL(), labLeadershipBiosPageURL, "'Lab Leadership Bios' Page URL matches");
		labsWebsite.clickExactSciencesLogolab();
		logInfo("Clicked on 'ExactSciences' Logo ");
		verifySafely(labsWebsite.getPageTitle(), labsWebsiteHomeTitleValue, "Home Page Title");
		verifySafely(labsWebsite.isHomeMenuHeaderHighlighted(), true,
				"'Home' Menu is highlighted in header section on the page");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}

}
