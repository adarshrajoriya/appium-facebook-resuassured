package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;

public class OglWebsiteTest extends BasicIntTest {

	private final OglHomePageVerificationsTest oglHomePageVerificationsTest = new OglHomePageVerificationsTest();
	private final OglProvidersHeaderTest oglProvidersHeaderTest = new OglProvidersHeaderTest();
	private final OglPatientsHeaderTest oglPatientsHeaderTest = new OglPatientsHeaderTest();
	private final OglEducationPageTest oglEducationPageTest = new OglEducationPageTest();
	private final OglResourcePageTest oglResourcePageTest = new OglResourcePageTest();
	private final OglContactUsPageTest oglContactUsPageTest = new OglContactUsPageTest();
	private final OglFooterTest oglFooterTest = new OglFooterTest();
	private final OglVideoTest oglVideoTest = new OglVideoTest();

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void OglHomePageVerificationsTest() throws Exception {

		oglHomePageVerificationsTest.verifyOglHomepageLinksTest();

	}

	@Test
	public void OglProvidersHeaderTest() throws Exception {

		oglProvidersHeaderTest.verifyOglProvidersHeaderTest();
	}

	@Test
	public void OglPatientsHeaderTest() throws Exception {

		oglPatientsHeaderTest.verifyOglPatientsHeaderTest();
	}

	@Test
	public void OglEducationPageTest() throws Exception {

		oglEducationPageTest.verifyOglEducationPageTest();
	}

	@Test
	public void OglResourcePageTest() throws Exception {

		oglResourcePageTest.verifyOglResourcePageTest();
	}

	@Test
	public void OglContactUsPageTest() throws Exception {

		oglContactUsPageTest.verifyOglContactUsPageTest();
	}

	@Test
	public void OglFooterTest() throws Exception {

		oglFooterTest.verifyOglFooterTest();
	}

	@Test
	public void OglVideoTest() throws Exception {

		oglVideoTest.verifyOglVideoTest();
	}

}
