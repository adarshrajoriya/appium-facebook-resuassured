package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.ProductsiteContactUsPage;
import exact.ath.productsite.ProductsiteHomepage;

/**
 * This class verifies Productsite 'Contact Us' page
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 07/13/2023
 */
public class ProductsiteContactUsVerificationsTest extends BasicIntTest {

	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();
	private final ProductsiteContactUsPage productsiteContactUsPage = new ProductsiteContactUsPage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String TabNames = productsitePagesProperties.getProperty("TabNames");
	private final String contactUsPageHeaderValue = productsitePagesProperties.getProperty("ContactUsPageHeaderValue");
	private final String contactUsPageUrl = productsitePagesProperties.getProperty("ContactUsPageUrl");
	private final String firstName = productsitePagesProperties.getProperty("FirstName");
	private final String lastName = productsitePagesProperties.getProperty("LastName");
	private final String email = productsitePagesProperties.getProperty("Email");
	private final String phoneNumber = productsitePagesProperties.getProperty("PhoneNumber");
	private final String precisionOncologyTestOption = productsitePagesProperties
			.getProperty("PrecisionOncologyTestOption");
	private final String message = productsitePagesProperties.getProperty("Message");
	private final String registerforUpdatesPageHeaderValue = productsitePagesProperties
			.getProperty("RegisterforUpdatesPageHeaderValue");
	private final String registerforUpdatesPageUrl = productsitePagesProperties
			.getProperty("RegisterforUpdatesPageUrl");
	private final String ContactUsPhoneNumber = productsitePagesProperties.getProperty("ContactUsPhoneNumber");
	private final String ContactUsEmail = productsitePagesProperties.getProperty("ContactUsEmail");
	private final String verificationMessageOfContactUsForm = productsitePagesProperties
			.getProperty("VerificationMessageOfContactUsForm");

	private final String[] tabNames = TabNames.split(",");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsiteContactUsVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		productsiteHomepage.clickHeaderTab(tabNames[4]);
		verifySafely(productsiteHomepage.getContactUsPageHeader(), contactUsPageHeaderValue,
				"Page header '" + productsiteHomepage.getContactUsPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), contactUsPageUrl, "'Contact Us' page URL matches");
		productsiteContactUsPage.enterFirstNameOfContactUsForm(firstName);
		productsiteContactUsPage.enterLastNameOfContactUsForm(lastName);
		productsiteContactUsPage.enterEmailAddressOfContactUsForm(email);
		productsiteContactUsPage.enterPhoneNumberOfContactUsForm(phoneNumber);
		productsiteContactUsPage.selectPrecisionOncologyTestOfContactUsForm(precisionOncologyTestOption);
		productsiteContactUsPage.enterMessageOfContactUsForm(message);
		productsiteContactUsPage.clickSubmitButtonOfContactUsForm();
		verifySafely(productsiteContactUsPage.getVerificationMessageOfContactUsForm(),
				verificationMessageOfContactUsForm,
				"'" + productsiteContactUsPage.getVerificationMessageOfContactUsForm() + "' message is displayed");
		verifyPhoneLinksDisplayedOnContactUsPage();
		verifyEmailLinksDisplayedOnContactUsPage();
		productsiteHomepage.enterFirstNameOfSignUpforOurHealthcareProfessionalUpdatesFields(firstName);
		productsiteHomepage.enterLastNameOfSignUpforOurHealthcareProfessionalUpdatesFields(lastName);
		productsiteHomepage.clickEmailsOfSignUpforOurHealthcareProfessionalUpdatesFields(email);
		productsiteHomepage.clickSubmitButton();
		verifySafely(productsiteHomepage.getPageHeader(), registerforUpdatesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), registerforUpdatesPageUrl, "'Register for Updates' page URL matches");

		driver.close();

		throwAssertionErrorOnFailure();
	}

	public void verifyPhoneLinksDisplayedOnContactUsPage() {
		for (String contactUsPhoneNumber : ContactUsPhoneNumber.split(",")) {
			verifySafely(productsiteContactUsPage.isPhoneLinksDisplayedOnContactUsPage(contactUsPhoneNumber), true,
					"'" + contactUsPhoneNumber + "' Phone number is displayed");
		}
	}

	public void verifyEmailLinksDisplayedOnContactUsPage() {
		for (String contactUsEmail : ContactUsEmail.split(",")) {
			verifySafely(productsiteContactUsPage.isEmailLinksDisplayedOnContactUsPage(contactUsEmail), true,
					"'" + productsiteContactUsPage.getEmailLinksNameOnContactUsPage(contactUsEmail)
							+ "' Email is displayed");
		}
	}

}
