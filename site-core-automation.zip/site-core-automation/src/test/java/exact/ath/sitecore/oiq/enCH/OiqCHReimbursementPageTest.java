package exact.ath.sitecore.oiq.enCH;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqCH.OiqCHReimbursementPage;

/**
 * This class verifies OIQ Switzerland web site Reimbursement page
 * 
 * @userstory #304475 Task#307103
 * @author Pushkar Singh
 * @since 07/06/2023
 */
public class OiqCHReimbursementPageTest extends BasicIntTest {

	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final OiqCHReimbursementPage oiqCHReimbursementPage = new OiqCHReimbursementPage();

	private final String loginUrl = oiqenCHPagesProperties.getProperty("oiqCHsiteURL");
	private final String oiqenCHPageTitle = oiqenCHPagesProperties.getProperty("oiqenCHPageTitle");
	private final String reimbursementPageTitle = oiqenCHPagesProperties.getProperty("reimbursementPageTitle");
	private final String popupbutton1Text = oiqenCHPagesProperties.getProperty("popupbutton1Text");
	private final String oPASLinkURL = oiqenCHPagesProperties.getProperty("oPASLinkURL");
	private final String ordonnanceDuDFIURL = oiqenCHPagesProperties.getProperty("ordonnanceDuDFIURL");
	private final String kLVURL = oiqenCHPagesProperties.getProperty("kLVURL");
	private final String verordnungKLVURL = oiqenCHPagesProperties.getProperty("verordnungKLVURL");
	private final String enSavoirPlusDynamicURL = oiqenCHPagesProperties.getProperty("enSavoirPlusDynamicURL");
	private final String erfahrenSieMehrURL = oiqenCHPagesProperties.getProperty("erfahrenSieMehrURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqCHReimbursementPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Switzerland Homepage URL '" + loginUrl + "'");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on " + popupbutton1Text + "");

		verifySafely(oiqCHHomePage.getOiqPageTitle(), oiqenCHPageTitle, "Page Heading displayed");

		oiqCHHomePage.clickHeaderOption3();
		logInfo("Clicked on 'REIMBURSEMENT' item from the header section");

		verifySafely(oiqCHHomePage.getPageTitle(), reimbursementPageTitle, "Page Heading displayed");

		oiqCHReimbursementPage.clickOPASLink();
		logInfo("Clicked on 'Modifications de l'Ordonnance sur les prestations de l'assurance des soins (OPAS)' link under Références: section.");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oPASLinkURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqCHReimbursementPage.clickOrdonnanceDuDFILink();
		logInfo("Clicked on 'Ordonnance du DFI sur les prestations de l'assurance obligatoire des soins en cas de maladie' link under Références: section");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), ordonnanceDuDFIURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqCHReimbursementPage.clickKLVLink();
		logInfo("Clicked on 'Änderungen in der Krankenpflege-Leistungsverordnung (KLV)' link under Referenzen section.");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), kLVURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqCHReimbursementPage.clickVerordnungKLVLink();
		logInfo("Clicked on 'Verordnung KLV des EDI über Leistungen in der obligatorischen Krankenpflegeversicherung' link under Referenzen section.");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), verordnungKLVURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqCHReimbursementPage.clickEnSavoirPlusBtn();
		logInfo("Clicked on 'EN SAVOIR PLUS' button from 'Les plus du test Oncotype DX(R)' card.");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), enSavoirPlusDynamicURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqCHReimbursementPage.clickErfahrenSieMehrBtn();
		logInfo("Clicked on 'ERFAHREN SIE MEHR' button from 'Weitere Informationen zum der Oncotype DX(R) Brustkrebstest' card.");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), erfahrenSieMehrURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		throwAssertionErrorOnFailure();
	}

}
