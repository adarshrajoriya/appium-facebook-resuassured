package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglEducationPage;
import exact.ath.ogl.OglHomepage;
import exact.ath.ogl.OglResourcePage;
import exact.ath.ogl.OglWebinarPage;
import exact.util.Sleeper;

/**
 * This class verifies the video section of OGL website
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 07/12/2023
 */

public class OglVideoTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();
	private final OglEducationPage oglEducationPage = new OglEducationPage();
	private final OglWebinarPage oglWebinarPage = new OglWebinarPage();
	private final OglResourcePage oglResourcePage = new OglResourcePage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String providers = oglPagesProperties.getProperty("providers");
	private final String overview = oglPagesProperties.getProperty("overview");
	private final String education = oglPagesProperties.getProperty("education");
	private final String educationURL = oglPagesProperties.getProperty("educationURL");
	private final String newApproachHccSurveillanceTitle = oglPagesProperties
			.getProperty("newApproachHccSurveillanceTitle");
	private final String webinarsURL = oglPagesProperties.getProperty("webinarsURL");
	private final String webinarNames = oglPagesProperties.getProperty("webinarNames");
	private final String resources = oglPagesProperties.getProperty("resources");
	private final String resourceURL = oglPagesProperties.getProperty("resourceURL");
	private final String supportingInformationNeedTitle = oglPagesProperties
			.getProperty("supportingInformationNeedTitle");
	private final String initialTime = "0:00";
	private String finalTime;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglVideoTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of the video section of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");

		oglHomepage.clickVideoBelowJumpSection();
		logInfo("Played video below 'The Oncoguard® Liver solution reflects visionary collaboration between committed partners aiming to raise the standard of HCC surveillance' Title on Homepage");
		Sleeper.sleepTightInSeconds(12);
		oglHomepage.clickVideoBelowJumpSection();
		logInfo("Paused video below 'The Oncoguard® Liver solution reflects visionary collaboration between committed partners aiming to raise the standard of HCC surveillance' Title on Homepage");
		finalTime = oglHomepage.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true, "Video is played and paused successfully Initial Time = '"
				+ initialTime + "' Final Time = '" + finalTime + "'");

		driver.refresh();
		oglHomepage.hoverTopNavOption(providers);
		oglHomepage.clickTopNavOption(overview);

		oglHomepage.clickVideoBelowJumpSection();
		logInfo("Played video below 'The Oncoguard® Liver solution reflects visionary collaboration between committed partners aiming to raise the standard of HCC surveillance' Title on Overviewpage");
		Sleeper.sleepTightInSeconds(12);
		oglHomepage.clickVideoBelowJumpSection();
		logInfo("Paused video below 'The Oncoguard® Liver solution reflects visionary collaboration between committed partners aiming to raise the standard of HCC surveillance' Title on Overviewpage");
		finalTime = oglHomepage.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true, "Video is played and paused successfully Initial Time = '"
				+ initialTime + "' Final Time = '" + finalTime + "'");

		oglHomepage.clickTopNavOption(education);
		verifySafely(driver.getURL(), educationURL, "'Education' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), newApproachHccSurveillanceTitle,
				"'A new approach to HCC surveillance' Title is displayed on Page");

		oglEducationPage.clickOnViewAllButton();
		verifySafely(driver.getURL(), webinarsURL, "'Webinars' Page is displayed");
		verifySafely(oglWebinarPage.isListOfCardsDisplayed(), true, "'List of cards' is displayed' on Page");
		driver.refresh();

		verificationsOfVideosOnWebinarPageAfterClickViewAllButton();

		driver.refresh();
		oglHomepage.clickTopNavOption(resources);
		verifySafely(driver.getURL(), resourceURL, "'Resource' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), supportingInformationNeedTitle,
				"'Supporting you with the test information you need' Title is displayed on the '" + resources
						+ "' page");

		oglResourcePage.clickOnPlaySpecimenCollectionVideoLink();
		oglHomepage.clickVideoBelowJumpSection();
		logInfo("Played video 'PLAY SPECIMEN COLLECTION' on Resourcepage");
		Sleeper.sleepTightInSeconds(12);
		oglHomepage.clickVideoBelowJumpSection();
		logInfo("Paused video 'PLAY SPECIMEN COLLECTION' on Resourcepage");
		finalTime = oglHomepage.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true, "Video is played and paused successfully Initial Time = '"
				+ initialTime + "' Final Time = '" + finalTime + "'");
		oglResourcePage.clickOnPlaySpecimenCollectionVideoCloseButton();
		logInfo("----------------Verification done for the video section of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();
	}

	private void verificationsOfVideosOnWebinarPageAfterClickViewAllButton() throws Exception

	{
		for (String webinarName : webinarNames.split(",")) {
			oglWebinarPage.clickCardsOnPage(webinarName);
			oglHomepage.clickVideoBelowJumpSection();
			logInfo("Played video on '" + webinarName + "' Webinar Page");
			Sleeper.sleepTightInSeconds(12);
			oglHomepage.clickVideoBelowJumpSection();
			logInfo("Paused video on '" + webinarName + "' Webinar Page");
			finalTime = oglHomepage.getVideoTime();
			verifySafely(!initialTime.equals(finalTime), true,
					"Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
							+ finalTime + "'");
			driver.back();
			driver.refresh();
		}
	}

}
