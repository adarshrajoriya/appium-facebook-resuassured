package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.AboutScreeningPage;
import exact.ath.cologuard.CancelPickupPage;
import exact.ath.cologuard.CollectingAndReturningYourSamplePage;
import exact.ath.cologuard.SchedulePickupPage;
import exact.ath.cologuard.StoreLocatorPage;
import exact.util.PostStatusToZephyr;
import exact.util.Sleeper;

/**
 * This class tests Collecting and returning your samples page verifications
 * 
 * @userstory #303911 Task#304661
 * @author Sandeep Singh
 * @since 05/19/2023
 */
public class CollectingAndReturningYourSamplesTest extends BasicIntTest {

	private final CollectingAndReturningYourSamplePage collectingAndReturningYourSamplePage = new CollectingAndReturningYourSamplePage();
	private final SchedulePickupPage schedulePickupPage = new SchedulePickupPage();
	private final StoreLocatorPage storeLocatorPage = new StoreLocatorPage();
	private final CancelPickupPage cancelPickupPage = new CancelPickupPage();
	private final AboutScreeningPage aboutScreeningPage = new AboutScreeningPage();
	private final String useCologuard = cologuardPagesProperties.getProperty("useCologuard");
	private final String collectingAndReturnYourSample = cologuardPagesProperties
			.getProperty("collectingAndReturningSamples");
	private final String collectingAndReturningSamplePageTitle = cologuardPagesProperties
			.getProperty("collectingAndReturningSamplePageTitle");
	private final String schedulePickupPageTitle = cologuardPagesProperties.getProperty("schedulePickupPageTitle");
	private final String trackingNumber = cologuardPagesProperties.getProperty("trackingNumber");
	private final String contactName = cologuardPagesProperties.getProperty("contactName");
	private final String streetAddress = cologuardPagesProperties.getProperty("streetAddress");
	private final String city = cologuardPagesProperties.getProperty("city");
	private final String state = cologuardPagesProperties.getProperty("state");
	private final String zipCode = cologuardPagesProperties.getProperty("zip");
	private final String phoneNumber = cologuardPagesProperties.getProperty("phone");
	private final String english = cologuardPagesProperties.getProperty("english");
	private final String shippingFAQ = cologuardPagesProperties.getProperty("shippingFAQ");
	private final String screeningAndMobilityIssues = cologuardPagesProperties
			.getProperty("screeningAndMobilityIssues");

	private final String schedulePickupURL = cologuardPagesProperties.getProperty("schedulePickupURL");
	private final String storeLocatorURL = cologuardPagesProperties.getProperty("storeLocatorURL");
	private final String cancelUPSPickupURL = cologuardPagesProperties.getProperty("cancelUPSPickupURL");
	private final String understandingResultsPageURL = cologuardPagesProperties
			.getProperty("understandingResultsPageURL");
	private final String readStoriesPageURL = cologuardPagesProperties.getProperty("cologuardReadStoriesPageURL");
	private final String englishShippingInstructionsURL = cologuardPagesProperties
			.getProperty("englishShippingInstructionsURL");
	private final String collectingAndReturningSampleURL = cologuardPagesProperties
			.getProperty("collectingAndReturningSampleURL");
	private final String initialTime = "0:00";
	private String finalTime;

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T715";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyCollectingAndReturningYourSamplesTest() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");
		acceptCookies();

		verifySafely(isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cologuardHomepage.selectSubOptionFromTopNavOptions(useCologuard, collectingAndReturnYourSample);

		verifySafely(driver.getURL(), collectingAndReturningSampleURL,
				"'Collecting and Returning your sample' page is displayed");
		verifySafely(driver.getTitle(), collectingAndReturningSamplePageTitle,
				collectingAndReturningSamplePageTitle + " is displayed as page title");

		collectingAndReturningYourSamplePage.playReadyToReturnYourKitVideo();
		logInfo("User is able to play video 'Ready to return your kit?' under 'Collecting and retruning your sample' page");
		Sleeper.sleepTightInSeconds(12);
		collectingAndReturningYourSamplePage.playReadyToReturnYourKitVideo();
		logInfo("User is able to pause video 'Ready to return your kit?' under 'Collecting and retruning your sample' page");
		finalTime = aboutScreeningPage.getVideoTime(0);
		verifySafely(!initialTime.equals(finalTime), true,
				"Under Using & returning your Cologuard® kit Video is played and paused successfully Initial Time = '"
						+ initialTime + "' Final Time = '" + finalTime + "'");

		collectingAndReturningYourSamplePage.clickSchedulePickup();
		verifySafely(driver.getURL(), schedulePickupURL, "'Schedule pickup' page is displayed");
		verifySafely(driver.getTitle(), schedulePickupPageTitle,
				schedulePickupPageTitle + " is displayed as page title");

		schedulePickupPage.enterPickupDate();
		schedulePickupPage.enterTrackingNumber(trackingNumber);
		schedulePickupPage.enterContactName(contactName);
		schedulePickupPage.enterStreetAddress(streetAddress);
		schedulePickupPage.enterCity(city);
		schedulePickupPage.selectState(state);
		schedulePickupPage.enterZIPCode(zipCode);
		schedulePickupPage.enterPhoneNumber(phoneNumber);
		schedulePickupPage.clickSubmitBtn();

		verifySafely(schedulePickupPage.isPickupConfirmationMessageDisplayed(), true,
				"Confirmation message is displayed after clicking 'Schedule pickup'");

		String upsPickupRequestNumber = schedulePickupPage.getUPSPickupRequestNumber();

		driver.back();

		collectingAndReturningYourSamplePage.clickDropOffAtUPSBtn();

		verifySafely(driver.getURL(), storeLocatorURL, "'Store Locator' page is displayed");

		storeLocatorPage.enterZipcode(zipCode);
		storeLocatorPage.clickSubmitBtn();

		verifySafely(storeLocatorPage.isNearestStoreDisplayed(), true,
				"Nearest store is displayed under 'UPS Store Locator' after searching with Zipcode");

		driver.back();
		collectingAndReturningYourSamplePage.clickDownloadShippingInstructions(english);

		verifySafely(driver.getURL(), englishShippingInstructionsURL,
				"English shipping instructions are displayed in a new tab");
		driver.switchToParentWindow();

		collectingAndReturningYourSamplePage.expandAccordion(shippingFAQ);
		verifySafely(collectingAndReturningYourSamplePage.isAccordionExpanded(shippingFAQ), true,
				"Shipping FAQ accordion is expanded");

		collectingAndReturningYourSamplePage.clickCancelUPSPickup();
		verifySafely(driver.getURL(), cancelUPSPickupURL, "'Cancel UPS pickup' page is displayed");

		cancelPickupPage.enterRequestNumber(upsPickupRequestNumber);
		cancelPickupPage.clickSubmitBtn();
		verifySafely(cancelPickupPage.isCancellationSuccessfulMsgDisplayed(), true,
				"'UPS Pickup was successfully cancelled' confirmation message is displayed");

		driver.back();

		collectingAndReturningYourSamplePage.expandAccordion(screeningAndMobilityIssues);
		verifySafely(collectingAndReturningYourSamplePage.isAccordionExpanded(screeningAndMobilityIssues), true,
				screeningAndMobilityIssues + " accordion is expanded for 'Addittional Important Topics'");

		collectingAndReturningYourSamplePage.clickUnderstandingResults();
		verifySafely(driver.getURL(), understandingResultsPageURL, "'Understanding Results' page is displayed");

		driver.back();
		collectingAndReturningYourSamplePage.clickReadStoriesBtn();
		verifySafely(driver.getURL(), readStoriesPageURL, "'Patient Stories' page is displayed");

		throwAssertionErrorOnFailure();
	}
}
