package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.ProductsiteBillingAndCoveragePage;
import exact.ath.productsite.ProductsiteCostsAndCoveragePage;
import exact.ath.productsite.ProductsiteHomepage;

/**
 * This class verifies Productsite 'Billing & Coverage' page
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 07/17/2023
 */
public class ProductsiteBillingAndCoverageVerificationsTest extends BasicIntTest {

	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();
	private final ProductsiteBillingAndCoveragePage productsiteBillingAndCoveragePage = new ProductsiteBillingAndCoveragePage();
	private final ProductsiteCostsAndCoveragePage productsiteCostsAndCoveragePage = new ProductsiteCostsAndCoveragePage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String billingAndCoverageDetailsColonPageHeaderValue = productsitePagesProperties
			.getProperty("ViewMoreBillingAndCoverageDetailsColonPageHeaderValue");
	private final String TabNames = productsitePagesProperties.getProperty("TabNames");
	private final String billingAndCoveragePageUrl = productsitePagesProperties
			.getProperty("ExploreBillingCoverageoptionsPageUrl");
	private final String goToCostCoverageForPatientsPageUrl = productsitePagesProperties
			.getProperty("GoToCostCoverageForPatientsPageUrl");
	private final String learnMoreCostCoverageForPatientsPageUrl = productsitePagesProperties
			.getProperty("LearnMoreCostCoverageForPatientsPageUrl");
	private final String patientStateValue = productsitePagesProperties.getProperty("PatientStateValue");
	private final String householdSizeValue = productsitePagesProperties.getProperty("HouseholdSizeValue");
	private final String annualIncomeValue = productsitePagesProperties.getProperty("AnnualIncomeValue");
	private final String financialAssistanceDisclosureAndApplicationFormPageUrl = productsitePagesProperties
			.getProperty("FinancialAssistanceDisclosureAndApplicationFormPageUrl");
	private final String spanishPageUrl = productsitePagesProperties.getProperty("SpanishPageUrl");
	private final String patientStateValueForBillingAndCoverage = productsitePagesProperties
			.getProperty("PatientStateValueForBillingAndCoverage");
	private final String householdSizeValueForBillingAndCoverage = productsitePagesProperties
			.getProperty("HouseholdSizeValueForBillingAndCoverage");
	private final String annualIncomeValueForBillingAndCoverage = productsitePagesProperties
			.getProperty("AnnualIncomeValueForBillingAndCoverage");
	private final String providerPortalPageUrl = productsitePagesProperties.getProperty("ProviderPortalPageUrl");
	private final String seeTheSpecificCoverageCriteriaForEachTestPageUrl = productsitePagesProperties
			.getProperty("SeeTheSpecificCoverageCriteriaForEachTestUrl");
	private final String download14DayRuleProviderGuidePageUrl = productsitePagesProperties
			.getProperty("Download14DayRuleProviderGuidePageUrl");
	private final String gAPBrochurePageUrl = productsitePagesProperties
			.getProperty("DownloadTheGapGuideForHelpNavigatingTheInsuranceProcessPageURL");
	private final String downloadInOtherLanguageSpanishPageUrl = productsitePagesProperties
			.getProperty("DownloadInOtherLanguageSpanishPageUrl");
	private final String downloadInOtherLanguageTraditionalChinesePageUrl = productsitePagesProperties
			.getProperty("DownloadInOtherLanguageTraditionalChinesePageUrl");
	private final String downloadInOtherLanguageSimplifiedChinesePageUrl = productsitePagesProperties
			.getProperty("DownloadInOtherLanguageSimplifiedChinesePageUrl");
	private final String MedicareCoverageCriteriaForEachTestSectionName = productsitePagesProperties
			.getProperty("MedicareCoverageCriteriaForEachTestSectionName");
	private final String MedicareCoverageCriteriaForEachTestSectionHeadingValue = productsitePagesProperties
			.getProperty("MedicareCoverageCriteriaForEachTestSectionHeadingValue");

	private final String[] tabNames = TabNames.split(",");
	private final String[] medicareCoverageCriteriaForEachTestSectionHeadingValue = MedicareCoverageCriteriaForEachTestSectionHeadingValue
			.split(",");

	private int count = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsiteBillingAndCoverageVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		productsiteHomepage.clickHeaderTab(tabNames[2]);
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(), billingAndCoverageDetailsColonPageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), billingAndCoveragePageUrl, "'Billing And Coverage' page URL matches");
		productsiteBillingAndCoveragePage.clicGoToCostCoverageForPatientsLink();
		verifySafely(driver.getURL(), goToCostCoverageForPatientsPageUrl,
				"'Go to Cost & Coverage for Patients' page URL matches");
		driver.back();
		productsiteBillingAndCoveragePage.clicLearnMoreLink();
		verifySafely(driver.getURL(), learnMoreCostCoverageForPatientsPageUrl,
				"User redirects to respective section on the page");
		productsiteCostsAndCoveragePage.selectPatientState(patientStateValue);
		productsiteCostsAndCoveragePage.selectHouseholdSize(householdSizeValue);
		productsiteCostsAndCoveragePage.enterAnnualIncome(annualIncomeValue);
		productsiteCostsAndCoveragePage.clickOnSubmitButton();
		verifySafely(productsiteCostsAndCoveragePage.isQualifyTextDisplayed(), true, "Qualify text is displayed ");
		productsiteBillingAndCoveragePage.clickFinancialAssistanceDisclosureAndApplicationFormLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), financialAssistanceDisclosureAndApplicationFormPageUrl,
				"'Financial Assistance Disclosure and Application Form' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		productsiteBillingAndCoveragePage.clickSpanishLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), spanishPageUrl, "'Spanish' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		productsiteBillingAndCoveragePage.clickBackButton();
		verifySafely(productsiteBillingAndCoveragePage.isFinancialAssistanceFormDisplayed(), true,
				"Financial Assistance Form is displayed");
		productsiteCostsAndCoveragePage.selectPatientState(patientStateValueForBillingAndCoverage);
		productsiteCostsAndCoveragePage.selectHouseholdSize(householdSizeValueForBillingAndCoverage);
		productsiteCostsAndCoveragePage.enterAnnualIncome(annualIncomeValueForBillingAndCoverage);
		productsiteCostsAndCoveragePage.clickOnSubmitButton();
		verifySafely(productsiteCostsAndCoveragePage.isQualifyTextDisplayed(), true, "Qualify text is displayed ");
		verifySafely(productsiteBillingAndCoveragePage.isONCOTYPE8886626897LinkDisplayed(), true,
				"888-ONCOTYPE (888-662-6897) link is displayed ");
		productsiteBillingAndCoveragePage.clickBackButton();
		verifySafely(productsiteBillingAndCoveragePage.isFinancialAssistanceFormDisplayed(), true,
				"Financial Assistance Form is displayed");
		productsiteBillingAndCoveragePage.clickProviderPortalLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), providerPortalPageUrl, "'Provider Portal' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[2]);
		productsiteBillingAndCoveragePage.clickSeeTheSpecificCoverageCriteriaForEachTestLink();
		verifySafely(driver.getURL(), seeTheSpecificCoverageCriteriaForEachTestPageUrl,
				"User redirects to respective section on the page");
		productsiteBillingAndCoveragePage.clickDownload14DayRuleProviderGuideLink();
		verifySafely(driver.getURL(), download14DayRuleProviderGuidePageUrl,
				"'Download 14 Day Rule Provider Guide' page URL matches");
		driver.back();
		productsiteBillingAndCoveragePage.clickGAPBrochureLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), gAPBrochurePageUrl, "'GAP Brochure' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteBillingAndCoveragePage.click14DayRuleLink();
		verifySafely(driver.getURL(), download14DayRuleProviderGuidePageUrl, "'14 Day Rule' page URL matches");
		driver.back();

		productsiteBillingAndCoveragePage.clickDownloadInOtherLanguageSpanishLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadInOtherLanguageSpanishPageUrl, "'Spanish' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteBillingAndCoveragePage.clickDownloadInOtherLanguageTraditionalChineseLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadInOtherLanguageTraditionalChinesePageUrl,
				"'Traditional Chinese' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteBillingAndCoveragePage.clickDownloadInOtherLanguageSimplifiedChineseLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadInOtherLanguageSimplifiedChinesePageUrl,
				"'Simplified Chinese' page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		verifyMedicareCoverageCriteriaForEachTest();
		driver.close();

		throwAssertionErrorOnFailure();
	}

	public void verifyMedicareCoverageCriteriaForEachTest() {
		for (String medicareCoverageCriteriaForEachTestSectionName : MedicareCoverageCriteriaForEachTestSectionName
				.split(",")) {
			productsiteBillingAndCoveragePage
					.clickMedicareCoverageCriteriaForEachTestSections(medicareCoverageCriteriaForEachTestSectionName);
			verifySafely(productsiteBillingAndCoveragePage.getMedicareCoverageCriteriaForEachTestSectionHeading(),
					medicareCoverageCriteriaForEachTestSectionHeadingValue[count],
					"Medicare Coverage Criteria for Each Test '" + medicareCoverageCriteriaForEachTestSectionName
							+ "' is opened");
			count++;
		}
	}

}
