package exact.ath.sitecore.oiq.deDE;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqDE.OiqDEKlinischenPraxisPage;
import exact.ath.oiq.oiqDE.OiqDEWebcastsPage;
import exact.util.Sleeper;

/**
 * This class verifies OIQ Germany web site Video components
 * 
 * @userstory #304475 Task#307772
 * @author Pushkar Singh
 * @since 08/10/2023
 */
public class OiqDEVideoTest extends BasicIntTest {

	private final OiqDEWebcastsPage oiqDEWebcastsPage = new OiqDEWebcastsPage();
	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final OiqDEKlinischenPraxisPage oiqDEKlinischenPraxisPage = new OiqDEKlinischenPraxisPage();

	private final String loginUrl = oiqdeDEPagesProperties.getProperty("oiqDEsiteURL");
	private final String webcastsVideos = oiqdeDEPagesProperties.getProperty("webcastsVideos");
	private final String fachkreise = oiqdeDEPagesProperties.getProperty("fachkreise");
	private final String webcasts = oiqdeDEPagesProperties.getProperty("webcasts");
	private final String webcastsVideosPage2 = oiqdeDEPagesProperties.getProperty("webcastsVideosPage2");
	private final String patienten = oiqdeDEPagesProperties.getProperty("patienten");
	private final String uberDenTest = oiqdeDEPagesProperties.getProperty("uberDenTest");
	private final String uberDenTestPageTitle = oiqdeDEPagesProperties.getProperty("uberDenTestPageTitle");
	private final String uberDenTestVideo = oiqdeDEPagesProperties.getProperty("uberDenTestVideo");
	private final String tragtDieKosten = oiqdeDEPagesProperties.getProperty("tragtDieKosten");
	private final String tragtDieKostenVideo = oiqdeDEPagesProperties.getProperty("tragtDieKostenVideo");
	private final String gestellte = oiqdeDEPagesProperties.getProperty("gestellte");
	private final String gestelltePageTitle = oiqdeDEPagesProperties.getProperty("gestelltePageTitle");
	private final String gestellteVideo = oiqdeDEPagesProperties.getProperty("gestellteVideo");

	private String initialTime;
	private String finalTime;
//	private int count = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOiqDEVideoTest() throws Exception {

//		closeTheBrowser();
		setupURL(loginUrl);
		logBlockHeader();

		acceptCookies();
		logInfo("Opened OIQ Deutschland Homepage URL '" + loginUrl + "'");

		oiqDEWebcastsPage.selectSubOptionFromOIQSiteTopNavOptions(fachkreise, webcasts);

		for (String webcastsVideo : webcastsVideos.split(",")) {
			oiqDEWebcastsPage.clickVideo(webcastsVideo);
			oiqDEWebcastsPage.switchToVideoFrame();
			initialTime = "0:00";
			oiqDEWebcastsPage.clickPlayButton();
			Sleeper.sleepTightInSeconds(7);
			oiqDEWebcastsPage.clickPauseButton();
			finalTime = oiqDEWebcastsPage.getVideoTime();
			verifySafely(!initialTime.equals(finalTime), true,
					"Webcasts Page Video '" + webcastsVideo + "' is played  successfully Initial Time = '" + initialTime
							+ "' Final Time = '" + finalTime + "'");
			initialTime = oiqDEWebcastsPage.getVideoTime();
			verifySafely(initialTime.equals(finalTime), true,
					"Webcasts Page Video '" + webcastsVideo + "' is paused  successfully Initial Time = '" + initialTime
							+ "' Final Time = '" + finalTime + "'");
			driver.refresh();
		}

		oiqDEWebcastsPage.click2ndPageLink();
		logInfo("Clicked on '2' from bottom jump link.");
		verifySafely(oiqDEWebcastsPage.is2ndPageDisplayed(), true, "2nd Page is displayed");

		for (String webcastsVideo : webcastsVideosPage2.split(",")) {
			oiqDEWebcastsPage.clickVideo(webcastsVideo);
			oiqDEWebcastsPage.switchToVideoFrame();
			initialTime = "0:00";
			oiqDEWebcastsPage.clickPlayButton();
			Sleeper.sleepTightInSeconds(7);
			oiqDEWebcastsPage.clickPauseButton();
			finalTime = oiqDEWebcastsPage.getVideoTime();
			verifySafely(!initialTime.equals(finalTime), true,
					"Webcasts Page Video '" + webcastsVideo + "' is played  successfully Initial Time = '" + initialTime
							+ "' Final Time = '" + finalTime + "'");
			initialTime = oiqDEWebcastsPage.getVideoTime();
			verifySafely(initialTime.equals(finalTime), true,
					"Webcasts Page Video '" + webcastsVideo + "' is paused  successfully Initial Time = '" + initialTime
							+ "' Final Time = '" + finalTime + "'");
			driver.refresh();
		}

		oiqDEWebcastsPage.selectSubOptionFromOIQSiteTopNavOptions(patienten, uberDenTest);
		oiqDEWebcastsPage.clickHeaderOption(uberDenTest);
		verifySafely(oiqCHHomePage.getPageTitle().contains(uberDenTestPageTitle), true,
				"Page Heading displayed VALUE: '" + uberDenTestPageTitle + "'");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(uberDenTest), true,
				"'Über den Test' underlined displayed on the right panel");

		initialTime = "0:00";
		oiqDEWebcastsPage.clickVideoPlayer();
		Sleeper.sleepTightInSeconds(7);
		oiqDEWebcastsPage.switchToOIQVideoFrame();
		oiqDEWebcastsPage.oiqVideoHover();
		oiqDEWebcastsPage.oiqVideoHover();
		oiqDEWebcastsPage.clickPauseButton();
		finalTime = oiqDEWebcastsPage.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true, "Über den Test Page Video '" + uberDenTestVideo
				+ "' is played  successfully Initial Time = '" + initialTime + "' Final Time = '" + finalTime + "'");
		initialTime = oiqDEWebcastsPage.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true, "Über den Test Page Video '" + uberDenTestVideo
				+ "' is paused  successfully Initial Time = '" + initialTime + "' Final Time = '" + finalTime + "'");

		driver.refresh();
		oiqDEWebcastsPage.selectSubOptionFromOIQSiteTopNavOptions(patienten, tragtDieKosten);
		verifySafely(oiqCHHomePage.getPageTitle(), tragtDieKosten, "Page Heading displayed");

		initialTime = "0:00";
		oiqDEWebcastsPage.clickVideoPlayer();
		Sleeper.sleepTightInSeconds(7);
		oiqDEWebcastsPage.switchToOIQVideoFrame();
		oiqDEWebcastsPage.oiqVideoHover();
		oiqDEWebcastsPage.oiqVideoHover();
		oiqDEWebcastsPage.clickPauseButton();
		finalTime = oiqDEWebcastsPage.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Wer trägt die Kosten für den Test? Page Video '" + tragtDieKostenVideo
						+ "' is played  successfully Initial Time = '" + initialTime + "' Final Time = '" + finalTime
						+ "'");
		initialTime = oiqDEWebcastsPage.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true,
				"Wer trägt die Kosten für den Test? Page Video '" + tragtDieKostenVideo
						+ "' is paused  successfully Initial Time = '" + initialTime + "' Final Time = '" + finalTime
						+ "'");

		driver.refresh();
		oiqDEWebcastsPage.selectSubOptionFromOIQSiteTopNavOptions(patienten, gestellte);
		verifySafely(oiqCHHomePage.getPageTitle(), gestelltePageTitle, "Page Heading displayed");

		initialTime = "0:00";
		oiqDEWebcastsPage.clickVideoPlayer();
		Sleeper.sleepTightInSeconds(7);
		oiqDEWebcastsPage.switchToOIQVideoFrame();
		oiqDEWebcastsPage.oiqVideoHover();
		oiqDEWebcastsPage.oiqVideoHover();
		oiqDEWebcastsPage.clickPauseButton();
		finalTime = oiqDEWebcastsPage.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Fragen und Antworten sowie nützliche Informationen Page Video '" + gestellteVideo
						+ "' is played  successfully Initial Time = '" + initialTime + "' Final Time = '" + finalTime
						+ "'");
		initialTime = oiqDEWebcastsPage.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true,
				"Fragen und Antworten sowie nützliche Informationen Page Video '" + gestellteVideo
						+ "' is paused  successfully Initial Time = '" + initialTime + "' Final Time = '" + finalTime
						+ "'");

		logBlockHeader();
		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
