package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglHomepage;
import exact.ath.ogl.OglOrdersAndResultsPage;
import exact.ath.ogl.OglResourcePage;

/**
 * This class verifies the Resource Page of OGL website
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 07/03/2023
 */

public class OglResourcePageTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();
	private final OglResourcePage oglResourcePage = new OglResourcePage();
	private final OglOrdersAndResultsPage oglOrdersAndResultsPage = new OglOrdersAndResultsPage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String resources = oglPagesProperties.getProperty("resources");
	private final String orderingInformation = oglPagesProperties.getProperty("orderingInformation");
	private final String orderSupplies = oglPagesProperties.getProperty("orderSupplies");
	private final String forms = oglPagesProperties.getProperty("forms");
	private final String specimenCollection = oglPagesProperties.getProperty("specimenCollection");
	private final String implementationGuide = oglPagesProperties.getProperty("implementationGuide");
	private final String epicCare = oglPagesProperties.getProperty("epicCare");
	private final String advocacy = oglPagesProperties.getProperty("advocacy");
	private final String resourceURL = oglPagesProperties.getProperty("resourceURL");
	private final String supportingInformationNeedTitle = oglPagesProperties
			.getProperty("supportingInformationNeedTitle");
	private final String orderSuppliesOncoguardLiverTestTitle = oglPagesProperties
			.getProperty("orderSuppliesOncoguardLiverTestTitle");
	private final String oncoguardLiverTestRequisitionForm = oglPagesProperties
			.getProperty("oncoguardLiverTestRequisitionForm");
	private final String oncoguardLiverOrderRequisitionFormURL = oglPagesProperties
			.getProperty("oncoguardLiverOrderRequisitionFormURL");
	private final String downloadFormsHereTitle = oglPagesProperties.getProperty("downloadFormsHereTitle");
	private final String oncoguardLiverTestAdvanceBeneficiaryNoticeNoncoverage = oglPagesProperties
			.getProperty("oncoguardLiverTestAdvanceBeneficiaryNoticeNoncoverage");
	private final String oncoguardLiverTestAdvanceBeneficiaryNoticeNoncoverageURL = oglPagesProperties
			.getProperty("oncoguardLiverTestAdvanceBeneficiaryNoticeNoncoverageURL");
	private final String oncoguardLiverTestStatementMedicalNecessity = oglPagesProperties
			.getProperty("oncoguardLiverTestStatementMedicalNecessity");
	private final String oncoguardLiverTestStatementMedicalNecessityURL = oglPagesProperties
			.getProperty("oncoguardLiverTestStatementMedicalNecessityURL");
	private final String specimenCollectionOncoguardLiverTestTitle = oglPagesProperties
			.getProperty("specimenCollectionOncoguardLiverTestTitle");
	private final String specimenShippingGuide = oglPagesProperties.getProperty("specimenShippingGuide");
	private final String specimenShippingGuideURL = oglPagesProperties.getProperty("specimenShippingGuideURL");
	private final String downloadSpecimenCollectionGuide = oglPagesProperties
			.getProperty("downloadSpecimenCollectionGuide");
	private final String downloadSpecimenCollectionGuideURL = oglPagesProperties
			.getProperty("downloadSpecimenCollectionGuideURL");
	private final String implementingOncoguardLiverTestingPracticeTitle = oglPagesProperties
			.getProperty("implementingOncoguardLiverTestingPracticeTitle");
	private final String downloadImplementationGuide = oglPagesProperties.getProperty("downloadImplementationGuide");
	private final String downloadImplementationGuideURL = oglPagesProperties
			.getProperty("downloadImplementationGuideURL");
	private final String epicCareLinkURL = oglPagesProperties.getProperty("epicCareLinkURL");
	private final String advocacyURL = oglPagesProperties.getProperty("advocacyURL");
	private final String liverfoundation = oglPagesProperties.getProperty("liverfoundation");
	private final String theCommunityLiver = oglPagesProperties.getProperty("theCommunityLiver");
	private final String globalLiver = oglPagesProperties.getProperty("globalLiver");
	private final String americanLiverFoundationLinkURL = oglPagesProperties
			.getProperty("americanLiverFoundationLinkURL");
	private final String communityLiverAllianceURL = oglPagesProperties.getProperty("communityLiverAllianceURL");
	private final String globalLiverURL = oglPagesProperties.getProperty("globalLiverURL");
	private final String EpicCareLinkTMTitle = oglPagesProperties.getProperty("EpicCareLinkTMTitle");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglResourcePageTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of Resource Page of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");

		oglHomepage.hoverTopNavOption(resources);

		verifySafely(oglHomepage.isSubItemDisplayed(orderingInformation), true,
				"Sub item '" + orderingInformation + "' is displayed under '" + resources + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(orderSupplies), true,
				"Sub item '" + orderSupplies + "' is displayed under '" + resources + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(forms), true,
				"Sub item '" + forms + "' is displayed under '" + resources + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(specimenCollection), true,
				"Sub item '" + specimenCollection + "' is displayed under '" + resources + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(implementationGuide), true,
				"Sub item '" + implementationGuide + "' is displayed under '" + resources + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(epicCare), true,
				"Sub item '" + epicCare + "' is displayed under '" + resources + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(advocacy), true,
				"Sub item '" + advocacy + "' is displayed under '" + resources + "' header");

		driver.refresh();
		oglHomepage.clickTopNavOption(resources);
		verifySafely(driver.getURL(), resourceURL, "'Resource' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), supportingInformationNeedTitle,
				"'Supporting you with the test information you need' Title is displayed on the '" + resources
						+ "' page");

		oglResourcePage.clickResourceLink(orderSupplies);
		verifySafely(oglResourcePage.getOrderSuppliesOncoguardLiverTestHeading(), orderSuppliesOncoguardLiverTestTitle,
				"'Order supplies to perform the Oncoguard® Liver test' Title is displayed on the same page");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(orderSupplies), true, "'Order Supplies' is highlighted.");

		oglResourcePage.clickResourceLink(forms);
		verifySafely(oglResourcePage.getdownloadFormsHereHeading(), downloadFormsHereTitle,
				"'Download the forms you need here' Title is displayed on the same page");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(forms), true, "'Forms' is highlighted.");

		driver.refresh();
		oglResourcePage.clickOnIconCardsUnderDownloadTheFormsHereTitle(0, oncoguardLiverTestRequisitionForm);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncoguardLiverOrderRequisitionFormURL,
				"'Copy-of-GHI297_Rev-4_Oncoguard-Liver-Order-Requisition-Form_Fillable.pdf' pdf URL is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickOnIconCardsUnderDownloadTheFormsHereTitle(1,
				oncoguardLiverTestAdvanceBeneficiaryNoticeNoncoverage);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncoguardLiverTestAdvanceBeneficiaryNoticeNoncoverageURL,
				"'11427_Oncoguard_ABN_FRM_ENG_v1r1.pdf' pdf URL is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickOnIconCardsUnderDownloadTheFormsHereTitle(2, oncoguardLiverTestStatementMedicalNecessity);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncoguardLiverTestStatementMedicalNecessityURL,
				"'21_03_17_SOMN_Document_Fillable_vFinal-1.pdf' pdf URL is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickResourceLink(specimenCollection);
		verifySafely(oglResourcePage.getSpecimenCollectionOncoguardLiverTestHeading(),
				specimenCollectionOncoguardLiverTestTitle,
				"'Specimen collection for the Oncoguard® Liver test' Title is displayed on the same page");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(specimenCollection), true,
				"'Specimen Collection' is highlighted.");

		driver.refresh();
		oglResourcePage.clickBannerItemResource(specimenShippingGuide);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), specimenShippingGuideURL,
				"'14105_OGL_holidayshipping_guide_2023_v1r3.pdf' pdf URL is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickBannerItemResource(downloadSpecimenCollectionGuide);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadSpecimenCollectionGuideURL,
				"'OGL_Specimen_Collection_Guide.pdf' pdf URL is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickResourceLink(implementationGuide);
		verifySafely(oglResourcePage.getImplementingOncoguardLiverTestingPracticeHeading(),
				implementingOncoguardLiverTestingPracticeTitle,
				"'Implementing Oncoguard® Liver testing in your practice' Title is displayed on the same page");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(implementationGuide), true,
				"'Implementation Guide' is highlighted.");

		driver.refresh();
		oglResourcePage.clickBannerItemResource(downloadImplementationGuide);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadImplementationGuideURL,
				"'ogl-implementation-guide-lg00069hcp-digital-v1r1.pdf' pdf URL is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickResourceLink(epicCare);
		verifySafely(oglResourcePage.getEpicCareLinkHeading(), EpicCareLinkTMTitle,
				"'EpicCare® Link™' Title is displayed on the same page");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(epicCare), true, "'EpicCare® Link™' is highlighted.");

		driver.refresh();
		oglOrdersAndResultsPage.clickOnEpicCareLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), epicCareLinkURL, "'Epic Care Link' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickResourceLink(advocacy);
		verifySafely(driver.getURL(), advocacyURL, "'Advocacy' Page is displayed");

		oglResourcePage.clickOnLearnMoreButtonInAdvocacyPage(0, liverfoundation);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), americanLiverFoundationLinkURL, "'Liver Foundation ' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickOnLearnMoreButtonInAdvocacyPage(1, theCommunityLiver);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), communityLiverAllianceURL, "'Community Liver Alliance' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oglResourcePage.clickOnLearnMoreButtonInAdvocacyPage(2, globalLiver);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(globalLiverURL), true, "'Global Liver' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Verification done for Resource Page of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();

	}

}
