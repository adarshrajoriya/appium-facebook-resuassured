package exact.ath.sitecore.annualReport;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.sys.Driver;
import exact.util.BasicUtils;


/**
 * Refer User Story #300895
 * 
 * @author pusingh
 *
 */
public class AnnualReportsPageTest extends BasicIntTest {
	
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final Driver driver = new Driver();
	
	private final String annualReportLinkURL = exactPagesProperties.getProperty("AnnualReportLinkURL");
	private final String proxyStatementLinkURL = exactPagesProperties.getProperty("ProxyStatementLinkURL");
	private final String eSGReportLinkURL = exactPagesProperties.getProperty("2021ESGReportLinkURL");
	private final String virtualShareholderMeetingLinkURL = exactPagesProperties.getProperty("VirtualShareholderMeetingLinkURL");
	private final String proxyVoteLinkURL = exactPagesProperties.getProperty("ProxyVoteLinkURL");
	private final String contactUsLinkURL = exactPagesProperties.getProperty("ContactUsLinkURL");
	private final String facebookIconURL = exactPagesProperties.getProperty("FacebookIconURL");
	private final String twitterIconURL = exactPagesProperties.getProperty("TwitterIconURL");
	private final String linkedInIconURL = exactPagesProperties.getProperty("LinkedInIconURL");
	private final String virtualShareholderMeetingPageTittle = exactPagesProperties.getProperty("VirtualShareholderMeetingPageTittle");
	private final String proxyVoteLinkPageTittle = exactPagesProperties.getProperty("ProxyVoteLinkPageTittle");
	private final String contactUsLinkPageTittle = exactPagesProperties.getProperty("ContactUsLinkPageTittle");
	private final String facebookIconPageTittle = exactPagesProperties.getProperty("FacebookIconPageTittle");
	private final String twitterIconPageTittle = exactPagesProperties.getProperty("TwitterIconPageTittle");
	private final String linkedInIconPageTittle = exactPagesProperties.getProperty("LinkedInIconPageTittle");
	private final String loginUrl = exactPagesProperties.getProperty("AnnualReportURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}
	
	@Test
	public void annualReportsPageTest() {

		setupURL(loginUrl);
		verifySafely(annualReportsPage.isannualReportsPageDisplayed(), true, "'ANNUAL MEETING DETAILS' Page is displayed URL VALUE: '" + driver.getURL() + "'");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		verifySafely(annualReportsPage.isannualReportsPageDisplayed(), true, "Page title 'ANNUAL MEETING DETAILS' is displayed");
		verifySafely(annualReportsPage.isexactSciencesLogoDisplayed(), true, "'EXACT SCIENCES' logo on top left Page is displayed");
		verifySafely(annualReportsPage.isWhenCardDisplayed(), true, "'WHEN' Card is displayed on the page");
		verifySafely(annualReportsPage.isWhereCardDisplayed(), true, "'WHERE' Card is displayed on the page");
		verifySafely(annualReportsPage.isToVoteCardDisplayed(), true, "'TO VOTE' Card is displayed on the page");
		verifySafely(annualReportsPage.isAnnualReportDisplayed(), true, "'The Annual Report' link is displayed on the page");
		verifySafely(annualReportsPage.isProxyStatementDisplayed(), true, "'The Proxy Statement' link is displayed on the page");
		verifySafely(annualReportsPage.is2021ESGReportDisplayed(), true, "'The 2021 ESG Report' link is displayed on the page");
		verifySafely(annualReportsPage.isVirtualShareholderMeetingLink1Displayed(), true, "'virtualshareholdermeeting.com' Link is displayed under the 'WHERE' Card");
		verifySafely(annualReportsPage.isVirtualShareholderMeetingLink2Displayed(), true, "'virtualshareholdermeeting.com' Link is displayed under the 'TO VOTE' Card");
		verifySafely(annualReportsPage.isProxyVoteLinkDisplayed(), true, "'ProxyVote.com' Link is displayed under the 'TO VOTE' Card");
		verifySafely(annualReportsPage.isAnnualReportsPageFooterDisplayed(), true, "'Footer' is displayed under on the page Text Value : '" + annualReportsPage.getAnnualReportsPageFooterText() + "'");
		annualReportsPage.clickExactSciencesLogoLink();
		verifySafely(annualReportsPage.isannualReportsPageDisplayed(), true, "'ANNUAL MEETING DETAILS' Page is displayed after cliking 'Exact Sciences Logo' URL matches VALUE: '" + driver.getURL() + "'");		
		annualReportsPage.clickVirtualShareholderMeetingLink1();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), virtualShareholderMeetingPageTittle, "Opened 'virtualshareholdermeeting.com' link under 'WHERE' icon card");
		verifySafely(driver.getURL().contains(virtualShareholderMeetingLinkURL), true, "'virtualshareholdermeeting.com' Page URL matches VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		annualReportsPage.clickVirtualShareholderMeetingLink2();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), virtualShareholderMeetingPageTittle, "Opened 'virtualshareholdermeeting.com' link under 'TO VOTE' icon card'");
		verifySafely(driver.getURL().contains(virtualShareholderMeetingLinkURL), true, "'virtualshareholdermeeting.com' Page URL matches VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		annualReportsPage.clickProxyVoteLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), proxyVoteLinkPageTittle, "Opened 'ProxyVote.com' link under 'TO VOTE' icon card");
		verifySafely(driver.getURL().contains(proxyVoteLinkURL), true, "'ProxyVote.com' Page URL matches VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();		
		annualReportsPage.clickAnnualReportLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), annualReportLinkURL, "Opened 'Annual Report' and Page URL matches");
		logInfo("Screenshot of 'Annual Report' pdf placed at path : " + BasicUtils.takeScreenshot() + "");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		annualReportsPage.clickProxyStatementLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), proxyStatementLinkURL, "Opened 'ProxyStatement' and Page URL matches");
		logInfo("Screenshot of 'ProxyStatement' pdf placed at path : " + BasicUtils.takeScreenshot() + "");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		annualReportsPage.click2021ESGReportLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), eSGReportLinkURL, "Opened '2021ESGReport' and Page URL matches");
		logInfo("Screenshot of '2021ESGReport' pdf placed at path : " + BasicUtils.takeScreenshot() + "");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();		
		annualReportsPage.clickFacebookIcon();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle().contains(facebookIconPageTittle), true, "Clicked 'facebook' icon under FOLLOW US ON from the footer and 'Facebook' Page opened VALUE: '" + driver.getTitle() + "'");
		verifySafely(driver.getURL(), facebookIconURL, "'facebook' icon under FOLLOW US ON from the footer and 'Facebook' Page URL");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		annualReportsPage.clickTwitterIcon();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), twitterIconPageTittle, "Clicked 'Twitter' icon under FOLLOW US ON from the footer and 'Twitter' Page opened");
		verifySafely(driver.getURL(), twitterIconURL, "'Twitter' icon under FOLLOW US ON from the footer and 'Twitter' Page URL");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		annualReportsPage.clickLinkedInIcon();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), linkedInIconPageTittle, "Clicked 'Linkedin' icon under FOLLOW US ON from the footer and 'Linkedin' Page opened");
		verifySafely(driver.getURL().contains(linkedInIconURL), true, "'Linkedin' Page URL matches VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		annualReportsPage.clickContactUsLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), contactUsLinkPageTittle, "Opened 'Contact Us' link from the footer section");
		verifySafely(driver.getURL().contains(contactUsLinkURL), true, "'Contact Us' Page URL matches VALUE: '" + driver.getURL() + "'");
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}
}
