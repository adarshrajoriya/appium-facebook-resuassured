package exact.ath.sitecore.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.corporateUk.CorporateUkHomePage;

/**
 * This class verifies footer section of Corporate Uk Website
 * 
 * @userstory #304475 Task#307942
 * @author Tushar Gupta
 * @since 07/25/2023
 */
public class CorporateUkFooterTest extends BasicIntTest {

	private final CorporateUkHomePage corporateUkHomePage = new CorporateUkHomePage();
	private final String corporateUkHomePageURL = corporateUkPagesProperties.getProperty("corporateUkHomePageURL");
	private final String pageHeadingDisplayedCorporateUkHomePage = corporateUkPagesProperties
			.getProperty("pageHeadingDisplayedCorporateUkHomePage");
	private final String contactUsURL = corporateUkPagesProperties.getProperty("contactUsURL");
	private final String footerTextNames = corporateUkPagesProperties.getProperty("footerTextNames");
	private final String footerURL = corporateUkPagesProperties.getProperty("footerURL");
	private final String footerLinksNames = corporateUkPagesProperties.getProperty("footerLinksNames");
	private final String footerLinksURL = corporateUkPagesProperties.getProperty("footerLinksURL");
	private final String oncotypeDxURL = corporateUkPagesProperties.getProperty("oncotypeDxURL");
	private final String oncotypeDx = corporateUkPagesProperties.getProperty("oncotypeDx");

	private final String footerQuickLinksTextNames = corporateUkPagesProperties
			.getProperty("footerQuickLinksTextNames");
	private final String footerQuickLinksURL = corporateUkPagesProperties.getProperty("footerQuickLinksURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyCorporateUkFooterTest() throws Exception {
		setupURL(corporateUkHomePageURL);
		logInfo("Page URL : " + corporateUkHomePageURL + "");

		acceptCookiesCorporateUk();
		logInfo("----------------Starting verification of Footer section of Corpoarte UK Website------------");
		verifySafely(corporateUkHomePage.isCorporateUkHomepageDisplayed(), true, "Corporate Uk Homepage is displayed");
		verifySafely(corporateUkHomePage.getPageHeadingDisplayedHomePage(), pageHeadingDisplayedCorporateUkHomePage,
				"'PURSUING EARLIER DETECTION AND LIFE-CHANGING ANSWERS' Title is displayed on Home Page Of Corporate Uk website");

		corporateUkHomePage.clickContactUsLink();
		verifySafely(driver.getURL(), contactUsURL, "'Page URL matches'");

		verificationOfFooterLinks();

		corporateUkHomePage.clickFooterLink(oncotypeDx);
		verifySafely(driver.getURL(), oncotypeDxURL, "'Page URL matches'");
		logInfo("----------------Verification done for Footer section of Corpoarte UK Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

	private void verificationOfFooterLinks() throws Exception {

		String[] footerTextNamesArr = footerTextNames.split(",");
		String[] footerURLArr = footerURL.split(",");

		for (int count = 0; count < footerTextNamesArr.length; count++) {

			corporateUkHomePage.clickFooterLink(footerTextNamesArr[count]);
			corporateUkHomePage.clickAgreeButton();
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), footerURLArr[count], "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
			corporateUkHomePage.clickCloseButton();

		}

		String[] footerQuickLinksTextNamesArr = footerQuickLinksTextNames.split(",");
		String[] footerQuickLinksURLArr = footerQuickLinksURL.split(",");

		for (int count = 0; count < footerQuickLinksTextNamesArr.length; count++) {

			corporateUkHomePage.clickFooterLink(footerQuickLinksTextNamesArr[count]);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), footerQuickLinksURLArr[count], "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();

		}

		String[] footerLinksNamesArr = footerLinksNames.split(",");
		String[] footerLinksURLArr = footerLinksURL.split(",");

		for (int count = 0; count < footerLinksNamesArr.length; count++) {

			corporateUkHomePage.clickFooterLink(footerLinksNamesArr[count]);
			corporateUkHomePage.clickAgreeButton();
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL().contains(footerLinksURLArr[count]), true,
					"'" + footerLinksNamesArr[count] + "'Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
			corporateUkHomePage.clickCloseButton();

		}
	}

}
