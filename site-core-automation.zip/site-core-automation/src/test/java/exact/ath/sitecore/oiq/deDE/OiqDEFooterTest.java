package exact.ath.sitecore.oiq.deDE;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqDE.OiqDEHomePage;

/**
 * This class verifies OIQ Germany web site Footer components
 * 
 * @userstory #304475 Task#307772
 * @author Pushkar Singh
 * @since 08/06/2023
 */
public class OiqDEFooterTest extends BasicIntTest {

	private final OiqDEHomePage oiqDEHomePage = new OiqDEHomePage();
	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();

	private final String loginUrl = oiqdeDEPagesProperties.getProperty("oiqDEsiteURL");
	private final String oiqenCHPageTitle = oiqenCHPagesProperties.getProperty("oiqenCHPageTitle");
	private final String startseite = oiqdeDEPagesProperties.getProperty("startseite");
	private final String impressum = oiqdeDEPagesProperties.getProperty("impressum");
	private final String impressumPageURL = oiqdeDEPagesProperties.getProperty("impressumPageURL");
	private final String lizenzen = oiqdeDEPagesProperties.getProperty("lizenzen");
	private final String lizenzenPageURL = oiqdeDEPagesProperties.getProperty("lizenzenPageURL");
	private final String datenschutzrichtlinien = oiqdeDEPagesProperties.getProperty("datenschutzrichtlinien");
	private final String datenschutzrichtlinienPageURL = oiqdeDEPagesProperties
			.getProperty("datenschutzrichtlinienPageURL");
	private final String begriffeBedingungen = oiqdeDEPagesProperties.getProperty("begriffeBedingungen");
	private final String begriffeBedingungenPageURL = oiqdeDEPagesProperties.getProperty("begriffeBedingungenPageURL");
	private final String worldwideWebsites = oiqdeDEPagesProperties.getProperty("worldwideWebsites");
	private final String worldwideWebsitesPageURL = oiqdeDEPagesProperties.getProperty("worldwideWebsitesPageURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqDEFooterTest() throws Exception {

		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Deutschland Homepage URL '" + loginUrl + "'");

		oiqDEHomePage.clickTopNavOption(startseite);
		verifySafely(oiqCHHomePage.getOiqPageTitle(), oiqenCHPageTitle, "Page Heading displayed");

		oiqDEHomePage.clickTopNavOption(impressum);
		verifySafely(driver.getURL(), impressumPageURL, "Page Heading displayed");
		driver.back();

		oiqDEHomePage.clickTopNavOption(lizenzen);
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), lizenzenPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEHomePage.clickTopNavOption(datenschutzrichtlinien);
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), datenschutzrichtlinienPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEHomePage.clickTopNavOption(begriffeBedingungen);
		oiqCHHomePage.clickpopupbutton1("Ich stimme zu");

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), begriffeBedingungenPageURL, "Page URL Matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqDEHomePage.clickTopNavOption(worldwideWebsites);
		verifySafely(driver.getURL(), worldwideWebsitesPageURL, "Page Heading displayed");
		driver.back();

		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
