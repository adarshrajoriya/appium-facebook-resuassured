package exact.ath.sitecore.corporate;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.sys.Driver;

public class CorporateNewsroomPageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CorporateWebsiteTitleValue");
	private final String breastCancerFirstGrid = exactPagesProperties.getProperty("BreastCancerFirstGridURL");
	private final String multiCancerFirstGrid = exactPagesProperties.getProperty("MultiCancerFirstGridURL");
	private final String colorectalCancerFirstGrid = exactPagesProperties.getProperty("ColorectalCancerFirstGridURL");
	private final String liverCancerFirstGrid = exactPagesProperties.getProperty("LiverCancerFirstGridURL");
	private final String earlierDetectionFirstGrid = exactPagesProperties.getProperty("EarlierDetectionFirstGridURL");
	private final String healthEquityFirstGrid = exactPagesProperties.getProperty("HealthEquityFirstGridURL");
	private final String lifeAtExactFirstGrid = exactPagesProperties.getProperty("LifeAtExactFirstGridURL");
	private final String patientStoriesFirstGrid = exactPagesProperties.getProperty("PatientStoriesFirstGridURL");
	private final String pipelineFirstGrid = exactPagesProperties.getProperty("PipelineFirstGridURL");
	private final String smarterAnswersFirstGrid = exactPagesProperties.getProperty("SmarterAnswersFirstGridURL");
	private final String workflowSlide = exactPagesProperties.getProperty("WorkflowSlideURL");
	private final String testingSecurity = exactPagesProperties.getProperty("TestingSecurityURL");
	private final String exactSciencesAnnouncesPreliminary = exactPagesProperties
			.getProperty("ExactSciencesAnnouncesPreliminaryURL");
	private final String corporateFastFacts = exactPagesProperties.getProperty("CorporateFastFactsURL");
	private final String corporateOnepager = exactPagesProperties.getProperty("CorporateOnepagerURL");
	private final String theHarrisPollSurveyInfographic = exactPagesProperties
			.getProperty("TheHarrisPollSurveyInfographicURL");
	private final String loginUrl = exactPagesProperties.getProperty("CorporateWebURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void corporateNewsroomPageTest() {

		closeTheBrowser();
		setupURL(loginUrl);
		logBlockHeader();
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		corporateWebsite.clickNewsRoomMenuOption();
		verifySafely(corporateWebsite.isNewsroomPageDisplayed(), true, "'News Room' Page is displayed");
		verifySafely(corporateWebsite.isNewsroomHeadeHighlightedDisplayed(), true, "'News Room' Header is highlighted");
		corporateWebsite.hoverNewsroomMenuOption();
		verifySafely(corporateWebsite.isNewsStoriesHeaderHighlightedDisplayed(), true,
				"'News & Stories' Header is highlighted");
		verifySafely(corporateWebsite.isTestingNewTopicSlideDisplayed(), true,
				"'TESTING NEW TOPIC' Slide is displayed");
		corporateWebsite.clickNextButtonNewsRoom();
		verifySafely(corporateWebsite.isABreastCancerSurgeonsBreastCancerStorySlideDisplayed(), true,
				"'A Breast Cancer Surgeon's Breast Cancer Story' Slide is displayed");
		corporateWebsite.clickNextButtonNewsRoom();
		verifySafely(corporateWebsite.isTheTollofaDiagnosisSlideDisplayed(), true,
				"'The Toll of a Diagnosis' Slide is displayed");
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickTestingNewTopicSlideReadmore();
		verifySafely(corporateWebsite.isTestingNewTopicPageDisplayed(), true,
				"'Testing New Topic' titled Page is displayed");
		driver.back();
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickBreastCancerStorySlideReadmore();
		verifySafely(corporateWebsite.isBreastCancerStoryPageDisplayed(), true,
				"'A BREAST CANCER SURGEON'S BREAST CANCER STORY' titled Page is displayed");
		driver.back();
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickTheTollofaDiagnosisSlideReadmore();
		verifySafely(corporateWebsite.isTheTollofaDiagnosisPageDisplayed(), true,
				"'The Toll of a Diagnosis: A Candid Conversation on Life, Death, and Terminal Illness' titled Page is displayed");
		driver.back();
		driver.refresh();
		corporateWebsite.clickPressReleaseViewAll();
		verifySafely(corporateWebsite.isPressReleasePageDisplayed(), true, "'PRESS RELEASES' Page is displayed");
		corporateWebsite.hoverNewsroomMenuOption();
		verifySafely(corporateWebsite.isPressReleaseOptionHighlighted(), true,
				"'Press Releases' option is highlighted");
		driver.back();
		verifySafely(corporateWebsite.isPatientStoriesIconDisplayed(), true,
				"'Patient Stories' icon is displayed under 'Featured Topic' ");
		verifySafely(corporateWebsite.isBreastCancerIconDisplayed(), true,
				"'Breast Cancer' icon is displayed under 'Featured Topic' ");
		verifySafely(corporateWebsite.isSmarterAnswersIconDisplayed(), true,
				"'Smarter Answers' icon is displayed under 'Featured Topic' ");
		corporateWebsite.clickPatientStoriesIcon();
		verifySafely(corporateWebsite.isPatientStoriesIconHighlighted(), true,
				"'Patient Stories' option is highlighted under Topics");
		driver.back();
		corporateWebsite.clickBreastCancerIcon();
		verifySafely(corporateWebsite.isBreastCancerIconHighlighted(), true,
				"'Breast Cancer' option is highlighted under Cancer Types");
		driver.back();
		corporateWebsite.clickSmarterAnswersIcon();
		verifySafely(corporateWebsite.isSmarterAnswersIconHighlighted(), true,
				"'Smarter Answers' option is highlighted under Topics");
		driver.back();
		corporateWebsite.clickBreastCancerLink();
		verifySafely(corporateWebsite.isBreastCancerIconHighlighted(), true,
				"'Breast Cancer' option is highlighted under Cancer Types");
		verifySafely(corporateWebsite.isBreastCancerPagination(), true,
				"'Breast Cancer' Maximum pagination number is 1 ");
		corporateWebsite.clickBreastCancerFirstGrid();
		verifySafely(driver.getURL().contains(breastCancerFirstGrid), true,
				"'Breast Cancer First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isBreastCancerFirstGridPageDisplayed(), true,
				"'A BREAST CANCER SURGEONS BREAST CANCER STORY' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickMultiCancerLink();
		verifySafely(corporateWebsite.isMultiCancerLinkHighlighted(), true,
				"'Multi Cancer' option is highlighted under Cancer Types");
		verifySafely(corporateWebsite.isMultiCancerPagination(), true,
				"'Multi Cancer' Maximum pagination number is 1 ");
		corporateWebsite.clickMultiCancerFirstGrid();
		verifySafely(driver.getURL().contains(multiCancerFirstGrid), true,
				"'Multi Cancer First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isMultiCancerFirstGridPageDisplayed(), true,
				"'Exact Sciences Explains: Biomarkers' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickColorectalCancerLink();
		verifySafely(corporateWebsite.isColorectalCancerLinkHighlighted(), true,
				"'Colorectal Cancer' option is highlighted under Cancer Types");
		verifySafely(corporateWebsite.isColorectalCancerPagination(), true,
				"'Colorectal Cancer' Maximum pagination number is 3 ");
		corporateWebsite.clickColorectalCancerFirstGrid();
		verifySafely(driver.getURL().contains(colorectalCancerFirstGrid), true,
				"'Colorectal Cancer First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isColorectalCancerFirstGridPageDisplayed(), true,
				"'Dr. Paul Limburg’s Statement on the Recently Published NordICC Study in the ' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickLiverCancerLink();
		verifySafely(corporateWebsite.isLiverCancerLinkHighlighted(), true,
				"'Liver Cancer' option is highlighted under Cancer Types");
		verifySafely(corporateWebsite.isLiverCancerPagination(), true,
				"'Liver Cancer' Maximum pagination number is 1 ");
		corporateWebsite.clickLiverCancerFirstGrid();
		verifySafely(driver.getURL().contains(liverCancerFirstGrid), true,
				"'Liver Cancer First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isLiverCancerFirstGridPageDisplayed(), true,
				"'The Deadly Cancer That May Not Be on Your Radar' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickEarlierDetectionLink();
		verifySafely(corporateWebsite.isEarlierDetectionLinkHighlighted(), true,
				"'Earlier Detection' option is highlighted under Topics");
		verifySafely(corporateWebsite.isEarlierDetectionPagination(), true,
				"'Earlier Detection' Maximum pagination number is 5 ");
		corporateWebsite.clickEarlierDetectionFirstGrid();
		verifySafely(driver.getURL().contains(earlierDetectionFirstGrid), true,
				"'Earlier Detection First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isEarlierDetectionFirstGridPageDisplayed(), true,
				"'Exact Sciences Explains: FOCUS Program' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickHealthEquityLink();
		verifySafely(corporateWebsite.isHealthEquityLinkHighlighted(), true,
				"'Health Equity' option is highlighted under Topics");
		verifySafely(corporateWebsite.isHealthEquityPagination(), true,
				"'Health Equity' Maximum pagination number is 2 ");
		corporateWebsite.clickHealthEquityFirstGrid();
		verifySafely(driver.getURL().contains(healthEquityFirstGrid), true,
				"'Health Equity First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isHealthEquityFirstGridPageDisplayed(), true,
				"'Exact Sciences Explains: FOCUS Program' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickLifeAtExactLink();
		verifySafely(corporateWebsite.isLifeAtExactLinkHighlighted(), true,
				"'Life At Exact' option is highlighted under Topics");
		verifySafely(corporateWebsite.isLifeAtExactPagination(), true,
				"'Life At Exact' Maximum pagination number is 1 ");
		corporateWebsite.clickLifeAtExactFirstGrid();
		verifySafely(driver.getURL().contains(lifeAtExactFirstGrid), true,
				"'Life At Exact First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isLifeAtExactFirstGridPageDisplayed(), true,
				"'Testing new topic' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickPatientStoriesLink();
		verifySafely(corporateWebsite.isPatientStoriesLinkHighlighted(), true,
				"'Patient Stories' option is highlighted under Topics");
		verifySafely(corporateWebsite.isPatientStoriesPagination(), true,
				"'Patient Stories' Maximum pagination number is 2 ");
		corporateWebsite.clickPatientStoriesFirstGrid();
		verifySafely(driver.getURL().contains(patientStoriesFirstGrid), true,
				"'Patient Stories First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isPatientStoriesFirstGridPageDisplayed(), true,
				"'A Breast Cancer Surgeon's Breast Cancer Story' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickPipelineLink();
		verifySafely(corporateWebsite.isPipelineLinkHighlighted(), true,
				"'Pipeline' option is highlighted under Topics");
		verifySafely(corporateWebsite.isPipelinePagination(), true, "'Pipeline' Maximum pagination number is 2 ");
		corporateWebsite.clickPipelineFirstGrid();
		verifySafely(driver.getURL().contains(pipelineFirstGrid), true,
				"'Pipeline First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isPipelineFirstGridPageDisplayed(), true,
				"'3 KEY TAKEAWAYS FROM 6:45 AM AT ASCO' titled Page is displayed");
		driver.back();
		driver.back();
		corporateWebsite.clickSmarterAnswersLink();
		verifySafely(corporateWebsite.isSmarterAnswersLinkHighlighted(), true,
				"'Smarter Answers' option is highlighted under Topics");
		verifySafely(corporateWebsite.isSmarterAnswersPagination(), true,
				"'Smarter Answers' Maximum pagination number is 3 ");
		corporateWebsite.clickSmarterAnswersFirstGrid();
		verifySafely(driver.getURL().contains(smarterAnswersFirstGrid), true,
				"'Smarter Answers First Grid' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isSmarterAnswersFirstGridPageDisplayed(), true,
				"'Exact Sciences Explains: Cancer Moonshot' titled Page is displayed");
		corporateWebsite.hoverNewsroomMenuOption();
		corporateWebsite.clickPressReleaseOption();
		verifySafely(corporateWebsite.isPressReleasePageDisplayed(), true, "'PRESS RELEASES' Page is displayed");
		corporateWebsite.hoverNewsroomMenuOption();
		verifySafely(corporateWebsite.isPressReleaseOptionHighlighted(), true,
				"'Press Releases' option is highlighted ");
		verifySafely(corporateWebsite.isWorkflowSlideDisplayed(), true, "'Workflow' Slide is displayed");
		corporateWebsite.clickNextButtonNewsRoom();
		verifySafely(corporateWebsite.isTestingSecuritySlideDisplayed(), true, "'Testing Security' Slide is displayed");
		corporateWebsite.clickNextButtonNewsRoom();
		verifySafely(corporateWebsite.isExactSciencesAnnouncesPreliminarySlideDisplayed(), true,
				"'Exact Sciences Announces Preliminary Fourth Quarter 2022 Results' Slide is displayed");
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickWorkflowSlide();
		verifySafely(driver.getURL().contains(workflowSlide), true,
				"'WORKFLOW' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isWorkflowPageDisplayed(), true, "'WORKFLOW' titled Page is displayed");
		driver.back();
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickTestingSecuritySlide();
		verifySafely(driver.getURL().contains(testingSecurity), true,
				"'TESTING SECURITY' Page URL matches '" + driver.getURL() + "'");
		verifySafely(corporateWebsite.isTestingSecurityPageDisplayed(), true,
				"'TESTING SECURITY' titled Page is displayed");
		driver.back();
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickNextButtonNewsRoom();
		corporateWebsite.clickExactSciencesAnnouncesPreliminarySlide();
		verifySafely(driver.getURL().contains(exactSciencesAnnouncesPreliminary), true,
				"'EXACT SCIENCES ANNOUNCES PRELIMINARY FOURTH QUARTER 2022 RESULTS' Page URL matches '"
						+ driver.getURL() + "'");
		verifySafely(corporateWebsite.isExactSciencesAnnouncesPreliminaryPageDisplayed(), true,
				"'EXACT SCIENCES ANNOUNCES PRELIMINARY FOURTH QUARTER 2022 RESULTS' titled Page is displayed");
		driver.back();
		verifySafely(corporateWebsite.isPressReleasePagination(), true,
				"'Press Releases' Maximum pagination number is 24");
		verifySafely(corporateWebsite.isVideoIconDisplayed(), true, "'Video' Icon is displayed");
		verifySafely(corporateWebsite.isPhotosIconDisplayed(), true, "'Photos' Icon is displayed");
		corporateWebsite.clickVideoIcon();
		verifySafely(corporateWebsite.isMutimediaPageDisplayed(), true, "'MULTIMEDIA' titled Page is displayed");
		corporateWebsite.hoverNewsroomMenuOption();
		verifySafely(corporateWebsite.isMultimediaOptionHighlighted(), true, "'Multimedia' option is highlighted ");
		driver.back();
		corporateWebsite.clickPhotosIcon();
		corporateWebsite.hoverNewsroomMenuOption();
		verifySafely(corporateWebsite.isMultimediaOptionHighlighted(), true, "'Multimedia' option is highlighted ");
		verifySafely(corporateWebsite.isVideoSubsectionDisplayed(), true,
				"'Video' subsection  is displayed under multimedia page");
		verifySafely(corporateWebsite.isPhotosSubsectionDisplayed(), true,
				"'Photos' subsection  is displayed under multimedia page");
		corporateWebsite.clickFirstPhotosDownload();
		verifySafely(driver.getURL().contains(corporateFastFacts), true,
				"'Corporate Fast Facts' Page URL matches '" + driver.getURL() + "'");
		driver.back();
		corporateWebsite.clickSecondPhotosDownload();
		verifySafely(driver.getURL().contains(corporateOnepager), true,
				"'Corporate One-pager' Page URL matches '" + driver.getURL() + "'");
		driver.back();
		corporateWebsite.clickThirdPhotosDownload();
		verifySafely(driver.getURL().contains(theHarrisPollSurveyInfographic), true,
				"'The Harris Poll Survey Infographic' Page URL matches '" + driver.getURL() + "'");
		driver.back();
		corporateWebsite.clickExactSciencesLogo();
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
