package exact.ath.sitecore.corporate;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.sys.Driver;

/**
 * @author pusingh
 *
 */
public class CorporatePipelineDataPageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CorporateWebsiteTitleValue");
	private final String publicationsCardTittles = exactPagesProperties.getProperty("PublicationsCardTittlesValues");
	private final String exactacademyURL = exactPagesProperties.getProperty("ExactacademyURL");
	private final String lBGardBloodTubesSDSURL = exactPagesProperties.getProperty("LBGardBloodTubesSDSURL");
	private final String lBGardBloodTubesIFUURL = exactPagesProperties.getProperty("LBGardBloodTubesIFUURL");
	private final String firstName = exactPagesProperties.getProperty("FirstNameValue");
	private final String lastName = exactPagesProperties.getProperty("LastNameValue");
	private final String title = exactPagesProperties.getProperty("TitleValue");
	private final String companyInstitution = exactPagesProperties.getProperty("CompanyInstitutionValue");
	private final String address = exactPagesProperties.getProperty("AddressValue");
	private final String email = exactPagesProperties.getProperty("EmailValue");
	private final String areaOfFocus = exactPagesProperties.getProperty("AreaOfFocusValue");
	private final String comments = exactPagesProperties.getProperty("CommentsValue");
	private final String highlightedPublicationsSlide1Text = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide1TextValue");
	private final String highlightedPublicationsSlide2Text = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide2TextValue");
	private final String highlightedPublicationsSlide3Text = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide3TextValue");
	private final String highlightedPublicationsSlide4Text = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide4TextValue");
	private final String highlightedPublicationsSlide5Text = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide5TextValue");
	private final String highlightedPublicationsSlide6Text = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide6TextValue");
	private final String highlightedPublicationsSlide7Text = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide7TextValue");
	private final String highlightedPublicationsSlide1PdfURL = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide1PdfURL");
	private final String highlightedPublicationsSlide2PageURL = exactPagesProperties
			.getProperty("HighlightedPublicationsSlide2PageURL");
	private final String cancerType1Value = exactPagesProperties.getProperty("CancerType1Value");
	private final String cancerType2Value = exactPagesProperties.getProperty("CancerType2Value");
	private final String cancerType3Value = exactPagesProperties.getProperty("CancerType3Value");
	private final String productType1Value = exactPagesProperties.getProperty("ProductType1Value");
	private final String productType2Value = exactPagesProperties.getProperty("ProductType2Value");
	private final String publicationType1Value = exactPagesProperties.getProperty("PublicationType1Value");
	private final String publicationType2Value = exactPagesProperties.getProperty("PublicationType2Value");
	private final String publicationYear2Value = exactPagesProperties.getProperty("PublicationYear2Value");

	private final String pipelineDataIconCardsRow1 = exactPagesProperties.getProperty("PipelineDataIconCardsRow1");
	private final String clinicaltrialsURL = exactPagesProperties.getProperty("ClinicaltrialsURL");
	private final String clinicaltrialsURL2 = exactPagesProperties.getProperty("ClinicaltrialsURL2");

//	private final String pipelineDataIconCardsRow1 = exactPagesProperties.getProperty("PipelineDataIconCardsRow1");

	private final String loginUrl = exactPagesProperties.getProperty("CorporateWebURL");

	private int iconCardsCount = 0;
	private int viewCount = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void corporatePipelineDataPageTest() {

		closeTheBrowser();
		setupURL(loginUrl);
		logBlockHeader();
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(corporateWebsite.isBreastRadiationScorePageDisplayed(), true,
				"'BREAST RADIATION SCORE' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isBreastRadiationScoreOptionHighlighted(), true,
				"'Breast Radiation Score' is highlighted under the 'Pipeline & Data' header on the page");
		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(corporateWebsite.isCologuard2PageDisplayed(), true, "'COLOGUARD® 2.0' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isCologuard2OptionHighlighted(), true,
				"'Cologuard® 2.0' is highlighted under the 'Pipeline & Data' header on the page");
		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(corporateWebsite.isColorectalCancerBloodPageDisplayed(), true,
				"'COLORECTAL CANCER BLOOD' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isColorectalCancerBloodOptionHighlighted(), true,
				"'Colorectal Cancer Blood' is highlighted under the 'Pipeline & Data' header on the page");
		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(corporateWebsite.isLBgardBloodTubesPageDisplayed(), true,
				"'CONFIDENCE. DELIVERED.' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isLBgardBloodTubesOptionHighlighted(), true,
				"'LBgard® Blood Tubes' is highlighted under the 'Pipeline & Data' header on the page");

		corporateWebsite.clickSubmitButton();
		verifySafely(corporateWebsite.isLBGardBloodTubesSDSButtonDisplayed(), true,
				"'LBGard Blood Tubes SDS' Button is displayed on the page");
		corporateWebsite.clickLBGardBloodTubesSDSButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(lBGardBloodTubesSDSURL), true,
				"'LBGard Blood Tubes SDS' pdf Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		verifySafely(corporateWebsite.isLBGardBloodTubesIFUButtonDisplayed(), true,
				"'LBGard Blood Tubes SDS' Button is displayed on the page");
		corporateWebsite.clickLBGardBloodTubesIFUButtonButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(lBGardBloodTubesIFUURL), true,
				"'LBGard Blood Tubes IFU' pdf Page URL matches '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		verifySafely(corporateWebsite.isLBgardBloodTubesPageDisplayed(), true,
				"'CONFIDENCE. DELIVERED.' Page is displayed");
		corporateWebsite.clickSubmitButton();
		verifySafely(corporateWebsite.isMandatoryFieldsDisplayed(), true,
				"'Please fill out this required field' message for Mandatory Fields is displayed on the page");

		corporateWebsite.enterFirstName(firstName);
		logInfo("Entered First Name '" + firstName + "'");
		corporateWebsite.enterLastName(lastName);
		logInfo("Entered Last Name '" + lastName + "'");
		corporateWebsite.enterTitle(title);
		logInfo("Entered Title '" + title + "'");
		corporateWebsite.enterCompanyInstitution(companyInstitution);
		logInfo("Entered Company/Institution '" + companyInstitution + "'");
		corporateWebsite.enterAddress(address);
		logInfo("Entered Address '" + address + "'");
		corporateWebsite.enterEmail(email);
		logInfo("Entered Email '" + email + "'");
		corporateWebsite.enterAreaOfFocus(areaOfFocus);
		logInfo("Entered Area of Focus '" + areaOfFocus + "'");
		corporateWebsite.enterComments(comments);
		logInfo("Entered Comments '" + comments + "'");

		corporateWebsite.clickSubmitButton();
		verifySafely(corporateWebsite.isThankYouMessageDisplayed(), true,
				"'Thank you' message is displayed on the page");
		driver.refresh();
		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(corporateWebsite.isMolecularResidualDiseasePageDisplayed(), true,
				"'MOLECULAR RESIDUAL DISEASE' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isMolecularResidualDiseaseOptionHighlighted(), true,
				"'Molecular Residual Disease' is highlighted under the 'Pipeline & Data' header on the page");
		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(corporateWebsite.isMultiCancerEarlyDetectionPageDisplayed(), true,
				"'MULTI-CANCER EARLY DETECTION(MCED) TEST' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isMultiCancerEarlyDetectionOptionHighlighted(), true,
				"'Multi-Cancer Early Detection' is highlighted under the 'Pipeline & Data' header on the page");
		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(driver.getURL(), exactacademyURL, "Opened 'EXACT ACADEMY' Page and URL matches");
		driver.back();

		iconCardsCount++;
		corporateWebsite.clickPipelineDataIconCardLearmMoreLink(iconCardsCount);
		verifySafely(corporateWebsite.isPublicationsAndAbstractsPageDisplayed(), true,
				"'PUBLICATIONS & ABSTRACTS' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();

		verifySafely(corporateWebsite.isPublicationsAndAbstractsOptionHighlighted(), true,
				"'Publications & Abstracts' is highlighted under the 'Pipeline & Data' header on the page");

		verifySafely(corporateWebsite.getHighlightedPublicationsSlide1Text(), highlightedPublicationsSlide1Text,
				"Highlighted publications Slide 1");
		corporateWebsite.clickViewSlideLink();
		verifySafely(driver.getURL().contains(highlightedPublicationsSlide1PdfURL), true,
				"Opened 'pdf' Page and URL matches VALUE: '" + driver.getURL() + "'");
		driver.back();
		corporateWebsite.clickNextArrowSign();
		verifySafely(corporateWebsite.getHighlightedPublicationsSlide2Heading(), highlightedPublicationsSlide2Text,
				"Highlighted publications Slide 2");
		corporateWebsite.clickViewSlideLink2();
		verifySafely(driver.getURL(), highlightedPublicationsSlide2PageURL,
				"Opened 'Highlighted publications Slide 2' Page and URL matches");
		driver.back();
		corporateWebsite.clickNextArrowSign();

		corporateWebsite.clickNextArrowSign();
		verifySafely(corporateWebsite.getHighlightedPublicationsSlide3Heading(), highlightedPublicationsSlide3Text,
				"Highlighted publications Slide 3");
		corporateWebsite.clickNextArrowSign();
		verifySafely(corporateWebsite.getHighlightedPublicationsSlide4Heading(), highlightedPublicationsSlide4Text,
				"Highlighted publications Slide 4");
		corporateWebsite.clickNextArrowSign();
		verifySafely(corporateWebsite.getHighlightedPublicationsSlide5Heading(), highlightedPublicationsSlide5Text,
				"Highlighted publications Slide 5");
		corporateWebsite.clickNextArrowSign();
		verifySafely(corporateWebsite.getHighlightedPublicationsSlide6Heading(), highlightedPublicationsSlide6Text,
				"Highlighted publications Slide 6");
		corporateWebsite.clickNextArrowSign();
		verifySafely(corporateWebsite.getHighlightedPublicationsSlide7Heading(), highlightedPublicationsSlide7Text,
				"Highlighted publications Slide 7");
		corporateWebsite.clickNextArrowSign();

		corporateWebsite.clickViewAllPublicationsAbstractsLink();
		corporateWebsite.clickSelectCancerTypeLabel();
		corporateWebsite.selectAdvancedCancerOption();
		verifySafely(corporateWebsite.getCurrentFilterValue().contains(cancerType1Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");
		verifySafely(corporateWebsite.isPublicationAdvancedCancerTypeDisplayed(), true,
				"'Advanced Cancer' is displayed at the top right corner of the publications");

		corporateWebsite.clickResetAllFilterButton();
		corporateWebsite.clickSelectCancerTypeLabel();
		corporateWebsite.selectBreastCancerOption();

		verifySafely(corporateWebsite.getCurrentFilterValue().contains(cancerType2Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");
		verifySafely(corporateWebsite.isPublicationBreastCancerTypeDisplayed(), true,
				"'Breast Cancer' is displayed at the top right corner of the publications");

		corporateWebsite.clickResetAllFilterButton();
		corporateWebsite.clickSelectProductLabel();
		corporateWebsite.selectOncotypeDXBreastRecurrenceScoreTestOption();

		verifySafely(corporateWebsite.getCurrentFilterValue().contains(productType1Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");
		verifySafely(corporateWebsite.isPublicationBreastCancerTypeDisplayed(), true,
				"'Breast Cancer' is displayed at the top right corner of the publications");

		corporateWebsite.clickResetAllFilterButton();
		corporateWebsite.clickSelectProductLabel();
		corporateWebsite.selectOncotypeDXGenomicProstateScoreTestOption();

		verifySafely(corporateWebsite.getCurrentFilterValue().contains(productType2Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");
		verifySafely(corporateWebsite.isPublicationProstateCancerTypeDisplayed(), true,
				"'Prostate Cancer' is displayed at the top right corner of the publications");

		corporateWebsite.clickResetAllFilterButton();
		corporateWebsite.clickSelectPublicationLabel();
		corporateWebsite.selectPublicationTypeAbstractOption();

		verifySafely(corporateWebsite.getCurrentFilterValue().contains(publicationType1Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");
		verifySafely(corporateWebsite.isPublicationTypeAbstractDisplayed(), true,
				"'Abstract' is displayed at the top right corner of the publications");

		corporateWebsite.clickResetAllFilterButton();
		corporateWebsite.clickSelectPublicationLabel();
		corporateWebsite.selectPublicationTypeManuscriptOption();

		verifySafely(corporateWebsite.getCurrentFilterValue().contains(publicationType2Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");
		verifySafely(corporateWebsite.isPublicationTypeManuscriptDisplayed(), true,
				"'Manuscript' is displayed at the top right corner of the publications");

		corporateWebsite.clickResetAllFilterButton();
		corporateWebsite.clickSelectPublicationYearLabel();
		corporateWebsite.selectPublicationYear2022Option();

		verifySafely(corporateWebsite.getCurrentFilterValue().contains(publicationYear2Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");
		verifySafely(corporateWebsite.isPublicationYear2022Displayed(), true,
				"'2022' year is displayed under publication title");

		driver.back();

		verifySafely(corporateWebsite.isPublicationsAndAbstractsPageDisplayed(), true,
				"'PUBLICATIONS & ABSTRACTS' Page is displayed");

		viewCount = 0;
		for (String publicationsCardTittle : publicationsCardTittles.split(",")) {
			viewCount++;
			verifySafely(corporateWebsite.getPublicationsCardTittle(viewCount).contains(publicationsCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '"
							+ corporateWebsite.getPublicationsCardTittle(viewCount) + "'");

		}

		viewCount = 1;
		corporateWebsite.clickPublicationsCardTittle(viewCount);
		verifySafely(corporateWebsite.getCurrentFilterValue().contains(cancerType3Value), true,
				"Applied Filter VALUE: '" + corporateWebsite.getCurrentFilterValue() + "'");

		corporateWebsite.hoverPipelineMenuOption();
		corporateWebsite.clickClinicalStudiesOption();
		verifySafely(corporateWebsite.isClinicalStudiesPageDisplayed(), true, "'CLINICAL STUDIES' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isClinicalStudiesOptionHighlighted(), true,
				"'Clinical Studies' is highlighted under the 'Pipeline & Data' header on the page");

		corporateWebsite.clickColorectalCancerScreeningTab();
		verifySafely(corporateWebsite.isColorectalCancerScreeningTabSelected(), true,
				"'COLORECTAL CANCER SCREENING' Tab is selected on the page");
		corporateWebsite.clickCompassNowEnrollingButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), clinicaltrialsURL, "Compass 'Now Enrolling' Button navigated to");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		corporateWebsite.clickDiagnosedColorectalCancerTab();
		verifySafely(corporateWebsite.isDiagnosedColorectalCancerTabSelected(), true,
				"'DIAGNOSED COLORECTAL CANCER' Tab is selected on the page");
		corporateWebsite.clickCompassNowEnrollingButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), clinicaltrialsURL2, "Compass 'Now Enrolling' Button navigated to");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		corporateWebsite.clickMultiCancerScreeningTab();
		verifySafely(corporateWebsite.isMultiCancerCancerScreeningTabSelected(), true,
				"'MULTI-CANCER SCREENING' Tab is selected on the page");
		verifySafely(corporateWebsite.isComingSoonCardDisplayed(), true, "'COMING SOON' Card is displayed on the page");

		corporateWebsite.hoverPipelineMenuOption();
		corporateWebsite.clickResearchOption();
		verifySafely(corporateWebsite.isResearchPageDisplayed(), true,
				"'RESEARCH GRANTS AND COLLABORATIONS' Page is displayed");
		corporateWebsite.hoverPipelineMenuOption();
		verifySafely(corporateWebsite.isResearchOptionHighlighted(), true,
				"'Research' is highlighted under the 'Pipeline & Data' header on the page");
		corporateWebsite.clickAboutUsLink();
		verifySafely(corporateWebsite.isAboutUsPageDisplayed(), true,
				"'ABOUT US' Page is displayed after clicking About Us hyperlink");

		corporateWebsite.clickPipelineMenuOption();
		verifySafely(corporateWebsite.isPipelineDataPageDisplayed(), true, "'PIPELINE & DATA' Page is displayed");
		verifySafely(corporateWebsite.isPipelineDataHeadeHighlightedDisplayed(), true,
				"'Pipeline & Data' header is highlighted on the page");

		corporateWebsite.clickExactSciencesLogo();
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");

		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
