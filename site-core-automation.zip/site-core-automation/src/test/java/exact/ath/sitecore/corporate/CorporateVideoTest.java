package exact.ath.sitecore.corporate;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.sys.Driver;
import exact.util.Sleeper;

public class CorporateVideoTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CorporateWebsiteTitleValue");
	private final String mutimediaVideosNames = exactPagesProperties.getProperty("MutimediaVideosNames");
	private final String loginUrl = exactPagesProperties.getProperty("CorporateWebURL");

	String initialTime;
	String finalTime;
	private int count = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void corporateVideoTest() {

		closeTheBrowser();
		setupURL(loginUrl);
		logBlockHeader();
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		initialTime = corporateWebsite.getVideoTime();
		corporateWebsite.clickPlayButton();
		Sleeper.sleepTightInSeconds(7);
		corporateWebsite.videoHover();
		corporateWebsite.clickPauseButton();
		finalTime = corporateWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true, "HomePage Video is played  successfully Initial Time = '"
				+ initialTime + "' Final Time = '" + finalTime + "'");
		initialTime = corporateWebsite.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true, "HomePage Video is paused  successfully Initial Time = '"
				+ finalTime + "' Final Time = '" + initialTime + "'");

		corporateWebsite.hoverAboutMenuOption();
		corporateWebsite.clickOurCollaborationsOption();
		verifySafely(corporateWebsite.isOurCollaborationsPageDisplayed(), true,
				"'Our Collaborations' titled Page is displayed");
		corporateWebsite.clickPlayButton();
		initialTime = corporateWebsite.getVideoTime();
		initialTime = "0:00";
		Sleeper.sleepTightInSeconds(7);
		corporateWebsite.videoHover();
		corporateWebsite.clickPauseButton();
		finalTime = corporateWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Our Collaborations Page Video is played  successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		initialTime = corporateWebsite.getVideoTime();

		verifySafely(initialTime.equals(finalTime), true,
				"Our Collaborations Page Video is paused  successfully Initial Time = '" + finalTime
						+ "' Final Time = '" + initialTime + "'");
		corporateWebsite.hoverPipelineMenuOption();
		corporateWebsite.clickMultiCancerEarlyDetection();
		verifySafely(corporateWebsite.isMultiCancerEarlyDetectionPageDisplayed(), true,
				"'Multi Cancer Early Detection' titled Page is displayed");

		corporateWebsite.clickMultiCancerVideoPlayButton();
		initialTime = corporateWebsite.getVideoTime();
		initialTime = "0:00";
		Sleeper.sleepTightInSeconds(7);
		corporateWebsite.videoHover();
		corporateWebsite.clickPauseButton();
		finalTime = corporateWebsite.getVideoTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Multi Cancer Early Detection' Page Video is played  successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		initialTime = corporateWebsite.getVideoTime();
		verifySafely(initialTime.equals(finalTime), true,
				"Multi Cancer Early Detection' Page Video is paused  successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		driver.refresh();

		corporateWebsite.hoverNewsroomMenuOption();
		corporateWebsite.clickMultimediaOption();
		verifySafely(corporateWebsite.isMutimediaPageDisplayed(), true, "'MULTIMEDIA' titled Page is displayed");

		count = 0;
		for (String mutimediaVideosName : mutimediaVideosNames.split(",")) {
			count++;
			initialTime = corporateWebsite.getVideoTime(count);
			initialTime = "0:00";
			corporateWebsite.clickPlayButton(count);
			Sleeper.sleepTightInSeconds(7);
			corporateWebsite.videoHover(count);
			corporateWebsite.clickPauseButton();
			finalTime = corporateWebsite.getVideoTime(count);
			verifySafely(!initialTime.equals(finalTime), true,
					"MULTIMEDIA Page Video '" + mutimediaVideosName + "' is played  successfully Initial Time = '"
							+ initialTime + "' Final Time = '" + finalTime + "'");
			initialTime = corporateWebsite.getVideoTime();
			verifySafely(initialTime.equals(finalTime), true,
					"MULTIMEDIA Page Video '" + mutimediaVideosName + "' is paused  successfully Initial Time = '"
							+ initialTime + "' Final Time = '" + finalTime + "'");
			driver.refresh();

		}

		corporateWebsite.clickExactSciencesLogo();
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
