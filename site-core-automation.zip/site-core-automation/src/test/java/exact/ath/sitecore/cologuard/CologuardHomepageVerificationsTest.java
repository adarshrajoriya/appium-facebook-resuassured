package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.util.PostStatusToZephyr;

/**
 * This class verifies Cologuard home page verifications
 * 
 * @userstory #303911 Task#303959
 * @author Sandeep Singh
 * @since 04/27/2023
 */
public class CologuardHomepageVerificationsTest extends BasicIntTest {

	private final String cologuardHomePageURL = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	private final String visitProfHeathCareSiteURL = cologuardPagesProperties.getProperty("visitProfHeathCareSiteURL");
	private final String impRiskInfoURL = cologuardPagesProperties.getProperty("impRiskInfoURL");
	private final String faqsURL = cologuardPagesProperties.getProperty("faqsURL");
	private final String signUpForInfoURL = cologuardPagesProperties.getProperty("signUpForInfoURL");
	private final String getCologuardURL = cologuardPagesProperties.getProperty("getCologuardURL");
	private final String loginPageURL = cologuardPagesProperties.getProperty("loginPageURL");
	private final String whyStartAt45URL = cologuardPagesProperties.getProperty("whyStartAt45URL");
	private final String requestNowURL = cologuardPagesProperties.getProperty("requestNowURL");
	private final String returningYourKitURL = cologuardPagesProperties.getProperty("returningYourKitURL");
	private final String aboutScreeningPageURL = cologuardPagesProperties.getProperty("aboutScreeningPageURL");
	private final String howToGetCologuardPageURL = cologuardPagesProperties.getProperty("howToGetCologuardPageURL");

	private final String visitProfHeathCareSite = cologuardPagesProperties.getProperty("visitProfHeathCareSite");
	private final String whyCologuard = cologuardPagesProperties.getProperty("whyCologuard");
	private final String getCologuard = cologuardPagesProperties.getProperty("getCologuard");
	private final String useCologuard = cologuardPagesProperties.getProperty("useCologuard");
	private final String insuranceAndBilling = cologuardPagesProperties.getProperty("insuranceAndBilling");

	private final String aboutScreening = cologuardPagesProperties.getProperty("aboutScreening");
	private final String startScreeningAt45 = cologuardPagesProperties.getProperty("startScreeningAt45");
	private final String cologuardDifference = cologuardPagesProperties.getProperty("cologuardDifference");
	private final String effectiveAndEasyToUse = cologuardPagesProperties.getProperty("effectiveAndEasyToUse");
	private final String affordable = cologuardPagesProperties.getProperty("affordable");
	private final String patientStories = cologuardPagesProperties.getProperty("patientStories");
	private final String collectingAndReturningSamples = cologuardPagesProperties
			.getProperty("collectingAndReturningSamples");

	private final String understandingYourResult = cologuardPagesProperties.getProperty("understandingYourResult");
	private final String resourcesAndSupport = cologuardPagesProperties.getProperty("resourcesAndSupport");
	private final String insurance = cologuardPagesProperties.getProperty("insurance");
	private final String appealAClaim = cologuardPagesProperties.getProperty("appealAClaim");
	private final String payABill = cologuardPagesProperties.getProperty("payABill");

	private final String screening = cologuardPagesProperties.getProperty("screening");
	private final String results = cologuardPagesProperties.getProperty("results");
	private final String cost = cologuardPagesProperties.getProperty("cost");
	private final String howToUse = cologuardPagesProperties.getProperty("howToUse");
	private final String howToGetCologuard = cologuardPagesProperties.getProperty("howToGetCologuard");

	private final String loginToOrderAndTrack = cologuardPagesProperties.getProperty("loginToOrderAndTrack");
	private final String returningYourKit = cologuardPagesProperties.getProperty("returningYourKit");
	private final String howToGetCologuardBannerItem = cologuardPagesProperties
			.getProperty("howToGetCologuardBannerItem");
	private final String aboutScreeningBannerItem = cologuardPagesProperties.getProperty("aboutScreeningBannerItem");

	private final String impRiskInfo = cologuardPagesProperties.getProperty("impRiskInfo");
	private final String FAQs = cologuardPagesProperties.getProperty("FAQs");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T714";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyCologuardHomepageLinksTest() throws Exception {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");
		acceptCookies();

		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		cologuardHomepage.clickLinkOnPage(visitProfHeathCareSite);
		verifySafely(driver.getURL(), visitProfHeathCareSiteURL, "'Cologuard HCP' Site is displayed");
		driver.back();

		cologuardHomepage.clickLinkOnPage(impRiskInfo);
		verifySafely(driver.getURL(), impRiskInfoURL, "'Important Risk Information' page is displayed");
		driver.back();

		cologuardHomepage.clickLinkOnPage(FAQs);
		verifySafely(driver.getURL(), faqsURL, "'FAQs' page is displayed");
		driver.back();

		cologuardHomepage.clickSignUpForInformation();
		verifySafely(driver.getURL(), signUpForInfoURL, "'Sign up for Information' page is displayed");

		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(whyCologuard), true,
				"Header option '" + whyCologuard + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(getCologuard), true,
				"Header option '" + getCologuard + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(useCologuard), true,
				"Header option '" + useCologuard + "' is displayed on home page");
		verifySafely(cologuardHomepage.isHeaderOptionDisplayed(insuranceAndBilling), true,
				"Header option '" + insuranceAndBilling + "' is displayed on home page");
		verifySafely(cologuardHomepage.isSearchIconAndBoxDisplayed(), true, "Search Icon is displayed on home page");
		verifySafely(cologuardHomepage.isLoginBtnDisplayed(), true, "'Log In' button is displayed on the home page");

		driver.back();

		cologuardHomepage.clickCologuardIcon();
		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true,
				"Cologuard homepage is displayed after clicking the Cologuard icon on homepage");

		driver.switchToParentWindow();

		cologuardHomepage.clickTopNavOption(whyCologuard);
		verifySafely(cologuardHomepage.isSubItemDisplayed(aboutScreening), true,
				"Sub item '" + aboutScreening + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(startScreeningAt45), true,
				"Sub item '" + startScreeningAt45 + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(cologuardDifference), true,
				"Sub item '" + cologuardDifference + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(effectiveAndEasyToUse), true,
				"Sub item '" + effectiveAndEasyToUse + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(affordable), true,
				"Sub item '" + affordable + "' is displayed under 'Why Cologuard?' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(patientStories), true,
				"Sub item '" + patientStories + "' is displayed under 'Why Cologuard?' item");

		cologuardHomepage.clickTopNavOption(getCologuard);
		verifySafely(driver.getURL(), getCologuardURL, "'Get Cologuard' page is displayed");

		driver.back();

		cologuardHomepage.clickTopNavOption(useCologuard);
		verifySafely(cologuardHomepage.isSubItemDisplayed(collectingAndReturningSamples), true,
				"Sub item '" + collectingAndReturningSamples + "' is displayed under 'Use Cologuard' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(understandingYourResult), true,
				"Sub item '" + understandingYourResult + "' is displayed under 'Use Cologuard' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(resourcesAndSupport), true,
				"Sub item '" + resourcesAndSupport + "' is displayed under 'Use Cologuard' item");

		cologuardHomepage.clickTopNavOption(insuranceAndBilling);
		verifySafely(cologuardHomepage.isSubItemDisplayed(insurance), true,
				"Sub item '" + insurance + "' is displayed under 'Insurance & Billing' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(appealAClaim), true,
				"Sub item '" + appealAClaim + "' is displayed under 'Insurance & Billing' item");
		verifySafely(cologuardHomepage.isSubItemDisplayed(payABill), true,
				"Sub item '" + payABill + "' is displayed under 'Insurance & Billing' item");

		cologuardHomepage.clickSearchIcon();
		verifySafely(cologuardHomepage.isSearchIconAndBoxDisplayed(), true, "Search box is displayed");
		verifySafely(cologuardHomepage.isPopularSearchItemDisplayed(screening), true,
				"'" + screening + "' is displayed under popular searches");
		verifySafely(cologuardHomepage.isPopularSearchItemDisplayed(results), true,
				"'" + results + "' is displayed under popular searches");
		verifySafely(cologuardHomepage.isPopularSearchItemDisplayed(cost), true,
				"'" + cost + "' is displayed under popular searches");
		verifySafely(cologuardHomepage.isPopularSearchItemDisplayed(howToUse), true,
				"'" + howToUse + "' is displayed under popular searches");
		verifySafely(cologuardHomepage.isPopularSearchItemDisplayed(howToGetCologuard), true,
				"'" + howToGetCologuard + "' is displayed under popular searches");

		cologuardHomepage.clickLoginButton();
		verifySafely(driver.getURL(), loginPageURL, "'Login Page' is displayed");

		driver.switchToParentWindow();

		cologuardHomepage.clickWhyStartAt45();
		verifySafely(driver.getURL(), whyStartAt45URL, "'Why Start at 45?' page is displayed");

		driver.back();
		cologuardHomepage.clickRequestNow();
		verifySafely(driver.getURL(), requestNowURL, "'Request Now' page is displayed");

		driver.back();

		verifySafely(cologuardHomepage.isBannerItemDisplayed(loginToOrderAndTrack), true,
				"'" + loginToOrderAndTrack.replace("\n", "") + "' is displayed in Banner below slides");
		verifySafely(cologuardHomepage.isBannerItemDisplayed(returningYourKit), true,
				"'" + returningYourKit.replace("\n", "") + "' is displayed in Banner below slides");
		verifySafely(cologuardHomepage.isBannerItemDisplayed(howToGetCologuardBannerItem), true,
				"'" + howToGetCologuard + "' is displayed in Banner below slides");
		verifySafely(cologuardHomepage.isBannerItemDisplayed(aboutScreeningBannerItem), true,
				"'" + aboutScreening + "' is displayed in Banner below slides");

		acceptCookies();
		cologuardHomepage.clickBannerItem(loginToOrderAndTrack);

		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), loginPageURL, "'Login Page' is displayed");
		driver.switchToParentWindow();

		cologuardHomepage.clickBannerItem(returningYourKit);
		verifySafely(driver.getURL(), returningYourKitURL, "'Returning your kit' page is displayed");

		driver.back();

		cologuardHomepage.clickBannerItem(howToGetCologuardBannerItem);
		verifySafely(driver.getURL(), howToGetCologuardPageURL, "'How to get Cologuard' page is displayed");

		driver.back();

		cologuardHomepage.clickBannerItem(aboutScreeningBannerItem);
		verifySafely(driver.getURL(), aboutScreeningPageURL, "'About screening' page is displayed");

		driver.back();

		driver.close();

		throwAssertionErrorOnFailure();
	}

}
