package exact.ath.sitecore.career;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;

public class CareerWebsiteTest extends BasicIntTest {

	private final CareerHomePageTest careerHomePageTest = new CareerHomePageTest();
	private final CareerWhyExactSciencesTest careerWhyExactSciencesTest = new CareerWhyExactSciencesTest();
	private final CareerLifeAtExactTest careerLifeAtExactTest = new CareerLifeAtExactTest();
	private final CareerLocationsTest careerLocationsTest = new CareerLocationsTest();
	private final CareerBenefitsTest careerBenefitsTest = new CareerBenefitsTest();
	private final CareerCurrentOpeningsTest careerCurrentOpeningsTest = new CareerCurrentOpeningsTest();
	private final CareerFooterTest careerFooterTest = new CareerFooterTest();
	private final CareerVideoTest careerVideoTest = new CareerVideoTest();

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test(priority = 1)
	public void careerHomePageTest() {

		careerHomePageTest.careerHomePageTest();

	}

	@Test(priority = 2)
	public void careerWhyExactSciencesTest() {

		careerWhyExactSciencesTest.careerWhyExactSciencesTest();

	}

	@Test(priority = 3)
	public void careerLifeAtExactTest() {

		careerLifeAtExactTest.careerLifeAtExactTest();

	}

	@Test(priority = 4)
	public void careerLocationsTest() {

		careerLocationsTest.careerLocationsTest();

	}

	@Test(priority = 5)
	public void careerBenefitsTest() {

		careerBenefitsTest.careerBenefitsTest();

	}

	@Test(priority = 6)
	public void careerCurrentOpeningsTest() {

		careerCurrentOpeningsTest.careerCurrentOpeningsTest();

	}

	@Test(priority = 7)
	public void careerFooterTest() {

		careerFooterTest.careerFooterTest();

	}

	@Test(priority = 8)
	public void careerVideoTest() {

		careerVideoTest.careerVideoTest();

	}

}
