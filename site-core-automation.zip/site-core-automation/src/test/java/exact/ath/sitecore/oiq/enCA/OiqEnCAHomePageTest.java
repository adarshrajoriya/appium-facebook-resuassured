package exact.ath.sitecore.oiq.enCA;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.oiq.oiqDE.OiqDEKlinischenPraxisPage;
import exact.ath.oiq.oiqEnCA.OiqEnCAHomePage;

/**
 * This class verifies OIQ Canada web site Home page
 * 
 * @userstory #304475 Task#307981
 * @author Pushkar Singh
 * @since 09/26/2023
 */
public class OiqEnCAHomePageTest extends BasicIntTest {

	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final OiqEnCAHomePage oiqEnCAHomePage = new OiqEnCAHomePage();
	private final OiqDEKlinischenPraxisPage oiqDEKlinischenPraxisPage = new OiqDEKlinischenPraxisPage();

	private final String loginUrl = oiqenCAPagesProperties.getProperty("oiqCAsiteURL");
	private final String oiqenCHPageTitle = oiqenCHPagesProperties.getProperty("oiqenCHPageTitle");
	private final String aboutTheTestPageHeading = oiqenCAPagesProperties.getProperty("aboutTheTestPageHeading");
	private final String aboutTheTest = oiqenCAPagesProperties.getProperty("aboutTheTest");
	private final String popupbutton2Text = oiqenCHPagesProperties.getProperty("popupbutton2Text");
	private final String exactsciencesURL = oiqenCHPagesProperties.getProperty("exactsciencesURL");
	private final String patientProfileNavigatorURL = oiqenCHPagesProperties.getProperty("patientProfileNavigatorURL");
	private final String patientProfileNavigatorTitle = oiqenCHPagesProperties
			.getProperty("patientProfileNavigatorTitle");
	private final String searchResultsTitle = oiqenCHPagesProperties.getProperty("searchResultsTitle");
	private final String physicianPortalURL = oiqenCAPagesProperties.getProperty("physicianPortalURL");
	private final String virtualBooth360DegreeURL = oiqenCHPagesProperties.getProperty("virtualBooth360DegreeURL");
	private final String enSavoirPlusURL = oiqenCHPagesProperties.getProperty("enSavoirPlusURL");
	private final String meherErfahrenURL = oiqenCHPagesProperties.getProperty("meherErfahrenURL");
	private final String contactUsTitle = oiqenCHPagesProperties.getProperty("contactUsTitle");
	private final String followUsURL = oiqenCHPagesProperties.getProperty("followUsURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqEnCAHomePageTest() {

		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Canada Homepage URL '" + loginUrl + "'");

		verifySafely(oiqCHHomePage.getOiqPageTitle(), oiqenCHPageTitle, "Page Heading displayed");

		oiqCHHomePage.clickOncotypeDxLogo();
		logInfo("Clicked on 'Oncotype DX' logo");
		verifySafely(oiqCHHomePage.getOiqPageTitle(), oiqenCHPageTitle, "Page Heading displayed");

		oiqCHHomePage.enterSearchBoxText("Test");
		logInfo("Entered 'Test' in Search Box");
		oiqCHHomePage.clickSearchIcon();
		logInfo("Clicked on Search icon");
		verifySafely(oiqCHHomePage.getPageTitle(), searchResultsTitle, "Page Heading displayed");
		driver.back();

		oiqEnCAHomePage.clickPhysicianLoginBtn();
		logInfo("Clicked on 'PHYSICIAN LOGIN' button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(physicianPortalURL), true,
				"Physician Portal Page URL matches VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqEnCAHomePage.clickLearnMoreHeroLink();
		logInfo("Clicked on 'LEARN MORE' Link under the 'SMARTER CANCER CARE'");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on CONTINUE button");
		verifySafely(oiqCHHomePage.getPageTitle(), aboutTheTestPageHeading, "Page Heading displayed");
		verifySafely(oiqDEKlinischenPraxisPage.isItemUnderlined(aboutTheTest), true,
				"'" + aboutTheTest + "' underlined displayed on the right panel");
		driver.back();

		oiqCHHomePage.clickVirtualBoothLink();
		logInfo("Clicked on 'VISIT OUR VIRTUAL BOOTH' under 'What Is the Test'");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), virtualBooth360DegreeURL, "Virtual Booth in 360 degree Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqCHHomePage.clickEnSavoirPlusLink();
		logInfo("Clicked on 'EN SAVOIR PLUS' under 'Site France'");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), enSavoirPlusURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		oiqCHHomePage.clickMeherErfahrenLink();
		logInfo("Clicked on 'MEHR ERFAHREN' under 'Webseite Deutschland'");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), meherErfahrenURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		verifySafely(oiqCHHomePage.isGetInTouchBtnDisplayed(), true, "'GET IN TOUCH' button is displayed on the page");
		verifySafely(oiqCHHomePage.isFollowUsBtnDisplayed(), true, "'FOLLOW US' button is displayed on the page");

		oiqCHHomePage.clickGetInTouchBtn();
		logInfo("Clicked on 'GET IN TOUCH' button");
		verifySafely(oiqCHHomePage.getPageTitle(), contactUsTitle, "Page Heading displayed");

		oiqCHHomePage.clickOncotypeDxLogo();
		logInfo("Clicked on 'Oncotype DX' logo");

		oiqCHHomePage.clickFollowUsBtn();
		logInfo("Clicked on 'FOLLOW US' button");
		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on I Agree button");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), followUsURL, "Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		throwAssertionErrorOnFailure();
	}

}
