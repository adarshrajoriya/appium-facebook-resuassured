package exact.ath.sitecore.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.corporateUk.CorporateUkHomePage;

/**
 * This class verifies Corporate Uk Home page verifications
 * 
 * @userstory #304475 Task#307942
 * @author Tushar Gupta
 * @since 07/18/2023
 */
public class CorporateUkHomePageVerificationsTest extends BasicIntTest {

	private final CorporateUkHomePage corporateUkHomePage = new CorporateUkHomePage();
	private final String corporateUkHomePageURL = corporateUkPagesProperties.getProperty("corporateUkHomePageURL");
	private final String about = corporateUkPagesProperties.getProperty("about");
	private final String ourProducts = corporateUkPagesProperties.getProperty("ourProducts");
	private final String pressRoom = corporateUkPagesProperties.getProperty("pressRoom");
	private final String joinOurTeam = corporateUkPagesProperties.getProperty("joinOurTeam");
	private final String youAreNowLeaving = corporateUkPagesProperties.getProperty("youAreNowLeaving");
	private final String joinOurTeamURL = corporateUkPagesProperties.getProperty("joinOurTeamURL");
	private final String aboutUsURL = corporateUkPagesProperties.getProperty("aboutUsURL");
	private final String productURL = corporateUkPagesProperties.getProperty("productURL");
	private final String pipeLineURL = corporateUkPagesProperties.getProperty("pipeLineURL");
	private final String pageHeadingDisplayedCorporateUkHomePage = corporateUkPagesProperties
			.getProperty("pageHeadingDisplayedCorporateUkHomePage");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyCorporateUkHomeLinksTest() throws Exception {
		setupURL(corporateUkHomePageURL);
		logInfo("Page URL : " + corporateUkHomePageURL + "");

		acceptCookiesCorporateUk();
		logInfo("----------------Starting verification of Home Page of Corpoarte UK Website------------");
		verifySafely(corporateUkHomePage.isCorporateUkHomepageDisplayed(), true, "Corporate Uk Homepage is displayed");
		verifySafely(corporateUkHomePage.getPageHeadingDisplayedHomePage(), pageHeadingDisplayedCorporateUkHomePage,
				"'PURSUING EARLIER DETECTION AND LIFE-CHANGING ANSWERS' Title is displayed on Home Page Of Corporate Uk website");
		verifySafely(corporateUkHomePage.isUnitedKingdomDisplayed(), true,
				"'United Kingdom' country is displayed under the header section");
		verifySafely(corporateUkHomePage.isExactScienceLogoDisplayed(), true,
				"Exact Science Logo is displayed under the header section");
		verifySafely(corporateUkHomePage.isHeaderOptionDisplayed(about), true,
				"Header option '" + about + "' is displayed under the header section");
		verifySafely(corporateUkHomePage.isHeaderOptionDisplayed(ourProducts), true,
				"Header option '" + ourProducts + "' is displayed under the header section");
		verifySafely(corporateUkHomePage.isHeaderOptionDisplayed(pressRoom), true,
				"Header option '" + pressRoom + "' is displayed under the header section");
		verifySafely(corporateUkHomePage.isHeaderOptionDisplayed(joinOurTeam), true,
				"Header option '" + joinOurTeam + "' is displayed under the header section");

		corporateUkHomePage.clickExactScienceLogo();
		verifySafely(corporateUkHomePage.isCorporateUkHomepageDisplayed(), true, "Corporate Uk Homepage is displayed");

		driver.refresh();
		corporateUkHomePage.clickHeaderOption(joinOurTeam);
		verifySafely(corporateUkHomePage.getPopUpText(), youAreNowLeaving,
				"'YOU ARE NOW LEAVING THIS SITE.' popup is displayed");
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(joinOurTeamURL), true, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		corporateUkHomePage.clickCloseButton();

		corporateUkHomePage.clickLearnMoreButtonBelowPursuingEarlier();
		verifySafely(driver.getURL(), aboutUsURL, "'Page URL matches'");
		driver.back();

		corporateUkHomePage.clickLearnMoreButtonBelowProviding();
		verifySafely(driver.getURL(), productURL, "'Page URL matches'");
		driver.back();

		corporateUkHomePage.clickLearnMoreButtonBelowDelivering();
		verifySafely(corporateUkHomePage.getPopUpText(), youAreNowLeaving,
				"'YOU ARE NOW LEAVING THIS SITE.' popup is displayed");
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), pipeLineURL, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateUkHomePage.clickCloseButton();

		corporateUkHomePage.clickLearnMoreButtonBelowKeeping();
		verifySafely(corporateUkHomePage.getPopUpText(), youAreNowLeaving,
				"'YOU ARE NOW LEAVING THIS SITE.' popup is displayed");
		corporateUkHomePage.clickAgreeButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(joinOurTeamURL), true, "'Page URL matches'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Verification done for Home Page of Corpoarte UK Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
