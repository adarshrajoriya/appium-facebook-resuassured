package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglHomepage;
import exact.ath.ogl.OglResourcePage;

/**
 * This class verifies the footer section of OGL website
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 07/10/2023
 */

public class OglFooterTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();
	private final OglResourcePage oglResourcePage = new OglResourcePage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String aboutExactSciences = oglPagesProperties.getProperty("aboutExactSciences");
	private final String licensingAccreditations = oglPagesProperties.getProperty("licensingAccreditations");
	private final String termsUse = oglPagesProperties.getProperty("termsUse");
	private final String privacyPolicy = oglPagesProperties.getProperty("privacyPolicy");
	private final String hippaNotice = oglPagesProperties.getProperty("hippaNotice");
	private final String doNotSellMyInfo = oglPagesProperties.getProperty("doNotSellMyInfo");
	private final String facebook = oglPagesProperties.getProperty("facebook");
	private final String twitter = oglPagesProperties.getProperty("twitter");
	private final String linkedIn = oglPagesProperties.getProperty("linkedIn");
	private final String licensingAccreditationsUrl = oglPagesProperties.getProperty("licensingAccreditationsUrl");
	private final String linkedInLink = oglPagesProperties.getProperty("linkedInLink");
	private final String footerElementNames = oglPagesProperties.getProperty("footerElementNames");
	private final String footerElementURL = oglPagesProperties.getProperty("footerElementURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglFooterTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of the footer section of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");

		verifySafely(oglHomepage.isFooterDisplayed(), true, "'Footer' is Displayed on the page");
		verifySafely(oglHomepage.isExactSciencesLogoDisplayed(), true, "'Exact Sciences Logo' is Displayed");
		verifySafely(oglHomepage.isAddressDetailsDisplayed(), true, "'Address Details' is Displayed");
		verifySafely(oglHomepage.isContactUsHyperLinkDisplayed(), true, "'Contact Us HyperLink' is Displayed");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(aboutExactSciences), true,
				"'" + aboutExactSciences + "' Link is Displayed under 'Quick Links'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(licensingAccreditations), true,
				"'" + licensingAccreditations + "' Link is Displayed under 'Quick Links'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(termsUse), true,
				"'" + termsUse + "' Link is Displayed under 'Quick Links'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(privacyPolicy), true,
				"'" + privacyPolicy + "' Link is Displayed under 'Quick Links'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(hippaNotice), true,
				"'" + hippaNotice + "' Link is Displayed under 'Quick Links'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(doNotSellMyInfo), true,
				"'" + doNotSellMyInfo + "' Link is Displayed under 'Quick Links'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(facebook), true,
				"'" + facebook + "' Link is Displayed under 'FOLLOW US ON'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(twitter), true,
				"'" + twitter + "' Link is Displayed under 'FOLLOW US ON'");
		verifySafely(oglResourcePage.isLinksOnPageDisplayed(linkedIn), true,
				"'" + linkedIn + "' Link is Displayed under 'FOLLOW US ON'");

		oglHomepage.clickFooterLink(licensingAccreditations);
		verifySafely(driver.getURL(), licensingAccreditationsUrl,
				"'" + licensingAccreditations + "' Page is displayed");
		driver.back();

		verificationsOfFooterLinks();

		driver.refresh();
		oglHomepage.clickFooterLink(linkedIn);
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(linkedInLink), true, "'" + linkedIn + "' Page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("----------------Verification done for the footer section of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();
	}

	private void verificationsOfFooterLinks() throws Exception

	{
		String[] footerElementNamesArr = footerElementNames.split(",");
		String[] footerElementURLArr = footerElementURL.split(",");

		for (int count = 0; count < footerElementNamesArr.length; count++) {

			oglHomepage.clickFooterLink(footerElementNamesArr[count]);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), footerElementURLArr[count], "' Page URL matches");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();

		}

	}

}
