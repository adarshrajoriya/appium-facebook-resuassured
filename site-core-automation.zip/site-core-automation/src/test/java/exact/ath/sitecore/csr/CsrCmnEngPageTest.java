package exact.ath.sitecore.csr;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.ath.sitecore.CsrWebsite;

/**
 * @author pusingh
 *
 */
public class CsrCmnEngPageTest extends BasicIntTest {

	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final CorporateWebsite corporateWebsite = new CorporateWebsite();

	private final CsrWebsite csrWebsite = new CsrWebsite();

	private final String uWCarboneURL = exactPagesProperties.getProperty("UWCarboneURL");

	private final String loginUrl = exactPagesProperties.getProperty("CsrWebURL");

	private final String csrCmnEngCardTittles = exactPagesProperties.getProperty("CsrCmnEngCardTittles");
	private final String csrCmnEngCardFullTittles = exactPagesProperties.getProperty("CsrCmnEngCardFullTittles");
	private final String csrFundingTransformativeCancerResearchOneQuestionTimeCardTittles = exactPagesProperties
			.getProperty("CsrFundingTransformativeCancerResearchOneQuestionTimeCardTittles");
	private final String fundingTransformativeCancerResearchOneQuestionTimePageURL = exactPagesProperties
			.getProperty("FundingTransformativeCancerResearchOneQuestionTimePageURL");
	private int viewCount = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void csrCmnEngPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");
		csrWebsite.clickCsrCmnEngHeader();
		logInfo("Clicked on 'Community Engagement' Header Option");
		verifySafely(csrWebsite.isCsrCmnEngHeaderHighlightedDisplayed(), true,
				"'Community Engagement' item is displayed Highlighted in header section on the page");
		csrWebsite.clickReadMore();
		logInfo("Clicked on 'READ MORE' button");
		verifySafely(driver.getURL(), fundingTransformativeCancerResearchOneQuestionTimePageURL,
				"'Funding Transformative Cancer Research One Question at a Time' Page URL matches");

		csrWebsite.clickUWCarboneLink();
		logInfo("Clicked on 'UW Carbone' link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), uWCarboneURL, "'UW Carbone' link Navigated to Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		logInfo("Verification of 'Funding Transformative Cancer Research One Question at a Time' page Icon cards");
		for (String csrFTCROOTCardTittle : csrFundingTransformativeCancerResearchOneQuestionTimeCardTittles
				.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCiAndCrIconCardTittle(viewCount).contains(csrFTCROOTCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCiAndCrIconCardTittle(viewCount)
							+ "'");
			csrWebsite.clickCsrCiAndCrIconCardTittle(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrFTCROOTCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		driver.back();
		verifySafely(csrWebsite.isCsrCmnEngHeaderHighlightedDisplayed(), true,
				"'Community Engagement' item is displayed Highlighted in header section on the page");

		String recentURL = getPageURL();
		closeTheBrowser();
		setupURL(recentURL);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		logInfo("Verification of 'Community Engagement' page Icon cards");
		viewCount = 1;
		for (String csrCmnEngCardTittle : csrCmnEngCardTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrCmnEngCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrCmnEngCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		recentURL = getPageURL();
		closeTheBrowser();
		setupURL(recentURL);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		csrWebsite.clickSeeMoreEntries();
		logInfo("Clicked on 'SEE MORE ENTRIES' button");
		verifySafely(csrWebsite.isJumpLink1Highlighted(), true, "'Jump Link 1' is displayed highlighted on the page");

		logInfo("Verification of 'Community Engagement' page Full Icon cards");
		viewCount = 0;
		for (String csrCmnEngCardTittle : csrCmnEngCardFullTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrCmnEngCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrCmnEngCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();
			if (viewCount == 6) {
				recentURL = getPageURL();
				closeTheBrowser();
				setupURL(recentURL);
				logInfo("Page URL : " + getPageURL() + "");
				if (annualReportsPage.acceptCookiesDisplayed()) {
					annualReportsPage.acceptCookies();
				}
			}

		}

		csrWebsite.clickJumpLink2();
		logInfo("Clicked on 'Jump Link 2'");
		verifySafely(csrWebsite.isJumpLink2Highlighted(), true, "'Jump Link 2' is displayed highlighted on the page");

		csrWebsite.clickJumpLink3();
		logInfo("Clicked on 'Jump Link 3'");
		verifySafely(csrWebsite.isJumpLink3Highlighted(), true, "'Jump Link 3' is displayed highlighted on the page");

		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
