package exact.ath.sitecore.oiq.deDE;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.oiq.oiqCH.OiqCHContactUsPage;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.sitecore.CorporateWebsite;

/**
 * This class verifies OIQ Germany web site KONTAKT header components
 * 
 * @userstory #304475 Task#307772
 * @author Pushkar Singh
 * @since 08/04/2023
 */
public class OiqDEKontaktHeaderTest extends BasicIntTest {

	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final OiqCHContactUsPage oiqCHContactUsPage = new OiqCHContactUsPage();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();

	private final String firstName = exactPagesProperties.getProperty("FirstNameValue");
	private final String lastName = exactPagesProperties.getProperty("LastNameValue");
	private final String phone = oiqenCHPagesProperties.getProperty("phoneValue");
	private final String email = exactPagesProperties.getProperty("EmailValue");

	private final String loginUrl = oiqdeDEPagesProperties.getProperty("oiqDEsiteURL");
	private final String kontaktTitle = oiqdeDEPagesProperties.getProperty("kontaktTitle");
	private final String submitFormMessage = oiqenCHPagesProperties.getProperty("submitFormMessage");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqDEKontaktHeaderTest() {

//		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Deutschland Homepage URL '" + loginUrl + "'");

		oiqCHHomePage.clickHeaderOption4();
		logInfo("Clicked on 'KONTAKT' header");

		verifySafely(oiqCHHomePage.getPageTitle(), kontaktTitle, "Page Heading displayed");
		verifySafely(oiqCHContactUsPage.isCountryDESelected(), true,
				"Country 'Germany' is selected by default from dropdown");
		verifySafely(oiqCHContactUsPage.getcountryCHContact().contains("Deutschland"), true,
				"Contact details is be displayed on the right pane for the selected Country 'Deutschland'");
		logInfo("Contact details: " + oiqCHContactUsPage.getcountryCHContact() + "");

		oiqCHContactUsPage.clickSubmitBtnBy();
		logInfo("Clicked on 'SUBMIT' button");
		verifySafely(oiqCHContactUsPage.isErrorMessageDisplayed(), true,
				"An error message is displayed on the mandatory fields");

		corporateWebsite.enterFirstName(firstName);
		logInfo("Entered First Name '" + firstName + "'");
		corporateWebsite.enterLastName(lastName);
		logInfo("Entered Last Name '" + lastName + "'");
		corporateWebsite.enterEmail(email);
		logInfo("Entered Email '" + email + "'");
		oiqCHContactUsPage.enterPhone(phone);
		logInfo("Entered Phone '" + phone + "'");

		oiqCHContactUsPage.clickSubmitBtnBy();
		logInfo("Clicked on 'SUBMIT' button");
		verifySafely(oiqCHContactUsPage.getsubmitFormMessage(), submitFormMessage, "Message displayed");

		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
