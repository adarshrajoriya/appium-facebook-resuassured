package exact.ath.sitecore.csr;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.ath.sitecore.CsrWebsite;
import exact.sys.Driver;

public class CsrFooterTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final CsrWebsite csrWebsite = new CsrWebsite();

	private final String purchasingTermsSiteURL = exactPagesProperties.getProperty("CSRPurchasingTermsWebSiteURL");
	private final String cologaurdsiteURL = exactPagesProperties.getProperty("CologaurdWebsiteURL");
	private final String facebookSiteURL = exactPagesProperties.getProperty("FacebookWebSiteURL");
	private final String twitterSiteURL = exactPagesProperties.getProperty("TwitterWebSiteURL");
	private final String linkedinSiteURL = exactPagesProperties.getProperty("LinkedinWebSiteURL");
	private final String loginUrl = exactPagesProperties.getProperty("CsrWebURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void csrFooterTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");
		verifySafely(corporateWebsite.isExactSciencesFooterLogoDisplayed(), true,
				"'EXACT SCIENCES' logo is displayed on the page");
		logInfo("Footer Address : " + corporateWebsite.getFooterAddress() + "");
		verifySafely(corporateWebsite.isContactUsFooterDisplayed(), true, "'Contact Us' displayed on the page");
		verifySafely(corporateWebsite.isAboutHyperlinkDisplayed(), true, "About Hyperlink Displayed");
		verifySafely(corporateWebsite.isTermOfUseHyperlinkDisplayed(), true, "Terms of Use Hyperlink Displayed");
		verifySafely(corporateWebsite.isPurchasingTermsHyperlinkDisplayed(), true,
				"Purchasing Terms Hyperlink Displayed");
		verifySafely(corporateWebsite.isPatentsTrademarksHyperlinkDisplayed(), true,
				"Patents Trademarks Hyperlink Displayed");
		verifySafely(corporateWebsite.isPrivacyPolicyHyperlinkDisplayed(), true, "Privacy Policy Hyperlink Displayed");
		verifySafely(corporateWebsite.isHIPAANoticeHyperlinkDisplayed(), true, "HIPAA Notice Hyperlink Displayed");
		verifySafely(corporateWebsite.isDoNotSellMyInfoHyperlinkDisplayed(), true,
				"Do Not Sell My Info Hyperlink Displayed");
		verifySafely(corporateWebsite.isCologuardcomHyperlinkDisplayed(), true, "Cologuard.com Hyperlink Displayed");

		verifySafely(corporateWebsite.isFacebookHyperlinkDisplayed(), true, "FACEBOOK Hyperlink Displayed");
		verifySafely(corporateWebsite.isTwitterHyperlinkDisplayed(), true, "TWITTER Hyperlink Displayed");
		verifySafely(corporateWebsite.isLinkedinHyperlinkDisplayed(), true, "LINKEDIN Hyperlink Displayed");

		corporateWebsite.clickContactUsFooter();
		logInfo("Clicked on 'Contact Us' Hyperlink");
		verifySafely(corporateWebsite.isContactUsPageDisplayed(), true, "Navigated to Contact Us title page");
		driver.back();
		corporateWebsite.clickAboutHyperlink();
		logInfo("Clicked on 'About Us' Hyperlink");
		verifySafely(corporateWebsite.isAboutUsPageDisplayed(), true, "Navigated to About Us title page");
		driver.back();
		corporateWebsite.clickTermOfUseHyperlink();
		logInfo("Clicked on 'Terms of Use' Hyperlink");
		verifySafely(corporateWebsite.isTermOfUsePageDisplayed(), true,
				"Navigated to TERMS & CONDITIONS OF USE title page");
		driver.back();
		corporateWebsite.clickPurchasingTermsHyperlink();
		logInfo("Clicked on 'Purchasing Terms' Hyperlink");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(purchasingTermsSiteURL), true,
				"Navigated to Purchasing_Terms_and_Conditions.pdf tittle page contains URL VALUE: '"
						+ purchasingTermsSiteURL + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickPatentsTrademarksHyperlink();
		logInfo("Clicked on 'Patents Trademarks' Hyperlink");
		verifySafely(corporateWebsite.isPatentsTrademarksPageDisplayed(), true,
				"Navigated to PATENTS AND TRADEMARKS tittle page");
		driver.back();
		corporateWebsite.clickPrivacyPolicyHyperlink();
		logInfo("Clicked on 'Privacy Policy' Hyperlink");
		verifySafely(corporateWebsite.isPrivacyPolicyPageDisplayed(), true,
				"Navigated to EXACT SCIENCES CORPORATION PRIVACY POLICY tittle page");
		driver.back();
		corporateWebsite.clickHIPAANoticeHyperlink();
		logInfo("Clicked on 'HIPAA Notice' Hyperlink");
		verifySafely(corporateWebsite.isHIPAANoticePageDisplayed(), true,
				"Navigated to Notice of Privacy Practices tittle page");
		driver.back();
		corporateWebsite.clickDoNotSellMyInfoHyperlink();
		logInfo("Clicked on 'Do Not Sell My Info' Hyperlink");
		verifySafely(corporateWebsite.isDoNotSellMyInfoPageDisplayed(), true,
				"Navigated to DO NOT SELL MY PERSONAL INFORMATION tittle page");
		driver.back();
		corporateWebsite.clickCologuardcomHyperlink();
		logInfo("Clicked on 'Cologuard.com' Hyperlink");
		verifySafely(driver.getURL().contains(cologaurdsiteURL), true,
				"'Cologuard.com' link navigated to URL contains VALUE: '" + cologaurdsiteURL + "'");
		driver.back();

		corporateWebsite.clickFacebookHyperHyperlink();
		logInfo("Clicked on 'FACEBOOK' Hyperlink");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(facebookSiteURL), true,
				"Facebook icon navigated to URL contains VALUE: '" + facebookSiteURL + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickTwitterHyperHyperlink();
		logInfo("Clicked on 'TWITTER' Hyperlink");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(twitterSiteURL), true,
				"Twitter icon navigated to URL contains VALUE: '" + twitterSiteURL + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickLinkedinHyperHyperlink();
		logInfo("Clicked on 'LINKEDIN' Hyperlink");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(linkedinSiteURL), true,
				"Linkedin icon navigated to URL contains VALUE: '" + linkedinSiteURL + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");

		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
