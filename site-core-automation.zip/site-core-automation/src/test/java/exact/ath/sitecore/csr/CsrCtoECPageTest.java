package exact.ath.sitecore.csr;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CsrWebsite;

/**
 * @author pusingh
 *
 */
public class CsrCtoECPageTest extends BasicIntTest {

	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final CsrWebsite csrWebsite = new CsrWebsite();

	private final String loginUrl = exactPagesProperties.getProperty("CsrWebURL");
	private final String csrCtoECCardTittles = exactPagesProperties.getProperty("CsrCtoECCardTittles");
	private final String csrCtoECCardFullTittles = exactPagesProperties.getProperty("CsrCtoECCardFullTittles");
	private final String levelingCancerCarePlayingFieldArizonaPageURL = exactPagesProperties
			.getProperty("LevelingCancerCarePlayingFieldArizonaPageURL");
	private int viewCount = 2;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void csrCtoECPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		verifySafely(csrWebsite.isCsrCiAndCrHeaderHighlightedDisplayed(), true,
				"'Corporate Impact and Community Relations' item is displayed Highlighted in header section on the page");
		csrWebsite.clickCsrCtoECHeader();
		logInfo("Clicked on 'Commitment to Eradicate Cancer' Header Option");
		verifySafely(csrWebsite.isCsrCtoECHeaderHighlightedDisplayed(), true,
				"'Commitment to Eradicate Cancer' item is displayed Highlighted in header section on the page");

		csrWebsite.clickReadMore();
		logInfo("Clicked on 'READ MORE' button");
		verifySafely(driver.getURL(), levelingCancerCarePlayingFieldArizonaPageURL,
				"'Leveling the Cancer Care Playing Field in Arizona' Page URL matches");
		driver.back();
		logInfo("Navigated back to page 'Commitment to Eradicate Cancer'");
		viewCount = 1;
		logInfo("Verification of 'Commitment to Eradicate Cancer' page Icon cards");
		for (String csrCtoECCardTittle : csrCtoECCardTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrCtoECCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrCtoECCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();

		}

		String recentURL = getPageURL();
		closeTheBrowser();
		setupURL(recentURL);
		logInfo("Page URL : " + getPageURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}

		csrWebsite.clickSeeMoreEntries();
		logInfo("Clicked on 'SEE MORE ENTRIES' button");
		verifySafely(csrWebsite.isJumpLink1Highlighted(), true, "'Jump Link 1' is displayed highlighted on the page");

		viewCount = 0;
		logInfo("Verification of 'Commitment to Eradicate Cancer' page Full Icon cards");
		for (String csrCtoECCardTittle : csrCtoECCardFullTittles.split(",")) {
			viewCount++;
			verifySafely(csrWebsite.getCsrCtoECCardTittle(viewCount).contains(csrCtoECCardTittle), true,
					"Displayed Publication Card - Tittle VALUE: '" + csrWebsite.getCsrCtoECCardTittle(viewCount) + "'");
			csrWebsite.clickCsrCtoECCard(viewCount);
			verifySafely(csrWebsite.getCsrCtoECPageTittle().contains(csrCtoECCardTittle), true,
					"Opened Page - Tittle VALUE: '" + csrWebsite.getCsrCtoECPageTittle() + "'");
			driver.back();
			if (viewCount == 6) {
				recentURL = getPageURL();
				closeTheBrowser();
				setupURL(recentURL);
				logInfo("Page URL : " + getPageURL() + "");
				if (annualReportsPage.acceptCookiesDisplayed()) {
					annualReportsPage.acceptCookies();
				}
			}

		}

		csrWebsite.clickJumpLink2();
		logInfo("Clicked on 'Jump Link 2'");
		verifySafely(csrWebsite.isJumpLink2Highlighted(), true, "'Jump Link 2' is displayed highlighted on the page");

		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
