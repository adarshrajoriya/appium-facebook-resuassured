package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.util.PostStatusToZephyr;

/**
 * This class verifies Cologuard footer verifications
 * 
 * @userstory #303911 Task#304284
 * @author Manpreet Panesar
 * @since 05/25/2023
 */
public class CologuardFooterTest extends BasicIntTest {

	private final String cologuardHomePageUrl = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	private final String contactUsUrl = cologuardPagesProperties.getProperty("ContactUsUrl");
	private final String aboutExactSciencesUrl = cologuardPagesProperties.getProperty("AboutExactSciencesUrl");
	private final String termsofUseUrl = cologuardPagesProperties.getProperty("TermsofUseUrl");
	private final String privacyPolicyUrl = cologuardPagesProperties.getProperty("PrivacyPolicyUrl");
	private final String hIPAANoticeUrl = cologuardPagesProperties.getProperty("HIPAANoticeUrl");
	private final String doNotSellMyInfoUrl = cologuardPagesProperties.getProperty("DoNotSellMyInfoUrl");
	private final String facebookUrl = cologuardPagesProperties.getProperty("FacebookUrl");
	private final String twitterUrl = cologuardPagesProperties.getProperty("TwitterUrl");
	private final String youtubeUrl = cologuardPagesProperties.getProperty("YoutubeUrl");
	private final String instagramUrl = cologuardPagesProperties.getProperty("InstagramUrl");
	private final String contactUsBanner = cologuardPagesProperties.getProperty("ContactUsBanner");
	private final String termsofUseBanner = cologuardPagesProperties.getProperty("TermsofUseBanner");
	private final String medWatchUrl = cologuardPagesProperties.getProperty("MedWatchUrl");

	private String linkText;

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T1081";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyCologuardFooterTest() throws Exception {
		checkForExUSSite(cologuardHomePageUrl);
		acceptCookies();
		verifySafely(cologuardHomepage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");
		footerVerifications();
		cologuardHomepage.clickMedWatchLink();
		logInfo("Clicked on 'www.fda.gov/MedWatch' footer link");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), medWatchUrl, "'www.fda.gov/MedWatch' Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.close();
		throwAssertionErrorOnFailure();
	}

	private void footerVerifications() {
		for (int count = 1; count <= 10; count++) {
			String counter = Integer.toString(count);
			String[] links = { contactUsUrl, aboutExactSciencesUrl, termsofUseUrl, privacyPolicyUrl, hIPAANoticeUrl,
					doNotSellMyInfoUrl, facebookUrl, twitterUrl, youtubeUrl, instagramUrl };
			String[] pageTitle = { contactUsBanner, "", termsofUseBanner };
			String[] linkTexts = { "Facebook", "Twitter", "Youtube", "Instagram" };
			if (count < 7) {
				linkText = cologuardHomepage.getFooterLinksText(counter);
			} else {
				linkText = linkTexts[count - 7];
			}
			cologuardHomepage.clickFooterLinks(counter);
			logInfo("Clicked on '" + linkText + "' footer link");
			if (count > 3 || count == 2) {
				driver.switchToCurrentWindow();
			} else {
				verifySafely(cologuardHomepage.getPageBannerText(), pageTitle[count - 1],
						"'" + linkText + "' Page Banner Text matches");
			}
			verifySafely(driver.getURL(), links[count - 1], "'" + linkText + "' Page URL matches");
			if (count > 3 || count == 2) {
				driver.closeCurrentWindow();
				driver.switchToParentWindow();
			} else {
				driver.back();
			}
		}
	}
}
