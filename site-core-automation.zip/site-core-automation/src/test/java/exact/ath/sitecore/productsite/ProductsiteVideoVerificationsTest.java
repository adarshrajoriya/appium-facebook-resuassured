package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.PSOncotypeDXBreastRecurrenceScoreTestPage;
import exact.ath.productsite.ProductsiteAboutUsPage;
import exact.ath.productsite.ProductsiteHomepage;
import exact.ath.productsite.ProductsiteOncoextraTestPage;
import exact.util.Sleeper;

/**
 * This class verifies Productsite 'Videos'
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 07/19/2023
 */
public class ProductsiteVideoVerificationsTest extends BasicIntTest {

	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();
	private final PSOncotypeDXBreastRecurrenceScoreTestPage pSOncotypeDXBreastRecurrenceScoreTestPage = new PSOncotypeDXBreastRecurrenceScoreTestPage();
	private final ProductsiteOncoextraTestPage productsiteOncoextraTestPage = new ProductsiteOncoextraTestPage();
	private final ProductsiteAboutUsPage productsiteAboutUsPage = new ProductsiteAboutUsPage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String TabNames = productsitePagesProperties.getProperty("TabNames");
	private final String HealthcareProviderSubpartsValues = productsitePagesProperties
			.getProperty("HealthcareProviderSubpartsValues");
	private final String PatientsAndCaregiversSubmenuValues = productsitePagesProperties
			.getProperty("PatientsAndCaregiversSubmenuValues");

	private final String[] tabNames = TabNames.split(",");
	private final String[] healthcareProviderSubpartsValues = HealthcareProviderSubpartsValues.split(",");
	private final String[] patientsAndCaregiversSubmenuValues = PatientsAndCaregiversSubmenuValues.split(",");

	String initialTime = "0:00";
	String finalTime;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsiteVideoVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		productsiteHomepage.clickOnDeepaVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteHomepage.clickOnVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Deepa's Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
						+ finalTime + "'");
		driver.refresh();
		productsiteHomepage.clickOnAmyVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteHomepage.clickOnVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Amy's Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
						+ finalTime + "'");
		driver.refresh();
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[0]);
		logInfo("Navigated to URL '" + driver.getURL() + "'");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnTailorxVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteHomepage.clickOnVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Tailorx Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
						+ finalTime + "'");
		driver.refresh();

		productsiteHomepage.clickHeaderTab(tabNames[1]);
		productsiteHomepage.clickPatientsAndCaregiversSubmenu(patientsAndCaregiversSubmenuValues[0]);
		productsiteHomepage.clickOnDeepaVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteHomepage.clickOnVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Deepa's Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
						+ finalTime + "'");
		driver.refresh();
		productsiteHomepage.clickOnAmyVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteHomepage.clickOnVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Nina Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
						+ finalTime + "'");
		driver.refresh();
		productsiteHomepage.clickOnLaurieVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteHomepage.clickOnVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Laurie's Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
						+ finalTime + "'");
		driver.refresh();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[3]);
		logInfo("Navigated to URL '" + driver.getURL() + "'");
		productsiteOncoextraTestPage.clickOnDnaRnaVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteOncoextraTestPage.clickOnDnaRnaVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"DNA + RNA Video is played and paused successfully Initial Time = '" + initialTime + "' Final Time = '"
						+ finalTime + "'");
		driver.refresh();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[3]);
		logInfo("Navigated to URL '" + driver.getURL() + "'");
		productsiteAboutUsPage.clickOnDefiningANewApproachToOncologyGenomicsVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteAboutUsPage.clickOnDefiningANewApproachToOncologyGenomicsVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Defining a new approach to oncology genomics Video is played and paused successfully Initial Time = '"
						+ initialTime + "' Final Time = '" + finalTime + "'");
		driver.refresh();

		productsiteAboutUsPage.clickOnAnthemOnVimeoVideoPlayButton();
		Sleeper.sleepTightInSeconds(12);
		productsiteAboutUsPage.clickOnAnthemOnVimeoVideoPauseButton();
		finalTime = productsiteHomepage.getVideoCurrentTime();
		verifySafely(!initialTime.equals(finalTime), true,
				"Anthem on Vimeo Video is played and paused successfully Initial Time = '" + initialTime
						+ "' Final Time = '" + finalTime + "'");
		driver.refresh();
		driver.close();

		throwAssertionErrorOnFailure();
	}

}
