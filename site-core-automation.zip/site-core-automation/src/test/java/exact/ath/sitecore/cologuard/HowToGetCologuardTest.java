package exact.ath.sitecore.cologuard;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.cologuard.HowToGetCologuardPage;
import exact.util.PostStatusToZephyr;

/**
 * This class verifies How to get Cologuard page verifications
 * 
 * @userstory #303911 Task#304281
 * @author Sandeep Singh
 * @since 05/03/2023
 */
public class HowToGetCologuardTest extends BasicIntTest {

	private final HowToGetCologuardPage howToGetCologuardPage = new HowToGetCologuardPage();

	// URLs
	private final String cologuardHomePageURL = cologuardPagesProperties.getProperty("cologuardHomePageURL");
	private final String getCologuardURL = cologuardPagesProperties.getProperty("getCologuardURL");
	private final String askForCologuardOnlineURL = cologuardPagesProperties.getProperty("askForCologuardOnlineURL");
	private final String getDiscussionGuideURL = cologuardPagesProperties.getProperty("getDiscussionGuideURL");
	private final String howToUseCologuardURL = cologuardPagesProperties.getProperty("howToUseCologuardURL");
	private final String signUpURL = cologuardPagesProperties.getProperty("signUpURL");

	// Strings
	private final String getCologuard = cologuardPagesProperties.getProperty("getCologuard");
	private final String getCologuardPageTitle = cologuardPagesProperties.getProperty("getCologuardPageTitle");
	private final String signUpForCologuardTitle = cologuardPagesProperties.getProperty("signUpForCologuardTitle");

	private final String testCycleKey = "EPS-R68";
	private final String testCaseKey = "EPS-T720";

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

		PostStatusToZephyr.updateZephyrResults(testCycleKey, testCaseKey, result);
	}

	@Test
	public void verifyGetCologuardPageTest() {

		checkForExUSSite(cologuardHomePageURL);
		logInfo("Opened Cologuard Homepage URL '" + cologuardHomePageURL + "'");
		acceptCookies();

		verifySafely(howToGetCologuardPage.isCologuardHomepageDisplayed(), true, "Cologuard homepage is displayed");

		howToGetCologuardPage.clickTopNavOption(getCologuard);
		verifySafely(driver.getURL(), getCologuardURL, "'Get Cologuard' page is displayed");
		verifySafely(driver.getTitle(), getCologuardPageTitle,
				getCologuardPageTitle + " title is displayed for the page");

		howToGetCologuardPage.clickReadMoreLink();
		verifySafely(howToGetCologuardPage.isReadLessDisplayed(), true, "'Read less' is now displayed");

		howToGetCologuardPage.clickReadLessLink();
		verifySafely(howToGetCologuardPage.isReadMoreDisplayed(), true, "'Read more' is now displayed");

		howToGetCologuardPage.clickRequestCologuardOnlineLink();
		verifySafely(driver.getURL(), askForCologuardOnlineURL, "'Request Colouard online' page is displayed");

		driver.switchToParentWindow();

		howToGetCologuardPage.clickGetDiscussionGuideLink();
		verifySafely(driver.getURL(), getDiscussionGuideURL, "'Get Disucssion guide' page is displayed");

		driver.switchToParentWindow();

		howToGetCologuardPage.clickHowToUseCologuard();
		verifySafely(driver.getURL(), howToUseCologuardURL, "'How to use Cologuard' page is displayed");

		driver.back();

		howToGetCologuardPage.clickSignupNow();
		verifySafely(driver.getURL(), signUpURL, "'Sign up now' page is displayed");
		verifySafely(driver.getTitle(), signUpForCologuardTitle,
				signUpForCologuardTitle + " title is displayed for the page");

		throwAssertionErrorOnFailure();
	}
}
