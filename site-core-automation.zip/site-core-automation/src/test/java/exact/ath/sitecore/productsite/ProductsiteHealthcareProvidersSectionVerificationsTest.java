package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.PSOncotypeDXBreastDcisScoreTestPage;
import exact.ath.productsite.PSOncotypeDXBreastRecurrenceScoreTestPage;
import exact.ath.productsite.PSOncotypeDXColonRecurrenceScoreTestPage;
import exact.ath.productsite.ProductsiteAdvancedSolidTumorPage;
import exact.ath.productsite.ProductsiteBreastCancerCarePage;
import exact.ath.productsite.ProductsiteColonCancerCarePage;
import exact.ath.productsite.ProductsiteHomepage;
import exact.ath.productsite.ProductsiteOncoextraTestPage;

/**
 * This class verifies Productsite 'HEALTHCARE PROVIDERS' section
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 06/09/2023
 */
public class ProductsiteHealthcareProvidersSectionVerificationsTest extends BasicIntTest {

	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();
	private final ProductsiteBreastCancerCarePage productsiteBreastCancerCarePage = new ProductsiteBreastCancerCarePage();
	private final PSOncotypeDXBreastRecurrenceScoreTestPage pSOncotypeDXBreastRecurrenceScoreTestPage = new PSOncotypeDXBreastRecurrenceScoreTestPage();
	private final PSOncotypeDXBreastDcisScoreTestPage pSOncotypeDXBreastDcisScoreTestPage = new PSOncotypeDXBreastDcisScoreTestPage();
	private final ProductsiteColonCancerCarePage productsiteColonCancerCarePage = new ProductsiteColonCancerCarePage();
	private final PSOncotypeDXColonRecurrenceScoreTestPage pSOncotypeDXColonRecurrenceScoreTestPage = new PSOncotypeDXColonRecurrenceScoreTestPage();
	private final ProductsiteAdvancedSolidTumorPage productsiteAdvancedSolidTumorPage = new ProductsiteAdvancedSolidTumorPage();
	private final ProductsiteOncoextraTestPage productsiteOncoextraTestPage = new ProductsiteOncoextraTestPage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String treatmentDeterminationSubsectionValue = productsitePagesProperties
			.getProperty("TreatmentDeterminationSubsectionValue");
	private final String therapySelectionSubsectionValue = productsitePagesProperties
			.getProperty("TherapySelectionSubsectionValue");
	private final String TabNames = productsitePagesProperties.getProperty("TabNames");
	private final String HealthcareProviderSubsectionValues = productsitePagesProperties
			.getProperty("HealthcareProviderSubsectionValues");
	private final String HealthcareProviderSubmenuValues = productsitePagesProperties
			.getProperty("HealthcareProviderSubmenuValues");
	private final String HealthcareProviderSubpartsValues = productsitePagesProperties
			.getProperty("HealthcareProviderSubpartsValues");
	private final String breastCancerPageHeaderValue = productsitePagesProperties
			.getProperty("BreastCancerPageHeaderValue");
	private final String breastCancerPageUrl = productsitePagesProperties.getProperty("BreastCancerPageUrl");
	private final String BreastCancerPageIconCardsValues = productsitePagesProperties
			.getProperty("BreastCancerPageIconCardsValues");
	private final String howToOrderTestPageHeaderValue = productsitePagesProperties
			.getProperty("HowToOrderTestPageHeaderValue");
	private final String howToOrderTestPageUrl = productsitePagesProperties.getProperty("HowToOrderTestPageUrl");
	private final String physicianPortalPageUrl = productsitePagesProperties.getProperty("PhysicianPortalPageUrl");
	private final String signUpForPhysicianPortalPageHeaderValue = productsitePagesProperties
			.getProperty("SignUpForPhysicianPortalPageHeaderValue");
	private final String signUpForPhysicianPortalPageUrl = productsitePagesProperties
			.getProperty("SignUpForPhysicianPortalPageUrl");
	private final String oncotypeDXBreastRecurrenceScoreTestPageHeaderValue = productsitePagesProperties
			.getProperty("OncotypeDXBreastRecurrenceScoreTestPageHeaderValue");
	private final String BreastRecurrenceScoreBannerTabNames = productsitePagesProperties
			.getProperty("BreastRecurrenceScoreBannerTabNames");
	private final String OncotypeDXBreastRecurrenceScoreTestPageLinksName = productsitePagesProperties
			.getProperty("OncotypeDXBreastRecurrenceScoreTestPageLinksName");
	private final String OncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle = productsitePagesProperties
			.getProperty("OncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle");
	private final String ClinicalEvidenceCardNames = productsitePagesProperties
			.getProperty("ClinicalEvidenceCardNames");
	private final String ClinicalEvidenceCarPageHeaderValue = productsitePagesProperties
			.getProperty("ClinicalEvidenceCarPageHeaderValue");
	private final String whatItMeansForTheOncotypeDXBreastRecurrenceScoretestPageUrl = productsitePagesProperties
			.getProperty("WhatItMeansForTheOncotypeDXBreastRecurrenceScoretestPageUrl");
	private final String clinicalUtilityInNeoadjuvantPatientsPageUrl = productsitePagesProperties
			.getProperty("ClinicalUtilityInNeoadjuvantPatientsPageUrl");
	private final String viewPublicationPageUrl = productsitePagesProperties.getProperty("ViewPublicationPageUrl");
	private final String viewPublication2PageUrl = productsitePagesProperties.getProperty("ViewPublication2PageUrl");
	private final String viewClinicalUtilityInTheLocoregionalPageUrl = productsitePagesProperties
			.getProperty("ViewClinicalUtilityInTheLocoregionalPageUrl");
	private final String testCompraisonPageHeaderValue = productsitePagesProperties
			.getProperty("TestCompraisonPageHeaderValue");
	private final String interpretingTheResultsPageHeaderValue = productsitePagesProperties
			.getProperty("InterpretingTheResultsPageHeaderValue");
	private final String resourcesPageHeaderValue = productsitePagesProperties.getProperty("ResourcesPageHeaderValue");
	private final String tailorxPageUrl = productsitePagesProperties.getProperty("TailorxPageUrl");
	private final String ascoGuidelinesPageUrl = productsitePagesProperties.getProperty("AscoGuidelinesPageUrl");
	private final String gapAndBillingBrochurePageUrl = productsitePagesProperties
			.getProperty("GapAndBillingBrochurePageUrl");
	private final String pathologyGuidelinesPageUrl = productsitePagesProperties
			.getProperty("PathologyGuidelinesPageUrl");
	private final String oncotypeDXBreastRecurrenceScoreRequisitionFormPageUrl = productsitePagesProperties
			.getProperty("OncotypeDXBreastRecurrenceScoreRequisitionFormPageUrl");
	private final String orderATestPageHeaderValue = productsitePagesProperties
			.getProperty("OrderATestPageHeaderValue");
	private final String HowToOrderPageButtonsName = productsitePagesProperties
			.getProperty("HowToOrderPageButtonsName");
	private final String HowToOrderPageButtonsUrl = productsitePagesProperties.getProperty("HowToOrderPageButtonsUrl");
	private final String oncotypeDXBreastDcisScoreTestPageHeaderValue = productsitePagesProperties
			.getProperty("OncotypeDXBreastDcisScoreTestPageHeaderValue");
	private final String OncotypeDXBreastDcisScoreTestPageLinksName = productsitePagesProperties
			.getProperty("OncotypeDXBreastDcisScoreTestPageLinksName");
	private final String OncotypeDXBreastDcisScoreTestPageLinksPageTitle = productsitePagesProperties
			.getProperty("OncotypeDXBreastDcisScoreTestPageLinksPageTitle");
	private final String colonCancerPageHeaderValue = productsitePagesProperties
			.getProperty("ColonCancerPageHeaderValue");
	private final String oncotypeDXColonRecurrenceScorePageHeaderValue = productsitePagesProperties
			.getProperty("OncotypeDXColonRecurrenceScorePageHeaderValue");
	private final String physicianPortalPageTitle = productsitePagesProperties.getProperty("PhysicianPortalPageTitle");
	private final String exploreTheResultsPageHeaderValue = productsitePagesProperties
			.getProperty("ExploreTheResultsPageHeaderValue");
	private final String ColonRecurrenceScoreBannerTabNames = productsitePagesProperties
			.getProperty("ColonRecurrenceScoreBannerTabNames");
	private final String seeTheClinicalUtilityOfTheTestPageHeaderValue = productsitePagesProperties
			.getProperty("SeeTheClinicalUtilityOfTheTestPageHeaderValue");
	private final String learnWhyColonRecurrenceScoreIsTheTestOfChoicePageHeaderValue = productsitePagesProperties
			.getProperty("LearnWhyColonRecurrenceScoreIsTheTestOfChoicePageHeaderValue");
	private final String seeHowToOrderColonPageHeaderValue = productsitePagesProperties
			.getProperty("SeeHowToOrderColonPageHeaderValue");
	private final String viewMoreBillingAndCoverageDetailsColonPageHeaderValue = productsitePagesProperties
			.getProperty("ViewMoreBillingAndCoverageDetailsColonPageHeaderValue");
	private final String viewStudyDetailsPageTitle = productsitePagesProperties
			.getProperty("ViewStudyDetailsPageTitle");
	private final String StudyNames = productsitePagesProperties.getProperty("StudyNames");
	private final String learnHowToReadTheTestResultsPageTitle = productsitePagesProperties
			.getProperty("LearnHowToReadTheTestResultsPageTitle");
	private final String downloadSampleStageIIIReportPageUrl = productsitePagesProperties
			.getProperty("DownloadSampleStageIIIReportPageUrl");
	private final String downloadSampleStageIIReportPageUrl = productsitePagesProperties
			.getProperty("DownloadSampleStageIIReportPageUrl");
	private final String whyColonRecurrenceScorePageHeaderValue = productsitePagesProperties
			.getProperty("WhyColonRecurrenceScorePageHeaderValue");
	private final String advancedSolidTumorsPageHeaderValue = productsitePagesProperties
			.getProperty("AdvancedSolidTumorsPageHeaderValue");
	private final String oncoExTraTestPageHeaderValue = productsitePagesProperties
			.getProperty("OncoExTraTestPageHeaderValue");
	private final String orderNowPageTitle = productsitePagesProperties.getProperty("OrderNowPageTitle");
	private final String OncoextraTestPageBannerTabNames = productsitePagesProperties
			.getProperty("OncoextraTestPageBannerTabNames");
	private final String downloadAnalyticValidationPageUrl = productsitePagesProperties
			.getProperty("DownloadAnalyticValidationPageUrl");
	private final String downloadPublicationPageUrl = productsitePagesProperties
			.getProperty("DownloadPublicationPageUrl");
	private final String oncoExTraReportPageHeaderValue = productsitePagesProperties
			.getProperty("OncoExTraReportPageHeaderValue");
	private final String OncoExTraTestReportName = productsitePagesProperties.getProperty("OncoExTraTestReportName");
	private final String OncoExTraTestReportPageUrl = productsitePagesProperties
			.getProperty("OncoExTraTestReportPageUrl");
	private final String resourceFaqPageHeaderValue = productsitePagesProperties
			.getProperty("ResourceFaqPageHeaderValue");
	private final String getTheStarterKitPageHeaderValue = productsitePagesProperties
			.getProperty("GetTheStarterKitPageHeaderValue");
	private final String getTheWhitePaperPageHeaderValue = productsitePagesProperties
			.getProperty("GetTheWhitePaperPageHeaderValue");
	private final String OncoExTraTestResourceFaqUrl = productsitePagesProperties
			.getProperty("OncoExTraTestResourceFaqUrl");
	private final String clinicalUtilityPageHeaderValue = productsitePagesProperties
			.getProperty("ClinicalUtilityPageHeaderValue");
	private final String FaqAndReferenceAccordionName = productsitePagesProperties
			.getProperty("FaqAndReferenceAccordionName");

	private final String[] tabNames = TabNames.split(",");
	private final String[] healthcareProviderSubsectionValues = HealthcareProviderSubsectionValues.split(",");
	private final String[] healthcareProviderSubmenuValues = HealthcareProviderSubmenuValues.split(",");
	private final String[] healthcareProviderSubpartsValues = HealthcareProviderSubpartsValues.split(",");
	private final String[] breastCancerPageIconCardsValues = BreastCancerPageIconCardsValues.split(",");
	private final String[] breastRecurrenceScoreBannerTabNames = BreastRecurrenceScoreBannerTabNames.split(",");
	private final String[] oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle = OncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle
			.split(",");
	private final String[] clinicalEvidenceCardNames = ClinicalEvidenceCardNames.split(",");
	private final String[] clinicalEvidenceCarPageHeaderValue = ClinicalEvidenceCarPageHeaderValue.split(",");
	private final String[] linksName = OncotypeDXBreastRecurrenceScoreTestPageLinksName.split(",");
	private final String[] howToOrderPageButtonsUrl = HowToOrderPageButtonsUrl.split(",");
	private final String[] oncotypeDXBreastDcisScoreTestPageLinksPageTitle = OncotypeDXBreastDcisScoreTestPageLinksPageTitle
			.split(",");
	private final String[] colonRecurrenceScoreBannerTabNames = ColonRecurrenceScoreBannerTabNames.split(",");
	private final String[] oncoextraTestPageBannerTabNames = OncoextraTestPageBannerTabNames.split(",");
	private final String[] oncoExTraTestReportPageUrl = OncoExTraTestReportPageUrl.split(",");

	private int count = 0;
	private int counter = 0;
	private int number = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsiteHealthcareProvidersSectionVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		verifySafely(productsiteHomepage.getHealthcareProviderSubsection(healthcareProviderSubsectionValues[0]),
				treatmentDeterminationSubsectionValue,
				"Healthcare Provider Subsection '" + healthcareProviderSubsectionValues[0] + "' is dispalyed");
		verifySafely(productsiteHomepage.getHealthcareProviderSubsection(healthcareProviderSubsectionValues[1]),
				therapySelectionSubsectionValue,
				"Healthcare Provider Subsection '" + healthcareProviderSubsectionValues[1] + "' is dispalyed");
		verifySafely(productsiteHomepage.isHealthcareProviderSubmenuDisplayed(healthcareProviderSubmenuValues[0]), true,
				"Healthcare Provider Submenu '" + healthcareProviderSubmenuValues[0] + "' is dispalyed");

		verifySafely(productsiteHomepage.isHealthcareProviderSubpartsDisplayed(healthcareProviderSubpartsValues[0]),
				true, "Healthcare Provider Subparts '" + healthcareProviderSubpartsValues[0] + "' is dispalyed");
		verifySafely(productsiteHomepage.isHealthcareProviderSubpartsDisplayed(healthcareProviderSubpartsValues[1]),
				true, "Healthcare Provider Subparts '" + healthcareProviderSubpartsValues[1] + "' is dispalyed");

		verifySafely(productsiteHomepage.isHealthcareProviderSubmenuDisplayed(healthcareProviderSubmenuValues[1]), true,
				"Healthcare Provider Submenu '" + healthcareProviderSubmenuValues[1] + "' is dispalyed");
		verifySafely(productsiteHomepage.isHealthcareProviderSubpartsDisplayed(healthcareProviderSubpartsValues[2]),
				true, "Healthcare Provider Subparts '" + healthcareProviderSubpartsValues[2] + "' is dispalyed");

		verifySafely(productsiteHomepage.isHealthcareProviderSubmenuDisplayed(healthcareProviderSubmenuValues[2]), true,
				"Healthcare Provider Submenu '" + healthcareProviderSubmenuValues[2] + "' is dispalyed");
		verifySafely(productsiteHomepage.isHealthcareProviderSubpartsDisplayed(healthcareProviderSubpartsValues[3]),
				true, "Healthcare Provider Subparts '" + healthcareProviderSubpartsValues[3] + "' is dispalyed");

		productsiteHomepage.clickHealthcareProviderSubmenu(healthcareProviderSubmenuValues[0]);
		verifySafely(productsiteHomepage.getPageHeader(), breastCancerPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), breastCancerPageUrl, "Breast cancer page url matched");
		verifySafely(
				productsiteBreastCancerCarePage
						.isBreastCancerPageIconCardsDisplayed(healthcareProviderSubpartsValues[0]),
				true, "Icon card'" + healthcareProviderSubpartsValues[0] + "' is dispalyed");
		verifySafely(
				productsiteBreastCancerCarePage
						.isBreastCancerPageIconCardsDisplayed(healthcareProviderSubpartsValues[1]),
				true, "Icon card'" + healthcareProviderSubpartsValues[1] + "' is dispalyed");
		productsiteBreastCancerCarePage.clickBreastCancerPageIconCardsExploreTest(breastCancerPageIconCardsValues[0]);
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXBreastRecurrenceScoreTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		productsiteBreastCancerCarePage.clickBreastCancerPageIconCardsExploreTest(breastCancerPageIconCardsValues[1]);
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXBreastDcisScoreTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		verifySafely(productsiteBreastCancerCarePage.isCallButtonDispalyed(), true,
				"'+1 866-662-6897' button is dispalyed");
		productsiteBreastCancerCarePage.clickHowToOrderOncotypeBreastTestLink();
		verifySafely(productsiteHomepage.getPageHeader(), howToOrderTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), howToOrderTestPageUrl, "'How To Order Test' page url matched");
		driver.back();
		productsiteBreastCancerCarePage.clickOrderThroughPhysicianPortal();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), physicianPortalPageUrl, "'Physician Portal' page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteBreastCancerCarePage.clickSignUpForPhysicianPortal();
		driver.switchToCurrentWindow();
		verifySafely(productsiteHomepage.getPageHeader(), signUpForPhysicianPortalPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), signUpForPhysicianPortalPageUrl,
				"'Sign Up For Physician Portal' page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.back();

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();

		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[0]);
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXBreastRecurrenceScoreTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteHomepage.clickHeroLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), breastCancerPageUrl, "Breast cancer page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[0]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[0], "After clicked on '"
				+ linksName[0] + "' user redirects to 'Is Your Patient Eligible?' content on same page");
		verifyOncotypeDXBreastRecurrenceScoreTestPageLinks();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReadTheGroundbreakingResults();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[5],
				"'Read The Groundbreaking Results' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickSeeHowToOrder();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[6],
				"'See how to order' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[7],
				"'Contact us' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReferencesAccordion();
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isReferencesAccordionExpand(), true,
				"'References' Accordion expanded");

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[0]);

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(breastRecurrenceScoreBannerTabNames[1]);
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(breastRecurrenceScoreBannerTabNames[1]),
				true, "'" + breastRecurrenceScoreBannerTabNames[1] + "' banner tab is higlighted");
		verifySafely(productsiteHomepage.getPageHeader(), clinicalEvidenceCarPageHeaderValue[0],
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifyClinicalEvidenceCards();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnClinicalEvidenceCard(clinicalEvidenceCardNames[1]);
		verifySafely(productsiteHomepage.getPageHeader(), clinicalEvidenceCarPageHeaderValue[1],
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(breastRecurrenceScoreBannerTabNames[1]),
				true, "'" + breastRecurrenceScoreBannerTabNames[1] + "' banner tab higlighted");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isClinicalEvidenceCardOpen(clinicalEvidenceCardNames[1]),
				true, "'" + clinicalEvidenceCardNames[1] + "' card is higlighted");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickWhatItMeansForTheOncotypeDXBreastRecurrenceScoretest();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), whatItMeansForTheOncotypeDXBreastRecurrenceScoretestPageUrl,
				"Watch Dr. Sharma and Dr. Pusztai talk about TAILORx and what it means for the Oncotype DX Breast Recurrence Score test page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[5]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[8],
				"'" + linksName[5] + "' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[6]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[9],
				"'" + linksName[6] + "' page title matched");
		driver.back();

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[7],
				"'Contact us' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnClinicalEvidenceCard(clinicalEvidenceCardNames[2]);
		verifySafely(productsiteHomepage.getPageHeader(), clinicalEvidenceCarPageHeaderValue[2],
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isClinicalEvidenceCardOpen(clinicalEvidenceCardNames[2]),
				true, "'" + clinicalEvidenceCardNames[2] + "' card is higlighted");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[7]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[10],
				"After clicked on '" + linksName[7] + "' user redirects to 'RxPONDER trial' content on a same page");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[8]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[10],
				"After clicked on '" + linksName[8] + "' user redirects to 'RxPONDER trial' content on a same page");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[9]);
		verifySafely(driver.getURL(), clinicalUtilityInNeoadjuvantPatientsPageUrl,
				"'" + linksName[9] + "' page url matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[6]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[9],
				"'" + linksName[6] + "' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[7],
				"'Contact us' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnClinicalEvidenceCard(clinicalEvidenceCardNames[3]);
		verifySafely(productsiteHomepage.getPageHeader(), clinicalEvidenceCarPageHeaderValue[3],
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isClinicalEvidenceCardOpen(clinicalEvidenceCardNames[3]),
				true, "'" + clinicalEvidenceCardNames[3] + "' card is higlighted");
		productsiteHomepage.clickHeroLink();
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXBreastRecurrenceScoreTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[7]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[11],
				"After clicked on '" + linksName[7] + "' user redirects on a same page");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[10]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[11],
				"After clicked on '" + linksName[7] + "' user redirects on a same page");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[11]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[11],
				"After clicked on '" + linksName[7] + "' user redirects on a same page");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickViewPublicationLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), viewPublicationPageUrl, "'View Publication' page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[12]);
		verifySafely(driver.getURL(), viewPublication2PageUrl, "'View Publication' page url matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickViewClinicalUtilityInTheLocoregionalLink();
		verifySafely(driver.getURL(), viewClinicalUtilityInTheLocoregionalPageUrl,
				"'View clinical utility in the locoregional and late-recurrence setting ' page url matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReferencesAccordion();
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isReferencesAccordionExpand(), true,
				"'References' Accordion expanded");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnClinicalEvidenceCard(clinicalEvidenceCardNames[4]);
		verifySafely(productsiteHomepage.getPageHeader(), clinicalEvidenceCarPageHeaderValue[4],
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isClinicalEvidenceCardOpen(clinicalEvidenceCardNames[4]),
				true, "'" + clinicalEvidenceCardNames[4] + "' card is higlighted");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickExploreClinicalEvidenceLink();
		verifySafely(productsiteHomepage.getPageHeader(), clinicalEvidenceCarPageHeaderValue[0],
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReferencesAccordion();
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isReferencesAccordionExpand(), true,
				"'References' Accordion expanded");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[6]);
		verifySafely(productsiteHomepage.getPageHeader(), signUpForPhysicianPortalPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[0]);

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(breastRecurrenceScoreBannerTabNames[2]);
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(breastRecurrenceScoreBannerTabNames[2]),
				true, "'" + breastRecurrenceScoreBannerTabNames[2] + "' banner tab is higlighted");
		verifySafely(productsiteHomepage.getPageHeader(), testCompraisonPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[13]);
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[12],
				"'" + linksName[13] + "' page title matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(breastRecurrenceScoreBannerTabNames[3]);
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(breastRecurrenceScoreBannerTabNames[3]),
				true, "'" + breastRecurrenceScoreBannerTabNames[3] + "' banner tab is higlighted");
		verifySafely(productsiteHomepage.getPageHeader(), interpretingTheResultsPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[14]);
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[9],
				"'" + linksName[14] + "' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickHereHowToOrder();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[6],
				"'Here's how to order' page title matched");
		driver.back();

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[0]);

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(breastRecurrenceScoreBannerTabNames[4]);
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(breastRecurrenceScoreBannerTabNames[4]),
				true, "'" + breastRecurrenceScoreBannerTabNames[4] + "' banner tab is higlighted");
		verifySafely(productsiteHomepage.getPageHeader(), resourcesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickTailorxLink();
		verifySafely(driver.getURL(), tailorxPageUrl, "'TAILORx' Page Url matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickAscoGuidelinesLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), ascoGuidelinesPageUrl, "'ASCO Guidelines' Page Url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickGapAndBillingBrochureLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), gapAndBillingBrochurePageUrl, "'GAP and Billing Brochure' Page Url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickPathologyGuidelinesLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), pathologyGuidelinesPageUrl, "'Pathology Guidelines' Page Url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOncotypeDXBreastRecurrenceScoreRequisitionFormLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), oncotypeDXBreastRecurrenceScoreRequisitionFormPageUrl,
				"'Oncotype DX Breast Recurrence Score Requisition Form' Page Url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[0]);

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(breastRecurrenceScoreBannerTabNames[5]);
		verifySafely(productsiteHomepage.getPageHeader(), orderATestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifyHowToOrderPageButtons();
		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[1]);
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXBreastDcisScoreTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifyOncotypeDXBreastDcisScoreTestPageLinks();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();

		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubmenu(healthcareProviderSubmenuValues[1]);
		verifySafely(productsiteHomepage.getPageHeader(), colonCancerPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteColonCancerCarePage.clickColonCancerPageIconCardExploreTest();
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXColonRecurrenceScorePageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReferencesAccordion();
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isReferencesAccordionExpand(), true,
				"'References' Accordion expanded");
		productsiteBreastCancerCarePage.clickOrderThroughPhysicianPortal();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), physicianPortalPageTitle, "'Physician Portal' page title matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteBreastCancerCarePage.clickSignUpForPhysicianPortal();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[9],
				"'Sign Up For Physician Portal' page title matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[7],
				"'Contact us' page title matched");
		driver.back();

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();

		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[2]);
		verifySafely(productsiteHomepage.getPageHeader(), oncotypeDXColonRecurrenceScorePageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXColonRecurrenceScoreTestPage.isOverviewTabHighlighted(), true,
				"'OVERVIEW' tab is highlighted");
		pSOncotypeDXColonRecurrenceScoreTestPage.clickExploreTheResultsButton();
		verifySafely(productsiteHomepage.getPageHeader(), exploreTheResultsPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(colonRecurrenceScoreBannerTabNames[1]),
				true, "'" + colonRecurrenceScoreBannerTabNames[1] + "' banner tab higlighted");
		driver.back();
		pSOncotypeDXColonRecurrenceScoreTestPage.clickSeeTheClinicalUtilityOfTheTestLink();
		verifySafely(productsiteHomepage.getPageHeader(), seeTheClinicalUtilityOfTheTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(colonRecurrenceScoreBannerTabNames[0]),
				true, "'" + colonRecurrenceScoreBannerTabNames[0] + "' banner tab higlighted");
		driver.back();
		pSOncotypeDXColonRecurrenceScoreTestPage.clickLearnWhyColonRecurrenceScoreIsTheTestOfChoiceLink();
		verifySafely(productsiteHomepage.getPageHeader(), learnWhyColonRecurrenceScoreIsTheTestOfChoicePageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(colonRecurrenceScoreBannerTabNames[2]),
				true, "'" + colonRecurrenceScoreBannerTabNames[2] + "' banner tab higlighted");
		driver.back();
		pSOncotypeDXColonRecurrenceScoreTestPage.clickSeeHowToOrderColonLink();
		verifySafely(productsiteHomepage.getPageHeader(), seeHowToOrderColonPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXColonRecurrenceScoreTestPage.clickViewMoreBillingAndCoverageDetailsColonLink();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(),
				viewMoreBillingAndCoverageDetailsColonPageHeaderValue,
				"Page header 'Supporting Your Patients' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReferencesAccordion();
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isReferencesAccordionExpand(), true,
				"'References' Accordion expanded");

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(colonRecurrenceScoreBannerTabNames[0]);
		verifySafely(productsiteHomepage.getPageHeader(), seeTheClinicalUtilityOfTheTestPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(colonRecurrenceScoreBannerTabNames[0]),
				true, "'" + colonRecurrenceScoreBannerTabNames[0] + "' banner tab higlighted");
		pSOncotypeDXColonRecurrenceScoreTestPage.clickViewStudyDetailsButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), viewStudyDetailsPageTitle, "'View Study Details' page title matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		verifyOncotypeDXColonRecurrenceScoreTestPageStudies();
		pSOncotypeDXColonRecurrenceScoreTestPage.clickLearnHowToReadTheTestResultsButton();
		verifySafely(driver.getTitle(), learnHowToReadTheTestResultsPageTitle,
				"'Learn how to read the test results' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReferencesAccordion();
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isReferencesAccordionExpand(), true,
				"'References' Accordion expanded");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(colonRecurrenceScoreBannerTabNames[1]);
		verifySafely(productsiteHomepage.getPageHeader(), exploreTheResultsPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(colonRecurrenceScoreBannerTabNames[1]),
				true, "'" + colonRecurrenceScoreBannerTabNames[1] + "' banner tab higlighted");
		pSOncotypeDXColonRecurrenceScoreTestPage.clickDownloadSampleStageIIIReportButton();
		verifySafely(driver.getURL(), downloadSampleStageIIIReportPageUrl,
				"'Download Sample Stage III Report' Page Url matched");
		driver.back();
		pSOncotypeDXColonRecurrenceScoreTestPage.clickDownloadSampleStageIIReportButton();
		verifySafely(driver.getURL(), downloadSampleStageIIReportPageUrl,
				"'Download Sample Stage II Report' Page Url matched");
		driver.back();
		productsiteBreastCancerCarePage.clickOrderThroughPhysicianPortal();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), physicianPortalPageTitle, "'Physician Portal' page title matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteBreastCancerCarePage.clickSignUpForPhysicianPortal();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[9],
				"'Sign Up For Physician Portal' page title matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[7],
				"'Contact us' page title matched");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(colonRecurrenceScoreBannerTabNames[2]);
		verifySafely(productsiteHomepage.getPageHeader(), whyColonRecurrenceScorePageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(colonRecurrenceScoreBannerTabNames[2]),
				true, "'" + colonRecurrenceScoreBannerTabNames[2] + "' banner tab higlighted");
		pSOncotypeDXColonRecurrenceScoreTestPage.clickOrderTheTestNowButton();
		verifySafely(productsiteHomepage.getPageHeader(), seeHowToOrderColonPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickReferencesAccordion();
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isReferencesAccordionExpand(), true,
				"'References' Accordion expanded");

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();

		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubmenu(healthcareProviderSubmenuValues[2]);
		verifySafely(productsiteHomepage.getPageHeader(), advancedSolidTumorsPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteAdvancedSolidTumorPage.clickAdvancedSolidTumorPageIconCardExploreTest();

		verifySafely(productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage(), oncoExTraTestPageHeaderValue,
				"Page header '" + productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage()
						+ "' is dispalyed");
		driver.back();
		productsiteAdvancedSolidTumorPage.clickOrderNowButton();
		verifySafely(driver.getTitle(), orderNowPageTitle, "'Order Now' page title matched");
		driver.back();
		productsiteBreastCancerCarePage.clickSignUpForPhysicianPortal();
		driver.switchToCurrentWindow();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[9],
				"'Sign Up For Physician Portal' page title matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnContactUsUnderOrangeBanner();
		verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[7],
				"'Contact us' page title matched");
		driver.back();

		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();

		productsiteHomepage.clickHeaderTab(tabNames[0]);
		productsiteHomepage.clickHealthcareProviderSubparts(healthcareProviderSubpartsValues[3]);
		verifySafely(productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage(), oncoExTraTestPageHeaderValue,
				"Page header '" + productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage()
						+ "' is dispalyed");
		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(oncoextraTestPageBannerTabNames[1]);
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(oncoextraTestPageBannerTabNames[1]),
				true, "'" + oncoextraTestPageBannerTabNames[1] + "' banner tab higlighted");
		verifySafely(productsiteHomepage.getPageHeader(), clinicalUtilityPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteOncoextraTestPage.clickDownloadAnalyticValidationButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadAnalyticValidationPageUrl,
				"'Download analytic validation' Page Url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteOncoextraTestPage.clickDownloadPublicationButton();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), downloadPublicationPageUrl, "'Download publication' Page Url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(oncoextraTestPageBannerTabNames[2]);
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(oncoextraTestPageBannerTabNames[2]),
				true, "'" + oncoextraTestPageBannerTabNames[2] + "' banner tab higlighted");
		verifySafely(productsiteHomepage.getPageHeader(), oncoExTraReportPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifyOncoExTraTestReports();
		verifySafely(productsiteOncoextraTestPage.isContactMedicalTeamButtonDisplayed(), true,
				"'Contact Medical Team' button is dispalyed");

		pSOncotypeDXBreastRecurrenceScoreTestPage.clickBannerTabs(oncoextraTestPageBannerTabNames[3]);
		verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isBannerTabOpen(oncoextraTestPageBannerTabNames[3]),
				true, "'" + oncoextraTestPageBannerTabNames[3] + "' banner tab higlighted");
		verifySafely(productsiteHomepage.getPageHeader(), resourceFaqPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		productsiteOncoextraTestPage.clickGetTheStarterKitButton();
		verifySafely(productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage(),
				getTheStarterKitPageHeaderValue, "Page header '"
						+ productsiteAdvancedSolidTumorPage.getHeaderValueForOncoextraPage() + "' is dispalyed");
		driver.back();
		productsiteOncoextraTestPage.clickGetTheWhitePaperButton();
		verifySafely(productsiteHomepage.getPageHeader(), getTheWhitePaperPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		driver.back();
		verifyOncoExTraResourceFaqLinks();
		productsiteOncoextraTestPage.clickBillingCoverageOverviewlink();
		verifySafely(productsiteHomepage.getOrangeBackgroundPageHeader(),
				viewMoreBillingAndCoverageDetailsColonPageHeaderValue,
				"Page header '" + productsiteHomepage.getOrangeBackgroundPageHeader() + "' is dispalyed");
		driver.back();
		verifyFaqAndReferenceAccordion();
		driver.close();
		throwAssertionErrorOnFailure();
	}

	public void verifyOncotypeDXBreastRecurrenceScoreTestPageLinks() {
		for (int count = 1; count <= 4; count++) {
			pSOncotypeDXBreastRecurrenceScoreTestPage.clickOnLinks(linksName[count]);
			verifySafely(driver.getTitle(), oncotypeDXBreastRecurrenceScoreTestPageLinksPageTitle[count],
					"'" + linksName[count] + "' page title matched");
			driver.back();
		}
	}

	public void verifyClinicalEvidenceCards() {
		for (String clinicalEvidenceCardNames : ClinicalEvidenceCardNames.split(",")) {
			verifySafely(pSOncotypeDXBreastRecurrenceScoreTestPage.isClinicalEvidenceCardDisplayed(
					clinicalEvidenceCardNames), true, "'" + clinicalEvidenceCardNames + "' card is displayed");
		}
	}

	public void verifyHowToOrderPageButtons() {
		for (String howToOrderPageButtonsName : HowToOrderPageButtonsName.split(",")) {
			pSOncotypeDXBreastRecurrenceScoreTestPage.clickHowToOrderPageButtons(howToOrderPageButtonsName);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), howToOrderPageButtonsUrl[count],
					"'" + howToOrderPageButtonsName + "' Page Url matched");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
			count++;
		}
	}

	public void verifyOncotypeDXBreastDcisScoreTestPageLinks() {
		for (String oncotypeDXBreastDcisScoreTestPageLinksName : OncotypeDXBreastDcisScoreTestPageLinksName
				.split(",")) {
			pSOncotypeDXBreastDcisScoreTestPage
					.clickOncotypeDXBreastDcisScoreTestPageLinks(oncotypeDXBreastDcisScoreTestPageLinksName);
			verifySafely(driver.getTitle(), oncotypeDXBreastDcisScoreTestPageLinksPageTitle[counter],
					"'" + oncotypeDXBreastDcisScoreTestPageLinksName + "' page title matched");
			driver.back();
			counter++;
		}

	}

	public void verifyOncotypeDXColonRecurrenceScoreTestPageStudies() {
		for (String studyNames : StudyNames.split(",")) {
			pSOncotypeDXColonRecurrenceScoreTestPage
					.clickViewStudyDetailsButtonsUnderClinicallyValidatedIn4Studies(studyNames);
			verifySafely(productsiteHomepage.getPageHeader(), seeTheClinicalUtilityOfTheTestPageHeaderValue,
					"After clicked page  header '" + productsiteHomepage.getPageHeader() + "' is same");
		}
	}

	public void verifyOncoExTraTestReports() {
		for (String oncoExTraTestReportName : OncoExTraTestReportName.split(",")) {
			productsiteOncoextraTestPage.clickOncoExTraReportsButtons(oncoExTraTestReportName);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), oncoExTraTestReportPageUrl[number],
					"'" + oncoExTraTestReportName + "' Page Url matched");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
			number++;
		}
	}

	public void verifyOncoExTraResourceFaqLinks() {
		for (String oncoExTraTestResourceFaqUrl : OncoExTraTestResourceFaqUrl.split(",")) {
			String url = productsiteOncoextraTestPage.getOncoExTraResourceFaqLinksName(oncoExTraTestResourceFaqUrl);
			productsiteOncoextraTestPage.clickOncoExTraResourceFaqLinks(oncoExTraTestResourceFaqUrl);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), oncoExTraTestResourceFaqUrl, "'" + url + "' Page Url matched");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
		}
	}

	public void verifyFaqAndReferenceAccordion() {
		for (String faqAndReferenceAccordionName : FaqAndReferenceAccordionName.split(",")) {
			productsiteOncoextraTestPage.clickFaqAndReferenceAccordion(faqAndReferenceAccordionName);
			verifySafely(productsiteOncoextraTestPage.isFaqAndReferenceAccordionExpand(faqAndReferenceAccordionName),
					true, "'" + faqAndReferenceAccordionName + "' accordion is expand");
		}
	}

}
