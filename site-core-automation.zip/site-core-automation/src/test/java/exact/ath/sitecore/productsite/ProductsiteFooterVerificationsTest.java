package exact.ath.sitecore.productsite;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.productsite.ProductsiteHomepage;

/**
 * This class verifies Productsite 'Footer'
 * 
 * @userstory US#304475 Task#306068
 * @author Manpreet Panesar
 * @since 07/13/2023
 */
public class ProductsiteFooterVerificationsTest extends BasicIntTest {

	private final ProductsiteHomepage productsiteHomepage = new ProductsiteHomepage();

	private final String productsiteURL = productsitePagesProperties.getProperty("ProductsiteURL");
	private final String productsiteHomapageTitle = productsitePagesProperties.getProperty("ProductsiteHomapageTitle");
	private final String QickLinksInFooter = productsitePagesProperties.getProperty("QickLinksInFooter");
	private final String FollowUsLinksInFooter = productsitePagesProperties.getProperty("FollowUsLinksInFooter");
	private final String LinksAtBottomOfFooter = productsitePagesProperties.getProperty("LinksAtBottomOfFooter");
	private final String QuickLinksUrls = productsitePagesProperties.getProperty("QuickLinksUrls");
	private final String FollowUsLinksUrls = productsitePagesProperties.getProperty("FollowUsLinksUrls");
	private final String licensesPageHeaderValue = productsitePagesProperties.getProperty("LicensesPageHeaderValue");
	private final String licensesPageUrl = productsitePagesProperties.getProperty("LicensesPageUrl");
	private final String medicareBillingPolicyPageHeaderValue = productsitePagesProperties
			.getProperty("MedicareBillingPolicyPageHeaderValue");
	private final String medicareBillingPolicyPageUrl = productsitePagesProperties
			.getProperty("MedicareBillingPolicyPageUrl");
	private final String privacyPolicyPageHeaderValue = productsitePagesProperties
			.getProperty("PrivacyPolicyPageHeaderValue");
	private final String privacyPolicyPageUrl = productsitePagesProperties.getProperty("PrivacyPolicyPageUrl");
	private final String hIPPANoticePageHeaderValue = productsitePagesProperties
			.getProperty("HIPPANoticePageHeaderValue");
	private final String hIPPANoticePageUrl = productsitePagesProperties.getProperty("HIPPANoticePageUrl");
	private final String doNotSellMyInformationPageHeaderValue = productsitePagesProperties
			.getProperty("DoNotSellMyInformationPageHeaderValue");
	private final String doNotSellMyInformationPageUrl = productsitePagesProperties
			.getProperty("DoNotSellMyInformationPageUrl");
	private final String termsConditionsPageHeaderValue = productsitePagesProperties
			.getProperty("TermsConditionsPageHeaderValue");
	private final String termsConditionsPageUrl = productsitePagesProperties.getProperty("TermsConditionsPageUrl");

	private final String[] quickLinksUrls = QuickLinksUrls.split(",");
	private final String[] followUsLinksUrls = FollowUsLinksUrls.split(",");

	private int count = 0;
	private int counter = 0;

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void productsiteFooterVerificationsTest() throws Exception {
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "Productsite homepage is displayed");
		verifySafely(productsiteHomepage.isExactSciencesLogoDisplayedInFooter(), true,
				"Exactscience logo is displayed");
		verifySafely(productsiteHomepage.isAddressDetailsDisplayedInFooter(), true, "Address details is displayed");
		verifyQuickLinksDisplayedInFooter();
		verifyFollowUsLinksDisplayedInFooter();
		verifyLinksAtBottomOfFooterIsDisplayed();
		verifyQuickLinksInFooterAreClickable();
		verifyFollowUsLinksInFooterClickable();
		driver.close();
		setupURL(productsiteURL);
		logInfo("Opened Productsite Homepage URL '" + productsiteURL + "'");
		acceptCookies();
		productsiteHomepage.clickLicensesFooterLink();
		verifySafely(productsiteHomepage.getPageHeader(), licensesPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), licensesPageUrl, "Licenses page url matched");
		driver.back();
		productsiteHomepage.clickMedicareBillingPolicyFooterLink();
		verifySafely(productsiteHomepage.getPageHeader(), medicareBillingPolicyPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), medicareBillingPolicyPageUrl, "Medicare Billing Policy page url matched");
		driver.back();
		productsiteHomepage.clickPrivacyPolicyFooterLink();
		driver.switchToCurrentWindow();
		verifySafely(productsiteHomepage.getPageHeaderWithImage(), privacyPolicyPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeaderWithImage() + "' is dispalyed");
		verifySafely(driver.getURL(), privacyPolicyPageUrl, "Privacy Policy page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteHomepage.clickHIPPANoticeFooterLink();
		driver.switchToCurrentWindow();
		verifySafely(productsiteHomepage.getHippaCompliancePageHeader(), hIPPANoticePageHeaderValue,
				"Page header '" + productsiteHomepage.getHippaCompliancePageHeader() + "' is dispalyed");
		verifySafely(driver.getURL(), hIPPANoticePageUrl, "HIPPA Notice page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteHomepage.clickDoNotSellMyInformationFooterLink();
		driver.switchToCurrentWindow();
		verifySafely(productsiteHomepage.getPageHeaderWithImage(), doNotSellMyInformationPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeaderWithImage() + "' is dispalyed");
		verifySafely(driver.getURL(), doNotSellMyInformationPageUrl, "Do Not Sell My Information page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		productsiteHomepage.clickCookieSettingsFooterLink();
		verifySafely(driver.getTitle(), productsiteHomapageTitle, "User redirects to productsite homepage");
		productsiteHomepage.clickTermsConditionsFooterLink();
		driver.switchToCurrentWindow();
		verifySafely(productsiteHomepage.getPageHeaderWithImage(), termsConditionsPageHeaderValue,
				"Page header '" + productsiteHomepage.getPageHeaderWithImage() + "' is dispalyed");
		verifySafely(driver.getURL(), termsConditionsPageUrl, "Terms & Conditions page url matched");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		driver.close();

		throwAssertionErrorOnFailure();
	}

	public void verifyQuickLinksDisplayedInFooter() {
		for (String quickLinksInFooter : QickLinksInFooter.split(",")) {
			verifySafely(productsiteHomepage.isQuickLinksDisplayedInFooter(quickLinksInFooter), true,
					"'" + quickLinksInFooter + "' link is displayed");
		}
	}

	public void verifyFollowUsLinksDisplayedInFooter() {
		for (String followUsLinksInFooter : FollowUsLinksInFooter.split(",")) {
			verifySafely(productsiteHomepage.isFollowUsLinksDisplayedInFooter(followUsLinksInFooter), true,
					"'" + followUsLinksInFooter + "' link is displayed");
		}
	}

	public void verifyLinksAtBottomOfFooterIsDisplayed() {
		for (String linksAtBottomOfFooter : LinksAtBottomOfFooter.split(",")) {
			verifySafely(productsiteHomepage.isLinksAtBottomOfFooterIsDisplayed(linksAtBottomOfFooter), true,
					"'" + linksAtBottomOfFooter + "' link is displayed");
		}
	}

	public void verifyQuickLinksInFooterAreClickable() {
		for (String quickLinksInFooter : QickLinksInFooter.split(",")) {
			productsiteHomepage.clickQuickLinksInFooter(quickLinksInFooter);
			if (count == 6) {
				driver.switchToCurrentWindow();
				verifySafely(driver.getURL(), quickLinksUrls[count], "'" + quickLinksUrls[count] + "' Url is matched");
				driver.closeCurrentWindow();
				driver.switchToParentWindow();
			} else {
				verifySafely(driver.getURL(), quickLinksUrls[count], "'" + quickLinksUrls[count] + "' Url is matched");
				driver.back();
			}
			count++;
		}
	}

	public void verifyFollowUsLinksInFooterClickable() {
		for (String followUsLinksInFooter : FollowUsLinksInFooter.split(",")) {
			productsiteHomepage.clickFollowUsLinksInFooter(followUsLinksInFooter);
			driver.switchToCurrentWindow();
			verifySafely(driver.getURL(), followUsLinksUrls[counter],
					"'" + followUsLinksUrls[counter] + "' Url is matched");
			driver.closeCurrentWindow();
			driver.switchToParentWindow();
			counter++;
		}
	}

}
