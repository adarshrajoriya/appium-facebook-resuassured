package exact.ath.sitecore.career;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CareerWebsite;
import exact.ath.sitecore.CorporateWebsite;
import exact.sys.Driver;

/**
 * This class verifies Career Website Footer verifications
 * 
 * @userstory #301264 Task#303951
 * @author qas_tgupta
 * @since 05/09/2023
 */

public class CareerFooterTest extends BasicIntTest {

	private final CareerWebsite careerWebsite = new CareerWebsite();
	private final Driver driver = new Driver();
	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CareerWebsiteTitleValue");
	private final String loginUrl = exactPagesProperties.getProperty("CareerWebURL");
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final String contactUsHeadingTitle = exactPagesProperties.getProperty("ContactUsHeadingTitle");
	private final String aboutHeadingTitle = exactPagesProperties.getProperty("AboutHeadingTitle");
	private final String termsOfUseHeadingTitle = exactPagesProperties.getProperty("TermsOfUseHeadingTitle");
	private final String purchasingTermsLinkURL = exactPagesProperties.getProperty("PurchasingTermsLinkURL");
	private final String patentsTrademarksHeadingTitle = exactPagesProperties
			.getProperty("PatentsTrademarksHeadingTitle");
	private final String privacyPolicyHeadingTitle = exactPagesProperties.getProperty("PrivacyPolicyHeadingTitle");
	private final String hippaNoticeHeadingTitle = exactPagesProperties.getProperty("HippaNoticeHeadingTitle");
	private final String hippaNoticeLinkURL = exactPagesProperties.getProperty("HippaNoticeLinkURL");
	private final String doNotSellMyInfoHeadingTitle = exactPagesProperties.getProperty("DoNotSellMyInfoHeadingTitle");
	private final String cologaurdLinkURL = exactPagesProperties.getProperty("CologaurdLinkURL");
	private final String facebookSiteURL = exactPagesProperties.getProperty("FacebookWebSiteURL");
	private final String twitterSiteURL = exactPagesProperties.getProperty("TwitterWebSiteURL");
	private final String linkedinSiteURL = exactPagesProperties.getProperty("LinkedinWebSiteURL");

	@Test
	public void careerFooterTest() {
		logBlockHeader();
		setupURL(loginUrl);
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		logInfo("----------------Starting verification of Footer of Career Website------------");
		verifySafely(careerWebsite.getCareerWebsiteHeading(), corporateWebsiteTitleValue, "Home Page Heading");
		logInfo("----------------Starting verification of Footer Elements of Career Website------------");
		verifySafely(careerWebsite.isExactSciencesFooterLogoDisplayed(), true, "'Exact Sciences Logo' is Displayed");
		verifySafely(careerWebsite.isAddressDetailsDisplayed(), true, "'Address Details' is Displayed");
		verifySafely(careerWebsite.isContactUsHyperLinkDisplayed(), true, "'Contact Us HyperLink' is Displayed");
		verifySafely(careerWebsite.isQuickLinksDisplayed(), true, "'QUICK LINKS' is Displayed");
		verifySafely(careerWebsite.isAboutDisplayed(), true, "'About Link' is Displayed");
		verifySafely(careerWebsite.isTermsOfUseDisplayed(), true, "'Terms Of Use Link' is Displayed");
		verifySafely(careerWebsite.isPurchasingTermsDisplayed(), true, "'Purchasing Terms Link' is Displayed");
		verifySafely(careerWebsite.isPatentsTrademarksDisplayed(), true, "'Patents & Trademarks Link' is Displayed");
		verifySafely(careerWebsite.isPrivacyPolicyDisplayed(), true, "'Privacy Policy Link' is Displayed");
		verifySafely(careerWebsite.isHippaNoticeDisplayed(), true, "'HIPAA Notice Link' is Displayed");
		verifySafely(careerWebsite.isDoNotSellMyInfoDisplayed(), true, "'Do Not Sell My Info Link' is Displayed");
		verifySafely(careerWebsite.isCologuardDisplayed(), true, "'Cologuard.com HyperLink' is Displayed");
		verifySafely(careerWebsite.isFollowUsOnDisplayed(), true, "'FOLLOW US ON Link' is Displayed");

		verifySafely(corporateWebsite.isFacebookHyperlinkDisplayed(), true, "FACEBOOK Hyperlink is Displayed");
		verifySafely(corporateWebsite.isTwitterHyperlinkDisplayed(), true, "TWITTER Hyperlink is Displayed");
		verifySafely(corporateWebsite.isLinkedinHyperlinkDisplayed(), true, "LINKEDIN Hyperlink is Displayed");
		logInfo("----------------Verification Done for Footer Elements of Career Website------------");
		careerWebsite.clickContactUsHyperLink();
		logInfo("Clicked on 'Contact -Us' hyperlink");
		verifySafely(careerWebsite.getContactUsHeading(), contactUsHeadingTitle,
				"'CONTACT US' Title is displayed after clicking Contact Us HyperLink");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickAboutLink();
		logInfo("Clicked on 'About' link from QUICK LINKS");
		verifySafely(careerWebsite.getAboutHeading(), aboutHeadingTitle,
				"'ABOUT US' Title is displayed after clicking About Link");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickTermsOfUseLink();
		logInfo("Clicked on 'Terms of Use' link from QUICK LINKS");
		verifySafely(careerWebsite.getTermsOfUseHeading(), termsOfUseHeadingTitle,
				"'TERMS & CONDITIONS OF USE' Title is displayed after clicking Terms Of Use Link");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickPurchasingTermsLink();
		logInfo("Clicked on 'Purchasing Terms' link from QUICK LINKS");
		verifySafely(driver.getURL(), purchasingTermsLinkURL, "Opened 'Purchasing Terms Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickPatentsTrademarksLink();
		logInfo("Clicked on 'Patents & Trademarks' link from QUICK LINKS");
		verifySafely(careerWebsite.getPatentsTrademarksHeading(), patentsTrademarksHeadingTitle,
				"'PATENTS & TRADEMARKS' Title is displayed after clicking Terms Of Use Link");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickPrivacyPolicyLink();
		logInfo("Clicked on 'Privacy Policy' link from QUICK LINKS");
		verifySafely(careerWebsite.getPrivacyPolicyHeading(), privacyPolicyHeadingTitle,
				"'EXACT SCIENCES CORPORATION PRIVACY POLICY' Title is displayed after clicking Privacy Policy Link");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickHippaNoticeLink();
		logInfo("Clicked on 'HIPAA Notice' link from QUICK LINKS");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		verifySafely(careerWebsite.getHippaNoticeHeading(), hippaNoticeHeadingTitle,
				"'Notice of Privacy Practices' Title is displayed after clicking Hippa Notice Link");
		verifySafely(driver.getURL(), hippaNoticeLinkURL, "Opened 'Hippa Notice Link' and Page URL matches");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickDoNotSellMyInfoLink();
		logInfo("Clicked on 'Do Not Sell My Info' link from QUICK LINKS");
		verifySafely(careerWebsite.getDoNotSellMyInfoHeading(), doNotSellMyInfoHeadingTitle,
				"'DO NOT SELL MY PERSONAL INFORMATION' Title is displayed after clicking Do Not Sell MyInfo Link");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		careerWebsite.clickCologuardLink();
		logInfo("Clicked on 'Cologuard.com' link from QUICK LINKS");
		verifySafely(driver.getURL().contains(cologaurdLinkURL), true,
				"'Cologuard.com' link navigated to URL contains VALUE: '" + cologaurdLinkURL + "'");
		driver.back();
		logInfo("Navigated back to  home page with back browser button");
		corporateWebsite.clickFacebookHyperHyperlink();
		logInfo("Clicked on  'Facebook' icon under FOLLOW US ON");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(facebookSiteURL), true,
				"Navigated to Facebook URL VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickTwitterHyperHyperlink();
		logInfo("Clicked on 'Twitter' icon under FOLLOW US ON");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(twitterSiteURL), true,
				"Navigated to Twitter URL VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		corporateWebsite.clickLinkedinHyperHyperlink();
		logInfo("Clicked on 'Linkedin' icon under FOLLOW US ON");
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL().contains(linkedinSiteURL), true,
				"Navigated to LinkedIN URL VALUE: '" + driver.getURL() + "'");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		logInfo("----------------Verification Done for Footer of Career Website------------");
		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}

}
