package exact.ath.sitecore.corporate;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.sitecore.AnnualReportsPage;
import exact.ath.sitecore.CorporateWebsite;
import exact.sys.Driver;

public class CorporateAboutPageTest extends BasicIntTest {

	private final Driver driver = new Driver();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();
	private final AnnualReportsPage annualReportsPage = new AnnualReportsPage();

	private final String corporateWebsiteTitleValue = exactPagesProperties.getProperty("CorporateWebsiteTitleValue");
	private final String executivesLeaders = exactPagesProperties.getProperty("ExecutivesLeaders");
	private final String medicalLeaders = exactPagesProperties.getProperty("MedicalLeaders");
	private final String boardOfDirectors = exactPagesProperties.getProperty("BoardOfDirectors");
	private final String corporateImpactandCommunityRelationsURL = exactPagesProperties
			.getProperty("CorporateImpactandCommunityRelationsURL");
	private final String laboratoriesContactUsURL = exactPagesProperties.getProperty("LaboratoriesContactUsURL");
	private final String humanResourcesContactUsURL = exactPagesProperties.getProperty("HumanResourcesContactUsURL");
	private final String investorContactUsURL = exactPagesProperties.getProperty("InvestorContactUsURL");
	private final String generalContactUsURL = exactPagesProperties.getProperty("GeneralContactUsURL");
	private final String mediaContactUsURL = exactPagesProperties.getProperty("MediaContactUsURL");
	private final String medicalContactUsURL = exactPagesProperties.getProperty("MedicalContactUsURL");
	private final String contactUsLocations = exactPagesProperties.getProperty("ContactUsLocations");
	private int executivesLeadersCount = 0;
	private final String loginUrl = exactPagesProperties.getProperty("CorporateWebURL");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void corporateAboutPageTest() {

		// About Page
		closeTheBrowser();
		setupURL(loginUrl);
		logBlockHeader();
		logInfo("Page URL : " + driver.getURL() + "");
		if (annualReportsPage.acceptCookiesDisplayed()) {
			annualReportsPage.acceptCookies();
		}
		corporateWebsite.clickAboutMenuOption();
		verifySafely(corporateWebsite.isAboutUsPageDisplayed(), true, "'ABOUT US' Page is displayed");
		verifySafely(corporateWebsite.isAboutHeaderOptionHighlightDisplayed(), true,
				"'About' header is highlighted on the page");
		corporateWebsite.clickExactSciencesLogo();
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");
		corporateWebsite.hoverAboutMenuOption();
		corporateWebsite.clickLeadershipOption();
		verifySafely(corporateWebsite.isLeadershipPageDisplayed(), true, "'LEADERSHIP TEAM' Page is displayed");
		corporateWebsite.hoverAboutMenuOption();
		verifySafely(corporateWebsite.isLeadershipOptionHighlightDisplayed(), true,
				"'Leadership' is highlighted under the 'About' header on the page");

		logBlockHeader();
		logInfo("Executives Leaders Verification");
		for (String executiveLeader : executivesLeaders.split(",")) {
			executivesLeadersCount++;
			corporateWebsite.clickViewProfileLink(executivesLeadersCount);
			verifySafely(corporateWebsite.getexecutivesLeadersTittle(), executiveLeader,
					"Navigated to Leader profile Page - Title");
			corporateWebsite.hoverAboutMenuOption();
			corporateWebsite.clickLeadershipOption();

		}

		logBlockHeader();
		logInfo("Medical Leaders Verification");
		for (String medicalLeader : medicalLeaders.split(",")) {
			executivesLeadersCount++;
			corporateWebsite.clickMedicalLeadersOption();
			corporateWebsite.clickViewProfileLink(executivesLeadersCount);
			verifySafely(corporateWebsite.getexecutivesLeadersTittle(), medicalLeader,
					"Navigated to Leader profile Page - Title");
			corporateWebsite.hoverAboutMenuOption();
			corporateWebsite.clickLeadershipOption();

		}
		logBlockHeader();

		corporateWebsite.hoverAboutMenuOption();
		corporateWebsite.clickBoardOfDirectorsOption();
		verifySafely(corporateWebsite.isBoardOfDirectorsPageDisplayed(), true,
				"'BOARD OF DIRECTORS' Page is displayed");
		corporateWebsite.hoverAboutMenuOption();
		verifySafely(corporateWebsite.isBoardOfDirectorsOptionHighlighted(), true,
				"'Board of Directors' is highlighted under the 'About' header on the page");

		logBlockHeader();
		logInfo("Board of Directors Verification");
		executivesLeadersCount = 0;
		for (String boardOfDirector : boardOfDirectors.split(",")) {
			executivesLeadersCount++;
			corporateWebsite.clickViewProfileLink(executivesLeadersCount);
			verifySafely(corporateWebsite.getexecutivesLeadersTittle().contains(boardOfDirector), true,
					"Navigated to Board of Director profile Page - Tittle VALUE: '"
							+ corporateWebsite.getexecutivesLeadersTittle() + "'");
			corporateWebsite.hoverAboutMenuOption();
			corporateWebsite.clickBoardOfDirectorsOption();

		}
		logBlockHeader();

		corporateWebsite.hoverAboutMenuOption();
		corporateWebsite.clickCompanyHistoryOption();
		verifySafely(corporateWebsite.isCompanyHistoryPageDisplayed(), true, "'COMPANY HISTORY' Page is displayed");
		corporateWebsite.hoverAboutMenuOption();
		verifySafely(corporateWebsite.isCompanyHistoryHighlighted(), true,
				"'Company History' is highlighted under the 'About' header on the page");

		corporateWebsite.hoverAboutMenuOption();
		corporateWebsite.clickCorporateImpactandCommunityRelationsOption();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), corporateImpactandCommunityRelationsURL,
				"Opened 'Corporate Impact and Community Relations' and Page URL matches");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();
		driver.refresh();
		corporateWebsite.hoverAboutMenuOption();
		corporateWebsite.clickOurCollaborationsOption();
		verifySafely(corporateWebsite.isOurCollaborationsPageDisplayed(), true,
				"'OUR COLLABORATIONS' Page is displayed");
		corporateWebsite.hoverAboutMenuOption();
		verifySafely(corporateWebsite.isOurCollaborationsHighlighted(), true,
				"'Our Collaborations' is highlighted under the 'About' header on the page");

		corporateWebsite.hoverAboutMenuOption();
		corporateWebsite.clickContactUsOption();
		verifySafely(corporateWebsite.isContactUsPageDisplayed(), true, "'CONTACT US' Page is displayed");
		corporateWebsite.hoverAboutMenuOption();
		verifySafely(corporateWebsite.isContactUsHighlighted(), true,
				"'Contact Us' is highlighted under the 'About' header on the page");

		corporateWebsite.clickLaboratoriesContactUsLink();
		verifySafely(driver.getURL(), laboratoriesContactUsURL,
				"Opened 'Contact us about Cologuard' Page and URL matches");
		driver.back();

		corporateWebsite.clickHumanResourcesContactUsLink();
		verifySafely(driver.getURL(), humanResourcesContactUsURL, "Opened 'CONTACT HR' Page and URL matches");
		driver.back();

		corporateWebsite.clickInvestorContactUsLink();
		verifySafely(driver.getURL(), investorContactUsURL, "Opened 'CONTACT INVESTOR RELATIONS' Page and URL matches");
		driver.back();

		corporateWebsite.clickGeneralContactUsLink();
		verifySafely(driver.getURL(), generalContactUsURL,
				"Opened 'CONTACT US: GENERAL INQUIRIES' Page and URL matches");
		driver.back();

		corporateWebsite.clickMediaContactUsLink();
		verifySafely(driver.getURL(), mediaContactUsURL, "Opened 'CONTACT US: MEDIA RELATIONS' Page and URL matches");
		driver.back();

		corporateWebsite.clickMedicalContactUsLink();
		verifySafely(driver.getURL(), medicalContactUsURL, "Opened 'Contact us' Page and URL matches");
		driver.back();

		logBlockHeader();
		logInfo("Contact Us Location card Verification");
		executivesLeadersCount = 0;
		for (String contactUsLocation : contactUsLocations.split(",")) {
			executivesLeadersCount++;
			corporateWebsite.clickMoreInfoLink(executivesLeadersCount);
			verifySafely(corporateWebsite.getMoreInfoTittle(), contactUsLocation, "Navigated to Location Page - Title");
			driver.back();

		}

		corporateWebsite.clickExactSciencesLogo();
		verifySafely(corporateWebsite.getCorporateWebsiteHeading(), corporateWebsiteTitleValue,
				"Navigated to Home Page - Title");
		logBlockHeader();
//		closeTheBrowser();
		throwAssertionErrorOnFailure();

	}
}
