package exact.ath.sitecore.corporateUk;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;

public class CorporateUkWebsiteTest extends BasicIntTest {

	private final CorporateUkHomePageVerificationsTest corporateUkHomePageVerificationsTest = new CorporateUkHomePageVerificationsTest();
	private final CorporateUkAboutUsPageTest corporateUkAboutUsPageTest = new CorporateUkAboutUsPageTest();
	private final CorporateUkOurProductPageTest corporateUkOurProductPageTest = new CorporateUkOurProductPageTest();
	private final CorporateUkPressRoomPageTest corporateUkPressRoomPageTest = new CorporateUkPressRoomPageTest();
	private final CorporateUkFooterTest corporateUkFooterTest = new CorporateUkFooterTest();

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) throws Exception {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void CorporateUkHomePageVerificationsTest() throws Exception {

		corporateUkHomePageVerificationsTest.verifyCorporateUkHomeLinksTest();

	}

	@Test
	public void CorporateUkAboutUsPageTest() throws Exception {

		corporateUkAboutUsPageTest.verifyCorporateUkAboutUsPageTest();
	}

	@Test
	public void CorporateUkOurProductPageTest() throws Exception {

		corporateUkOurProductPageTest.verifyCorporateUkOurProductPageTest();
	}

	@Test
	public void CorporateUkPressRoomPageTest() throws Exception {

		corporateUkPressRoomPageTest.verifyCorporateUkPressRoomPageTest();
	}

	@Test
	public void CorporateUkFooterTest() throws Exception {

		corporateUkFooterTest.verifyCorporateUkFooterTest();
	}

}
