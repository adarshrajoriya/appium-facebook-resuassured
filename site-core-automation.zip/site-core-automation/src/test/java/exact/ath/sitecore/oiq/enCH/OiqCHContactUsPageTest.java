package exact.ath.sitecore.oiq.enCH;

import static exact.ReportLogMain.logBlockHeader;
import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.oiq.oiqCH.OiqCHContactUsPage;
import exact.ath.oiq.oiqCH.OiqCHHomePage;
import exact.ath.sitecore.CorporateWebsite;

/**
 * This class verifies OIQ Switzerland web site Contact Us page
 * 
 * @userstory #304475 Task#307103
 * @author Pushkar Singh
 * @since 07/10/2023
 */
public class OiqCHContactUsPageTest extends BasicIntTest {

	private final OiqCHHomePage oiqCHHomePage = new OiqCHHomePage();
	private final OiqCHContactUsPage oiqCHContactUsPage = new OiqCHContactUsPage();
	private final CorporateWebsite corporateWebsite = new CorporateWebsite();

	private final String firstName = exactPagesProperties.getProperty("FirstNameValue");
	private final String lastName = exactPagesProperties.getProperty("LastNameValue");
	private final String phone = oiqenCHPagesProperties.getProperty("phoneValue");
	private final String email = exactPagesProperties.getProperty("EmailValue");

	private final String loginUrl = oiqenCHPagesProperties.getProperty("oiqCHsiteURL");
	private final String oiqenCHPageTitle = oiqenCHPagesProperties.getProperty("oiqenCHPageTitle");
	private final String contactUsTitle = oiqenCHPagesProperties.getProperty("contactUsTitle");
	private final String popupbutton1Text = oiqenCHPagesProperties.getProperty("popupbutton1Text");
	private final String submitFormMessage = oiqenCHPagesProperties.getProperty("submitFormMessage");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());

	}

	@Test
	public void verifyOiqCHContactUsPageTest() {

		closeTheBrowser();
		logBlockHeader();
		setupURL(loginUrl);

		acceptCookies();

		logInfo("Opened OIQ Switzerland Homepage URL '" + loginUrl + "'");

		oiqCHHomePage.clickpopupbutton1();
		logInfo("Clicked on " + popupbutton1Text + "");

		verifySafely(oiqCHHomePage.getOiqPageTitle(), oiqenCHPageTitle, "Page Heading displayed");

		oiqCHHomePage.clickHeaderOption4();
		logInfo("Clicked on 'CONTACT US' item from the header section");

		verifySafely(oiqCHHomePage.getPageTitle(), contactUsTitle, "Page Heading displayed");
		verifySafely(oiqCHContactUsPage.isCountryCHSelected(), true,
				"Country 'Switzerland' is selected by default from dropdown");
		verifySafely(oiqCHContactUsPage.getcountryCHContact().contains("Switzerland"), true,
				"Contact details is be displayed on the right pane for the selected Country 'Switzerland'");
		logInfo("Contact details: " + oiqCHContactUsPage.getcountryCHContact() + "");

		oiqCHContactUsPage.clickSubmitBtnBy();
		logInfo("Clicked on 'SUBMIT' button");
		verifySafely(oiqCHContactUsPage.isErrorMessageDisplayed(), true,
				"An error message is displayed on the mandatory fields");

		corporateWebsite.enterFirstName(firstName);
		logInfo("Entered First Name '" + firstName + "'");
		corporateWebsite.enterLastName(lastName);
		logInfo("Entered Last Name '" + lastName + "'");
		corporateWebsite.enterEmail(email);
		logInfo("Entered Email '" + email + "'");
		oiqCHContactUsPage.enterPhone(phone);
		logInfo("Entered Phone '" + phone + "'");

		oiqCHContactUsPage.clickSubmitBtnBy();
		logInfo("Clicked on 'SUBMIT' button");
		verifySafely(oiqCHContactUsPage.getsubmitFormMessage(), submitFormMessage, "Message displayed");

		closeTheBrowser();
		throwAssertionErrorOnFailure();
	}

}
