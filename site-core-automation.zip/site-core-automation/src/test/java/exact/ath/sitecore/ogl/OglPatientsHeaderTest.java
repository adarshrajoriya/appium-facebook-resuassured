package exact.ath.sitecore.ogl;

import static exact.ReportLogMain.logInfo;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import exact.BasicIntTest;
import exact.ath.ogl.OglAboutUsPage;
import exact.ath.ogl.OglHomepage;
import exact.ath.ogl.OglRiskFactorsPage;

/**
 * This class verifies the Patients header components of OGL website
 * 
 * @userstory #304475 Task#305965
 * @author Tushar Gupta
 * @since 06/29/2023
 */

public class OglPatientsHeaderTest extends BasicIntTest {

	private final OglHomepage oglHomepage = new OglHomepage();

	private final OglRiskFactorsPage oglRiskFactorsPage = new OglRiskFactorsPage();

	private final OglAboutUsPage oglAboutUsPage = new OglAboutUsPage();
	private final String oglHomePageURL = oglPagesProperties.getProperty("oglHomePageURL");
	private final String pageHeadingDisplayedOglHomePageTitle = oglPagesProperties
			.getProperty("pageHeadingDisplayedOglHomePageTitle");
	private final String patients = oglPagesProperties.getProperty("patients");
	private final String liverDisease = oglPagesProperties.getProperty("liverDisease");
	private final String riskFactors = oglPagesProperties.getProperty("riskFactors");
	private final String detectionAndMonitoring = oglPagesProperties.getProperty("detectionAndMonitoring");
	private final String theOncoguardLiverSolution = oglPagesProperties.getProperty("theOncoguardLiverSolution");
	private final String theOncoguardLiverTest = oglPagesProperties.getProperty("theOncoguardLiverTest");
	private final String support = oglPagesProperties.getProperty("support");
	private final String advocacy = oglPagesProperties.getProperty("advocacy");
	private final String faqs = oglPagesProperties.getProperty("faqs");
	private final String aboutUs = oglPagesProperties.getProperty("aboutUs");
	private final String liverDiseaseURL = oglPagesProperties.getProperty("liverDiseaseURL");
	private final String betterWayTopRiskExactlyTitle = oglPagesProperties.getProperty("betterWayTopRiskExactlyTitle");
	private final String riskFactorsURL = oglPagesProperties.getProperty("riskFactorsURL");
	private final String knowingIfAtRiskTitle = oglPagesProperties.getProperty("knowingIfAtRiskTitle");
	private final String surveillanceLinkURL = oglPagesProperties.getProperty("surveillanceLinkURL");
	private final String americanLiverFoundationLinkURL = oglPagesProperties
			.getProperty("americanLiverFoundationLinkURL");

	private final String oncoguardLiverSolutionURL = oglPagesProperties.getProperty("oncoguardLiverSolutionURL");
	private final String menuNames = oglPagesProperties.getProperty("menuNames");
	private final String menuURLs = oglPagesProperties.getProperty("menuURLs");
	private final String menuHeadings = oglPagesProperties.getProperty("menuHeadings");

	@BeforeMethod
	public void setup(Method method) {
		logInfo("START TEST: " + method.getName());
	}

	@AfterMethod
	public void cleanup(ITestResult result) {
		logInfo("END TEST: " + result.getMethod().getMethodName());
	}

	@Test
	public void verifyOglPatientsHeaderTest() throws Exception {

		setupURL(oglHomePageURL);
		logInfo("Page URL : " + driver.getURL() + "");
		acceptCookiesOgl();
		logInfo("----------------Starting verification of Patient Header Components of OGL Website------------");
		verifySafely(oglHomepage.isOglHomepageDisplayed(), true, "Ogl homepage is displayed");

		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), pageHeadingDisplayedOglHomePageTitle,
				"'A solution for early HCC detection? Exactly.' Title is displayed on Home Page Of OGL website");
		oglHomepage.hoverTopNavOption(patients);
		verifySafely(oglHomepage.isSubItemDisplayed(liverDisease), true,
				"Sub item '" + liverDisease + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(riskFactors), true,
				"Sub item '" + riskFactors + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(detectionAndMonitoring), true,
				"Sub item '" + detectionAndMonitoring + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(theOncoguardLiverSolution), true,
				"Sub item '" + theOncoguardLiverSolution + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(theOncoguardLiverTest), true,
				"Sub item '" + theOncoguardLiverTest + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(support), true,
				"Sub item '" + support + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(advocacy), true,
				"Sub item '" + advocacy + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(faqs), true,
				"Sub item '" + faqs + "' is displayed under '" + patients + "' header");
		verifySafely(oglHomepage.isSubItemDisplayed(aboutUs), true,
				"Sub item '" + aboutUs + "' is displayed under '" + patients + "' header");

		driver.refresh();
		oglHomepage.hoverTopNavOption(patients);
		oglHomepage.clickSubItemOption(liverDisease);

		verifySafely(driver.getURL(), liverDiseaseURL, "'Liver Disease' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), betterWayTopRiskExactlyTitle,
				"'A better way to stay on top of risk? Exactly.' Title is displayed on Page");

		oglHomepage.hoverTopNavOption(patients);
		oglHomepage.clickTopNavOption(riskFactors);
		verifySafely(driver.getURL(), riskFactorsURL, "'Risk Factors' Page is displayed");
		verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), knowingIfAtRiskTitle,
				"'Knowing if you’re at risk' Title is displayed on Page");

		oglRiskFactorsPage.clickOnSurveillanceLink();
		verifySafely(driver.getURL(), surveillanceLinkURL, "'Detection And Monitoring' Page is displayed");
		driver.back();

		oglRiskFactorsPage.clickOnAmericanLiverFoundationLink();
		driver.switchToCurrentWindow();
		verifySafely(driver.getURL(), americanLiverFoundationLinkURL,
				"'American Liver Foundation Link' page is displayed");
		driver.closeCurrentWindow();
		driver.switchToParentWindow();

		verificationsOfSubMenuLinksOfPatientHeader();
		oglAboutUsPage.clickOnOncoguardLiverSolutionLink();
		verifySafely(driver.getURL(), oncoguardLiverSolutionURL, "'The Oncoguard Liver Solution' Page is displayed");
		logInfo("----------------Verification done for Patient Header Components of OGL Website------------");
		closeTheBrowser();

		throwAssertionErrorOnFailure();

	}

	private void verificationsOfSubMenuLinksOfPatientHeader() throws Exception

	{
		String[] menuNamesArr = menuNames.split(",");
		String[] menuURLsArr = menuURLs.split(",");
		String[] menuHeadingsArr = menuHeadings.split(",");

		for (int count = 0; count < menuNamesArr.length; count++) {

			oglHomepage.hoverTopNavOption(patients);
			oglHomepage.clickSubItemOption(menuNamesArr[count]);
			verifySafely(driver.getURL(), menuURLsArr[count], "'" + menuNamesArr[count] + "' Page is displayed");
			verifySafely(oglHomepage.getPageHeadingDisplayedOglHomePage(), menuHeadingsArr[count],
					"'" + menuHeadingsArr[count] + "' Title is displayed on Page");
		}
	}

}
