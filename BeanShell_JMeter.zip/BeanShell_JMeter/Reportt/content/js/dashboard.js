/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 89.47368421052632, "KoPercent": 10.526315789473685};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6304347826086957, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5, 500, 1500, ""], "isController": true}, {"data": [0.25, 500, 1500, "ChangePassword"], "isController": true}, {"data": [0.5, 500, 1500, "PasswordLink"], "isController": false}, {"data": [0.5, 500, 1500, "BackHome"], "isController": false}, {"data": [0.5, 500, 1500, "-132"], "isController": false}, {"data": [0.0, 500, 1500, "PasswordLink-0"], "isController": false}, {"data": [0.75, 500, 1500, "-154"], "isController": false}, {"data": [0.0, 500, 1500, "PasswordLink-1"], "isController": false}, {"data": [0.5, 500, 1500, "Home and Logout"], "isController": true}, {"data": [1.0, 500, 1500, "-145-1"], "isController": false}, {"data": [1.0, 500, 1500, "-146-0"], "isController": false}, {"data": [0.75, 500, 1500, "-137"], "isController": false}, {"data": [1.0, 500, 1500, "-145-0"], "isController": false}, {"data": [1.0, 500, 1500, "-139"], "isController": false}, {"data": [1.0, 500, 1500, "-146-1"], "isController": false}, {"data": [0.0, 500, 1500, "Login"], "isController": true}, {"data": [0.25, 500, 1500, "-145"], "isController": false}, {"data": [0.5, 500, 1500, "-125"], "isController": false}, {"data": [1.0, 500, 1500, "-132-0"], "isController": false}, {"data": [1.0, 500, 1500, "-154-1"], "isController": false}, {"data": [0.5, 500, 1500, "-132-1"], "isController": false}, {"data": [0.75, 500, 1500, "-146"], "isController": false}, {"data": [1.0, 500, 1500, "-154-0"], "isController": false}, {"data": [1.0, 500, 1500, "-137-1"], "isController": false}, {"data": [1.0, 500, 1500, "-127"], "isController": false}, {"data": [1.0, 500, 1500, "-126"], "isController": false}, {"data": [0.0, 500, 1500, "-128"], "isController": false}, {"data": [1.0, 500, 1500, "-137-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 38, 4, 10.526315789473685, 592.3684210526318, 256, 2046, 363.5, 1549.5000000000002, 1808.4999999999993, 2046.0, 4.476381199198964, 14.194495265932382, 3.565390689421604], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["", 2, 0, 0.0, 1208.5, 1116, 1301, 1208.5, 1301.0, 1301.0, 1301.0, 1.2453300124533002, 8.436989220112078, 2.1817598069738477], "isController": true}, {"data": ["ChangePassword", 2, 1, 50.0, 1183.0, 1023, 1343, 1183.0, 1343.0, 1343.0, 1343.0, 1.215066828675577, 10.606916388213852, 3.1509862925273393], "isController": true}, {"data": ["PasswordLink", 2, 1, 50.0, 1013.0, 400, 1626, 1013.0, 1626.0, 1626.0, 1626.0, 1.2300123001230012, 6.287597055658057, 1.1459294280442804], "isController": false}, {"data": ["BackHome", 2, 0, 0.0, 628.5, 620, 637, 628.5, 637.0, 637.0, 637.0, 1.607717041800643, 8.28900597869775, 0.7175065313504824], "isController": false}, {"data": ["-132", 2, 0, 0.0, 929.0, 317, 1541, 929.0, 1541.0, 1541.0, 1541.0, 1.2978585334198571, 5.512730167099287, 1.7395613643737833], "isController": false}, {"data": ["PasswordLink-0", 1, 1, 100.0, 291.0, 291, 291, 291.0, 291.0, 291.0, 291.0, 3.4364261168384878, 1.869227878006873, 2.1343427835051547], "isController": false}, {"data": ["-154", 2, 0, 0.0, 450.5, 306, 595, 450.5, 595.0, 595.0, 595.0, 2.190580503833516, 11.034193592552025, 1.9402895673603504], "isController": false}, {"data": ["PasswordLink-1", 1, 1, 100.0, 1334.0, 1334, 1334, 1334.0, 1334.0, 1334.0, 1334.0, 0.7496251874062968, 3.0255868159670163, 0.46558751874062965], "isController": false}, {"data": ["Home and Logout", 2, 0, 0.0, 1079.0, 926, 1232, 1079.0, 1232.0, 1232.0, 1232.0, 1.2903225806451613, 13.152091733870968, 1.71875], "isController": true}, {"data": ["-145-1", 2, 0, 0.0, 360.5, 308, 413, 360.5, 413.0, 413.0, 413.0, 2.7739251040221915, 11.018496445908461, 1.8393507281553398], "isController": false}, {"data": ["-146-0", 1, 0, 0.0, 301.0, 301, 301, 301.0, 301.0, 301.0, 301.0, 3.3222591362126246, 1.8071272840531563, 2.073167566445183], "isController": false}, {"data": ["-137", 2, 0, 0.0, 453.5, 295, 612, 453.5, 612.0, 612.0, 612.0, 3.257328990228013, 13.870686583876221, 3.047383957654723], "isController": false}, {"data": ["-145-0", 2, 0, 0.0, 304.5, 302, 307, 304.5, 307.0, 307.0, 307.0, 3.278688524590164, 1.7866290983606559, 3.2594774590163933], "isController": false}, {"data": ["-139", 2, 0, 0.0, 308.0, 300, 316, 308.0, 316.0, 316.0, 316.0, 3.2310177705977385, 0.6752322294022617, 2.268654079159935], "isController": false}, {"data": ["-146-1", 1, 0, 0.0, 321.0, 321, 321, 321.0, 321.0, 321.0, 321.0, 3.115264797507788, 12.570580218068535, 1.9439982476635513], "isController": false}, {"data": ["Login", 2, 1, 50.0, 4624.5, 4598, 4651, 4624.5, 4651.0, 4651.0, 4651.0, 0.40807998367680065, 7.654090045398899, 1.8357621531320139], "isController": true}, {"data": ["-145", 2, 1, 50.0, 666.0, 611, 721, 666.0, 721.0, 721.0, 721.0, 1.953125, 8.822441101074219, 3.2367706298828125], "isController": false}, {"data": ["-125", 2, 0, 0.0, 580.5, 558, 603, 580.5, 603.0, 603.0, 603.0, 2.0060180541624875, 12.752123558174524, 0.7483387662988967], "isController": false}, {"data": ["-132-0", 1, 0, 0.0, 301.0, 301, 301, 301.0, 301.0, 301.0, 301.0, 3.3222591362126246, 1.8136160714285714, 3.390391403654485], "isController": false}, {"data": ["-154-1", 1, 0, 0.0, 317.0, 317, 317, 317.0, 317.0, 317.0, 317.0, 3.1545741324921135, 12.153120070977918, 1.8668671135646688], "isController": false}, {"data": ["-132-1", 1, 0, 0.0, 1237.0, 1237, 1237, 1237.0, 1237.0, 1237.0, 1237.0, 0.8084074373484236, 3.1096844684721097, 0.5344646827000809], "isController": false}, {"data": ["-146", 2, 0, 0.0, 517.0, 412, 622, 517.0, 622.0, 622.0, 622.0, 1.932367149758454, 8.13990791062802, 1.808763586956522], "isController": false}, {"data": ["-154-0", 1, 0, 0.0, 277.0, 277, 277, 277.0, 277.0, 277.0, 277.0, 3.6101083032490977, 2.065940884476534, 2.1293998194945845], "isController": false}, {"data": ["-137-1", 1, 0, 0.0, 342.0, 342, 342, 342.0, 342.0, 342.0, 342.0, 2.923976608187134, 11.798702485380115, 1.8217744883040934], "isController": false}, {"data": ["-127", 2, 0, 0.0, 343.5, 302, 385, 343.5, 385.0, 385.0, 385.0, 2.890173410404624, 0.6040010838150289, 1.9926390895953758], "isController": false}, {"data": ["-126", 2, 0, 0.0, 284.5, 256, 313, 284.5, 313.0, 313.0, 313.0, 3.552397868561279, 0.7423956483126111, 2.4492118117229134], "isController": false}, {"data": ["-128", 2, 0, 0.0, 1921.0, 1796, 2046, 1921.0, 2046.0, 2046.0, 2046.0, 0.9775171065493646, 4.818853861192571, 0.5756277492668622], "isController": false}, {"data": ["-137-0", 1, 0, 0.0, 269.0, 269, 269, 269.0, 269.0, 269.0, 269.0, 3.717472118959108, 2.0221015334572487, 2.3197897304832713], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain /Success: Your password has been successfully updated/", 1, 25.0, 2.6315789473684212], "isController": false}, {"data": ["Test failed: text expected to contain /Edit Account/", 1, 25.0, 2.6315789473684212], "isController": false}, {"data": ["One or more sub-samples failed", 1, 25.0, 2.6315789473684212], "isController": false}, {"data": ["Response was null", 1, 25.0, 2.6315789473684212], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 38, 4, "Test failed: text expected to contain /Success: Your password has been successfully updated/", 1, "Test failed: text expected to contain /Edit Account/", 1, "One or more sub-samples failed", 1, "Response was null", 1, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["PasswordLink", 2, 1, "One or more sub-samples failed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["PasswordLink-0", 1, 1, "Response was null", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["PasswordLink-1", 1, 1, "Test failed: text expected to contain /Edit Account/", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["-145", 2, 1, "Test failed: text expected to contain /Success: Your password has been successfully updated/", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
